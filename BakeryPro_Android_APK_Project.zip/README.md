# BakeryPro Android APK Project

This project wraps BakeryPro V4 in a native Android WebView.

## No Android Studio is required
The included GitHub Actions workflow builds the APK in the cloud.

## Cloud build steps
1. Create a new GitHub repository for BakeryPro.
2. Upload all files from this project ZIP to the repository.
3. Open the repository's **Actions** tab.
4. Open **Build BakeryPro APK**.
5. Choose **Run workflow**.
6. When the build completes, download the **BakeryPro-APK** artifact.
7. Extract it to get `app-debug.apk`.
8. Transfer the APK to your Android phone and install it.

Android may ask you to allow installation from the browser/files app.

## App package
`com.bakerypro.app`

## Minimum Android
Android 7.0 (API 24)

## Notes
- BakeryPro data remains stored locally in the Android WebView until the cloud backend is connected.
- MTN/Airtel payments are still simulated until merchant APIs are connected.
- For Google Play distribution later, use a release signing key and build an Android App Bundle (AAB).
