# DS Bakery Master v0.35 — Deployment Preparation

Release:
- App version: 0.35.0
- Database migration: 034
- Stage: deployment_preparation
- Database: DS Bakery Supabase staging
- Intended staging host: Railway

This release prepares the application for a real hosted staging deployment without altering the existing Railway production service.

See:
- `docs/V035_DEPLOYMENT_PREPARATION.md`
- `docs/RAILWAY_STAGING_DEPLOYMENT.md`
- `.env.railway.staging.example`
- `railway.json`
