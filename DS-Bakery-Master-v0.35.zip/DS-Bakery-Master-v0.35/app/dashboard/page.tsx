import Sidebar from "@/components/Sidebar";
import { runtimeMode } from "@/lib/runtime";
import { requirePermission } from "@/lib/access";

export default async function Dashboard(){
  await requirePermission("dashboard:view");
  const mode=runtimeMode();
  return <div className="shell"><Sidebar/><main className="main">
    <div className="pagehead"><div><h1>Owner Dashboard</h1><p>Staff administration, refunds, permissions and live reports now join the same master system.</p></div><a className="btn primary" href="/system-status">System Status</a></div>
    <div className="hero"><h2>DS Bakery Master v0.29 — Supabase Staging Connection Handoff</h2><p>The customer-facing DS Bakery website now reads the same safe live product catalog as the staff system, while keeping recipes, stock, costs and internal records private.</p></div>
    <div className="grid4">
      <div className="card stat"><div className="label">Runtime</div><div className="value" style={{fontSize:22}}>{mode==="live"?"LIVE":"DEMO"}</div></div>
      <div className="card stat"><div className="label">Latest Migration</div><div className="value">028</div></div>
      <div className="card stat"><div className="label">Core Business Flows</div><div className="value" style={{fontSize:20}}>Integrated</div></div>
      <div className="card stat"><div className="label">Launch Status</div><div className="value" style={{fontSize:20}}>Needs Validation</div></div>
    </div>
    <div className="grid2" style={{marginTop:16}}>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Supabase staging handoff in v0.29</h3><p>Live staff invitations and role/status control</p><p>Attendance and staff schedules</p><p>Individual permission enforcement</p><p>Customer-order refunds by original method</p><p>Live audit history and management reports</p></div>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Still Required Before Launch</h3><p>Run migrations on a real non-production Supabase project</p><p>Full Next.js production build</p><p>Role/RLS test accounts</p><p>Backup + restore test</p><p>End-to-end bakery workday test</p></div>
    </div>
  </main></div>;
}
