import Sidebar from "@/components/Sidebar";
import { getSystemHealth } from "@/lib/integration/health";
import { requireStaff } from "@/lib/auth";

export const dynamic = "force-dynamic";

const modules = [
  ["Products / Recipes / Costing","Ready"],
  ["Stock / Purchasing","Ready"],
  ["Cashier POS","Ready"],
  ["Expenses / Cash / Daily Closing","Ready"],
  ["Dashboard / Financial Reports","Ready"],
  ["Security / Audit / Backup procedures","Ready"],
  ["Production / Baker Tasks","Ready"],
  ["Waste / Production Control","Ready"],
  ["Suppliers / Payables / Purchase Orders","Ready"],
  ["Customers / Orders / Deposits","Ready"],
  ["Operational Reports","Ready"],
  ["Custom Cakes","Ready"],
  ["Deliveries / Riders","Ready"],
  ["Loyalty / Birthdays","Ready"],
  ["WhatsApp click-to-chat","Ready"],
  ["Attendance / Schedules / Permissions","Ready"],
];

export default async function SystemStatus() {
  await requireStaff(["owner"]);
  const health = await getSystemHealth();

  return <div className="shell"><Sidebar/><main className="main">
    <div className="pagehead">
      <div>
        <h1>Integration & Go-Live Status</h1>
        <p>Preflight view for the single DS Bakery master system.</p>
      </div>
      <span className={health.mode==="live"?"badge green":"badge gold"}>
        {health.mode==="live"?"LIVE CONFIG":"DEMO CONFIG"}
      </span>
    </div>

    <div className="hero">
      <h2>DS Bakery Master v0.29 — Supabase Staging Connection Handoff</h2>
      <p>Core, operations, customer-service and staff/admin workflows now have live Supabase wiring. Production launch still depends on real database migration, role/RLS testing, build verification, backup/restore testing and deployment validation.</p>
    </div>

    <div className="grid2">
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Runtime Health</h3>
        {health.checks.map(c=><div key={c.key} style={{padding:"11px 0",borderBottom:"1px solid #f0e6da"}}>
          <div style={{display:"flex",justifyContent:"space-between",gap:12}}>
            <b>{c.label}</b>
            <span className={c.status==="pass"?"badge green":c.status==="warn"?"badge gold":"badge red"}>{c.status.toUpperCase()}</span>
          </div>
          <p style={{margin:"5px 0 0",fontSize:12,color:"var(--muted)",lineHeight:1.5}}>{c.detail}</p>
        </div>)}
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Go-Live Gates</h3>
        <p>□ Production Supabase project created</p>
        <p>□ Full schema applied without errors</p>
        <p>□ Real staff Auth accounts created</p>
        <p>□ Owner / Manager / Cashier / Baker / Storekeeper RLS tests pass</p>
        <p>□ Full bakery workday simulation passes</p>
        <p>□ Daily backup schedule configured</p>
        <p>□ Restore tested into non-production database</p>
        <p>□ Production domain / HTTPS configured</p>
      </div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Master Modules</h3>
      <div className="tablewrap"><table><thead><tr><th>Module</th><th>Feature Build</th><th>Live Data Requirement</th></tr></thead>
      <tbody>{modules.map((m,i)=><tr key={i}>
        <td><b>{m[0]}</b></td>
        <td><span className="badge green">{m[1]}</span></td>
        <td>{health.mode==="live"?<span className="badge green">Supabase available</span>:<span className="badge gold">Demo / sample data may remain</span>}</td>
      </tr>)}</tbody></table></div>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>What v0.29 means</h2>
      <p>The public customer website now joins the same master system through safe read-only catalog RPCs. Production launch still depends on real database, role/RLS, build, backup/restore and full-workday acceptance tests.</p>
    </div>
  </main></div>
}
