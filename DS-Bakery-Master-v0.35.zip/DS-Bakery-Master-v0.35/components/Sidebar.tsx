import Link from "next/link";

const links = [
  ["/dashboard","Dashboard"],
  ["/system-status","System Status"],
  ["/validation","Production Validation"],
  ["/staging-connection","Staging Connection"],
  ["/validation-history","Validation History"],
  ["/environment","Environment Safety"],
  ["/go-live-setup","Go-Live Setup"],
  ["/production-cutover","Production Cutover"],
  ["/public-site-settings","Public Website Settings"],
  ["/custom-cakes","Custom Cakes"],
  ["/deliveries","Deliveries"],
  ["/delivery-riders","Delivery Riders"],
  ["/loyalty","Loyalty & Rewards"],
  ["/customer-retention","Customer Retention"],
  ["/communications","WhatsApp Communication"],
  ["/message-templates","Message Templates"],
  ["/attendance","Attendance"],
  ["/staff-schedule","Staff Schedule"],
  ["/permission-overrides","Individual Permissions"],
  ["/production","Daily Bake Plan"],
  ["/baker-tasks","Baker Tasks"],
  ["/waste","Waste Tracking"],
  ["/production-control","Production Control"],
  ["/customer-orders","Customer Orders"],
  ["/customers","Customers"],
  ["/purchase-orders","Purchase Orders"],
  ["/supplier-accounts","Supplier Accounts"],
  ["/reports","Financial Reports"],
  ["/pos","Cashier POS"],
  ["/products","Products"],
  ["/inventory","Inventory"],
  ["/recipes","Recipes & Costing"],
  ["/suppliers","Suppliers"],
  ["/purchases","Purchases"],
  ["/stock-movements","Stock Movements"],
  ["/expenses","Expenses"],
  ["/cash-movements","Cash In / Out"],
  ["/shifts","Cashier Shifts"],
  ["/daily-closing","Daily Closing"],
  ["/staff","Staff & Roles"],
  ["/activity-log","Activity Log"],
  ["/security","Security"],
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <img src="/ds-bakery-logo.png" alt="DS Bakery" />
        <div><strong>DS Bakery</strong><small>Master System v0.35</small></div>
      </div>
      <nav className="nav">
        {links.map(([href,label]) => <Link key={href} href={href}>{label}</Link>)}
      </nav>
      <div style={{marginTop:24,padding:12,borderTop:"1px solid var(--line)",color:"var(--muted)",fontSize:12,lineHeight:1.5}}>
        Integration Stage active<br/>
        Supabase Staging • Connection Evidence • Release Handoff
      </div>
    </aside>
  );
}
