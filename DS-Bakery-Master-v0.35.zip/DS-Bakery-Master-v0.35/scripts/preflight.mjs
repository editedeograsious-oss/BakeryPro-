import fs from "node:fs";
import path from "node:path";

const cwd = process.cwd();
let failed = false;

function check(label, condition, detail) {
  const status = condition ? "PASS" : "FAIL";
  console.log(`${status.padEnd(4)}  ${label}${detail ? ` — ${detail}` : ""}`);
  if (!condition) failed = true;
}

function warn(label, condition, detail) {
  const status = condition ? "PASS" : "WARN";
  console.log(`${status.padEnd(4)}  ${label}${detail ? ` — ${detail}` : ""}`);
}

const requiredFiles = [
  "supabase/schema.sql",
  "middleware.ts",
  "lib/supabase/client.ts",
  "lib/supabase/server.ts",
  "lib/auth.ts",
  "scripts/backup.sh",
  "scripts/restore.sh",
  "docs/SECURITY_CHECKLIST.md",
  "docs/BACKUP_RESTORE.md",
];

console.log("\nDS Bakery Master Preflight\n");

for (const file of requiredFiles) {
  check(`Required file: ${file}`, fs.existsSync(path.join(cwd, file)));
}

const migrations = fs.readdirSync(path.join(cwd, "supabase"))
  .filter((f) => /^\d{3}_.*\.sql$/.test(f))
  .sort();

check("Migration count", migrations.length >= 33, `${migrations.length} migration files`);

const numbers = migrations.map((m) => Number(m.slice(0, 3)));
const expected = [];
for (let n = 2; n <= 34; n++) expected.push(n);
const missing = expected.filter((n) => !numbers.includes(n));
check("Migration sequence 002–034", missing.length === 0, missing.length ? `Missing: ${missing.join(", ")}` : "Complete");

const schema = fs.readFileSync(path.join(cwd, "supabase/schema.sql"), "utf8");
for (const marker of [
  "PHASE 1F MIGRATION",
  "PHASE 2A MIGRATION",
  "PHASE 2B MIGRATION",
  "PHASE 2C MIGRATION",
  "PHASE 2D MIGRATION",
  "PHASE 2E MIGRATION",
  "PHASE 3A MIGRATION",
  "PHASE 3B MIGRATION",
  "PHASE 3C MIGRATION",
  "PHASE 3D MIGRATION",
  "PHASE 3E MIGRATION",
  "INTEGRATION STAGE / MIGRATION 017",
  "INTEGRATION STAGE / MIGRATION 018",
  "INTEGRATION STAGE / MIGRATION 019",
  "INTEGRATION STAGE / MIGRATION 020",
  "INTEGRATION STAGE / MIGRATION 021",
  "INTEGRATION STAGE / MIGRATION 022",
  "INTEGRATION STAGE / MIGRATION 023",
  "INTEGRATION STAGE / MIGRATION 024",
  "INTEGRATION STAGE / MIGRATION 025",
  "INTEGRATION STAGE / MIGRATION 026",
  "INTEGRATION STAGE / MIGRATION 027",
  "INTEGRATION STAGE / MIGRATION 028",
  "INTEGRATION STAGE / MIGRATION 029",
  "INTEGRATION STAGE / MIGRATION 030",
  "INTEGRATION STAGE / MIGRATION 031",
  "INTEGRATION STAGE / MIGRATION 032",
  "INTEGRATION STAGE / MIGRATION 033",
  "INTEGRATION STAGE / MIGRATION 034",
]) {
  check(`schema.sql contains ${marker}`, schema.includes(marker));
}

const hasUrl = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL);
const hasAnon = Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
warn(
  "Supabase environment",
  hasUrl && hasAnon,
  hasUrl && hasAnon ? "Configured" : "Not configured in this shell; demo mode only"
);

warn(
  "Production demo-mode flag",
  process.env.NEXT_PUBLIC_DEMO_MODE === "false",
  process.env.NEXT_PUBLIC_DEMO_MODE === "false"
    ? "Production-safe setting"
    : "Set NEXT_PUBLIC_DEMO_MODE=false for production"
);

console.log("");
if (failed) {
  console.error("Preflight failed. Fix FAIL items before deployment.");
  process.exit(1);
}
console.log("Preflight structural checks passed.");
