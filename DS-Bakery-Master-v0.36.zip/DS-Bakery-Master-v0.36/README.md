# DS Bakery Master v0.36 — Staging Hardening Consolidation

Release:
- App version: 0.36.0
- Database migration: 035
- Stage: staging_hardening_consolidation
- Database: DS Bakery Supabase staging
- Staging host: Railway

This release consolidates the working staging patches into the canonical source tree. The practical Owner dashboard, business-focused role-aware sidebar, TypeScript fixes, dependency override and security/RLS hardening are now part of one master project.

Production is still intentionally gated. Replace staging placeholders with real bakery data, complete the real backup/restore drill, finish final public-site verification, and execute controlled production cutover before live operations.

See:
- `docs/V036_STAGING_HARDENING_CONSOLIDATION.md`
- `docs/RAILWAY_STAGING_DEPLOYMENT.md`
- `.env.railway.staging.example`
- `Dockerfile`
- `railway.json`
