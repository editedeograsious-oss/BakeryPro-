import Sidebar from "@/components/Sidebar";
import ActivityLogManager from "@/components/admin/ActivityLogManager";
import { requireStaff } from "@/lib/auth";
import { getActivityLogData } from "@/lib/repositories/adminLive";
export const dynamic="force-dynamic";
export default async function ActivityLog(){
  await requireStaff(["owner","manager"]);
  const data=await getActivityLogData();
  return <div className="shell"><Sidebar/><main className="main"><ActivityLogManager rows={data.rows}/></main></div>;
}
