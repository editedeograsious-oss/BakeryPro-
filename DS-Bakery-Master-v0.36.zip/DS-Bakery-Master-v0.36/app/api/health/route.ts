import { NextResponse } from "next/server";
import { getSystemHealth } from "@/lib/integration/health";

export const dynamic = "force-dynamic";

export async function GET() {
  const health = await getSystemHealth();
  const hasFailure = health.checks.some((c) => c.status === "fail");

  return NextResponse.json(
    {
      service: "ds-bakery-master",
      version: "0.36.0",
      mode: health.mode,
      environment: health.environment,
      checks: health.checks,
      timestamp: new Date().toISOString(),
    },
    {
      status: hasFailure ? 503 : 200,
      headers: {
        "Cache-Control":"no-store",
      },
    }
  );
}
