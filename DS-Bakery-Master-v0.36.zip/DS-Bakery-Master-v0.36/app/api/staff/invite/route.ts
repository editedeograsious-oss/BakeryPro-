import { NextResponse } from "next/server";
import { createClient as createAdminClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";

const ALLOWED_ROLES=["manager","cashier","baker","storekeeper"] as const;

export async function POST(request:Request){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user)return NextResponse.json({error:"Authentication required."},{status:401});

  const {data:profile}=await supabase.from("profiles").select("role,active,disabled_at").eq("id",user.id).single();
  if(!profile||profile.role!=="owner"||!profile.active||profile.disabled_at){
    return NextResponse.json({error:"Owner authorization required."},{status:403});
  }

  const body=await request.json().catch(()=>null);
  const email=String(body?.email??"").trim().toLowerCase();
  const fullName=String(body?.full_name??"").trim();
  const role=String(body?.role??"");

  if(!email||!fullName||!ALLOWED_ROLES.includes(role as any)){
    return NextResponse.json({error:"Valid email, name and staff role are required."},{status:400});
  }

  const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!serviceKey){
    return NextResponse.json({error:"Server staff-invite credentials are not configured."},{status:503});
  }

  const admin=createAdminClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});
  const {data,error}=await admin.auth.admin.inviteUserByEmail(email,{
    data:{full_name:fullName,role},
  });
  if(error||!data.user){
    return NextResponse.json({error:error?.message??"Could not create invitation."},{status:400});
  }

  const {error:profileError}=await admin.from("profiles").upsert({
    id:data.user.id,
    full_name:fullName,
    role,
    active:true,
    disabled_at:null,
    disabled_by:null,
  });
  if(profileError){
    return NextResponse.json({error:`Auth invite created, but staff profile failed: ${profileError.message}`},{status:500});
  }

  await admin.from("audit_logs").insert({
    actor_id:user.id,
    action:"invite_staff",
    entity:"profile",
    entity_id:data.user.id,
    after_data:{email,full_name:fullName,role},
  });

  return NextResponse.json({ok:true,user_id:data.user.id});
}
