import Sidebar from "@/components/Sidebar";
import AttendanceManager from "@/components/admin/AttendanceManager";
import { requireStaff } from "@/lib/auth";
import { getAttendancePageData } from "@/lib/repositories/adminLive";
import { hasPermission } from "@/lib/access";
export const dynamic="force-dynamic";
export default async function Attendance(){
  const staff=await requireStaff(["owner","manager","cashier","baker","storekeeper"]);
  const data=await getAttendancePageData();
  const canManage=await hasPermission("attendance:manage");
  return <div className="shell"><Sidebar/><main className="main"><AttendanceManager rows={data.rows} settings={data.settings} self={data.self} live={!data.demo} canManage={canManage}/></main></div>;
}
