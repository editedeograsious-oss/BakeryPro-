import Sidebar from "@/components/Sidebar";
import BakerTaskPanel from "@/components/operations/BakerTaskPanel";
import { requireStaff } from "@/lib/auth";
import { getBakerTaskPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function BakerTasks(){
  const staff=await requireStaff(["owner","manager","baker"]);
  const data=await getBakerTaskPageData();
  const canManage=["owner","manager"].includes(staff.profile.role);

  return <div className="shell"><Sidebar/><main className="main">
    <BakerTaskPanel tasks={data.tasks} bakers={data.bakers} products={data.products} live={!data.demo} canManage={canManage}/>
  </main></div>;
}
