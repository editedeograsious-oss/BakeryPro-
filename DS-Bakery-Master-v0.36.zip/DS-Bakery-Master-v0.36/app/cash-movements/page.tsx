import Sidebar from "@/components/Sidebar";
import CashMovementManager from "@/components/operations/CashMovementManager";
import { requireStaff } from "@/lib/auth";
import { getCashMovementPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function CashMovements(){
  const staff=await requireStaff(["owner","manager","cashier"]);
  const data=await getCashMovementPageData();

  return <div className="shell"><Sidebar/><main className="main">
    <CashMovementManager movements={data.movements} shifts={data.shifts} live={!data.demo} role={staff.profile.role}/>
  </main></div>;
}
