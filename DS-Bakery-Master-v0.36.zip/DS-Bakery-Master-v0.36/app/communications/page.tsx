import Sidebar from "@/components/Sidebar";
import CommunicationManager from "@/components/service/CommunicationManager";
import { requirePermission } from "@/lib/access";
import { getCommunicationPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function Communications(){
  await requirePermission("communication:send",["owner","manager","cashier"]);
  const data=await getCommunicationPageData();
  return <div className="shell"><Sidebar/><main className="main"><CommunicationManager queue={data.queue} templates={data.templates} logs={data.logs} live={!data.demo}/></main></div>;
}
