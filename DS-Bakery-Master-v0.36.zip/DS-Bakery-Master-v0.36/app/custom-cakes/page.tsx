import Sidebar from "@/components/Sidebar";
import CustomCakeManager from "@/components/service/CustomCakeManager";
import { requireStaff } from "@/lib/auth";
import { getCustomCakePageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function CustomCakes(){
  const staff=await requireStaff(["owner","manager","cashier","baker"]);
  const data=await getCustomCakePageData();
  return <div className="shell"><Sidebar/><main className="main"><CustomCakeManager cakes={data.cakes} customers={data.customers} shifts={data.shifts} live={!data.demo} role={staff.profile.role}/></main></div>;
}
