import Sidebar from "@/components/Sidebar";
import CustomerOrderManager from "@/components/service/CustomerOrderManager";
import { requireStaff } from "@/lib/auth";
import { getCustomerOrdersPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function CustomerOrders(){
  const staff=await requireStaff(["owner","manager","cashier","baker"]);
  const data=await getCustomerOrdersPageData();
  return <div className="shell"><Sidebar/><main className="main"><CustomerOrderManager orders={data.orders} customers={data.customers} products={data.products} shifts={data.shifts} live={!data.demo} role={staff.profile.role}/></main></div>;
}
