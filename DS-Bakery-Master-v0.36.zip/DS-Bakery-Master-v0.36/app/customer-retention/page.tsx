import Sidebar from "@/components/Sidebar";
import RetentionPanel from "@/components/service/RetentionPanel";
import { requireStaff } from "@/lib/auth";
import { getRetentionPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function CustomerRetention(){
  await requireStaff(["owner","manager","cashier"]);
  const data=await getRetentionPageData();
  return <div className="shell"><Sidebar/><main className="main"><RetentionPanel customers={data.customers} birthdays={data.birthdays}/></main></div>;
}
