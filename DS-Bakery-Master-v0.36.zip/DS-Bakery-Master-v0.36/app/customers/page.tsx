import Sidebar from "@/components/Sidebar";
import CustomerManager from "@/components/service/CustomerManager";
import { requireStaff } from "@/lib/auth";
import { getCustomersPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function Customers(){
  await requireStaff(["owner","manager","cashier"]);
  const data=await getCustomersPageData();
  return <div className="shell"><Sidebar/><main className="main"><CustomerManager customers={data.customers} live={!data.demo}/></main></div>;
}
