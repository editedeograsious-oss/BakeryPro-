import DailyClosingPanel from "@/components/core/DailyClosingPanel";
import { requireStaff } from "@/lib/auth";
import { getDailyClosingPageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function DailyClosing(){
  await requireStaff(["owner","manager"]);
  const data=await getDailyClosingPageData();
  return <DailyClosingPanel snapshot={data.snapshot} live={!data.demo}/>;
}
