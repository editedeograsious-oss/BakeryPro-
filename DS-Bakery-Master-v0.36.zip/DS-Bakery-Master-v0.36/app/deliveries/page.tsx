import Sidebar from "@/components/Sidebar";
import DeliveryManager from "@/components/service/DeliveryManager";
import { requirePermission } from "@/lib/access";
import { getDeliveryPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function Deliveries(){
  const staff=await requirePermission("delivery:manage",["owner","manager","cashier"]);
  const data=await getDeliveryPageData();
  return <div className="shell"><Sidebar/><main className="main"><DeliveryManager jobs={data.jobs} riders={data.riders} orders={data.orders} live={!data.demo} role={staff.profile.role}/></main></div>;
}
