import Sidebar from "@/components/Sidebar";
import RiderManager from "@/components/service/RiderManager";
import { requireStaff } from "@/lib/auth";
import { getRiderPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function DeliveryRiders(){
  await requireStaff(["owner","manager"]);
  const data=await getRiderPageData();
  return <div className="shell"><Sidebar/><main className="main"><RiderManager riders={data.riders} live={!data.demo}/></main></div>;
}
