import Sidebar from "@/components/Sidebar";
import EnvironmentManager from "@/components/validation/EnvironmentManager";
import { requireStaff } from "@/lib/auth";
import { getEnvironmentConfig } from "@/lib/repositories/environmentLive";

export const dynamic="force-dynamic";

export default async function EnvironmentPage(){
  await requireStaff(["owner"]);
  const data=await getEnvironmentConfig();
  return <div className="shell"><Sidebar/><main className="main">
    <EnvironmentManager config={data.config} live={!data.demo}/>
  </main></div>;
}
