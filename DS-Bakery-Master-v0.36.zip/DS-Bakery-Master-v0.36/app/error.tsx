'use client';

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div style={{minHeight:"70vh",display:"grid",placeItems:"center",padding:24}}>
      <div className="card" style={{maxWidth:520}}>
        <h2 style={{fontFamily:"Georgia,serif",color:"var(--brown)",marginTop:0}}>Something went wrong</h2>
        <p style={{color:"var(--muted)"}}>
          The system could not load this module. No transaction should be retried blindly if you are unsure whether it already completed.
        </p>
        <p style={{fontSize:12,color:"var(--red)"}}>{error.message}</p>
        <button className="btn primary" onClick={reset}>Try Again</button>
      </div>
    </div>
  );
}
