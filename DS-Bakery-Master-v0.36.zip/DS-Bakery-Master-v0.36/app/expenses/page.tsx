import Sidebar from "@/components/Sidebar";
import ExpenseManager from "@/components/operations/ExpenseManager";
import { requireStaff } from "@/lib/auth";
import { getExpensePageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function Expenses(){
  await requireStaff(["owner","manager"]);
  const data=await getExpensePageData();

  return <div className="shell"><Sidebar/><main className="main">
    <ExpenseManager expenses={data.expenses} shifts={data.shifts} live={!data.demo}/>
  </main></div>;
}
