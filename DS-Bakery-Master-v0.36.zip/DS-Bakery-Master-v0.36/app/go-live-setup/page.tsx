import Sidebar from "@/components/Sidebar";
import GoLiveSetupManager from "@/components/validation/GoLiveSetupManager";
import { requireStaff } from "@/lib/auth";
import { getGoLiveSetupData } from "@/lib/repositories/goLiveSetup";

export const dynamic="force-dynamic";

export default async function GoLiveSetupPage(){
  await requireStaff(["owner"]);
  const data=await getGoLiveSetupData();
  return <div className="shell"><Sidebar/><main className="main">
    <GoLiveSetupManager readiness={data.readiness} live={!data.demo}/>
  </main></div>;
}
