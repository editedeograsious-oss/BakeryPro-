import "./globals.css";
import RuntimeBanner from "@/components/RuntimeBanner";
import { deploymentEnvironment } from "@/lib/runtime";

export function generateMetadata(){
  const env=deploymentEnvironment();
  return {
    title: env==="production" ? "DS Bakery" : `DS Bakery — ${env.toUpperCase()}`,
    description: "DS Bakery Management System",
    robots: env==="production"
      ? { index:true, follow:true }
      : { index:false, follow:false },
  };
}

export default function RootLayout({children}:{children:React.ReactNode}) {
  return (
    <html lang="en">
      <body>
        <RuntimeBanner />
        {children}
      </body>
    </html>
  );
}
