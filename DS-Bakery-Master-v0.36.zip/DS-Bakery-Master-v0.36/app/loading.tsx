export default function Loading() {
  return (
    <div style={{minHeight:"70vh",display:"grid",placeItems:"center",padding:24}}>
      <div className="card" style={{maxWidth:420,textAlign:"center"}}>
        <h2 style={{fontFamily:"Georgia,serif",color:"var(--brown)",marginTop:0}}>DS Bakery</h2>
        <p style={{color:"var(--muted)"}}>Loading shared bakery data…</p>
      </div>
    </div>
  );
}
