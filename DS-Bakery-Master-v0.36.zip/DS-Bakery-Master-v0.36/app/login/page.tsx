'use client';

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function Login(){
  const router=useRouter();
  const params=useSearchParams();
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [role,setRole]=useState("owner");
  const [message,setMessage]=useState("");
  const [loading,setLoading]=useState(false);

  const liveMode = useMemo(
    ()=>Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
    []
  );

  async function submit(e:React.FormEvent){
    e.preventDefault();
    setMessage("");

    if (!liveMode) {
      localStorage.setItem("dsb-demo-role", role);
      router.push("/dashboard");
      return;
    }

    setLoading(true);
    const supabase=createClient();
    const { error }=await supabase.auth.signInWithPassword({email,password});
    setLoading(false);

    if(error){
      setMessage("Login failed. Check your email and password.");
      return;
    }

    router.replace(params.get("next") || "/dashboard");
    router.refresh();
  }

  return <div className="auth-wrap">
    <form className="auth-card" onSubmit={submit}>
      <div className="brand" style={{marginBottom:22}}>
        <img src="/ds-bakery-logo.svg" alt="DS Bakery"/>
        <div><strong>DS Bakery</strong><small>Secure Staff Login</small></div>
      </div>

      <div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username"/></div>
      <div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></div>

      {!liveMode && <div className="field">
        <label>Preview role</label>
        <select value={role} onChange={e=>setRole(e.target.value)}>
          <option value="owner">Owner</option><option value="manager">Manager</option>
          <option value="cashier">Cashier</option><option value="baker">Baker</option>
          <option value="storekeeper">Storekeeper</option>
        </select>
      </div>}

      {message && <p style={{color:"var(--red)",fontSize:12}}>{message}</p>}
      <button disabled={loading} className="btn primary" style={{width:"100%"}}>
        {loading?"Signing in…":liveMode?"Sign In":"Enter Demo System"}
      </button>

      <p style={{fontSize:12,color:"var(--muted)",lineHeight:1.5}}>
        {liveMode
          ? "Production authentication is handled by Supabase Auth. Disabled staff profiles are rejected by application/database controls."
          : "Cloud credentials are not configured, so this is running in demo-login mode."}
      </p>
    </form>
  </div>
}
