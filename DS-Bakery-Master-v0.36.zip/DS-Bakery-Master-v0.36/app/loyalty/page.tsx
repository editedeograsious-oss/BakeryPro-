import Sidebar from "@/components/Sidebar";
import LoyaltyManager from "@/components/service/LoyaltyManager";
import { requireStaff } from "@/lib/auth";
import { getLoyaltyPageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function Loyalty(){
  const staff=await requireStaff(["owner","manager","cashier"]);
  const data=await getLoyaltyPageData();
  return <div className="shell"><Sidebar/><main className="main"><LoyaltyManager customers={data.customers} ledger={data.ledger} settings={data.settings} orders={data.orders} live={!data.demo} role={staff.profile.role}/></main></div>;
}
