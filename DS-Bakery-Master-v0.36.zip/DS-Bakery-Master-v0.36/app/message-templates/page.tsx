import Sidebar from "@/components/Sidebar";
import TemplateManager from "@/components/service/TemplateManager";
import { requireStaff } from "@/lib/auth";
import { getTemplatePageData } from "@/lib/repositories/customerServiceLive";
export const dynamic="force-dynamic";
export default async function MessageTemplates(){
  const staff=await requireStaff(["owner","manager","cashier"]);
  const data=await getTemplatePageData();
  return <div className="shell"><Sidebar/><main className="main"><TemplateManager templates={data.templates} live={!data.demo} role={staff.profile.role}/></main></div>;
}
