import { redirect } from "next/navigation";
export default function OperationalReports(){ redirect("/reports"); }
