import Sidebar from "@/components/Sidebar";
import PermissionOverrideManager from "@/components/admin/PermissionOverrideManager";
import { requireStaff } from "@/lib/auth";
import { getPermissionOverrideData } from "@/lib/repositories/adminLive";
export const dynamic="force-dynamic";
export default async function PermissionOverrides({searchParams}:{searchParams:Promise<{staff?:string}>}){
  await requireStaff(["owner"]);
  const q=await searchParams;
  const data=await getPermissionOverrideData(q.staff);
  return <div className="shell"><Sidebar/><main className="main"><PermissionOverrideManager staff={data.staff} permissions={data.permissions} selectedId={data.selectedId} live={!data.demo}/></main></div>;
}
