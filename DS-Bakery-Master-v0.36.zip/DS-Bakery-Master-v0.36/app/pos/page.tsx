import PosTerminal from "@/components/core/PosTerminal";
import { requireStaff } from "@/lib/auth";
import { getPosPageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function POS(){
  await requireStaff(["owner","manager","cashier"]);
  const data=await getPosPageData();

  return <PosTerminal products={data.products} openShift={data.openShift} customers={data.customers} live={!data.demo}/>;
}
