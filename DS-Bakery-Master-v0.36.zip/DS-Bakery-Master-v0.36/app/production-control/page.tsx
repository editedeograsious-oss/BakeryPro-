import Sidebar from "@/components/Sidebar";
import ProductionControlPanel from "@/components/operations/ProductionControlPanel";
import { requireStaff } from "@/lib/auth";
import { getProductionControlPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function ProductionControl(){
  await requireStaff(["owner","manager"]);
  const data=await getProductionControlPageData();

  return <div className="shell"><Sidebar/><main className="main">
    <ProductionControlPanel rows={data.rows}/>
  </main></div>;
}
