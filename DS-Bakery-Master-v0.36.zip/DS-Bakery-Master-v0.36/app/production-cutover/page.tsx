import Sidebar from "@/components/Sidebar";
import ProductionCutoverManager from "@/components/validation/ProductionCutoverManager";
import { requireStaff } from "@/lib/auth";
import { getProductionCutoverData } from "@/lib/repositories/productionCutover";

export const dynamic="force-dynamic";

export default async function ProductionCutoverPage(){
  const staff=await requireStaff(["owner","manager"]);
  const data=await getProductionCutoverData();
  return <div className="shell"><Sidebar/><main className="main">
    <ProductionCutoverManager status={data.status} live={!data.demo} role={staff.profile.role}/>
  </main></div>;
}
