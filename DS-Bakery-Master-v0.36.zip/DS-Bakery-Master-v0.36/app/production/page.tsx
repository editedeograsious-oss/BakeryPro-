import Sidebar from "@/components/Sidebar";
import ProductionManager from "@/components/operations/ProductionManager";
import { requireStaff } from "@/lib/auth";
import { getProductionPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function Production(){
  const staff=await requireStaff(["owner","manager","baker"]);
  const data=await getProductionPageData(staff.profile.role);
  const canManage=["owner","manager"].includes(staff.profile.role);

  return <div className="shell"><Sidebar/><main className="main">
    <ProductionManager plan={data.plan} products={data.products} bakers={data.bakers} live={!data.demo} canManage={canManage}/>
  </main></div>;
}
