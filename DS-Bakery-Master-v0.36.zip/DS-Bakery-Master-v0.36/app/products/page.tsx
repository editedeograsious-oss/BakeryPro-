import Sidebar from "@/components/Sidebar";
import ProductManager from "@/components/core/ProductManager";
import { requireStaff } from "@/lib/auth";
import { getProductPageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function Products(){
  await requireStaff(["owner","manager"]);
  const data=await getProductPageData();

  return <div className="shell"><Sidebar/><main className="main">
    <ProductManager products={data.products} categories={data.categories} live={!data.demo}/>
  </main></div>;
}
