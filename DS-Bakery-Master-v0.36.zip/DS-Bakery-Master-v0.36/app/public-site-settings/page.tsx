import Sidebar from "@/components/Sidebar";
import PublicSiteSettingsManager from "@/components/public/PublicSiteSettingsManager";
import { requireStaff } from "@/lib/auth";
import { getPublicSiteSettingsAdmin } from "@/lib/repositories/publicSiteLive";

export const dynamic="force-dynamic";

export default async function PublicSiteSettingsPage(){
  await requireStaff(["owner","manager"]);
  const data=await getPublicSiteSettingsAdmin();
  return <div className="shell"><Sidebar/><main className="main">
    <PublicSiteSettingsManager settings={data.settings} live={!data.demo}/>
  </main></div>;
}
