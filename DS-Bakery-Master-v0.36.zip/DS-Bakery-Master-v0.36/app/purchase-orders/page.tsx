import Sidebar from "@/components/Sidebar";
import PurchaseOrderManager from "@/components/operations/PurchaseOrderManager";
import { requireStaff } from "@/lib/auth";
import { getPurchaseOrderPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function PurchaseOrders(){
  const staff=await requireStaff(["owner","manager","storekeeper"]);
  const data=await getPurchaseOrderPageData();
  const canApprove=["owner","manager"].includes(staff.profile.role);

  return <div className="shell"><Sidebar/><main className="main">
    <PurchaseOrderManager orders={data.orders} suppliers={data.suppliers} materials={data.materials} live={!data.demo} canApprove={canApprove}/>
  </main></div>;
}
