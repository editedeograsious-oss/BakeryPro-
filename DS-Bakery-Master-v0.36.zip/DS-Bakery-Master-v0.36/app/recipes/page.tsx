import Sidebar from "@/components/Sidebar";
import RecipeManager from "@/components/core/RecipeManager";
import { requireStaff } from "@/lib/auth";
import { getRecipePageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function Recipes(){
  const staff=await requireStaff(["owner","manager","baker"]);
  const data=await getRecipePageData();
  const canEdit=["owner","manager"].includes(staff.profile.role);

  return <div className="shell"><Sidebar/><main className="main">
    <RecipeManager recipes={data.recipes} products={data.products} materials={data.materials} live={!data.demo} canEdit={canEdit}/>
  </main></div>;
}
