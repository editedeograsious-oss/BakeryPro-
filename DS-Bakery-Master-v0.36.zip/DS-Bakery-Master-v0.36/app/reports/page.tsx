import Sidebar from "@/components/Sidebar";
import LiveManagementReport from "@/components/reports/LiveManagementReport";
import { requirePermission } from "@/lib/access";
import { getLiveReportData } from "@/lib/repositories/adminLive";
export const dynamic="force-dynamic";
export default async function Reports({searchParams}:{searchParams:Promise<{period?:string}>}){
  await requirePermission("reports:view",["owner","manager"]);
  const q=await searchParams;
  const period=q.period==="month"?"month":"week";
  const data=await getLiveReportData(period);
  return <div className="shell"><Sidebar/><main className="main"><LiveManagementReport period={period} summary={data.summary} products={data.products} payments={data.payments} expenses={data.expenses}/></main></div>;
}
