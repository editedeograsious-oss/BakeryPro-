import type { MetadataRoute } from "next";
import { deploymentEnvironment } from "@/lib/runtime";

export default function robots():MetadataRoute.Robots {
  const production=deploymentEnvironment()==="production";
  return {
    rules: production
      ? { userAgent:"*", allow:"/" }
      : { userAgent:"*", disallow:"/" },
  };
}
