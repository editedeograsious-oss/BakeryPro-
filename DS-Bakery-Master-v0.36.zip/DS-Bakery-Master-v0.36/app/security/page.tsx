import Sidebar from "@/components/Sidebar";
import { requirePermission } from "@/lib/access";

const permissions = [
  ["Owner","All modules, staff/security controls, reports, closing","Full"],
  ["Manager","Operations, reports, closing, audit review","Broad"],
  ["Cashier","POS and active products","Restricted"],
  ["Baker","Recipes, active materials, products","Restricted"],
  ["Storekeeper","Inventory, suppliers and purchasing","Restricted"],
];

export default async function SecurityPage(){
  await requirePermission("security:manage",["owner"]);
  return <div className="shell"><Sidebar/><main className="main">
    <div className="pagehead">
      <div><h1>Security & Reliability</h1><p>Role permissions, sessions, account controls and backup readiness.</p></div>
      <span className="badge green">Phase 1F</span>
    </div>

    <div className="grid4">
      <div className="card stat"><div className="label">Roles</div><div className="value">5</div></div>
      <div className="card stat"><div className="label">Protected Modules</div><div className="value">12+</div></div>
      <div className="card stat"><div className="label">Audit Trail</div><div className="value">On</div></div>
      <div className="card stat"><div className="label">Backup Mode</div><div className="value" style={{fontSize:20}}>Configured</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Security Controls</h3>
        <p>✓ Supabase Auth-ready login</p>
        <p>✓ Middleware session refresh / unauthenticated redirect</p>
        <p>✓ Database RLS role checks</p>
        <p>✓ Disabled-profile enforcement</p>
        <p>✓ Refund approval PIN hashes</p>
        <p>✓ Audit log for sensitive actions</p>
        <p>✓ Security response headers</p>
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Backup & Restore</h3>
        <p>Logical PostgreSQL backup scripts are included in <code>scripts/</code>.</p>
        <p>Operational restore instructions are included in <code>docs/BACKUP_RESTORE.md</code>.</p>
        <p style={{color:"var(--muted)",fontSize:12,lineHeight:1.6}}>Cloud-provider automatic backup availability depends on the Supabase plan selected when DS Bakery is deployed. The project does not claim those backups are active until they are actually enabled.</p>
      </div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Permission Matrix</h3>
      <div className="tablewrap"><table><thead><tr><th>Role</th><th>Access</th><th>Level</th></tr></thead>
      <tbody>{permissions.map((r,i)=><tr key={i}><td><b>{r[0]}</b></td><td>{r[1]}</td><td><span className={r[2]==="Full"?"badge green":"badge gold"}>{r[2]}</span></td></tr>)}</tbody></table></div>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>Deployment requirement</h2>
      <p>Before real staff use this system, create actual Supabase Auth users, set each profile role, verify RLS policies using separate test accounts, configure a production backup destination, and test one restore into a non-production database.</p>
    </div>
  </main></div>
}
