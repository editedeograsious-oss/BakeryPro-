import CashierShiftPanel from "@/components/core/CashierShiftPanel";
import { requireStaff } from "@/lib/auth";
import { getCashierShiftPageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function Shifts(){
  await requireStaff(["owner","manager","cashier"]);
  const data=await getCashierShiftPageData();
  return <CashierShiftPanel shifts={data.shifts} live={!data.demo}/>;
}
