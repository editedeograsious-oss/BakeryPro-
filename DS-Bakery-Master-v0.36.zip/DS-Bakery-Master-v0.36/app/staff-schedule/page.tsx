import Sidebar from "@/components/Sidebar";
import ScheduleManager from "@/components/admin/ScheduleManager";
import { requireStaff } from "@/lib/auth";
import { getSchedulePageData } from "@/lib/repositories/adminLive";
import { hasPermission } from "@/lib/access";
export const dynamic="force-dynamic";
export default async function StaffSchedule(){
  const staff=await requireStaff(["owner","manager","cashier","baker","storekeeper"]);
  const canManage=await hasPermission("schedule:manage");
  const data=await getSchedulePageData(canManage);
  return <div className="shell"><Sidebar/><main className="main"><ScheduleManager rows={data.rows} staff={data.staff} live={!data.demo} canManage={canManage}/></main></div>;
}
