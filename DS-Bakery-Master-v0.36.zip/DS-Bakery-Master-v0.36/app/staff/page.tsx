import Sidebar from "@/components/Sidebar";
import StaffAdminManager from "@/components/admin/StaffAdminManager";
import { requireStaff } from "@/lib/auth";
import { getStaffAdminData } from "@/lib/repositories/adminLive";
export const dynamic="force-dynamic";
export default async function StaffPage(){
  await requireStaff(["owner"]);
  const data=await getStaffAdminData();
  return <div className="shell"><Sidebar/><main className="main"><StaffAdminManager staff={data.staff} live={!data.demo}/></main></div>;
}
