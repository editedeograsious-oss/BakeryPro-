import Sidebar from "@/components/Sidebar";
import StagingConnectionPanel from "@/components/validation/StagingConnectionPanel";
import { requireStaff } from "@/lib/auth";
import { getStagingConnectionData } from "@/lib/repositories/stagingConnection";

export const dynamic="force-dynamic";

export default async function StagingConnectionPage(){
  await requireStaff(["owner","manager"]);
  const data=await getStagingConnectionData();
  return <div className="shell"><Sidebar/><main className="main">
    <StagingConnectionPanel env={data.env} summary={data.summary} demo={data.demo}/>
  </main></div>;
}
