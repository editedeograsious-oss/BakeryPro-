import Sidebar from "@/components/Sidebar";
import StockMovementLedger from "@/components/admin/StockMovementLedger";
import { requireStaff } from "@/lib/auth";
import { getStockMovementLedgerData } from "@/lib/repositories/operationsLive";
export const dynamic="force-dynamic";
export default async function StockMovements(){
  await requireStaff(["owner","manager","storekeeper"]);
  const data=await getStockMovementLedgerData();
  return <div className="shell"><Sidebar/><main className="main"><StockMovementLedger rows={data.rows}/></main></div>;
}
