import Sidebar from "@/components/Sidebar";
import SupplierAccountsPanel from "@/components/operations/SupplierAccountsPanel";
import { requireStaff } from "@/lib/auth";
import { getSupplierAccountsPageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function SupplierAccounts(){
  await requireStaff(["owner","manager"]);
  const data=await getSupplierAccountsPageData();

  return <div className="shell"><Sidebar/><main className="main">
    <SupplierAccountsPanel accounts={data.accounts} statements={data.statements} payables={data.payables} shifts={data.shifts} live={!data.demo}/>
  </main></div>;
}
