import Sidebar from "@/components/Sidebar";
import SupplierDirectoryManager from "@/components/admin/SupplierDirectoryManager";
import { requireStaff } from "@/lib/auth";
import { getSupplierDirectoryData } from "@/lib/repositories/operationsLive";
export const dynamic="force-dynamic";
export default async function Suppliers(){
  await requireStaff(["owner","manager","storekeeper"]);
  const data=await getSupplierDirectoryData();
  return <div className="shell"><Sidebar/><main className="main"><SupplierDirectoryManager suppliers={data.suppliers} live={!data.demo}/></main></div>;
}
