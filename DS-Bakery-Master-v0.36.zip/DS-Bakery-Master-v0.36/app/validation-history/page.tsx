import Sidebar from "@/components/Sidebar";
import ValidationHistory from "@/components/validation/ValidationHistory";
import { requireStaff } from "@/lib/auth";
import { getValidationHistory } from "@/lib/repositories/validationLive";

export const dynamic="force-dynamic";

export default async function ValidationHistoryPage(){
  await requireStaff(["owner","manager"]);
  const data=await getValidationHistory();
  return <div className="shell"><Sidebar/><main className="main">
    <ValidationHistory runs={data.runs}/>
  </main></div>;
}
