import Sidebar from "@/components/Sidebar";
import LaunchValidationPanel from "@/components/validation/LaunchValidationPanel";
import { requireStaff } from "@/lib/auth";
import { getValidationData } from "@/lib/repositories/validationLive";

export const dynamic="force-dynamic";

export default async function ValidationPage(){
  await requireStaff(["owner"]);
  const data=await getValidationData();
  return <div className="shell"><Sidebar/><main className="main">
    <LaunchValidationPanel envChecks={data.envChecks} dbChecks={data.dbChecks} release={data.release} demo={data.demo}/>
  </main></div>;
}
