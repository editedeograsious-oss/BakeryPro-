import Sidebar from "@/components/Sidebar";
import WasteManager from "@/components/operations/WasteManager";
import { requireStaff } from "@/lib/auth";
import { getWastePageData } from "@/lib/repositories/operationsLive";

export const dynamic="force-dynamic";

export default async function Waste(){
  const staff=await requireStaff(["owner","manager","baker","storekeeper"]);
  const data=await getWastePageData();

  return <div className="shell"><Sidebar/><main className="main">
    <WasteManager events={data.events} products={data.products} materials={data.materials} runs={data.runs} threshold={data.threshold} live={!data.demo} role={staff.profile.role}/>
  </main></div>;
}
