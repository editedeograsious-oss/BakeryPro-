'use client';

import { useMemo, useState } from "react";

export default function ActivityLogManager({rows}:{rows:any[]}){
  const [query,setQuery]=useState("");
  const shown=useMemo(()=>rows.filter(r=>JSON.stringify(r).toLowerCase().includes(query.toLowerCase())),[rows,query]);
  return <>
    <div className="pagehead"><div><h1>Activity Log</h1><p>Live audit entries for sensitive business and security actions.</p></div><input style={{maxWidth:300}} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search actor / action / entity…"/></div>
    <div className="tablewrap"><table><thead><tr><th>Time</th><th>Staff</th><th>Role</th><th>Action</th><th>Entity</th><th>Reference</th></tr></thead>
      <tbody>{shown.length===0?<tr><td colSpan={6}>No matching audit records.</td></tr>:shown.map(r=><tr key={r.id}><td>{new Date(r.created_at).toLocaleString()}</td><td><b>{r.actor_name??"System"}</b></td><td>{r.actor_role??"—"}</td><td><code>{r.action}</code></td><td>{r.entity}</td><td>{r.entity_id??"—"}</td></tr>)}</tbody>
    </table></div>
    <div className="hero" style={{marginTop:16}}><h2>Audit records are append-only from normal screens</h2><p>Operational pages create audit entries through controlled database functions. Staff screens do not provide a delete button for financial/security history.</p></div>
  </>;
}
