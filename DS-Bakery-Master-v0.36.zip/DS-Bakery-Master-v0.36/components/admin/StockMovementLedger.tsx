'use client';

import { useMemo, useState } from "react";
import { ugx } from "@/lib/costing";

export default function StockMovementLedger({rows}:{rows:any[]}){
  const [query,setQuery]=useState("");
  const shown=useMemo(()=>rows.filter(r=>JSON.stringify(r).toLowerCase().includes(query.toLowerCase())),[rows,query]);

  return <>
    <div className="pagehead">
      <div><h1>Stock Movement Ledger</h1><p>Live, read-only movement history. Stock changes are posted only through controlled workflows.</p></div>
      <input style={{maxWidth:300}} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search material / type / reference…"/>
    </div>
    <div className="hero"><h2>No manual silent stock edits</h2><p>Purchasing, production, approved raw-material waste and physical stock counts create traceable inventory transactions. This page does not insert ledger rows directly.</p></div>
    <div className="tablewrap">
      <table><thead><tr><th>Date/Time</th><th>Material</th><th>Type</th><th>Quantity</th><th>Unit Cost</th><th>Reference</th><th>Notes</th><th>Recorded By</th></tr></thead>
      <tbody>{shown.length===0?<tr><td colSpan={8}>No matching stock movements.</td></tr>:shown.map(r=><tr key={r.id}>
        <td>{new Date(r.created_at).toLocaleString()}</td><td><b>{r.material_name}</b></td>
        <td><span className={Number(r.quantity_delta)>=0?"badge green":"badge gold"}>{r.tx_type}</span></td>
        <td><b>{Number(r.quantity_delta)>0?"+":""}{Number(r.quantity_delta).toLocaleString()} {r.base_unit}</b></td>
        <td>{r.unit_cost==null?"—":`${ugx(Number(r.unit_cost))}/${r.base_unit}`}</td>
        <td>{r.reference_type??"—"}{r.reference_id?<><br/><small>{r.reference_id}</small></>:null}</td>
        <td>{r.notes??"—"}</td><td>{r.recorded_by_name??"System"}</td>
      </tr>)}</tbody></table>
    </div>
  </>;
}
