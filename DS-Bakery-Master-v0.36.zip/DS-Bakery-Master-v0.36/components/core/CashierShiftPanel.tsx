'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function CashierShiftPanel({shifts,live}:{shifts:any[];live:boolean}){
  const router=useRouter();
  const [openingFloat,setOpeningFloat]=useState(0);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  const active=shifts.filter((s:any)=>s.status==="open");

  async function startShift(){
    if(openingFloat<0){setMessage("Opening float cannot be negative.");return;}
    if(!live){setMessage("Demo mode: cashier shift start simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("start_cashier_shift",{p_opening_float:openingFloat});
      if(error)throw error;
      setMessage("Cashier shift opened.");
      setOpeningFloat(0);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not start shift.");}
    finally{setBusy(false);}
  }

  async function closeShift(id:string){
    if(!live){setMessage("Demo mode: cashier shift close simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("close_cashier_shift",{p_shift_id:id,p_note:null});
      if(error)throw error;
      setMessage("Cashier shift closed.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not close shift.");}
    finally{setBusy(false);}
  }

  return <div className="shell"><Sidebar/><main className="main">
    <div className="pagehead">
      <div><h1>Cashier Shifts</h1><p>Live till responsibility, opening float and sales totals.</p></div>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Open Shifts</div><div className="value">{active.length}</div></div>
      <div className="card stat"><div className="label">Opening Float</div><div className="value">{ugx(active.reduce((s:number,x:any)=>s+Number(x.opening_float||0),0))}</div></div>
      <div className="card stat"><div className="label">POS Cash Sales</div><div className="value">{ugx(active.reduce((s:number,x:any)=>s+Number(x.cash_sales||0),0))}</div></div>
      <div className="card stat"><div className="label">Expected Till Cash</div><div className="value">{ugx(active.reduce((s:number,x:any)=>s+Number(x.expected_cash??x.opening_float??0),0))}</div></div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Start My Shift</h3>
      <div className="field"><label>Opening float (UGX)</label><input type="number" min="0" value={openingFloat} onChange={e=>setOpeningFloat(Number(e.target.value))}/></div>
      <button className="btn primary" disabled={busy} onClick={startShift}>{busy?"Working…":"Start Shift"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}>
      <table><thead><tr><th>Cashier</th><th>Started</th><th>Status</th><th>Opening Float</th><th>Gross Sales</th><th>POS Cash</th><th>Order Cash</th><th>Expected Cash</th><th>Action</th></tr></thead>
      <tbody>{shifts.length===0?<tr><td colSpan={9}>No cashier shifts found.</td></tr>:shifts.map((r:any)=><tr key={r.id}>
        <td><b>{r.cashier_name}</b></td><td>{new Date(r.opened_at).toLocaleString()}</td><td><span className={r.status==="open"?"badge green":"badge gold"}>{r.status}</span></td>
        <td>{ugx(Number(r.opening_float))}</td><td>{ugx(Number(r.gross_sales||0))}</td><td><b>{ugx(Number(r.cash_sales||0))}</b></td><td>{ugx(Number(r.order_cash_receipts||0))}</td><td><b>{ugx(Number((r.expected_cash ?? r.opening_float) ?? 0))}</b></td>
        <td>{r.status==="open"?<button className="btn secondary" disabled={busy} onClick={()=>closeShift(r.id)}>Close Shift</button>:<span style={{color:"var(--muted)"}}>—</span>}</td>
      </tr>)}</tbody></table>
    </div>
  </main></div>
}
