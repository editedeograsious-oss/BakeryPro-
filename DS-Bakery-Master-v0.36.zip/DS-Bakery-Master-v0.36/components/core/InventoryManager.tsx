'use client';

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function InventoryManager({
  materials,
  live,
  canAdjust,
}: {
  materials:any[];
  live:boolean;
  canAdjust:boolean;
}) {
  const router=useRouter();
  const [selected,setSelected]=useState(materials[0]?.id ?? "");
  const material=materials.find((m:any)=>m.id===selected);
  const [counted,setCounted]=useState(material?Number(material.current_stock_qty):0);
  const [reason,setReason]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  const low=useMemo(()=>materials.filter((m:any)=>m.low || Number(m.current_stock_qty)<=Number(m.low_stock_threshold)),[materials]);
  const stockValue=useMemo(()=>materials.reduce((s:number,m:any)=>s+Number(m.stock_value ?? 0),0),[materials]);

  function choose(id:string){
    setSelected(id);
    const m=materials.find((x:any)=>x.id===id);
    setCounted(m?Number(m.current_stock_qty):0);
    setReason("");
  }

  async function saveCount(){
    if(!material) return;
    if(counted<0){setMessage("Counted stock cannot be negative.");return;}
    if(!reason.trim()){setMessage("Enter a reason for the stock count adjustment.");return;}

    if(!live){
      setMessage("Demo mode: stock count preview only. No database stock was changed.");
      return;
    }

    setBusy(true); setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("record_stock_count",{
        p_raw_material_id:selected,
        p_counted_qty:counted,
        p_reason:reason.trim(),
        p_client_request_id:requestId.current,
      });
      if(error) throw error;
      setMessage("Stock count posted to the movement ledger.");
      requestId.current=crypto.randomUUID();
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save stock count.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead">
      <div><h1>Raw Materials & Inventory</h1><p>Live balances are derived from controlled inventory movements.</p></div>
      {canAdjust?<a className="btn primary" href="/purchases">Receive Purchase Stock</a>:<span className="badge gold">Read Only</span>}
    </div>

    {message && <div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Raw Materials</div><div className="value">{materials.length}</div></div>
      <div className="card stat"><div className="label">Low Stock</div><div className="value">{low.length}</div></div>
      <div className="card stat"><div className="label">Stock Value</div><div className="value">{ugx(stockValue)}</div></div>
      <div className="card stat"><div className="label">Ledger Control</div><div className="value" style={{fontSize:20}}>Active</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Low-stock alerts</h3>
        {low.length===0?<p style={{color:"var(--muted)"}}>No materials below reorder level.</p>:low.slice(0,8).map((m:any)=><p key={m.id}><b>{m.name}</b> — {Number(m.current_stock_qty).toLocaleString()} {m.base_unit} <span className="badge red">Below {Number(m.low_stock_threshold).toLocaleString()} {m.base_unit}</span></p>)}
      </div>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>{canAdjust?"Stock Count Adjustment":"Inventory Access"}</h3>
        {canAdjust?<>
          <div className="field"><label>Material</label><select value={selected} onChange={e=>choose(e.target.value)}>{materials.map((m:any)=><option key={m.id} value={m.id}>{m.name}</option>)}</select></div>
          <div className="field"><label>Counted quantity ({material?.base_unit ?? "base unit"})</label><input type="number" min="0" value={counted} onChange={e=>setCounted(Number(e.target.value))}/></div>
          <div className="field"><label>Reason</label><input value={reason} onChange={e=>setReason(e.target.value)} placeholder="Physical count / correction reason"/></div>
          <button className="btn secondary" disabled={busy||!material} onClick={saveCount}>{busy?"Posting…":"Post Stock Count"}</button>
        </>:<p style={{color:"var(--muted)",lineHeight:1.6}}>Your role can view ingredient stock and reorder levels but cannot post stock-count adjustments or receive purchases.</p>}
      </div>
    </div>

    <div className="tablewrap" style={{marginTop:16}}>
      <table><thead><tr><th>Material</th><th>Base Unit</th><th>Current Unit Cost</th><th>Stock</th><th>Reorder Level</th><th>Stock Value</th><th>Status</th></tr></thead>
      <tbody>{materials.length===0?<tr><td colSpan={7}>No materials found.</td></tr>:materials.map((m:any)=><tr key={m.id}>
        <td><b>{m.name}</b></td><td>{m.base_unit}</td><td>{ugx(Number(m.unit_cost ?? 0))}/{m.base_unit}</td>
        <td>{Number(m.current_stock_qty).toLocaleString()} {m.base_unit}</td><td>{Number(m.low_stock_threshold).toLocaleString()} {m.base_unit}</td>
        <td>{ugx(Number(m.stock_value ?? 0))}</td>
        <td><span className={m.low||Number(m.current_stock_qty)<=Number(m.low_stock_threshold)?"badge red":"badge green"}>{m.low||Number(m.current_stock_qty)<=Number(m.low_stock_threshold)?"Low":"OK"}</span></td>
      </tr>)}</tbody></table>
    </div>
  </>;
}
