'use client';

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { createClient } from "@/lib/supabase/client";
import { CartLine, subtotal, discountAmount, grandTotal, changeDue } from "@/lib/pos";
import { ugx } from "@/lib/costing";

type PaymentMethod="cash"|"mtn_momo"|"airtel_money";

export default function PosTerminal({
  products,
  openShift,
  customers,
  live,
}:{
  products:any[];
  openShift:any|null;
  customers:any[];
  live:boolean;
}){
  const router=useRouter();
  const [cart,setCart]=useState<CartLine[]>([]);
  const [discountType,setDiscountType]=useState<"amount"|"percent">("amount");
  const [discountValue,setDiscountValue]=useState(0);
  const [paymentMethod,setPaymentMethod]=useState<PaymentMethod>("cash");
  const [received,setReceived]=useState(0);
  const [reference,setReference]=useState("");
  const [customerId,setCustomerId]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef<string>(crypto.randomUUID());

  const sub=useMemo(()=>subtotal(cart),[cart]);
  const disc=useMemo(()=>discountAmount(sub,discountType,discountValue),[sub,discountType,discountValue]);
  const total=useMemo(()=>grandTotal(sub,disc),[sub,disc]);
  const change=paymentMethod==="cash"?changeDue(received,total):0;

  function addProduct(p:any){
    setCart(prev=>{
      const found=prev.find(x=>x.productId===p.id);
      if(found)return prev.map(x=>x.productId===p.id?{...x,quantity:x.quantity+1}:x);
      return [...prev,{productId:p.id,name:p.name,unitPrice:Number(p.selling_price),quantity:1}];
    });
  }

  function updateQty(id:string,delta:number){
    setCart(prev=>prev.map(x=>x.productId===id?{...x,quantity:Math.max(0,x.quantity+delta)}:x).filter(x=>x.quantity>0));
  }

  async function submit(hold:boolean){
    if(!cart.length){setMessage("Add at least one product.");return;}
    if(!openShift){setMessage("Start a cashier shift before creating sales.");return;}
    if(!hold && paymentMethod==="cash" && received<total){setMessage("Cash received is less than the total.");return;}
    if(!hold && paymentMethod!=="cash" && !reference.trim()){setMessage("Enter the Mobile Money transaction reference.");return;}

    if(!live){
      setMessage(hold?"Demo sale held.":"Demo sale completed. No cloud transaction was created.");
      if(!hold){setCart([]);setDiscountValue(0);setReceived(0);setReference("");setCustomerId("");}
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const payments=hold?[]:[{
        method:paymentMethod,
        // Ledger records the sale amount, not physical cash tendered.
        amount:total,
        reference:paymentMethod==="cash"?null:reference.trim(),
      }];
      const {data,error}=await supabase.rpc("complete_sale_with_customer",{
        p_items:cart.map(x=>({product_id:x.productId,quantity:x.quantity})),
        p_discount:disc,
        p_payments:payments,
        p_notes:null,
        p_hold:hold,
        p_client_request_id:requestId.current,
        p_customer_id:customerId||null,
      });
      if(error)throw error;
      setMessage(`${hold?"Sale held":"Sale completed"} • Reference ${data}`);
      if(!hold){
        setCart([]);setDiscountValue(0);setReceived(0);setReference("");setCustomerId("");
        requestId.current=crypto.randomUUID();
      }
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not complete sale.");
    }finally{setBusy(false);}
  }

  return <div className="shell"><Sidebar/><main className="main">
    <div className="pagehead">
      <div><h1>Cashier POS</h1><p>Live products, authoritative server pricing and controlled payment posting.</p></div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        <span className={openShift?"badge green":"badge red"}>{openShift?"Shift Open":"No Open Shift"}</span>
        <button className="btn secondary" disabled={busy} onClick={()=>submit(true)}>Hold Sale</button>
        <button className="btn secondary" onClick={()=>setCart([])}>Clear Cart</button>
      </div>
    </div>

    {message&&<div className="hero" style={{padding:14,marginBottom:14}}><b>{message}</b></div>}

    {!openShift&&<div className="hero"><h2>Cashier shift required</h2><p>Open a cashier shift before selling. <a href="/shifts"><b>Go to Cashier Shifts</b></a>.</p></div>}

    <div className="grid2">
      <section><div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Products</h3>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:10}}>
          {products.map((p:any)=><button key={p.id} onClick={()=>addProduct(p)} className="btn secondary" style={{minHeight:95,textAlign:"left"}}>
            <div style={{fontWeight:900}}>{p.name}</div>
            <div style={{fontSize:11,color:"var(--muted)",marginTop:4}}>{p.category_name}</div>
            <div style={{fontSize:12,color:"var(--muted)",marginTop:4}}>{ugx(Number(p.selling_price))}</div>
          </button>)}
        </div>
      </div></section>

      <section><div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Current Sale</h3>
        {cart.length===0?<p style={{color:"var(--muted)"}}>Tap a product to start the sale.</p>:<div className="tablewrap"><table style={{minWidth:0}}><thead><tr><th>Item</th><th>Qty</th><th>Total</th></tr></thead><tbody>
          {cart.map(line=><tr key={line.productId}><td><b>{line.name}</b><br/><small>{ugx(line.unitPrice)} each</small></td><td><div style={{display:"flex",gap:6,alignItems:"center"}}><button className="btn secondary" style={{padding:"5px 9px"}} onClick={()=>updateQty(line.productId,-1)}>-</button><b>{line.quantity}</b><button className="btn secondary" style={{padding:"5px 9px"}} onClick={()=>updateQty(line.productId,1)}>+</button></div></td><td><b>{ugx(line.unitPrice*line.quantity)}</b></td></tr>)}
        </tbody></table></div>}

        <div style={{marginTop:16,borderTop:"1px solid var(--line)",paddingTop:14}}>
          <div className="grid2">
            <div className="field"><label>Discount type</label><select value={discountType} onChange={e=>setDiscountType(e.target.value as any)}><option value="amount">Amount (UGX)</option><option value="percent">Percent (%)</option></select></div>
            <div className="field"><label>Discount value</label><input type="number" min="0" value={discountValue} onChange={e=>setDiscountValue(Number(e.target.value))}/></div>
          </div>
          <p style={{display:"flex",justifyContent:"space-between"}}><span>Subtotal</span><b>{ugx(sub)}</b></p>
          <p style={{display:"flex",justifyContent:"space-between"}}><span>Discount</span><b>- {ugx(disc)}</b></p>
          <p style={{display:"flex",justifyContent:"space-between",fontSize:22,borderTop:"2px solid var(--brown)",paddingTop:9}}><span><b>Total</b></span><b>{ugx(total)}</b></p>
        </div>

        <div className="field"><label>Customer (optional for loyalty)</label><select value={customerId} onChange={e=>setCustomerId(e.target.value)}><option value="">Walk-in customer</option>{customers.map((c:any)=><option key={c.id??c.customer_id} value={c.id??c.customer_id}>{c.full_name} {c.phone?`• ${c.phone}`:""}</option>)}</select></div>
        <div className="field"><label>Payment method</label><select value={paymentMethod} onChange={e=>setPaymentMethod(e.target.value as PaymentMethod)}><option value="cash">Cash</option><option value="mtn_momo">MTN MoMo</option><option value="airtel_money">Airtel Money</option></select></div>
        {paymentMethod==="cash"?<>
          <div className="field"><label>Cash received</label><input type="number" min="0" value={received} onChange={e=>setReceived(Number(e.target.value))}/></div>
          <p><b>Change: {ugx(change)}</b></p>
          <p style={{color:"var(--muted)",fontSize:11}}>Only the sale total is posted to the cash ledger. Customer change is not counted as sales revenue.</p>
        </>:<div className="field"><label>Transaction reference</label><input value={reference} onChange={e=>setReference(e.target.value)} placeholder="Type Mobile Money reference"/></div>}

        <button className="btn primary" disabled={busy||!openShift} style={{width:"100%",marginTop:8}} onClick={()=>submit(false)}>{busy?"Posting…":"Complete Sale"}</button>
      </div></section>
    </div>
  </main></div>
}
