'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function ProductManager({
  products,
  categories,
  live,
}: {
  products: any[];
  categories: any[];
  live: boolean;
}) {
  const router = useRouter();
  const [showForm,setShowForm]=useState(false);
  const [name,setName]=useState("");
  const [price,setPrice]=useState(0);
  const [categoryId,setCategoryId]=useState(categories[0]?.id ?? "");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function addProduct(){
    if(!name.trim() || price<0){
      setMessage("Enter a product name and a valid selling price.");
      return;
    }

    if(!live){
      setMessage("Demo mode: product creation is not written to the cloud database.");
      return;
    }

    setBusy(true); setMessage("");
    try{
      const supabase=createClient();
      const { error }=await supabase.rpc("save_product",{
        p_product_id:null,
        p_name:name.trim(),
        p_category_id:categoryId || null,
        p_selling_price:price,
        p_description:null,
      });
      if(error) throw error;
      setMessage("Product saved to the shared database.");
      setName(""); setPrice(0); setShowForm(false);
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not save product.");
    }finally{setBusy(false);}
  }

  return <>
    <div className="pagehead">
      <div><h1>Products</h1><p>Sellable products with live standard recipe costing.</p></div>
      <button className="btn primary" onClick={()=>setShowForm(v=>!v)}>{showForm?"Cancel":"+ Add Product"}</button>
    </div>

    {message && <div className="hero" style={{padding:14}}><b>{message}</b></div>}

    {showForm && <div className="card" style={{marginBottom:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>New Product</h3>
      <div className="grid2">
        <div className="field"><label>Product name</label><input value={name} onChange={e=>setName(e.target.value)}/></div>
        <div className="field"><label>Category</label><select value={categoryId} onChange={e=>setCategoryId(e.target.value)}><option value="">Uncategorized</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
      </div>
      <div className="field"><label>Selling price (UGX)</label><input type="number" min="0" value={price} onChange={e=>setPrice(Number(e.target.value))}/></div>
      <button className="btn primary" disabled={busy} onClick={addProduct}>{busy?"Saving…":"Save Product"}</button>
    </div>}

    <div className="tablewrap"><table><thead><tr><th>Product</th><th>Category</th><th>Selling Price</th><th>Food Cost</th><th>Gross Profit</th><th>Margin</th><th>Status</th></tr></thead>
      <tbody>{products.length===0?<tr><td colSpan={7}>No products found.</td></tr>:products.map((p:any)=><tr key={p.id}>
        <td><b>{p.name}</b></td><td>{p.category_name ?? "—"}</td><td>{ugx(Number(p.selling_price))}</td>
        <td>{p.unit_food_cost===null||p.unit_food_cost===undefined?"No recipe":ugx(Number(p.unit_food_cost))}</td>
        <td><b>{p.gross_profit===null||p.gross_profit===undefined?"—":ugx(Number(p.gross_profit))}</b></td>
        <td>{p.gross_margin_pct===null||p.gross_margin_pct===undefined?"—":`${Number(p.gross_margin_pct).toFixed(1)}%`}</td>
        <td><span className={p.status==="active"?"badge green":"badge gold"}>{p.status}</span></td>
      </tr>)}</tbody>
    </table></div>
  </>;
}
