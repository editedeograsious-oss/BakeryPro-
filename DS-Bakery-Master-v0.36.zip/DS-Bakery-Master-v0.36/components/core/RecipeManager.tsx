'use client';

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

type DraftIngredient={raw_material_id:string;quantity_base_unit:number};

export default function RecipeManager({
  recipes,
  products,
  materials,
  live,
  canEdit,
}:{
  recipes:any[];
  products:any[];
  materials:any[];
  live:boolean;
  canEdit:boolean;
}){
  const router=useRouter();
  const [show,setShow]=useState(false);
  const [productId,setProductId]=useState(products[0]?.id ?? "");
  const [name,setName]=useState("");
  const [yieldQty,setYieldQty]=useState(1);
  const [items,setItems]=useState<DraftIngredient[]>(
    materials[0]?[{raw_material_id:materials[0].id,quantity_base_unit:1}]:[]
  );
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  const selectedProduct=products.find((p:any)=>p.id===productId);
  const draftCost=useMemo(()=>items.reduce((sum,item)=>{
    const m=materials.find((x:any)=>x.id===item.raw_material_id);
    return sum+Number(item.quantity_base_unit||0)*Number(m?.unit_cost||0);
  },0),[items,materials]);

  function addIngredient(){
    if(!materials.length)return;
    setItems(prev=>[...prev,{raw_material_id:materials[0].id,quantity_base_unit:1}]);
  }

  async function saveRecipe(){
    if(!productId||!name.trim()||yieldQty<=0||items.length===0){
      setMessage("Select a product, enter recipe name/yield, and add ingredients.");
      return;
    }
    if(items.some(x=>!x.raw_material_id||x.quantity_base_unit<=0)){
      setMessage("Every ingredient needs a material and positive quantity.");
      return;
    }

    if(!live){
      setMessage("Demo mode: recipe preview only. No database recipe was changed.");
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("save_active_recipe",{
        p_product_id:productId,
        p_name:name.trim(),
        p_yield_qty:yieldQty,
        p_items:items,
      });
      if(error)throw error;
      setMessage("Active recipe saved. Previous active recipe was archived.");
      setShow(false);setName("");setYieldQty(1);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save recipe.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead">
      <div><h1>Recipes & Costing</h1><p>Recipe costs use current raw-material unit costs from shared inventory.</p></div>
      {canEdit?<button className="btn primary" onClick={()=>setShow(v=>!v)}>{show?"Cancel":"+ New / Replace Recipe"}</button>:<span className="badge gold">Read Only</span>}
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    {show&&canEdit&&<div className="card" style={{marginBottom:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Active Recipe</h3>
      <div className="grid2">
        <div className="field"><label>Product</label><select value={productId} onChange={e=>setProductId(e.target.value)}>{products.map((p:any)=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
        <div className="field"><label>Recipe name</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Standard recipe name"/></div>
      </div>
      <div className="field"><label>Yield (sellable units)</label><input type="number" min="0.001" step="0.001" value={yieldQty} onChange={e=>setYieldQty(Number(e.target.value))}/></div>

      {items.map((item,i)=><div className="grid2" key={i}>
        <div className="field"><label>Ingredient</label><select value={item.raw_material_id} onChange={e=>setItems(prev=>prev.map((x,j)=>j===i?{...x,raw_material_id:e.target.value}:x))}>{materials.map((m:any)=><option key={m.id} value={m.id}>{m.name} ({m.base_unit})</option>)}</select></div>
        <div className="field"><label>Quantity in base unit</label><input type="number" min="0.000001" step="any" value={item.quantity_base_unit} onChange={e=>setItems(prev=>prev.map((x,j)=>j===i?{...x,quantity_base_unit:Number(e.target.value)}:x))}/></div>
      </div>)}

      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        <button className="btn secondary" onClick={addIngredient}>+ Ingredient</button>
        <button className="btn primary" disabled={busy} onClick={saveRecipe}>{busy?"Saving…":"Save Active Recipe"}</button>
      </div>
      <p style={{color:"var(--muted)",fontSize:12,marginTop:12}}>Current draft batch cost: <b>{ugx(draftCost)}</b> • Unit food cost: <b>{ugx(yieldQty>0?draftCost/yieldQty:0)}</b> • Product selling price: <b>{ugx(Number(selectedProduct?.selling_price??0))}</b></p>
    </div>}

    {recipes.length===0?<div className="card"><p>No active recipes found.</p></div>:recipes.map((r:any)=><div className="card" key={r.id} style={{marginBottom:16}}>
      <div className="pagehead" style={{marginBottom:8}}>
        <div><h3 style={{color:"var(--brown)",margin:0}}>{r.product_name}</h3><p style={{color:"var(--muted)",margin:"4px 0"}}>{r.name} • Yield {Number(r.yield_qty).toLocaleString()} units</p></div>
        <span className="badge green">Active</span>
      </div>
      <div className="grid4">
        <div><div className="label">Batch Cost</div><b>{ugx(Number(r.batch_cost))}</b></div>
        <div><div className="label">Unit Food Cost</div><b>{ugx(Number(r.unit_food_cost))}</b></div>
        <div><div className="label">Gross Profit / Unit</div><b>{ugx(Number(r.gross_profit))}</b></div>
        <div><div className="label">Margin</div><b>{Number(r.margin_pct).toFixed(1)}%</b></div>
      </div>
      <div className="tablewrap" style={{marginTop:12}}><table><thead><tr><th>Ingredient</th><th>Quantity</th><th>Unit Cost</th><th>Line Cost</th></tr></thead><tbody>
        {r.ingredients.map((x:any)=><tr key={x.raw_material_id}><td><b>{x.name}</b></td><td>{Number(x.quantity_base_unit).toLocaleString()} {x.base_unit}</td><td>{ugx(Number(x.unit_cost))}/{x.base_unit}</td><td>{ugx(Number(x.line_cost))}</td></tr>)}
      </tbody></table></div>
    </div>)}
  </>;
}
