'use client';

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function CashMovementManager({movements,shifts,live,role}:{movements:any[];shifts:any[];live:boolean;role:string}){
  const router=useRouter();
  const [type,setType]=useState("cash_out");
  const [amount,setAmount]=useState(0);
  const [reason,setReason]=useState("");
  const [reference,setReference]=useState("");
  const [shiftId,setShiftId]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  const cashIn=useMemo(()=>movements.filter(m=>m.movement_type==="cash_in").reduce((s,m)=>s+Number(m.amount||0),0),[movements]);
  const cashOut=useMemo(()=>movements.filter(m=>m.movement_type==="cash_out").reduce((s,m)=>s+Number(m.amount||0),0),[movements]);

  async function save(){
    if(amount<=0||!reason.trim()){setMessage("Positive amount and reason are required.");return;}
    if(!live){setMessage("Demo mode: cash movement simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("record_cash_movement",{
        p_movement_type:type,
        p_amount:amount,
        p_reason:reason.trim(),
        p_reference:reference.trim()||null,
        p_shift_id:shiftId||null,
        p_client_request_id:requestId.current,
      });
      if(error)throw error;
      setMessage(`Cash movement recorded • ${data}`);
      requestId.current=crypto.randomUUID();
      setAmount(0);setReason("");setReference("");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not record cash movement.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Cash In / Out</h1><p>Manual cash movements outside customer sales and opening float.</p></div></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="hero"><h2>Opening float does not belong here</h2><p>Opening float is already recorded when a cashier shift starts. Recording it again as Cash In would double-count expected cash.</p></div>

    <div className="grid4">
      <div className="card stat"><div className="label">Cash In</div><div className="value">{ugx(cashIn)}</div></div>
      <div className="card stat"><div className="label">Cash Out</div><div className="value">{ugx(cashOut)}</div></div>
      <div className="card stat"><div className="label">Net Manual Movement</div><div className="value">{ugx(cashIn-cashOut)}</div></div>
      <div className="card stat"><div className="label">Records</div><div className="value">{movements.length}</div></div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Record Manual Cash Movement</h3>
      <div className="grid2"><div className="field"><label>Type</label><select value={type} onChange={e=>setType(e.target.value)}><option value="cash_in">Cash In</option><option value="cash_out">Cash Out</option></select></div><div className="field"><label>Amount</label><input type="number" min="0.01" value={amount} onChange={e=>setAmount(Number(e.target.value))}/></div></div>
      <div className="field"><label>Reason</label><input value={reason} onChange={e=>setReason(e.target.value)} placeholder="Owner top-up / petty cash / bank deposit…"/></div>
      <div className="grid2"><div className="field"><label>Reference (optional)</label><input value={reference} onChange={e=>setReference(e.target.value)}/></div><div className="field"><label>Cashier shift {role==="cashier"?"(your open shift is enforced)":"(optional)"}</label><select value={shiftId} onChange={e=>setShiftId(e.target.value)}><option value="">Auto / general business cash</option>{shifts.map(s=><option key={s.id} value={s.id}>{s.cashier_name}</option>)}</select></div></div>
      <button className="btn primary" disabled={busy} onClick={save}>{busy?"Working…":"Record Movement"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Date</th><th>Type</th><th>Reason</th><th>Amount</th><th>Reference</th><th>Recorded By</th><th>Shift</th></tr></thead>
      <tbody>{movements.length===0?<tr><td colSpan={7}>No manual cash movements found.</td></tr>:movements.map(m=><tr key={m.id}><td>{new Date(m.created_at).toLocaleString()}</td><td><span className={m.movement_type==="cash_in"?"badge green":"badge gold"}>{m.movement_type.replace("_"," ")}</span></td><td>{m.reason}</td><td><b>{ugx(Number(m.amount))}</b></td><td>{m.reference??"—"}</td><td>{m.created_by_name??"—"}</td><td>{m.shift_cashier_name??"—"}</td></tr>)}</tbody>
    </table></div>
  </>;
}
