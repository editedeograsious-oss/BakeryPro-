'use client';

import { ugx } from "@/lib/costing";

export default function ProductionControlPanel({rows}:{rows:any[]}){
  const planned=rows.reduce((s,r)=>s+Number(r.planned_qty||0),0);
  const produced=rows.reduce((s,r)=>s+Number(r.produced_qty||0),0);
  const waste=rows.reduce((s,r)=>s+Number(r.approved_waste_qty||0),0);
  const wasteCost=rows.reduce((s,r)=>s+Number(r.approved_waste_cost||0),0);

  return <>
    <div className="pagehead"><div><h1>Production Control</h1><p>Today’s planned output, actual production, approved waste and estimated sellable output.</p></div></div>
    <div className="grid4">
      <div className="card stat"><div className="label">Planned</div><div className="value">{planned.toLocaleString()}</div></div>
      <div className="card stat"><div className="label">Produced</div><div className="value">{produced.toLocaleString()}</div></div>
      <div className="card stat"><div className="label">Approved Waste</div><div className="value">{waste.toLocaleString()}</div></div>
      <div className="card stat"><div className="label">Waste Cost</div><div className="value">{ugx(wasteCost)}</div></div>
    </div>
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Product</th><th>Planned</th><th>Produced</th><th>Variance</th><th>Approved Waste</th><th>Sellable Output</th><th>Waste Rate</th><th>Waste Cost</th></tr></thead>
    <tbody>{rows.length===0?<tr><td colSpan={8}>No production data for today.</td></tr>:rows.map(r=><tr key={r.product_id}><td><b>{r.product_name}</b></td><td>{Number(r.planned_qty).toLocaleString()}</td><td>{Number(r.produced_qty).toLocaleString()}</td><td>{Number(r.production_variance).toLocaleString()}</td><td>{Number(r.approved_waste_qty).toLocaleString()}</td><td><b>{Number(r.estimated_sellable_output).toLocaleString()}</b></td><td>{Number(r.waste_rate_pct).toFixed(2)}%</td><td>{ugx(Number(r.approved_waste_cost))}</td></tr>)}</tbody>
    </table></div>
    <div className="hero" style={{marginTop:16}}><h2>No double deduction</h2><p>Finished-product waste does not consume raw ingredients again because recipe ingredients were already deducted when production was confirmed.</p></div>
  </>;
}
