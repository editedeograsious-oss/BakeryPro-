'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function WasteManager({
  events,products,materials,runs,threshold,live,role
}:{
  events:any[];products:any[];materials:any[];runs:any[];threshold:number;live:boolean;role:string;
}){
  const router=useRouter();
  const [type,setType]=useState<"finished_product"|"raw_material">(role==="storekeeper"?"raw_material":"finished_product");
  const [productId,setProductId]=useState(products[0]?.id??"");
  const [materialId,setMaterialId]=useState(materials[0]?.id??"");
  const [runId,setRunId]=useState("");
  const [qty,setQty]=useState(0);
  const [reason,setReason]=useState("");
  const [notes,setNotes]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  const canApprove=role==="owner"||role==="manager";
  const canFinished=role!=="storekeeper";
  const canRaw=role!=="baker";

  async function record(){
    if(qty<=0||!reason.trim()){setMessage("Enter a positive quantity and reason.");return;}
    if(type==="finished_product"&&!productId){setMessage("Choose a finished product.");return;}
    if(type==="raw_material"&&!materialId){setMessage("Choose a raw material.");return;}
    if(!live){setMessage("Demo mode: waste record simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("record_waste_event",{
        p_waste_type:type,
        p_quantity:qty,
        p_reason:reason.trim(),
        p_product_id:type==="finished_product"?productId:null,
        p_raw_material_id:type==="raw_material"?materialId:null,
        p_production_run_id:type==="finished_product"?(runId||null):null,
        p_notes:notes.trim()||null,
        p_client_request_id:requestId.current,
      });
      if(error)throw error;
      setMessage(`Waste event recorded • ${data}`);
      requestId.current=crypto.randomUUID();
      setQty(0);setReason("");setNotes("");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not record waste.");}
    finally{setBusy(false);}
  }

  async function decide(id:string,decision:"approve"|"reject"){
    if(!canApprove)return;
    if(!live){setMessage(`Demo mode: waste ${decision}d.`);return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("decide_waste_event",{p_waste_id:id,p_decision:decision,p_note:null});
      if(error)throw error;
      setMessage(`Waste ${decision}d.`);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not decide waste.");}
    finally{setBusy(false);}
  }

  const approved=events.filter(e=>e.approval_status==="approved");
  const approvedCost=approved.reduce((s,e)=>s+Number(e.total_cost||0),0);

  return <>
    <div className="pagehead">
      <div><h1>Waste Tracking</h1><p>Live finished-product and raw-material loss ledger.</p></div>
      <span className="badge gold">Approval threshold {ugx(threshold)}</span>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Approved Waste Cost</div><div className="value">{ugx(approvedCost)}</div></div>
      <div className="card stat"><div className="label">Approved Events</div><div className="value">{approved.length}</div></div>
      <div className="card stat"><div className="label">Pending</div><div className="value">{events.filter(e=>e.approval_status==="pending").length}</div></div>
      <div className="card stat"><div className="label">Raw Waste Stock Rule</div><div className="value" style={{fontSize:18}}>Deduct on Approval</div></div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Record Waste</h3>
      <div className="field"><label>Waste type</label><select value={type} onChange={e=>setType(e.target.value as any)}>
        {canFinished&&<option value="finished_product">Finished Product</option>}
        {canRaw&&<option value="raw_material">Raw Material</option>}
      </select></div>
      {type==="finished_product"?<>
        <div className="grid2">
          <div className="field"><label>Product</label><select value={productId} onChange={e=>setProductId(e.target.value)}>{products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
          <div className="field"><label>Production run (recommended)</label><select value={runId} onChange={e=>{setRunId(e.target.value);const r=runs.find(x=>x.id===e.target.value);if(r)setProductId(r.product_id)}}><option value="">No run link</option>{runs.map(r=><option key={r.id} value={r.id}>{r.product_name} • {Number(r.quantity_produced).toLocaleString()} units • {new Date(r.confirmed_at).toLocaleString()}</option>)}</select></div>
        </div>
      </>:<div className="field"><label>Raw material</label><select value={materialId} onChange={e=>setMaterialId(e.target.value)}>{materials.map(m=><option key={m.id} value={m.id}>{m.name} ({m.base_unit})</option>)}</select></div>}
      <div className="grid2">
        <div className="field"><label>Quantity</label><input type="number" min="0.000001" step="any" value={qty} onChange={e=>setQty(Number(e.target.value))}/></div>
        <div className="field"><label>Reason</label><input value={reason} onChange={e=>setReason(e.target.value)} placeholder="Burnt / dropped / quality issue…"/></div>
      </div>
      <div className="field"><label>Notes</label><input value={notes} onChange={e=>setNotes(e.target.value)}/></div>
      <button className="btn primary" disabled={busy} onClick={record}>{busy?"Working…":"Record Waste"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}>
      <table><thead><tr><th>Item</th><th>Type</th><th>Qty</th><th>Reason</th><th>Cost</th><th>Recorded By</th><th>Status</th><th>Decision</th></tr></thead>
      <tbody>{events.length===0?<tr><td colSpan={8}>No waste events found.</td></tr>:events.map(e=><tr key={e.id}>
        <td><b>{e.item_name}</b></td><td>{String(e.waste_type).replace("_"," ")}</td><td>{Number(e.quantity).toLocaleString()} {e.base_unit??""}</td><td>{e.reason}</td><td>{ugx(Number(e.total_cost||0))}</td><td>{e.recorded_by_name??"—"}</td>
        <td><span className={e.approval_status==="approved"?"badge green":e.approval_status==="pending"?"badge gold":"badge red"}>{e.approval_status}</span></td>
        <td>{canApprove&&e.approval_status==="pending"?<div style={{display:"flex",gap:6}}><button className="btn primary" disabled={busy} onClick={()=>decide(e.id,"approve")}>Approve</button><button className="btn secondary" disabled={busy} onClick={()=>decide(e.id,"reject")}>Reject</button></div>:<span style={{color:"var(--muted)"}}>—</span>}</td>
      </tr>)}</tbody></table>
    </div>
  </>;
}
