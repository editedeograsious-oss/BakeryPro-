'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function PublicSiteSettingsManager({settings,live}:{settings:any;live:boolean}){
  const router=useRouter();
  const [businessName,setBusinessName]=useState(settings?.business_name??"DS Bakery");
  const [tagline,setTagline]=useState(settings?.tagline??"");
  const [heroMessage,setHeroMessage]=useState(settings?.hero_message??"");
  const [phone,setPhone]=useState(settings?.phone??"");
  const [secondaryPhone,setSecondaryPhone]=useState(settings?.secondary_phone??"");
  const [whatsapp,setWhatsapp]=useState(settings?.whatsapp_phone??"");
  const [email,setEmail]=useState(settings?.email??"");
  const [address,setAddress]=useState(settings?.address_text??"");
  const [hours,setHours]=useState(settings?.opening_hours??"");
  const [tiktok,setTiktok]=useState(settings?.tiktok_handle??"");
  const [customCake,setCustomCake]=useState(Boolean(settings?.custom_cake_enabled));
  const [delivery,setDelivery]=useState(Boolean(settings?.delivery_enabled));
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function save(){
    if(!businessName.trim()){setMessage("Business name is required.");return;}
    if(!live){setMessage("Demo mode: public website settings save simulated.");return;}

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("update_public_site_settings",{
        p_business_name:businessName.trim(),
        p_tagline:tagline.trim()||null,
        p_hero_message:heroMessage.trim()||null,
        p_phone:phone.trim()||null,
        p_secondary_phone:secondaryPhone.trim()||null,
        p_whatsapp_phone:whatsapp.trim()||null,
        p_email:email.trim()||null,
        p_address_text:address.trim()||null,
        p_opening_hours:hours.trim()||null,
        p_tiktok_handle:tiktok.trim()||null,
        p_custom_cake_enabled:customCake,
        p_delivery_enabled:delivery,
      });
      if(error)throw error;
      setMessage("Public website settings updated.");
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not update public website settings.");
    }finally{
      setBusy(false);
    }
  }

  return <>
    <div className="pagehead">
      <div><h1>Public Website Settings</h1><p>Owner/Manager-controlled contact details and customer-facing options.</p></div>
      <a className="btn secondary" href="/" target="_blank" rel="noreferrer">Open Public Site</a>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid2">
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Brand & Message</h3>
        <div className="field"><label>Business name</label><input value={businessName} onChange={e=>setBusinessName(e.target.value)}/></div>
        <div className="field"><label>Tagline</label><input value={tagline} onChange={e=>setTagline(e.target.value)}/></div>
        <div className="field"><label>Hero message</label><textarea rows={4} value={heroMessage} onChange={e=>setHeroMessage(e.target.value)}/></div>
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Contact</h3>
        <div className="field"><label>Phone 1</label><input value={phone} onChange={e=>setPhone(e.target.value)}/></div>
        <div className="field"><label>Phone 2</label><input value={secondaryPhone} onChange={e=>setSecondaryPhone(e.target.value)}/></div>
        <div className="field"><label>WhatsApp phone</label><input value={whatsapp} onChange={e=>setWhatsapp(e.target.value)} placeholder="Example: +256..."/></div>
        <div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)}/></div>
        <div className="field"><label>Address / location text</label><input value={address} onChange={e=>setAddress(e.target.value)}/></div>
        <div className="field"><label>Opening hours</label><input value={hours} onChange={e=>setHours(e.target.value)} placeholder="Example: Mon–Sat, 7:00 AM–7:00 PM"/></div>
        <div className="field"><label>TikTok name / handle</label><input value={tiktok} onChange={e=>setTiktok(e.target.value)} placeholder="Ds bakery"/></div>
      </div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Customer Options</h3>
      <label style={{display:"flex",gap:9,alignItems:"center",margin:"10px 0"}}><input type="checkbox" checked={customCake} onChange={e=>setCustomCake(e.target.checked)}/> Show custom cake ordering information</label>
      <label style={{display:"flex",gap:9,alignItems:"center",margin:"10px 0"}}><input type="checkbox" checked={delivery} onChange={e=>setDelivery(e.target.checked)}/> Show delivery availability</label>
      <button className="btn primary" disabled={busy} onClick={save}>{busy?"Saving…":"Save Public Website Settings"}</button>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>Public data boundary</h2>
      <p>The public site receives only safe product/catalog fields and these public contact settings. Recipe costs, stock levels, margins, supplier details and staff data are not exposed.</p>
    </div>
  </>;
}
