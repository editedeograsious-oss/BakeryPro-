'use client';

import { useRouter } from "next/navigation";
import { ugx } from "@/lib/costing";

export default function LiveManagementReport({period,summary,products,payments,expenses}:{period:"week"|"month";summary:any;products:any[];payments:any[];expenses:any[]}){
  const router=useRouter();
  const setPeriod=(p:string)=>router.push(`/reports?period=${p}`);
  return <>
    <div className="pagehead"><div><h1>Management Reports</h1><p>Live report data from the shared financial and operational ledgers.</p></div><div style={{display:"flex",gap:8}}><button className={period==="week"?"btn primary":"btn secondary"} onClick={()=>setPeriod("week")}>This Week</button><button className={period==="month"?"btn primary":"btn secondary"} onClick={()=>setPeriod("month")}>This Month</button><button className="btn secondary" onClick={()=>window.print()}>Print / Save PDF</button></div></div>
    <div className="grid4">
      <div className="card stat"><div className="label">Net POS Sales</div><div className="value">{ugx(Number(summary.sales||0))}</div></div>
      <div className="card stat"><div className="label">COGS</div><div className="value">{ugx(Number(summary.cogs||0))}</div></div>
      <div className="card stat"><div className="label">Gross Profit</div><div className="value">{ugx(Number(summary.gross_profit||0))}</div></div>
      <div className="card stat"><div className="label">Estimated Operating Profit</div><div className="value">{ugx(Number(summary.operating_profit||0))}</div></div>
    </div>
    <div className="grid4" style={{marginTop:14}}>
      <div className="card stat"><div className="label">Recorded Expenses</div><div className="value">{ugx(Number(summary.expenses||0))}</div></div>
      <div className="card stat"><div className="label">Purchases</div><div className="value">{ugx(Number(summary.purchases||0))}</div></div>
      <div className="card stat"><div className="label">Approved Waste Cost</div><div className="value">{ugx(Number(summary.waste_cost||0))}</div></div>
      <div className="card stat"><div className="label">POS Transactions</div><div className="value">{Number(summary.transactions||0).toLocaleString()}</div></div>
    </div>
    <div className="grid4" style={{marginTop:14}}>
      <div className="card stat"><div className="label">Customer Orders</div><div className="value">{ugx(Number(summary.customer_order_value||0))}</div></div>
      <div className="card stat"><div className="label">Customer Balances</div><div className="value">{ugx(Number(summary.customer_order_outstanding||0))}</div></div>
      <div className="card stat"><div className="label">Supplier Outstanding</div><div className="value">{ugx(Number(summary.supplier_outstanding||0))}</div></div>
      <div className="card stat"><div className="label">Supplier Overdue</div><div className="value">{ugx(Number(summary.supplier_overdue||0))}</div></div>
    </div>
    <div className="grid2" style={{marginTop:16}}>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Product Performance</h3>{products.length===0?<p style={{color:"var(--muted)"}}>Live product details appear after database migration/testing.</p>:products.map((p:any)=><p key={p.product_id}><b>{p.product_name}</b><span style={{float:"right"}}>{ugx(Number(p.sales_amount))} • GP {ugx(Number(p.gross_profit))}</span></p>)}</div>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Payment Mix</h3>{payments.length===0?<p style={{color:"var(--muted)"}}>Payment mix will populate from completed payment ledgers.</p>:payments.map((p:any)=><p key={p.method}>{p.method}<b style={{float:"right"}}>{ugx(Number(p.amount))}</b></p>)}</div>
    </div>
    <div className="hero" style={{marginTop:16}}><h2>Accounting note</h2><p>Gross profit uses historical sale-item cost snapshots. Estimated operating profit subtracts recorded operating expenses; supplier settlements are cashflow and are not treated as operating expenses.</p></div>
  </>;
}
