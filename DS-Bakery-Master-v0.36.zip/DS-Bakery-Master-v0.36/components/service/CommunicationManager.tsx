'use client';

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { buildWhatsAppUrl, renderMessageTemplate } from "@/lib/whatsapp";
import { ugx } from "@/lib/costing";

export default function CommunicationManager({queue,templates,logs,live}:{queue:any[];templates:any[];logs:any[];live:boolean}){
  const router=useRouter();
  const [selectedKey,setSelectedKey]=useState(queue[0]?`${queue[0].queue_type}:${queue[0].customer_id}:${queue[0].order_id??""}`:"");
  const [templateId,setTemplateId]=useState(templates[0]?.id??"");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  const current=queue.find(q=>`${q.queue_type}:${q.customer_id}:${q.order_id??""}`===selectedKey)??queue[0];
  const selectedTemplate=templates.find(t=>t.id===templateId)??templates[0];

  const rendered=useMemo(()=>{
    if(!current||!selectedTemplate)return "";
    return renderMessageTemplate(selectedTemplate.body_template,{
      customer_name:current.customer_name,
      order_no:current.order_no??"",
      balance:Number(current.balance_due??0).toLocaleString("en-UG"),
      required_at:current.due_at?new Date(current.due_at).toLocaleString():"",
      rider_name:current.rider_name??"",
    });
  },[current,selectedTemplate]);

  function chooseQueue(key:string){
    setSelectedKey(key);
    const q=queue.find(x=>`${x.queue_type}:${x.customer_id}:${x.order_id??""}`===key);
    const match=templates.find(t=>t.template_type===q?.queue_type);
    if(match)setTemplateId(match.id);
  }

  async function openWhatsApp(){
    if(!current||!selectedTemplate){setMessage("Select a queue item and message template.");return;}
    if(selectedTemplate.requires_marketing_opt_in&&!current.whatsapp_opt_in){setMessage("This marketing/birthday message is blocked because the customer has not opted in.");return;}
    if(!current.phone){setMessage("Customer phone number is missing.");return;}

    const url=buildWhatsAppUrl(current.phone,rendered);
    if(!live){
      setMessage("Demo mode: WhatsApp open simulated. Live mode records the open before navigating.");
      return;
    }

    const popup=window.open("about:blank","_blank");
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("log_whatsapp_open",{
        p_customer_id:current.customer_id,
        p_order_id:current.order_id??null,
        p_template_id:selectedTemplate.id,
        p_recipient_phone:current.phone,
        p_message:rendered,
        p_client_request_id:requestId.current,
      });
      if(error)throw error;
      requestId.current=crypto.randomUUID();
      setMessage("WhatsApp opened with pre-filled text. The system records Opened, not Sent or Delivered.");
      if(popup)popup.location.href=url; else window.location.href=url;
      router.refresh();
    }catch(e){
      if(popup)popup.close();
      setMessage(e instanceof Error?e.message:"Could not log WhatsApp open.");
    }finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Customer Communication</h1><p>Live communication queue with click-to-WhatsApp and consent checks.</p></div><span className="badge green">Manual WhatsApp</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="hero"><h2>Prepared → Opened in WhatsApp → Staff sends</h2><p>The system does not claim provider Sent/Delivered/Read status until an official WhatsApp Business API is actually connected.</p></div>

    <div className="grid4">
      <div className="card stat"><div className="label">Queue Items</div><div className="value">{queue.length}</div></div>
      <div className="card stat"><div className="label">Ready Contacts</div><div className="value">{queue.filter(q=>q.queue_type==="ready_for_pickup").length}</div></div>
      <div className="card stat"><div className="label">Birthday Contacts</div><div className="value">{queue.filter(q=>q.queue_type==="birthday").length}</div></div>
      <div className="card stat"><div className="label">Recent Opens</div><div className="value">{logs.length}</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Communication Queue</h3>
        <div className="field"><label>Customer / event</label><select value={selectedKey} onChange={e=>chooseQueue(e.target.value)}><option value="">Select queue item</option>{queue.map(q=>{const key=`${q.queue_type}:${q.customer_id}:${q.order_id??""}`;return <option key={key} value={key}>{q.customer_name} • {String(q.queue_type).replaceAll("_"," ")} {q.order_no?`• ${q.order_no}`:""}</option>})}</select></div>
        {current&&<><p><b>{current.customer_name}</b> • {current.phone??"No phone"}</p><p>Reason: {current.reason}</p><p>Balance: <b>{ugx(Number(current.balance_due??0))}</b></p><p>WhatsApp preference: <span className={current.whatsapp_opt_in?"badge green":"badge gold"}>{current.whatsapp_opt_in?"Opted In":"No Marketing Opt-In"}</span></p></>}
      </div>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Prepare Message</h3>
        <div className="field"><label>Template</label><select value={templateId} onChange={e=>setTemplateId(e.target.value)}>{templates.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
        <div style={{border:"1px solid var(--line)",borderRadius:14,padding:14,minHeight:160,background:"#fffaf5",whiteSpace:"pre-wrap"}}>{rendered}</div>
        <button className="btn primary" disabled={busy||!current} style={{width:"100%",marginTop:12}} onClick={openWhatsApp}>{busy?"Opening…":"Open in WhatsApp"}</button>
      </div>
    </div>

    <div className="card" style={{marginTop:16}}><h3 style={{color:"var(--brown)",marginTop:0}}>Recent Communication Opens</h3>{logs.length===0?<p style={{color:"var(--muted)"}}>No communication opens logged.</p>:logs.slice(0,20).map(l=><p key={l.id}><b>{l.customer_name??l.recipient_phone_snapshot}</b> • {l.template_name??"Custom"} • {new Date(l.initiated_at).toLocaleString()} <span className="badge gold">{l.status}</span></p>)}</div>
  </>;
}
