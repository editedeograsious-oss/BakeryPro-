'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function CustomCakeManager({
  cakes,customers,shifts,live,role
}:{
  cakes:any[];customers:any[];shifts:any[];live:boolean;role:string;
}){
  const router=useRouter();
  const [selectedId,setSelectedId]=useState(cakes[0]?.order_id??"");
  const [customerId,setCustomerId]=useState(customers[0]?.id??customers[0]?.customer_id??"");
  const [requiredAt,setRequiredAt]=useState("");
  const [fulfillment,setFulfillment]=useState("pickup");
  const [deliveryAddress,setDeliveryAddress]=useState("");
  const [size,setSize]=useState("");
  const [servings,setServings]=useState(0);
  const [tiers,setTiers]=useState(1);
  const [flavour,setFlavour]=useState("");
  const [filling,setFilling]=useState("");
  const [frosting,setFrosting]=useState("");
  const [theme,setTheme]=useState("");
  const [primaryColor,setPrimaryColor]=useState("");
  const [secondaryColor,setSecondaryColor]=useState("");
  const [inscription,setInscription]=useState("");
  const [special,setSpecial]=useState("");
  const [quote,setQuote]=useState(0);
  const [productionNotes,setProductionNotes]=useState("");
  const [deposit,setDeposit]=useState(0);
  const [method,setMethod]=useState("cash");
  const [reference,setReference]=useState("");
  const [shiftId,setShiftId]=useState("");
  const [file,setFile]=useState<File|null>(null);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const createRequest=useRef(crypto.randomUUID());
  const paymentRequest=useRef(crypto.randomUUID());

  const current=cakes.find(c=>c.order_id===selectedId)??cakes[0];
  const canApprove=role==="owner"||role==="manager";

  async function createCake(){
    if(!customerId||!requiredAt){setMessage("Customer and required date/time are required.");return;}
    if(fulfillment==="delivery"&&!deliveryAddress.trim()){setMessage("Delivery address is required.");return;}
    if(tiers<=0){setMessage("Tiers must be greater than zero.");return;}
    if(!live){setMessage("Demo mode: custom cake creation simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("create_custom_cake_order",{
        p_customer_id:customerId,
        p_required_at:new Date(requiredAt).toISOString(),
        p_fulfillment:fulfillment,
        p_delivery_address:fulfillment==="delivery"?deliveryAddress.trim():null,
        p_cake_size_label:size.trim()||null,
        p_servings:servings>0?servings:null,
        p_tiers:tiers,
        p_flavour:flavour.trim()||null,
        p_filling:filling.trim()||null,
        p_frosting:frosting.trim()||null,
        p_theme:theme.trim()||null,
        p_primary_color:primaryColor.trim()||null,
        p_secondary_color:secondaryColor.trim()||null,
        p_inscription:inscription.trim()||null,
        p_special_instructions:special.trim()||null,
        p_client_request_id:createRequest.current,
      });
      if(error)throw error;
      createRequest.current=crypto.randomUUID();

      if(file){
        const ext=file.name.includes(".")?file.name.split(".").pop()!.toLowerCase():"bin";
        const path=`${data}/${crypto.randomUUID()}.${ext}`;
        const upload=await supabase.storage.from("custom-cake-references").upload(path,file,{upsert:false});
        if(upload.error) throw upload.error;
        const savePath=await supabase.rpc("save_custom_cake_reference_path",{p_order_id:data,p_reference_image_path:path});
        if(savePath.error) throw savePath.error;
      }

      setMessage(`Custom cake order created • ${data}`);
      setFile(null);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not create custom cake order.");}
    finally{setBusy(false);}
  }

  async function saveQuote(){
    if(!current){setMessage("Select a custom cake.");return;}
    if(quote<=0){setMessage("Quote must be greater than zero.");return;}
    if(!live){setMessage("Demo mode: quote simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("quote_custom_cake_order",{p_order_id:current.order_id,p_quote_amount:quote,p_production_notes:productionNotes.trim()||null});
      if(error)throw error;
      setMessage("Custom cake quote saved.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save quote.");}
    finally{setBusy(false);}
  }

  async function recordDeposit(){
    if(!current){setMessage("Select a custom cake.");return;}
    if(deposit<=0||deposit>Number(current.balance_due)){setMessage("Deposit must be positive and cannot exceed the balance.");return;}
    if(method!=="cash"&&!reference.trim()){setMessage("Mobile Money reference is required.");return;}
    if(!live){setMessage("Demo mode: deposit simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("record_customer_order_payment",{
        p_order_id:current.order_id,
        p_amount:deposit,
        p_method:method,
        p_reference:reference.trim()||null,
        p_shift_id:shiftId||null,
        p_client_request_id:paymentRequest.current,
      });
      if(error)throw error;
      paymentRequest.current=crypto.randomUUID();
      setDeposit(0);setReference("");
      setMessage(`Deposit recorded • ${data}`);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not record deposit.");}
    finally{setBusy(false);}
  }

  async function approve(){
    if(!current||!canApprove)return;
    if(!live){setMessage("Demo mode: production approval simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("approve_custom_cake_for_production",{p_order_id:current.order_id});
      if(error)throw error;
      setMessage("Custom cake approved for production.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not approve custom cake.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Custom Cakes</h1><p>Design brief, private reference image, quote, deposit and production approval.</p></div><span className="badge green">Private Image Storage</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="card">
      <h3 style={{color:"var(--brown)",marginTop:0}}>New Custom Cake Brief</h3>
      <div className="grid2">
        <div className="field"><label>Customer</label><select value={customerId} onChange={e=>setCustomerId(e.target.value)}>{customers.map(c=><option key={c.id??c.customer_id} value={c.id??c.customer_id}>{c.full_name}</option>)}</select></div>
        <div className="field"><label>Required date/time</label><input type="datetime-local" value={requiredAt} onChange={e=>setRequiredAt(e.target.value)}/></div>
      </div>
      <div className="grid2">
        <div className="field"><label>Fulfillment</label><select value={fulfillment} onChange={e=>setFulfillment(e.target.value)}><option value="pickup">Pickup</option><option value="delivery">Delivery</option></select></div>
        <div className="field"><label>Delivery address</label><input disabled={fulfillment!=="delivery"} value={deliveryAddress} onChange={e=>setDeliveryAddress(e.target.value)}/></div>
      </div>
      <div className="grid2"><div className="field"><label>Size label</label><input value={size} onChange={e=>setSize(e.target.value)} placeholder="2 kg"/></div><div className="field"><label>Servings</label><input type="number" min="0" value={servings} onChange={e=>setServings(Number(e.target.value))}/></div></div>
      <div className="grid2"><div className="field"><label>Tiers</label><input type="number" min="1" value={tiers} onChange={e=>setTiers(Number(e.target.value))}/></div><div className="field"><label>Flavour</label><input value={flavour} onChange={e=>setFlavour(e.target.value)}/></div></div>
      <div className="grid2"><div className="field"><label>Filling</label><input value={filling} onChange={e=>setFilling(e.target.value)}/></div><div className="field"><label>Frosting</label><input value={frosting} onChange={e=>setFrosting(e.target.value)}/></div></div>
      <div className="grid2"><div className="field"><label>Theme</label><input value={theme} onChange={e=>setTheme(e.target.value)}/></div><div className="field"><label>Inscription</label><input value={inscription} onChange={e=>setInscription(e.target.value)}/></div></div>
      <div className="grid2"><div className="field"><label>Primary color</label><input value={primaryColor} onChange={e=>setPrimaryColor(e.target.value)}/></div><div className="field"><label>Secondary color</label><input value={secondaryColor} onChange={e=>setSecondaryColor(e.target.value)}/></div></div>
      <div className="field"><label>Special instructions</label><input value={special} onChange={e=>setSpecial(e.target.value)}/></div>
      <div className="field"><label>Reference image (private bucket)</label><input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]??null)}/></div>
      <button className="btn primary" disabled={busy} onClick={createCake}>{busy?"Working…":"Create Custom Cake Brief"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Order</th><th>Customer</th><th>Design</th><th>Required</th><th>Quote</th><th>Deposit Required</th><th>Paid</th><th>Balance</th><th>Status</th><th>Open</th></tr></thead>
      <tbody>{cakes.length===0?<tr><td colSpan={10}>No custom cakes found.</td></tr>:cakes.map(c=><tr key={c.order_id}><td><b>{c.order_no}</b></td><td>{c.customer_name}</td><td>{c.cake_size_label??"Custom"} • {c.flavour??"—"} • {c.theme??"—"}</td><td>{new Date(c.required_at).toLocaleString()}</td><td>{ugx(Number(c.quote_amount))}</td><td>{ugx(Number(c.deposit_required??0))}</td><td>{ugx(Number(c.amount_paid))}</td><td><b>{ugx(Number(c.balance_due))}</b></td><td><span className={c.design_status==="approved"||c.design_status==="ready"?"badge green":"badge gold"}>{c.design_status}</span></td><td><button className="btn secondary" onClick={()=>{setSelectedId(c.order_id);setQuote(Number(c.quote_amount));setProductionNotes(c.production_notes??"")}}>Open</button></td></tr>)}</tbody>
    </table></div>

    {current&&<div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>{current.order_no} — Quote & Deposit</h3>
        {current.reference_image_url&&<img src={current.reference_image_url} alt="Customer cake reference" style={{width:"100%",maxHeight:260,objectFit:"contain",borderRadius:12,border:"1px solid var(--line)"}}/>}
        <p><b>{current.customer_name}</b> • {current.cake_size_label??"Custom size"} • {current.tiers} tier(s)</p>
        <p>{current.theme??"No theme"} • {current.inscription??"No inscription"}</p>
        <div className="field"><label>Quote (UGX)</label><input type="number" min="0" value={quote} onChange={e=>setQuote(Number(e.target.value))}/></div>
        <div className="field"><label>Production notes</label><input value={productionNotes} onChange={e=>setProductionNotes(e.target.value)}/></div>
        <button className="btn secondary" disabled={busy||role==="baker"} onClick={saveQuote}>Save Quote</button>
        <hr style={{border:0,borderTop:"1px solid var(--line)",margin:"16px 0"}}/>
        <div className="field"><label>Deposit / payment</label><input type="number" min="0" value={deposit} onChange={e=>setDeposit(Number(e.target.value))}/></div>
        <div className="field"><label>Method</label><select value={method} onChange={e=>setMethod(e.target.value)}><option value="cash">Cash</option><option value="mtn_momo">MTN MoMo</option><option value="airtel_money">Airtel Money</option></select></div>
        {method!=="cash"?<div className="field"><label>Reference</label><input value={reference} onChange={e=>setReference(e.target.value)}/></div>:<div className="field"><label>Cashier shift</label><select value={shiftId} onChange={e=>setShiftId(e.target.value)}><option value="">Auto / general cash</option>{shifts.map(s=><option key={s.id} value={s.id}>{s.cashier_name}</option>)}</select></div>}
        <button className="btn primary" disabled={busy||role==="baker"||Number(current.balance_due)<=0} onClick={recordDeposit}>Record Deposit</button>
      </div>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Production Gate</h3>
        <p>Quote: <b>{ugx(Number(current.quote_amount))}</b></p>
        <p>Required deposit: <b>{ugx(Number(current.deposit_required??0))}</b></p>
        <p>Paid: <b>{ugx(Number(current.amount_paid))}</b></p>
        <p>Balance: <b>{ugx(Number(current.balance_due))}</b></p>
        <p>Status: <span className="badge gold">{current.design_status}</span></p>
        <button className="btn primary" style={{width:"100%"}} disabled={!canApprove||busy||Number(current.amount_paid)<Number(current.deposit_required??0)} onClick={approve}>Approve for Production</button>
        {!canApprove&&<p style={{color:"var(--muted)",fontSize:12}}>Only Owner/Manager can approve production.</p>}
      </div>
    </div>}
  </>;
}
