'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function DeliveryManager({jobs,riders,orders,live,role}:{jobs:any[];riders:any[];orders:any[];live:boolean;role:string}){
  const router=useRouter();
  const [orderId,setOrderId]=useState(orders[0]?.id??"");
  const order=orders.find(o=>o.id===orderId);
  const [charge,setCharge]=useState(0);
  const [address,setAddress]=useState(order?.delivery_address??"");
  const [scheduled,setScheduled]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  function chooseOrder(id:string){
    setOrderId(id);
    const o=orders.find(x=>x.id===id);
    setAddress(o?.delivery_address??"");
  }

  async function createJob(){
    if(!orderId||!address.trim()){setMessage("Delivery order and address are required.");return;}
    if(charge<0){setMessage("Delivery charge cannot be negative.");return;}
    if(!live){setMessage("Demo mode: delivery job creation simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("create_delivery_job",{
        p_order_id:orderId,
        p_delivery_charge:charge,
        p_address:address.trim(),
        p_scheduled_for:scheduled?new Date(scheduled).toISOString():null,
        p_client_request_id:requestId.current,
      });
      if(error)throw error;
      setMessage(`Delivery job created • ${data}`);
      requestId.current=crypto.randomUUID();
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not create delivery job.");}
    finally{setBusy(false);}
  }

  async function assign(jobId:string,riderId:string){
    if(!riderId){setMessage("Choose a rider.");return;}
    if(!live){setMessage("Demo mode: rider assignment simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("assign_delivery_rider",{p_delivery_id:jobId,p_rider_id:riderId});
      if(error)throw error;
      setMessage("Rider assigned.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not assign rider.");}
    finally{setBusy(false);}
  }

  async function status(jobId:string,next:string){
    let note:string|null=null;
    if(next==="failed"){
      note=window.prompt("Failure reason")?.trim()||null;
      if(!note){setMessage("Failure reason is required.");return;}
    }
    if(!live){setMessage(`Demo mode: delivery moved to ${next}.`);return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("update_delivery_status",{p_delivery_id:jobId,p_status:next,p_note:note});
      if(error)throw error;
      setMessage(`Delivery moved to ${next}.`);
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update delivery.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Deliveries</h1><p>Delivery jobs, rider assignment, dispatch and completion — separate from payment status.</p></div><span className="badge green">Status-Based Delivery</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Open Jobs</div><div className="value">{jobs.filter(j=>!["delivered","cancelled"].includes(j.status)).length}</div></div>
      <div className="card stat"><div className="label">Out for Delivery</div><div className="value">{jobs.filter(j=>j.status==="out_for_delivery").length}</div></div>
      <div className="card stat"><div className="label">Delivered</div><div className="value">{jobs.filter(j=>j.status==="delivered").length}</div></div>
      <div className="card stat"><div className="label">Unpaid Delivery Balances</div><div className="value">{ugx(jobs.reduce((s,j)=>s+Number(j.balance_due||0),0))}</div></div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Create Delivery Job</h3>
      <div className="grid2">
        <div className="field"><label>Delivery order</label><select value={orderId} onChange={e=>chooseOrder(e.target.value)}><option value="">Select order</option>{orders.map(o=><option key={o.id} value={o.id}>{o.order_no} • {o.customer_name}</option>)}</select></div>
        <div className="field"><label>Delivery charge (UGX)</label><input type="number" min="0" value={charge} onChange={e=>setCharge(Number(e.target.value))}/></div>
      </div>
      <div className="grid2"><div className="field"><label>Address</label><input value={address} onChange={e=>setAddress(e.target.value)}/></div><div className="field"><label>Scheduled date/time</label><input type="datetime-local" value={scheduled} onChange={e=>setScheduled(e.target.value)}/></div></div>
      <button className="btn primary" disabled={busy} onClick={createJob}>{busy?"Working…":"Create Delivery Job"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Order</th><th>Customer</th><th>Address</th><th>Scheduled</th><th>Rider</th><th>Balance</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>{jobs.length===0?<tr><td colSpan={8}>No delivery jobs found.</td></tr>:jobs.map(j=><tr key={j.id}>
        <td><b>{j.order_no}</b></td><td>{j.customer_name}<br/><small>{j.customer_phone??""}</small></td><td>{j.delivery_address}</td><td>{j.scheduled_for?new Date(j.scheduled_for).toLocaleString():"—"}</td><td>{j.rider_name??"Unassigned"}</td><td><b>{ugx(Number(j.balance_due||0))}</b></td>
        <td><span className={j.status==="delivered"?"badge green":j.status==="failed"?"badge red":"badge gold"}>{j.status}</span></td>
        <td><div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
          {!["delivered","cancelled"].includes(j.status)&&<select defaultValue={j.rider_id??""} onChange={e=>assign(j.id,e.target.value)}><option value="">Assign rider</option>{riders.filter(r=>r.active).map(r=><option key={r.rider_id} value={r.rider_id}>{r.full_name} ({r.active_jobs} jobs)</option>)}</select>}
          {(j.status==="assigned"||j.status==="failed")&&<button className="btn primary" disabled={busy} onClick={()=>status(j.id,"out_for_delivery")}>Dispatch</button>}
          {j.status==="out_for_delivery"&&<><button className="btn primary" disabled={busy} onClick={()=>status(j.id,"delivered")}>Delivered</button><button className="btn secondary" disabled={busy} onClick={()=>status(j.id,"failed")}>Failed</button></>}
          {role!=="cashier"&&j.status!=="delivered"&&j.status!=="cancelled"&&<button className="btn secondary" disabled={busy} onClick={()=>status(j.id,"cancelled")}>Cancel</button>}
        </div></td>
      </tr>)}</tbody>
    </table></div>
    <div className="hero" style={{marginTop:16}}><h2>Delivered does not mean Paid</h2><p>A delivered order may still show a customer balance. Delivery status never creates a payment entry.</p></div>
  </>;
}
