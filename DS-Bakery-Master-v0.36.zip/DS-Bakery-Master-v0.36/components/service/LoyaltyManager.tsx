'use client';

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";

export default function LoyaltyManager({
  customers,ledger,settings,orders,live,role
}:{
  customers:any[];ledger:any[];settings:any;orders:any[];live:boolean;role:string;
}){
  const router=useRouter();
  const [selected,setSelected]=useState(customers[0]?.customer_id??"");
  const [points,setPoints]=useState(0);
  const [reason,setReason]=useState("");
  const [redeemOrderId,setRedeemOrderId]=useState("");
  const [redeemPoints,setRedeemPoints]=useState(Number(settings?.reward_points??100));
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const [earnAmount,setEarnAmount]=useState(Number(settings?.earn_amount_per_point??1000));
  const [rewardBlock,setRewardBlock]=useState(Number(settings?.reward_points??100));
  const [rewardValue,setRewardValue]=useState(Number(settings?.reward_value??5000));
  const [birthdayDays,setBirthdayDays]=useState(Number(settings?.birthday_reminder_days??30));
  const redeemRequest=useRef(crypto.randomUUID());
  const adjustRequest=useRef(crypto.randomUUID());
  const current=customers.find(c=>c.customer_id===selected)??customers[0];
  const currentLedger=ledger.filter(l=>l.customer_id===selected);
  const customerOrders=orders.filter(o=>o.customer_id===selected);
  const outstanding=customers.reduce((s,c)=>s+Number(c.points_balance||0),0);
  const canAdjust=role==="owner"||role==="manager";

  async function adjust(){
    if(!current||points===0||!reason.trim()){setMessage("Enter non-zero points and a reason.");return;}
    if(!canAdjust){setMessage("Only Owner/Manager can manually adjust points.");return;}
    if(!live){setMessage("Demo mode: points adjustment simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("adjust_customer_loyalty_points",{
        p_customer_id:current.customer_id,p_points:points,p_reason:reason.trim(),
        p_event_type:"manual_adjustment",p_client_request_id:adjustRequest.current
      });
      if(error)throw error;
      setMessage(`Points adjusted • ${data}`);adjustRequest.current=crypto.randomUUID();setPoints(0);setReason("");router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not adjust points.");}
    finally{setBusy(false);}
  }

  async function redeem(){
    if(!redeemOrderId||redeemPoints<=0){setMessage("Choose an order and positive points.");return;}
    if(!live){setMessage("Demo mode: loyalty redemption simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("redeem_loyalty_on_order",{
        p_order_id:redeemOrderId,p_points:redeemPoints,p_client_request_id:redeemRequest.current
      });
      if(error)throw error;
      setMessage(`Reward applied • ${ugx(Number(data))} discount`);
      redeemRequest.current=crypto.randomUUID();
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not redeem points.");}
    finally{setBusy(false);}
  }


  async function saveSettings(){
    if(role!=="owner"){setMessage("Only Owner can update loyalty settings.");return;}
    if(earnAmount<=0||rewardBlock<=0||rewardValue<0||birthdayDays<1||birthdayDays>90){
      setMessage("Enter valid loyalty settings.");return;
    }
    if(!live){setMessage("Demo mode: loyalty settings save simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("update_loyalty_settings",{
        p_earn_amount_per_point:earnAmount,
        p_reward_points:rewardBlock,
        p_reward_value:rewardValue,
        p_birthday_reminder_days:birthdayDays,
        p_vip_spend_threshold:Number(settings?.vip_spend_threshold??1000000),
        p_regular_spend_threshold:Number(settings?.regular_spend_threshold??500000),
        p_regular_order_threshold:Number(settings?.regular_order_threshold??5),
      });
      if(error)throw error;
      setMessage("Loyalty settings updated.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update loyalty settings.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Loyalty & Rewards</h1><p>Ledger-based points, rewards and customer value.</p></div><span className="badge green">Live Loyalty Ledger</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="hero"><h2>Current configurable rule</h2><p>Earn 1 point per <b>{ugx(Number(settings?.earn_amount_per_point??1000))}</b> eligible value. Reward block: <b>{Number(settings?.reward_points??100)} points = {ugx(Number(settings?.reward_value??5000))}</b>.</p></div>
    {role==="owner"&&<div className="card" style={{marginBottom:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Owner Loyalty Settings</h3>
      <div className="grid4">
        <div className="field"><label>UGX per point</label><input type="number" min="1" value={earnAmount} onChange={e=>setEarnAmount(Number(e.target.value))}/></div>
        <div className="field"><label>Reward points block</label><input type="number" min="1" value={rewardBlock} onChange={e=>setRewardBlock(Number(e.target.value))}/></div>
        <div className="field"><label>Reward value (UGX)</label><input type="number" min="0" value={rewardValue} onChange={e=>setRewardValue(Number(e.target.value))}/></div>
        <div className="field"><label>Birthday reminder days</label><input type="number" min="1" max="90" value={birthdayDays} onChange={e=>setBirthdayDays(Number(e.target.value))}/></div>
      </div>
      <button className="btn secondary" disabled={busy} onClick={saveSettings}>Save Loyalty Settings</button>
    </div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Loyalty Customers</div><div className="value">{customers.length}</div></div>
      <div className="card stat"><div className="label">Points Outstanding</div><div className="value">{outstanding.toLocaleString()}</div></div>
      <div className="card stat"><div className="label">VIP</div><div className="value">{customers.filter(c=>c.customer_segment==="VIP").length}</div></div>
      <div className="card stat"><div className="label">Reward Value</div><div className="value">{ugx(Number(settings?.reward_value??0))}</div></div>
    </div>

    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Customer</th><th>Segment</th><th>Transactions</th><th>Lifetime Value</th><th>Points</th><th>Open</th></tr></thead>
      <tbody>{customers.length===0?<tr><td colSpan={6}>No loyalty customers found.</td></tr>:customers.map(c=><tr key={c.customer_id}><td><b>{c.full_name}</b><br/><small>{c.phone??""}</small></td><td><span className={c.customer_segment==="VIP"?"badge green":"badge gold"}>{c.customer_segment}</span></td><td>{Number(c.order_count||0)}</td><td>{ugx(Number(c.lifetime_value||0))}</td><td><b>{Number(c.points_balance||0).toLocaleString()}</b></td><td><button className="btn secondary" onClick={()=>{setSelected(c.customer_id);setRedeemOrderId("")}}>Open</button></td></tr>)}</tbody>
    </table></div>

    {current&&<div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>{current.full_name}</h3>
        <p>Segment: <b>{current.customer_segment}</b></p><p>Available points: <b>{Number(current.points_balance).toLocaleString()}</b></p><p>Lifetime value: <b>{ugx(Number(current.lifetime_value))}</b></p>
        <h4>Redeem on Customer Order</h4>
        <div className="field"><label>Open order</label><select value={redeemOrderId} onChange={e=>setRedeemOrderId(e.target.value)}><option value="">Select order</option>{customerOrders.map(o=><option key={o.id} value={o.id}>{o.order_no} • {ugx(Number(o.balance_due))} balance</option>)}</select></div>
        <div className="field"><label>Points</label><input type="number" min={Number(settings?.reward_points??100)} step={Number(settings?.reward_points??100)} value={redeemPoints} onChange={e=>setRedeemPoints(Number(e.target.value))}/></div>
        <button className="btn primary" disabled={busy} onClick={redeem}>Apply Reward</button>
        {canAdjust&&<><hr style={{border:0,borderTop:"1px solid var(--line)",margin:"16px 0"}}/><h4>Manual Adjustment</h4><div className="field"><label>Points (+ or -)</label><input type="number" value={points} onChange={e=>setPoints(Number(e.target.value))}/></div><div className="field"><label>Reason</label><input value={reason} onChange={e=>setReason(e.target.value)}/></div><button className="btn secondary" disabled={busy} onClick={adjust}>Adjust Points</button></>}
      </div>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Points History</h3>
        {currentLedger.length===0?<p style={{color:"var(--muted)"}}>No points activity.</p>:currentLedger.map(l=><div key={l.id} style={{display:"flex",justifyContent:"space-between",gap:12,borderBottom:"1px solid #f0e6da",padding:"9px 0"}}><span><b>{String(l.event_type).replaceAll("_"," ")}</b><br/><small>{new Date(l.created_at).toLocaleString()} • {l.reason}</small></span><b style={{color:Number(l.points_delta)>=0?"var(--green)":"var(--red)"}}>{Number(l.points_delta)>0?"+":""}{l.points_delta}</b></div>)}
      </div>
    </div>}
  </>;
}
