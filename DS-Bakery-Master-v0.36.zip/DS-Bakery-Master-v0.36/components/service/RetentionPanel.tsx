'use client';

import { ugx } from "@/lib/costing";

export default function RetentionPanel({customers,birthdays}:{customers:any[];birthdays:any[]}){
  const repeat=customers.filter(c=>Number(c.order_count||0)>1).length;
  const top=[...customers].sort((a,b)=>Number(b.lifetime_value)-Number(a.lifetime_value))[0];
  return <>
    <div className="pagehead"><div><h1>Customer Retention</h1><p>Live birthday reminders, segments and repeat-customer insights.</p></div><span className="badge gold">Retention View</span></div>
    <div className="grid4">
      <div className="card stat"><div className="label">VIP Customers</div><div className="value">{customers.filter(c=>c.customer_segment==="VIP").length}</div></div>
      <div className="card stat"><div className="label">Regular Customers</div><div className="value">{customers.filter(c=>c.customer_segment==="Regular").length}</div></div>
      <div className="card stat"><div className="label">Birthdays Next 30 Days</div><div className="value">{birthdays.length}</div></div>
      <div className="card stat"><div className="label">Repeat-Customer Rate</div><div className="value">{customers.length?Math.round(repeat/customers.length*100):0}%</div></div>
    </div>
    <div className="grid2" style={{marginTop:16}}>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Upcoming Birthdays</h3>{birthdays.length===0?<p style={{color:"var(--muted)"}}>No birthdays in the current reminder window.</p>:birthdays.map(b=><div key={b.customer_id} style={{padding:"10px 0",borderBottom:"1px solid #f0e6da"}}><b>{b.full_name}</b> <span className="badge gold">{b.days_until_birthday} days</span><p style={{margin:"5px 0",color:"var(--muted)"}}>{b.next_birthday} • {Number(b.points_balance||0).toLocaleString()} points</p></div>)}</div>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Repeat-Customer Insights</h3><p>Repeat customers: <b>{repeat} of {customers.length}</b></p><p>Highest lifetime value: <b>{top?.full_name??"—"}</b></p><p>Top lifetime value: <b>{ugx(Number(top?.lifetime_value??0))}</b></p><p>Largest points balance: <b>{Math.max(0,...customers.map(c=>Number(c.points_balance||0))).toLocaleString()}</b></p></div>
    </div>
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Customer</th><th>Segment</th><th>Transactions</th><th>Lifetime Value</th><th>Points</th><th>Last Activity</th></tr></thead><tbody>{customers.map(c=><tr key={c.customer_id}><td><b>{c.full_name}</b></td><td>{c.customer_segment}</td><td>{c.order_count}</td><td>{ugx(Number(c.lifetime_value))}</td><td>{Number(c.points_balance).toLocaleString()}</td><td>{c.last_order_at?new Date(c.last_order_at).toLocaleDateString():"—"}</td></tr>)}</tbody></table></div>
  </>;
}
