'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function RiderManager({riders,live}:{riders:any[];live:boolean}){
  const router=useRouter();
  const [selected,setSelected]=useState<any|null>(null);
  const [name,setName]=useState("");
  const [phone,setPhone]=useState("");
  const [vehicle,setVehicle]=useState("");
  const [active,setActive]=useState(true);
  const [notes,setNotes]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  function edit(r:any){setSelected(r);setName(r.full_name);setPhone(r.phone);setVehicle(r.vehicle_label??"");setActive(Boolean(r.active));setNotes("");}
  function clear(){setSelected(null);setName("");setPhone("");setVehicle("");setActive(true);setNotes("");requestId.current=crypto.randomUUID();}

  async function save(){
    if(!name.trim()||!phone.trim()){setMessage("Rider name and phone are required.");return;}
    if(!live){setMessage("Demo mode: rider save simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("save_delivery_rider",{
        p_rider_id:selected?.rider_id??null,
        p_full_name:name.trim(),p_phone:phone.trim(),p_vehicle_label:vehicle.trim()||null,
        p_active:active,p_notes:notes.trim()||null,p_client_request_id:requestId.current,
      });
      if(error)throw error;
      setMessage(`Rider saved • ${data}`);clear();router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save rider.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Delivery Riders</h1><p>Owner/Manager rider directory and workload.</p></div><button className="btn primary" onClick={clear}>+ New Rider</button></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="grid4">
      <div className="card stat"><div className="label">Active Riders</div><div className="value">{riders.filter(r=>r.active).length}</div></div>
      <div className="card stat"><div className="label">Active Jobs</div><div className="value">{riders.reduce((s,r)=>s+Number(r.active_jobs||0),0)}</div></div>
      <div className="card stat"><div className="label">Delivered Today</div><div className="value">{riders.reduce((s,r)=>s+Number(r.delivered_today||0),0)}</div></div>
      <div className="card stat"><div className="label">Inactive Riders</div><div className="value">{riders.filter(r=>!r.active).length}</div></div>
    </div>
    <div className="grid2" style={{marginTop:16}}>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>{selected?"Edit Rider":"New Rider"}</h3>
        <div className="field"><label>Full name</label><input value={name} onChange={e=>setName(e.target.value)}/></div>
        <div className="field"><label>Phone</label><input value={phone} onChange={e=>setPhone(e.target.value)}/></div>
        <div className="field"><label>Vehicle</label><input value={vehicle} onChange={e=>setVehicle(e.target.value)}/></div>
        <div className="field"><label>Notes</label><input value={notes} onChange={e=>setNotes(e.target.value)}/></div>
        <label style={{display:"flex",gap:8,alignItems:"center",margin:"10px 0"}}><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/> Active rider</label>
        <button className="btn primary" disabled={busy} onClick={save}>{busy?"Saving…":"Save Rider"}</button>
      </div>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Rider Workload</h3>{riders.map(r=><p key={r.rider_id}><b>{r.full_name}</b> • {r.active_jobs} active • {r.delivered_today} delivered today <button className="btn secondary" style={{float:"right"}} onClick={()=>edit(r)}>Edit</button></p>)}</div>
    </div>
  </>;
}
