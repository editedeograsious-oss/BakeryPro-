'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function TemplateManager({templates,live,role}:{templates:any[];live:boolean;role:string}){
  const router=useRouter();
  const [selected,setSelected]=useState<any|null>(null);
  const [name,setName]=useState("");
  const [type,setType]=useState("custom");
  const [body,setBody]=useState("");
  const [marketing,setMarketing]=useState(false);
  const [active,setActive]=useState(true);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());
  const canManage=role==="owner"||role==="manager";

  function clear(){setSelected(null);setName("");setType("custom");setBody("");setMarketing(false);setActive(true);requestId.current=crypto.randomUUID();}
  function edit(t:any){setSelected(t);setName(t.name);setType(t.template_type);setBody(t.body_template);setMarketing(Boolean(t.requires_marketing_opt_in));setActive(Boolean(t.active));}

  async function save(){
    if(!canManage)return;
    if(!name.trim()||!body.trim()){setMessage("Template name and message body are required.");return;}
    if(!live){setMessage("Demo mode: template save simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("save_communication_template",{
        p_template_id:selected?.id??null,p_name:name.trim(),p_template_type:type,
        p_body_template:body.trim(),p_requires_marketing_opt_in:marketing,p_active:active,
        p_client_request_id:requestId.current,
      });
      if(error)throw error;
      setMessage(`Template saved • ${data}`);clear();router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save template.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Message Templates</h1><p>Live owner/manager-controlled WhatsApp wording.</p></div><button className="btn primary" disabled={!canManage} onClick={clear}>+ New Template</button></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    {canManage&&<div className="card">
      <h3 style={{color:"var(--brown)",marginTop:0}}>{selected?"Edit Template":"New Template"}</h3>
      <div className="grid2"><div className="field"><label>Name</label><input value={name} onChange={e=>setName(e.target.value)}/></div><div className="field"><label>Type</label><select value={type} onChange={e=>setType(e.target.value)}><option value="ready_for_pickup">Ready for pickup</option><option value="in_production">In production</option><option value="out_for_delivery">Out for delivery</option><option value="birthday">Birthday</option><option value="balance_reminder">Balance reminder</option><option value="custom">Custom</option></select></div></div>
      <div className="field"><label>Message body</label><textarea value={body} onChange={e=>setBody(e.target.value)} rows={5}/></div>
      <label style={{display:"flex",gap:8,alignItems:"center",margin:"8px 0"}}><input type="checkbox" checked={marketing} onChange={e=>setMarketing(e.target.checked)}/> Requires marketing opt-in</label>
      <label style={{display:"flex",gap:8,alignItems:"center",margin:"8px 0 14px"}}><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/> Active</label>
      <button className="btn primary" disabled={busy} onClick={save}>{busy?"Saving…":"Save Template"}</button>
    </div>}
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Name</th><th>Type</th><th>Message</th><th>Opt-In</th><th>Status</th><th>Action</th></tr></thead><tbody>{templates.map(t=><tr key={t.id}><td><b>{t.name}</b></td><td><code>{t.template_type}</code></td><td style={{maxWidth:480}}>{t.body_template}</td><td>{t.requires_marketing_opt_in?"Required":"No"}</td><td><span className={t.active?"badge green":"badge gold"}>{t.active?"Active":"Inactive"}</span></td><td>{canManage?<button className="btn secondary" onClick={()=>edit(t)}>Edit</button>:"—"}</td></tr>)}</tbody></table></div>
    <div className="hero" style={{marginTop:16}}><h2>Supported placeholders</h2><p><code>{"{{customer_name}}"}</code> • <code>{"{{order_no}}"}</code> • <code>{"{{balance}}"}</code> • <code>{"{{required_at}}"}</code> • <code>{"{{rider_name}}"}</code></p></div>
  </>;
}
