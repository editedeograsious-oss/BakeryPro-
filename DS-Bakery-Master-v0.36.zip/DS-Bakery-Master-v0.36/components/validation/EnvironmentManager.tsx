'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function EnvironmentManager({config,live}:{config:any;live:boolean}){
  const router=useRouter();
  const [mode,setMode]=useState(config?.environment_mode==="production"?"production":"staging");
  const [allowTests,setAllowTests]=useState(Boolean(config?.allow_staging_test_accounts));
  const [notes,setNotes]=useState(config?.notes??"");
  const [confirmation,setConfirmation]=useState("");
  const [lockConfirmation,setLockConfirmation]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function save(){
    if(mode==="production"&&allowTests){
      setMessage("Staging test accounts cannot be enabled in production.");
      return;
    }
    const expected=mode==="production"?"CONFIRM PRODUCTION":"CONFIRM STAGING";
    if(confirmation!==expected){
      setMessage(`Type ${expected} exactly.`);
      return;
    }
    if(!live){
      setMessage("Demo mode: environment change simulated.");
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("configure_system_environment",{
        p_environment_mode:mode,
        p_allow_staging_test_accounts:allowTests,
        p_notes:notes.trim()||null,
        p_confirmation:confirmation,
      });
      if(error)throw error;
      setMessage("Environment configuration updated.");
      setConfirmation("");
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not update environment.");
    }finally{
      setBusy(false);
    }
  }

  async function lockProduction(){
    if(lockConfirmation!=="LOCK PRODUCTION"){
      setMessage("Type LOCK PRODUCTION exactly.");
      return;
    }
    if(!live){
      setMessage("Demo mode: production lock simulated.");
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("enable_production_lock",{
        p_confirmation:lockConfirmation,
      });
      if(error)throw error;
      setMessage("Production lock enabled.");
      setLockConfirmation("");
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not enable production lock.");
    }finally{
      setBusy(false);
    }
  }

  return <>
    <div className="pagehead">
      <div><h1>Environment Safety</h1><p>Explicitly separate staging from production before running test accounts or go-live actions.</p></div>
      <span className={config?.environment_mode==="production"?"badge red":config?.environment_mode==="staging"?"badge gold":"badge red"}>{String(config?.environment_mode??"unconfigured").toUpperCase()}</span>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Current Mode</div><div className="value" style={{fontSize:20}}>{config?.environment_mode??"unconfigured"}</div></div>
      <div className="card stat"><div className="label">Staging Test Accounts</div><div className="value" style={{fontSize:20}}>{config?.allow_staging_test_accounts?"Enabled":"Disabled"}</div></div>
      <div className="card stat"><div className="label">Production Lock</div><div className="value" style={{fontSize:20}}>{config?.production_lock?"Locked":"Not Locked"}</div></div>
      <div className="card stat"><div className="label">Last Update</div><div className="value" style={{fontSize:15}}>{config?.updated_at?new Date(config.updated_at).toLocaleString():"—"}</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Configure Environment</h3>
        <div className="field"><label>Environment</label><select value={mode} disabled={Boolean(config?.production_lock)} onChange={e=>{setMode(e.target.value);if(e.target.value==="production")setAllowTests(false)}}><option value="staging">Staging</option><option value="production">Production</option></select></div>
        <label style={{display:"flex",gap:8,alignItems:"center",margin:"10px 0 14px"}}><input type="checkbox" disabled={mode==="production"||Boolean(config?.production_lock)} checked={allowTests} onChange={e=>setAllowTests(e.target.checked)}/> Allow staging test accounts</label>
        <div className="field"><label>Notes</label><textarea rows={3} value={notes} onChange={e=>setNotes(e.target.value)}/></div>
        <div className="field"><label>Confirmation</label><input value={confirmation} onChange={e=>setConfirmation(e.target.value)} placeholder={mode==="production"?"CONFIRM PRODUCTION":"CONFIRM STAGING"}/></div>
        <button className="btn primary" disabled={busy||Boolean(config?.production_lock)} onClick={save}>Save Environment</button>
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Production Lock</h3>
        <p style={{color:"var(--muted)",lineHeight:1.6}}>After the real production environment is validated, the Owner can lock it. A locked production environment cannot be changed back to staging through the normal application.</p>
        <div className="field"><label>Type LOCK PRODUCTION</label><input disabled={Boolean(config?.production_lock)} value={lockConfirmation} onChange={e=>setLockConfirmation(e.target.value)}/></div>
        <button className="btn secondary" disabled={busy||Boolean(config?.production_lock)||config?.environment_mode!=="production"} onClick={lockProduction}>{config?.production_lock?"Production Locked":"Enable Production Lock"}</button>
      </div>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>Safety rule</h2>
      <p>The automated staging user creator should run only when this database says <b>staging</b> and <b>staging test accounts are enabled</b>. Production mode forces that option off.</p>
    </div>
  </>;
}
