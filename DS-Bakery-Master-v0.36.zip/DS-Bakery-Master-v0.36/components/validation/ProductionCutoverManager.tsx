'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function ProductionCutoverManager({
  status,live,role
}:{status:any;live:boolean;role:string}){
  const router=useRouter();
  const [authorization,setAuthorization]=useState("");
  const [suspensionReason,setSuspensionReason]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  const isOwner=role==="owner";

  async function authorize(){
    if(!isOwner){
      setMessage("Only Owner can authorize or resume live operations.");
      return;
    }
    if(authorization!=="AUTHORIZE LIVE OPERATIONS"){
      setMessage("Type AUTHORIZE LIVE OPERATIONS exactly.");
      return;
    }
    if(!live){
      setMessage("Demo mode: live-operation authorization simulated.");
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("authorize_production_operations",{
        p_confirmation:authorization,
      });
      if(error)throw error;
      setAuthorization("");
      setMessage("Live business operations authorized.");
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not authorize live operations.");
    }finally{
      setBusy(false);
    }
  }

  async function suspend(){
    if(!suspensionReason.trim()){
      setMessage("Suspension reason is required.");
      return;
    }
    if(!live){
      setMessage("Demo mode: production suspension simulated.");
      return;
    }

    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("suspend_production_operations",{
        p_reason:suspensionReason.trim(),
      });
      if(error)throw error;
      setSuspensionReason("");
      setMessage("Live business operations suspended.");
      router.refresh();
    }catch(e){
      setMessage(e instanceof Error?e.message:"Could not suspend operations.");
    }finally{
      setBusy(false);
    }
  }

  const prerequisites=[
    ["Environment is Production",status?.environment_mode==="production"],
    ["Production Lock enabled",Boolean(status?.production_lock)],
    ["Go-Live Setup completed",Boolean(status?.go_live_setup_completed)],
  ] as const;

  return <>
    <div className="pagehead">
      <div><h1>Production Cutover</h1><p>Final authorization for real sales, payments, stock movements and production transactions.</p></div>
      <span className={status?.operations_enabled?"badge green":"badge red"}>{status?.operations_enabled?"LIVE OPERATIONS ENABLED":"TRANSACTIONS BLOCKED"}</span>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Environment</div><div className="value" style={{fontSize:19}}>{status?.environment_mode??"unconfigured"}</div></div>
      <div className="card stat"><div className="label">Production Lock</div><div className="value" style={{fontSize:19}}>{status?.production_lock?"Enabled":"Off"}</div></div>
      <div className="card stat"><div className="label">Go-Live Setup</div><div className="value" style={{fontSize:19}}>{status?.go_live_setup_completed?"Complete":"Incomplete"}</div></div>
      <div className="card stat"><div className="label">Operations</div><div className="value" style={{fontSize:19}}>{status?.operations_enabled?"Enabled":"Blocked"}</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Authorization Prerequisites</h3>
        {prerequisites.map(([name,ok])=><div key={name} style={{display:"flex",justifyContent:"space-between",gap:12,padding:"11px 0",borderBottom:"1px solid #f0e6da"}}>
          <b>{name}</b><span className={ok?"badge green":"badge red"}>{ok?"PASS":"NOT READY"}</span>
        </div>)}
        {status?.authorized_at&&<p style={{marginTop:14}}><b>Last authorized:</b> {new Date(status.authorized_at).toLocaleString()}</p>}
        {status?.suspended_at&&<p><b>Last suspended:</b> {new Date(status.suspended_at).toLocaleString()}<br/><span style={{color:"var(--muted)"}}>{status.suspension_reason}</span></p>}
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Authorize / Resume Operations</h3>
        <p style={{color:"var(--muted)",lineHeight:1.6}}>Only Owner can enable real production operations. This is rejected unless Production mode, Production Lock and Go-Live Setup are all complete.</p>
        <div className="field"><label>Type AUTHORIZE LIVE OPERATIONS</label><input disabled={!isOwner||busy||Boolean(status?.operations_enabled)} value={authorization} onChange={e=>setAuthorization(e.target.value)}/></div>
        <button className="btn primary" disabled={!isOwner||busy||Boolean(status?.operations_enabled)||!status?.ready_to_authorize} onClick={authorize}>{status?.operations_enabled?"Operations Already Enabled":"Authorize Live Operations"}</button>
        {!isOwner&&<p style={{color:"var(--muted)",fontSize:12}}>Manager can view and suspend operations, but cannot enable them.</p>}
      </div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Emergency Suspension</h3>
      <p style={{color:"var(--muted)",lineHeight:1.6}}>Owner or Manager can stop new critical transactional writes if there is a cash, stock, payment, security or reconciliation problem. Owner authorization is required to resume.</p>
      <div className="field"><label>Suspension reason</label><input value={suspensionReason} onChange={e=>setSuspensionReason(e.target.value)} placeholder="Example: Till reconciliation issue under review"/></div>
      <button className="btn secondary" disabled={busy||!status?.operations_enabled} onClick={suspend}>Suspend Live Operations</button>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>What the production gate blocks</h2>
      <p>When a live production environment is not authorized, critical writes to sales, payments, refunds, customer orders, purchases, supplier payments, inventory transactions, production runs, waste, expenses and cash movements are blocked at the database layer.</p>
    </div>
  </>;
}
