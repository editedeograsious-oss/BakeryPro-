'use client';

export default function StagingConnectionPanel({env,summary,demo}:{env:any;summary:any;demo:boolean}){
  const checks=[
    ["Public Supabase URL",env.publicUrlConfigured,env.projectHost??"Not configured"],
    ["Anon Key",env.anonKeyConfigured,env.anonKeyConfigured?"Configured":"Missing"],
    ["Service Role",env.serviceRoleConfigured,env.serviceRoleConfigured?"Server secret configured":"Missing"],
    ["Database URL",env.databaseUrlConfigured,env.databaseUrlConfigured?"Configured for psql/backup":"Missing"],
  ] as const;

  const latest=Array.isArray(summary?.latest_checks)?summary.latest_checks:[];

  return <>
    <div className="pagehead">
      <div><h1>Staging Connection</h1><p>Connect and verify the real non-production Supabase environment without exposing secrets in the UI.</p></div>
      <span className={demo?"badge gold":summary?.environment_mode==="staging"?"badge green":"badge red"}>{demo?"DEMO":"LIVE CHECK"}</span>
    </div>

    <div className="hero">
      <h2>DS Bakery v{summary?.release?.app_version??"0.29.0"} • Migration {String(summary?.release?.latest_migration??28).padStart(3,"0")}</h2>
      <p>This page shows only whether connection settings exist and the safe project host. It never displays the anon key, service-role key or database password.</p>
    </div>

    <div className="grid4">
      <div className="card stat"><div className="label">Environment</div><div className="value" style={{fontSize:18}}>{summary?.environment_mode??"unconfigured"}</div></div>
      <div className="card stat"><div className="label">Test Accounts</div><div className="value" style={{fontSize:18}}>{summary?.allow_staging_test_accounts?"Enabled":"Disabled"}</div></div>
      <div className="card stat"><div className="label">Passed Connection Checks</div><div className="value">{Number(summary?.pass_count??0)}</div></div>
      <div className="card stat"><div className="label">Failed Connection Checks</div><div className="value">{Number(summary?.fail_count??0)}</div></div>
    </div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Server Environment</h3>
        {checks.map(([name,ok,detail])=><div key={name} style={{padding:"10px 0",borderBottom:"1px solid #f0e6da"}}>
          <div style={{display:"flex",justifyContent:"space-between",gap:12}}><b>{name}</b><span className={ok?"badge green":"badge red"}>{ok?"READY":"MISSING"}</span></div>
          <p style={{color:"var(--muted)",fontSize:12,margin:"5px 0 0"}}>{detail}</p>
        </div>)}
      </div>

      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Connection Evidence</h3>
        {latest.length===0?<p style={{color:"var(--muted)"}}>No recorded connection checks yet.</p>:latest.map((c:any)=><div key={c.check_type} style={{padding:"10px 0",borderBottom:"1px solid #f0e6da"}}>
          <div style={{display:"flex",justifyContent:"space-between",gap:12}}><b>{String(c.check_type).replaceAll("_"," ")}</b><span className={c.status==="pass"?"badge green":c.status==="fail"?"badge red":"badge gold"}>{String(c.status).toUpperCase()}</span></div>
          <p style={{color:"var(--muted)",fontSize:12,margin:"5px 0 0"}}>{c.detail??"—"}</p>
        </div>)}
      </div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Recommended Real Staging Sequence</h3>
      <ol style={{lineHeight:1.8,color:"var(--muted)"}}>
        <li>Create/connect a non-production Supabase project.</li>
        <li>Apply <code>supabase/schema.sql</code> to an empty staging database.</li>
        <li>Configure the database as <b>Staging</b> in Environment Safety.</li>
        <li>Configure local/server staging environment variables privately.</li>
        <li>Run <code>npm run staging:connection-check</code>.</li>
        <li>Run <code>npm run staging:full-check</code>.</li>
        <li>Review Production Validation and Validation History.</li>
      </ol>
    </div>
  </>;
}
