'use client';

export default function ValidationHistory({runs}:{runs:any[]}){
  return <>
    <div className="pagehead">
      <div><h1>Validation History</h1><p>Recorded staging/production validation evidence for DS Bakery releases.</p></div>
      <a className="btn secondary" href="/validation">Current Validation</a>
    </div>

    <div className="grid4">
      <div className="card stat"><div className="label">Runs</div><div className="value">{runs.length}</div></div>
      <div className="card stat"><div className="label">Passed</div><div className="value">{runs.filter(r=>r.overall_status==="pass").length}</div></div>
      <div className="card stat"><div className="label">Warnings</div><div className="value">{runs.filter(r=>r.overall_status==="warn").length}</div></div>
      <div className="card stat"><div className="label">Failed</div><div className="value">{runs.filter(r=>r.overall_status==="fail").length}</div></div>
    </div>

    <div className="tablewrap" style={{marginTop:16}}>
      <table><thead><tr><th>Started</th><th>Environment</th><th>Release</th><th>Checks</th><th>Pass</th><th>Warn</th><th>Fail</th><th>Status</th><th>Started By</th></tr></thead>
      <tbody>{runs.length===0?<tr><td colSpan={9}>No recorded validation runs yet.</td></tr>:runs.map(r=><tr key={r.id}>
        <td>{new Date(r.started_at).toLocaleString()}</td>
        <td><b>{r.environment}</b></td>
        <td>v{r.app_version} / {String(r.latest_migration).padStart(3,"0")}</td>
        <td>{r.check_count}</td><td>{r.pass_count}</td><td>{r.warn_count}</td><td>{r.fail_count}</td>
        <td><span className={r.overall_status==="pass"?"badge green":r.overall_status==="fail"?"badge red":"badge gold"}>{r.overall_status}</span></td>
        <td>{r.started_by_name}</td>
      </tr>)}</tbody></table>
    </div>

    <div className="hero" style={{marginTop:16}}>
      <h2>Evidence, not a checkbox</h2>
      <p>A passing validation run is generated from actual staging sign-ins, anonymous public-data checks, role-access tests and database readiness checks.</p>
    </div>
  </>;
}
