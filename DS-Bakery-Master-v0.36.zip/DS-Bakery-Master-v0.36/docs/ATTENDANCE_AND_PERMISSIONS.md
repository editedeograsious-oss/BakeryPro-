# DS Bakery Attendance & Individual Permissions

## Attendance vs Cashier Shift
These are different concepts.

**Staff work shift**
- planned start/end
- attendance
- lateness
- absence
- work station

**Cashier shift**
- opening float
- POS activity
- expected cash
- cash closing

A cashier can be present at work without having a till open.

## Attendance
Default late grace period: 5 minutes.

This is configurable in `attendance_settings`.

Clock-in:
- requires an active staff account
- requires a scheduled shift for today
- prevents duplicate clock-in
- calculates late minutes

Clock-out:
- closes the open attendance record
- completes the work shift

Owner/Manager attendance adjustments require a written reason and are audit logged.

## Individual Permission Overrides
The system uses:

1. role default
2. individual override

Effective permission:
`individual override if present, otherwise role default`

Only the Owner can set or clear an override.

## Critical safety rule
Existing database RPCs for sensitive actions may still enforce hard role restrictions.

For example, an individual UI permission does not automatically make a cashier an Owner or allow owner-only security operations.

This is intentional defense in depth.
