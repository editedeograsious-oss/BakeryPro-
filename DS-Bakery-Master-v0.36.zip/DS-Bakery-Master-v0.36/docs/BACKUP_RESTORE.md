# DS Bakery Backup & Restore

## Current state

Backup/recovery tooling is prepared, but the production go-live backup gate remains **pending until a real restore drill passes**.

## Two-layer strategy

1. Use any backup/restore features available on the selected Supabase production plan.
2. Independently create logical backups with the Supabase CLI.

For Supabase-hosted databases, use `supabase db dump` rather than raw `pg_dump` for the portable logical backup workflow. The CLI applies Supabase-specific filtering.

## Secure backup

On a trusted machine with Docker and Supabase CLI installed:

```bash
export DATABASE_URL='your secure Supabase database connection string'
export BACKUP_DIR='/secure/ds-bakery-backups'
npm run backup:preflight
npm run backup:supabase
```

Do not put `DATABASE_URL` in chat, source control, screenshots, or the public website.

The backup contains:
- `roles.sql`
- `schema.sql`
- `data.sql`
- `SHA256SUMS`

## Verify the backup files

```bash
npm run backup:verify -- /secure/ds-bakery-backups/ds_bakery_YYYYMMDDTHHMMSSZ
```

## Restore drill

Never run the first restore test against the live bakery database.

Create a separate non-production target database/project, then:

```bash
export TARGET_DATABASE_URL='secure test target connection string'
export RESTORE_CONFIRM='RESTORE_TO_TEST_ONLY'
npm run restore:test -- /secure/ds-bakery-backups/ds_bakery_YYYYMMDDTHHMMSSZ
```

Compare the restored counts/totals to `docs/RECOVERY_BASELINE_v0.34.json`.

Only after the restore drill passes should the Owner mark the Backup Plan item as verified in Go-Live Setup.
