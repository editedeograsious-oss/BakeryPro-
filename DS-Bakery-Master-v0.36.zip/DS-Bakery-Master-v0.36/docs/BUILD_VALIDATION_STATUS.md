# DS Bakery v0.29 — Validation Status in This Build Environment

This file records what was actually verified while preparing v0.29.

## Passed

- v0.29 shell scripts passed `bash -n` syntax validation.

- v0.29 staging/backup shell helpers passed `bash -n` syntax validation.

- Staging schema/upgrade shell helpers passed `bash -n` syntax validation.

- `npm run validate` passed for v0.29 after the public website integration.

- `npm run validate` passed.
- Structural preflight passed.
- Migration files are sequential from `002` through `021`.
- Fresh `schema.sql` contains all integration markers through migration 030.
- Project validation passed.
- Explicit role/permission guards were found on protected application pages.
- Client-code scan found no direct Supabase table write pattern.
- Client-code scan found no server-secret environment access.
- Production environment template disables demo mode.
- TypeScript/TSX syntax parser checked 133 source files with 0 parse diagnostics.
- Backup/restore shell scripts passed `bash -n` syntax validation.

## Not verified here

### Full dependency install
An `npm install --ignore-scripts --no-audit --no-fund` attempt exceeded the execution time available in this environment.

No usable `node_modules` directory was created.

Therefore the following are **not claimed as passed** here:

- `npm run typecheck`
- `npm run build`

These are mandatory release gates on the deployment/staging machine.

### Real Supabase database
No Supabase credentials/database were connected in this build environment.

Therefore the following are **not claimed as passed** here:

- clean execution of migrations 002–030
- upgrade execution of migration 030
- RLS tests with real Auth users
- `launch_readiness_checks()` against real bakery data
- private Storage policy tests
- staff invitation through Supabase Admin API

### Backup/restore
No real `DATABASE_URL` was connected here.

Backup scripts and verification tooling are included, but a real backup + restore test remains a launch requirement.

## Required release command

After dependencies and staging credentials are available:

```bash
npm run release:check
```

Then execute the database/RLS/E2E/restore steps in `docs/DEPLOYMENT_RUNBOOK.md`.
