# Custom Cake Reference Images

DS Bakery uses a private Supabase Storage bucket:

`custom-cake-references`

Migration 019 attempts to create this private bucket and its staff access policies automatically when the Supabase `storage` schema is available.

## Why private
Customer reference photos may contain personal or event-specific content. They are never made public by default.

## Object path
v0.20 uploads references to:

`<order_id>/<uuid>.<extension>`

The database stores only the object path in:

`custom_cake_specs.reference_image_path`

Authorized screens generate short-lived signed URLs for viewing.

## Staff access
- Owner / Manager: view, upload, update; may delete
- Cashier: view/upload while taking the order
- Baker: view
- Storekeeper: no access

## Deployment check
Before launch:
1. Confirm bucket is private.
2. Test Cashier upload.
3. Test Baker read-only viewing.
4. Confirm an unauthenticated request cannot access an object.
5. Confirm signed URLs expire.

Recommended application limit remains image files only and approximately 10 MB maximum.
