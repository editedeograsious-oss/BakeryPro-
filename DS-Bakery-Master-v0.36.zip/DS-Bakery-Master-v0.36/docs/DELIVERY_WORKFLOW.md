# DS Bakery Delivery Workflow

## Phase 3B approach
Start with status-based delivery management rather than GPS.

Flow:

1. Customer order is marked for delivery.
2. Staff creates a delivery job and confirms:
   - delivery address
   - delivery charge
   - scheduled date/time
3. Owner/Manager/Cashier assigns an active rider.
4. Customer order must be `ready` before dispatch.
5. Staff dispatches the order.
6. Delivery outcome becomes:
   - Delivered
   - Failed
7. A failed delivery must include a reason.
8. A failed job can be reassigned and dispatched again.

## Payments
Delivery status never creates a customer payment automatically.

If an order still has a balance after delivery, that balance remains due until a real Cash / MTN MoMo / Airtel Money payment is recorded in `customer_order_payments`.

## Delivery charge
The delivery charge becomes part of the customer order total.

Order total =
`items subtotal - discount + delivery charge`

## GPS
Live GPS is deliberately excluded from Phase 3B. It can be added later if DS Bakery has a real operational need and riders will use authenticated mobile devices.
