# DS Bakery Deployment Checklist

- [ ] `NEXT_PUBLIC_DEMO_MODE=false`
- [ ] `NEXT_PUBLIC_SUPABASE_URL` set
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` set
- [ ] No service-role key exposed in client environment
- [ ] `/api/health` returns healthy response
- [ ] `npm run preflight` passes
- [ ] Clean schema installation tested
- [ ] Upgrade migrations tested
- [ ] Owner login tested
- [ ] Manager login tested
- [ ] Cashier login tested
- [ ] Baker login tested
- [ ] Storekeeper login tested
- [ ] Full workday E2E test passes
- [ ] Backup job configured
- [ ] Restore test passes
- [ ] HTTPS enabled
- [ ] Custom-cake storage bucket private
- [ ] WhatsApp remains click-to-chat unless official API is actually connected
- [ ] Production domain configured

- [ ] `custom-cake-references` bucket is private and RLS-tested
- [ ] Mobile Money cross-ledger reference conflicts reviewed
- [ ] Customer-order cash receipts reconcile to cashier shifts
