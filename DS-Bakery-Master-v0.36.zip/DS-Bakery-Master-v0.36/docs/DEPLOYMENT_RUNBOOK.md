# DS Bakery v0.22 — Deployment Runbook

This runbook is the launch path for the **single DS Bakery Master System**.

## 1. Create non-production Supabase first

Do not begin with the real bakery database.

Create a separate staging/test Supabase project and record:

- Project URL
- Anon key
- Service-role key
- Direct/Postgres connection string for administrative backup testing

Never put the service-role key in a variable beginning with `NEXT_PUBLIC_`.

## 2. Validate a clean database

On the staging project:

1. Apply the full `supabase/schema.sql` to an empty database.
2. Confirm all objects are created without errors.
3. Confirm `system_release_state` reports:
   - app version `0.22.0`
   - latest migration `21`
4. Sign in as the Owner.
5. Open **Production Validation**.
6. Resolve every red database check.

Also run the SQL files under:

`supabase/tests/`

from an administrative SQL session.

## 3. Validate the upgrade path

Use a second temporary database:

1. Apply the v0.21 schema/migrations through `020`.
2. Add realistic sample records.
3. Apply `021_production_validation.sql`.
4. Confirm existing records remain accessible.
5. Confirm Supplier and Stock Movement pages now read live data.
6. Re-run database integrity SQL.

Do not prove only the clean-install path; upgrades must also work.

## 4. Configure production environment

Start from `.env.production.example`.

Required:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_DEMO_MODE=false`
- `SUPABASE_SERVICE_ROLE_KEY`
- `DATABASE_URL`
- `BACKUP_DIR`

The service-role key and database URL are server secrets.

## 5. Staff acceptance accounts

Create separate staging accounts for:

- Owner
- Manager
- Cashier
- Baker
- Storekeeper

Do not test all permissions while logged in as Owner.

Use `docs/ROLE_RLS_ACCEPTANCE_MATRIX.md`.

## 6. Full bakery workday simulation

Execute `docs/E2E_WORKDAY_TEST.md`.

At minimum simulate:

Purchase → Receive Stock → Production → Waste → POS → Customer Order → Deposit → Custom Cake → Delivery → Supplier Payment → Expenses → Closing → Refund → Reports.

The day should reconcile from operational actions to stock, cashflow and reports.

## 7. Backup and restore proof

1. Set `DATABASE_URL` to **staging**.
2. Run `scripts/backup.sh`.
3. Run `scripts/verify_backup.sh <backup.dump>`.
4. Create a separate empty restore-test database.
5. Set `DATABASE_URL` to that restore-test database.
6. Run `scripts/restore.sh <backup.dump>`.
7. Verify key table counts and login/application reads.

A backup is not considered proven until restore succeeds.

## 8. Production build

With dependencies installed:

```bash
npm run validate
npm run typecheck
npm run build
```

The release gate is:

```bash
npm run release:check
```

Do not deploy a release with a failed build or typecheck.

## 9. Domain and HTTPS

Deploy behind HTTPS.

After the real domain is known:

- configure Supabase Auth redirect URLs
- configure allowed site URLs
- enable HSTS at the hosting layer where appropriate
- finalize Content-Security-Policy using the actual Supabase/domain endpoints

## 10. Production cutover

Before first real transaction:

- all validation checks green or explicitly signed off
- no unresolved critical RLS failures
- no unresolved historical Mobile Money reference conflicts
- backup schedule active
- restore test completed
- real owner account tested
- `NEXT_PUBLIC_DEMO_MODE=false`

Then record the sign-off in `docs/GO_LIVE_SIGNOFF.md`.


## Public website acceptance

Before production cutover:

1. Open the site while signed out.
2. Confirm catalog prices match active products.
3. Confirm inactive products do not appear.
4. Confirm recipe/stock/cost/supplier fields are not available in public RPC responses.
5. Confirm direct anonymous select attempts against internal tables are blocked by RLS.
6. Confirm public contact/WhatsApp settings are correct.
7. Confirm custom-cake and delivery visibility settings behave as expected.


## Production Cutover

After all staging, build, role/RLS, E2E and backup/restore gates pass:

1. Configure the real database as Production.
2. Confirm staging test accounts are disabled.
3. Enable Production Lock.
4. Open `/production-cutover`.
5. Confirm Environment / Production Lock / Go-Live Setup prerequisites.
6. Owner types `AUTHORIZE LIVE OPERATIONS`.
7. Follow `docs/FIRST_LIVE_TRANSACTION.md`.
8. Reconcile the first live transaction immediately.

If a serious mismatch appears, Owner or Manager should suspend live operations from Production Cutover before more business transactions are entered.
