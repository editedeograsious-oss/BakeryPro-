# DS Bakery Full Workday End-to-End Test

Run this test on a non-production Supabase project with five separate staff accounts.

## Test accounts
- Owner
- Manager
- Cashier
- Baker
- Storekeeper

Do not use one owner account to simulate every role. RLS must be tested using the actual role accounts.

## Morning opening
1. Owner signs in and checks dashboard/system status.
2. Staff clock in against scheduled work shifts.
3. Cashier opens a cashier shift with an opening float.
4. Storekeeper reviews low-stock materials.
5. Manager reviews today's bake plan.

Expected:
- unauthorized modules remain inaccessible
- attendance and cashier shift remain separate

## Purchasing
1. Storekeeper creates a purchase order.
2. Storekeeper attempts to approve it — should fail.
3. Manager approves it.
4. Storekeeper receives part of the delivery.
5. Confirm raw-material stock increases only by the received quantity.
6. Receive the remaining quantity.
7. Manager records a supplier payment.

Expected:
- PO approval does not change stock
- stock changes only on receipt
- supplier balance changes only on payment

## Production
1. Baker opens assigned bake plan.
2. Baker confirms a partial production run.
3. Confirm recipe ingredients decrease.
4. Attempt a production run that requires more stock than available.

Expected:
- successful production creates all ingredient ledger entries
- insufficient stock causes the entire run to fail atomically

## Waste
1. Baker records finished-product waste.
2. Confirm raw materials are not deducted a second time.
3. Storekeeper records raw-material waste above approval threshold.
4. Manager approves it.

Expected:
- pending raw waste does not change stock
- approved raw waste creates one negative inventory movement

## POS
1. Cashier selects a known customer and completes a cash sale.
2. Verify amount received and change.
3. Cashier completes MTN MoMo sale with manual reference.
4. Attempt MoMo sale without reference.
5. Attempt duplicate reference if uniqueness is enabled.
6. Attempt protected refund/cancel without approval.

Expected:
- authoritative totals come from server-side rules
- known customer is attached atomically for loyalty
- duplicate inbound Mobile Money reference is rejected even if first used on a customer order
- unauthorized refund/cancel fails
- original completed sale remains traceable

## Customer order
1. Cashier creates customer/order.
2. Record a deposit.
3. Move order to production.
4. Baker moves it to Ready.
5. Print order receipt.

Expected:
- balance equals order total minus payment ledger
- baker cannot access owner financial reports

## Custom cake
1. Create custom-cake brief and upload a private reference image.
2. Add quotation.
3. Confirm required deposit is calculated from the configured percentage.
4. Attempt production approval below required deposit — should fail.
5. Record enough deposit.
6. Manager approves for production.
7. Confirm Baker can view the signed reference image but cannot upload/replace it.

## Delivery
1. Create delivery job.
2. Assign rider.
3. Attempt dispatch before order Ready — should fail.
4. Mark order Ready and dispatch.
5. Mark delivery complete while balance remains unpaid.

Expected:
- delivery completion does not create a payment

## Loyalty / communication
1. Complete and fully pay an eligible customer order.
2. Confirm points are earned once.
3. Apply a reward.
4. Prepare a birthday WhatsApp message for an opted-out customer.

Expected:
- POS/customer-order points are ledger-backed and not duplicated on retries
- reward redemption is not duplicated on retry
- birthday marketing is blocked without opt-in
- click-to-WhatsApp logs Opened, not Sent/Delivered
- a repeated communication request ID creates only one log row

## Closing
1. Record an expense.
2. Close cashier shift.
3. Compare counted vs expected cash.
4. Complete daily closing.
5. Open weekly operational report.

Expected:
- reports reflect transactions from the same ledgers
- no manually typed supplier/customer balance replaces ledger-derived values

## Security tests
Using Cashier:
- cannot manage staff
- cannot access owner-only security controls
- cannot approve purchase orders

Using Baker:
- cannot view owner profit reports
- cannot alter product prices

Using Storekeeper:
- cannot record supplier payments
- cannot access customer financial controls

Using Manager:
- cannot set owner-only individual permission overrides

## Backup / restore
1. Create logical backup.
2. Restore to a separate test database.
3. Reconcile:
   - product count
   - raw-material stock
   - sales totals
   - customer-order balances
   - supplier balances
   - audit-log count

Go live only after this entire test passes.

## Staff administration and permissions
1. Owner invites one Cashier and one Baker.
2. Owner denies `delivery:manage` for the Cashier.
3. Cashier attempts Delivery page access.
4. Owner clears override.
5. Cashier retries.
Expected:
- denied override blocks access
- clearing override restores role-default access
- audit entries exist for permission changes

## Attendance and schedule
1. Manager schedules a Baker for today.
2. Baker clocks in.
3. Attempt to clock in again.
4. Baker clocks out.
Expected:
- duplicate clock-in fails
- timestamps use configured business date/time
- attendance remains separate from cashier till shifts

## Customer-order refund
1. Create an order with cash + Mobile Money payments.
2. Refund part of the order.
3. Confirm refund allocations preserve payment methods.
4. Confirm balance, loyalty, closing and delivery balance update.
5. Refund remaining net payment.
6. Cancel the order with a reason.
Expected:
- refund cannot exceed net paid
- retry with same request ID is not duplicated
- paid order cannot cancel until net paid is zero


## Public customer website
1. Open the public homepage without signing in.
2. Confirm active products/prices match the staff Products screen.
3. Confirm inactive products are hidden.
4. Confirm no stock quantities, food costs, margins or supplier data appear.
5. Configure a public WhatsApp number in Public Website Settings.
6. Open a product Order button.
7. Open the Custom Cake enquiry button.

Expected:
- anonymous customer sees only safe catalog/contact information
- WhatsApp links contain pre-filled customer-friendly text
- anonymous browsing does not create customer/order/payment records
- internal tables remain inaccessible directly to anonymous users
