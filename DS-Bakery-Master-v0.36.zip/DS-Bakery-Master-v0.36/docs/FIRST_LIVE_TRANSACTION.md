# DS Bakery — First Live Transaction Procedure

Use this only after Production Cutover shows:

- Environment: Production
- Production Lock: Enabled
- Go-Live Setup: Complete
- Live Operations: Enabled

## Recommended first transaction

Use one simple, low-value normal bakery sale with a known product and Cash payment.

Do not begin with:

- a large custom-cake order
- a mixed payment
- a large supplier payment
- a bulk stock receipt
- a large refund

The purpose is to prove the live ledger path with minimal business risk.

## Before the sale

1. Confirm the physical product exists.
2. Confirm its selling price.
3. Confirm the Cashier has an open till.
4. Confirm the expected opening float.
5. Confirm the product is active in POS.
6. Confirm Production Cutover says Live Operations Enabled.

## Complete one sale

Cashier records the sale normally.

## Immediately verify

### POS
- sale number exists
- total is correct
- payment method is Cash
- completed status is correct

### Cashier till
- expected cash increased by the sale amount
- transaction count increased

### Customer/loyalty
If a customer was attached:
- sale is linked to the customer
- loyalty follows the configured rule

### Reports
- sales total includes the transaction
- gross profit uses the sale-item cost snapshot

### Audit
- the sale/financial action is traceable

## If anything is wrong

1. Do not continue entering more transactions.
2. Owner or Manager opens Production Cutover.
3. Enter a clear suspension reason.
4. Suspend Live Operations.
5. Investigate and reconcile before Owner resumes.

Do not hide or delete the original transaction to make the reports appear correct.
