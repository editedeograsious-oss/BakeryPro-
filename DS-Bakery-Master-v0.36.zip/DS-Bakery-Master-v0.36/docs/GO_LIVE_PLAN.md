# DS Bakery Go-Live Plan

## Stage 1 — Integration shell (v0.17)
- visible Demo vs Live mode
- health endpoint
- system-status page
- loading/error handling
- structural preflight script
- end-to-end workday test plan

## Stage 2 — Live data wiring
Replace remaining in-page demo arrays with repository/database reads and writes.

Priority:
1. Products / inventory / recipes
2. POS / cashier shifts / daily closing
3. Production / waste
4. Suppliers / payables
5. Customers / orders / custom cakes
6. Delivery / loyalty / communications
7. Attendance / schedules / permission overrides
8. Dashboard / reports

Each conversion must preserve:
- RLS
- server-side validation
- audit logging
- ledger-derived balances

## Stage 3 — Database validation
Use a clean non-production Supabase project.

Apply `supabase/schema.sql`.

Then test upgrade path separately using migrations 002–016 against a database representing earlier versions.

Do not assume SQL is production-ready until both paths execute successfully.

## Stage 4 — Role testing
Create separate real Auth users:
- owner
- manager
- cashier
- baker
- storekeeper

Run authorization tests with each account.

## Stage 5 — Full workday simulation
Follow `docs/E2E_WORKDAY_TEST.md`.

## Stage 6 — Reliability
- production backup schedule
- off-app backup storage
- restore into test database
- HTTPS deployment
- secure environment variables
- no service-role key in browser

## Stage 7 — Launch
- set `NEXT_PUBLIC_DEMO_MODE=false`
- final data seed/import
- confirm owner login
- confirm cashier POS
- confirm daily backup
- open bakery operations

## Stage 8 — First-week monitoring
Review:
- audit log
- stock variances
- cash variances
- duplicate payment references
- failed delivery jobs
- failed communication attempts
- backup completion
