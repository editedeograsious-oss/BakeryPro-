# DS Bakery — Go-Live Sign-Off

Release target: **v0.28.0 / Migration 027**

Do not mark a box complete without evidence.

## Database
- [ ] Clean `schema.sql` install succeeds
- [ ] Upgrade through migration 021 succeeds
- [ ] Production Validation has zero FAIL results
- [ ] Historical Mobile Money conflicts reviewed
- [ ] No negative stock balances
- [ ] No duplicate active recipes
- [ ] Purchase totals reconcile
- [ ] Customer-order net payments reconcile

## Go-Live Business Setup
- [ ] Automatic Go-Live Setup gate passes
- [ ] Catalog verified
- [ ] Opening stock verified
- [ ] Payment methods verified
- [ ] Public website verified
- [ ] Staff accounts verified
- [ ] Backup plan verified
- [ ] Go-Live Setup completed and audited

## Application
- [ ] `npm run validate` passes
- [ ] `npm run typecheck` passes
- [ ] `npm run build` passes
- [ ] Production Validation route is Owner-only
- [ ] System Status route is Owner-only
- [ ] No server secret exists in client code
- [ ] `NEXT_PUBLIC_DEMO_MODE=false`

## Roles / RLS
- [ ] Owner acceptance test
- [ ] Manager acceptance test
- [ ] Cashier acceptance test
- [ ] Baker acceptance test
- [ ] Storekeeper acceptance test
- [ ] Disabled-account test
- [ ] Individual Deny override test
- [ ] Individual override-clear test

## Full Workday
- [ ] Purchase order
- [ ] Approval
- [ ] Stock receiving
- [ ] Production
- [ ] Waste
- [ ] POS sale
- [ ] Customer order/deposit
- [ ] Custom cake
- [ ] Delivery
- [ ] Supplier payment
- [ ] Expense
- [ ] Cash movement
- [ ] Refund
- [ ] Daily closing
- [ ] Report review

## Backup / Recovery
- [ ] Automated backup schedule active
- [ ] Independent logical backup created
- [ ] Backup archive verified
- [ ] Restore into non-production succeeded
- [ ] Restored application data checked

## Public Website
- [ ] Anonymous catalog matches active products
- [ ] Inactive products are hidden
- [ ] Anonymous direct internal-table access is blocked
- [ ] No costs, margins, stock or supplier data appear publicly
- [ ] WhatsApp/contact settings verified
- [ ] Custom-cake/delivery visibility verified

## Production Cutover
- [ ] Real environment configured as Production
- [ ] Production Lock enabled
- [ ] Go-Live Setup completed
- [ ] Production Cutover prerequisites pass
- [ ] Owner authorized live operations
- [ ] Controlled first transaction completed
- [ ] First transaction reconciled in till/report/audit

## Deployment
- [ ] Production URL uses HTTPS
- [ ] Supabase Auth redirect/site URLs configured
- [ ] Server-only secrets configured
- [ ] Domain-specific security headers reviewed
- [ ] First real Owner login tested

## Approval

Owner/Business sign-off: ____________________  Date: __________

Technical deployment sign-off: ______________  Date: __________

First production transaction authorized: [ ] YES
