# DS Bakery Loyalty Rules

Phase 3C uses configurable rules stored in `loyalty_settings`.

## Demo defaults
- Earn: 1 point for every UGX 1,000 of eligible completed value
- Reward: 100 points = UGX 5,000
- Birthday reminder window: 30 days
- VIP threshold: UGX 1,000,000 lifetime customer-order value
- Regular threshold: UGX 500,000 lifetime value OR 5 orders

These are starting values only. The owner should set the real DS Bakery policy before launch.

## Points ledger
The system does not store an editable points balance.

Balance = sum of `loyalty_point_transactions.points_delta`.

Examples:
- completed sale/order: positive points
- refund/cancellation: negative adjustment
- reward redemption: negative points
- birthday/manual bonus: traceable manual entry

## Customer orders
A customer order earns points when:
1. status is `completed`, and
2. completed payments cover the order total.

If the order is not fully paid, points are not earned yet.

## POS sales
`sales.customer_id` allows a known customer to be linked to a POS sale.
The database can synchronize earned points against the sale net of refunds.

## Reward redemption
Phase 3C implements order-based reward redemption:
- customer must have enough points
- points must follow the configured reward block
- reward becomes an order discount
- order total may not fall below payments already recorded
- reward redemption is audit logged

## Birthdays
Birthday reminders are staff-facing only.
Phase 3C does not automatically message customers.
