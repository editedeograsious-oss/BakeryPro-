# DS Bakery — Role / RLS Acceptance Matrix

Use **separate staging Auth accounts** for each role.

A UI redirect alone is not enough. Where practical, also confirm the database rejects the unauthorized RPC/table action.

| Area | Owner | Manager | Cashier | Baker | Storekeeper |
|---|---|---|---|---|---|
| Dashboard | Allow | Allow | Deny unless explicitly permitted | Deny | Deny |
| POS | Allow | Allow | Allow | Deny | Deny |
| Products write | Allow | Allow | Deny | Deny | Deny |
| Recipes write | Allow | Allow | Deny | Deny | Deny |
| Inventory view | Allow | Allow | Deny | Allow read | Allow |
| Physical stock count | Allow | Allow | Deny | Deny | Allow |
| Purchase order create | Allow | Allow | Deny | Deny | Allow |
| Purchase order approve | Allow | Allow | Deny | Deny | Deny |
| Purchase receive | Allow | Allow | Deny | Deny | Allow |
| Supplier payment | Allow | Allow | Deny | Deny | Deny |
| Production plan create | Allow | Allow | Deny | Deny | Deny |
| Production confirm | Allow | Allow | Deny | Assigned only | Deny |
| Finished-product waste | Allow | Allow | Deny | Allow | Deny |
| Raw-material waste | Allow | Allow | Deny | Deny | Allow |
| Waste approve | Allow | Allow | Deny | Deny | Deny |
| Customer create/order/payment | Allow | Allow | Allow | Deny create/pay | Deny |
| Customer-order refund | Allow | Allow | Deny | Deny | Deny |
| Custom-cake quote | Allow | Allow | Allow | Read/production only | Deny |
| Custom-cake production approval | Allow | Allow | Deny | Deny | Deny |
| Delivery manage | Allow | Allow | Allow by role default | Deny | Deny |
| Loyalty manual adjustment | Allow | Allow | Deny | Deny | Deny |
| Loyalty redemption | Allow | Allow | Allow | Deny | Deny |
| WhatsApp customer communication | Allow | Allow | Allow | Deny | Deny |
| Message-template edit | Allow | Allow | Deny | Deny | Deny |
| Daily closing | Allow | Allow | Deny | Deny | Deny |
| Reports | Allow | Allow | Deny | Deny | Deny |
| Audit log | Allow | Allow | Deny | Deny | Deny |
| Staff invite/role/disable | Allow | Deny | Deny | Deny | Deny |
| Permission overrides | Allow | Deny | Deny | Deny | Deny |
| Attendance self clock | Allow | Allow | Allow | Allow | Allow |
| Attendance settings | Allow | Allow unless denied override | Deny | Deny | Deny |
| Staff schedule manage | Allow | Allow unless denied override | Deny | Deny | Deny |
| Production Validation | Allow | Deny | Deny | Deny | Deny |

## Individual permission override tests

For a Manager:

1. Confirm Reports works under role default.
2. Owner sets `reports:view = Deny`.
3. Confirm Reports route is denied.
4. Owner clears the override.
5. Confirm Reports works again.

For a Cashier:

1. Confirm Delivery works under role default.
2. Owner sets `delivery:manage = Deny`.
3. Confirm Delivery route is denied.
4. Clear override.
5. Confirm role-default access returns.

## Disabled account test

1. Sign in as a Cashier.
2. Owner disables that profile.
3. Attempt a protected route and a financial RPC from the disabled session.
4. Confirm application/session checks fail and database role helpers no longer authorize the profile.

## Critical rule

An individual **Allow** must never be interpreted as permission to bypass a hard safety/financial role check inside a sensitive RPC.
