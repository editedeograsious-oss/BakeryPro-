# DS Bakery Production Security Checklist

- [ ] Production Supabase project created
- [ ] HTTPS-only deployment
- [ ] Real staff Auth accounts created
- [ ] Owner account protected with strong unique password
- [ ] Staff roles assigned in `profiles`
- [ ] Separate test accounts for owner, manager, cashier, baker, storekeeper
- [ ] RLS tested with each role
- [ ] Disabled staff test confirms protected data becomes inaccessible
- [ ] Refund/cancel approval PIN set for owner/manager
- [ ] No plaintext PIN/password stored in application tables
- [ ] Service-role key never exposed to browser
- [ ] Backup job configured
- [ ] Backup destination access restricted
- [ ] Restore tested into non-production database
- [ ] Daily closing performed and locked
- [ ] Audit-log access limited to owner/manager
