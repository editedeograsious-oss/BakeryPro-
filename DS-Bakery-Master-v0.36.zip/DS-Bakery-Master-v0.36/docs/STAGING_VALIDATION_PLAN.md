# DS Bakery — Staging Validation Plan

## Step 1 — Create a staging Supabase project

Use a non-production project.

Do not use the real bakery database for these tests.

## Step 2 — Apply database schema

For a clean staging database:

```sql
-- execute the contents of:
supabase/schema.sql
```

For an upgrade test from v0.24:

```sql
-- execute:
supabase/024_staging_validation_harness.sql
```

## Step 3 — Configure staging environment

Copy:

`.env.staging.example`

Fill:

- `STAGING_SUPABASE_URL`
- `STAGING_SUPABASE_ANON_KEY`
- `STAGING_SUPABASE_SERVICE_ROLE_KEY`
- `STAGING_TEST_EMAIL_DOMAIN`
- `STAGING_TEST_PASSWORD`

Keep the service-role key private.

## Step 4 — Configure Environment Safety

Sign in as Owner and open:

`/environment`

Set:

- Environment: **Staging**
- Allow staging test accounts: **Enabled**
- Confirmation: `CONFIRM STAGING`

Then run:

```bash
npm run staging:preflight
```

Do not continue unless preflight passes.

## Step 5 — Create five staging role accounts

```bash
npm run staging:create-test-users
```

Expected accounts:

- `ds-owner-test@<domain>`
- `ds-manager-test@<domain>`
- `ds-cashier-test@<domain>`
- `ds-baker-test@<domain>`
- `ds-storekeeper-test@<domain>`

## Step 6 — Run automated staging validation

```bash
npm run staging:validate
```

The script should finish with:

`0 fail(s)`

Warnings must be reviewed before go-live.

A validation run is recorded in the database.

## Step 7 — Review in the application

Sign in as Owner and open:

- `/validation`
- `/validation-history`

Confirm:

- current database readiness
- latest staging run
- zero failures
- warnings understood or resolved

## Step 8 — Run manual role matrix

Follow:

`docs/ROLE_RLS_ACCEPTANCE_MATRIX.md`

Automated smoke tests are not a substitute for manual workflow validation.

## Step 9 — Run full workday E2E

Follow:

`docs/E2E_WORKDAY_TEST.md`

Simulate:

Purchase → Receiving → Production → Waste → POS → Customer Order → Deposit → Custom Cake → Delivery → Supplier Payment → Expense → Closing → Refund → Report.

## Step 10 — Build

```bash
npm run release:check
```

Required:

- preflight pass
- project validation pass
- syntax pass
- typecheck pass
- Next.js production build pass

## Step 11 — Backup and restore

Follow:

`docs/DEPLOYMENT_RUNBOOK.md`

Create a logical backup and restore it into a separate test database.

## Step 12 — Final sign-off

Complete:

`docs/GO_LIVE_SIGNOFF.md`

Only then authorize the first real production transaction.


## Go-Live Setup after staging validation

After `npm run staging:validate` records a passing run:

```bash
npm run staging:go-live-readiness
```

Then sign in as Owner and open:

`/go-live-setup`

Verify:

- product prices/categories
- opening stock counts
- Cash / MTN MoMo / Airtel Money
- public website/contact details
- real staff roles/accounts
- backup and restore plan

When all automatic and manual checks pass, type:

`COMPLETE GO LIVE SETUP`

Do this before switching the real deployment environment to Production.
