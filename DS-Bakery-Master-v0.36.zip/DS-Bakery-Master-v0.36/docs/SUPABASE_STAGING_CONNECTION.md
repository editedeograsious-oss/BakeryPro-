# Connect DS Bakery to a Real Supabase Staging Project

## Preferred workflow

Use a dedicated **non-production** Supabase project.

The production bakery project should not be the first database used for migrations, role tests or sample transactions.

## A. Create staging project

Create a project named clearly, for example:

`DS Bakery Staging`

Do not use a production/live name.

## B. Apply DS Bakery schema

For an empty project, apply:

`supabase/schema.sql`

The schema contains migrations 002 through 028.

Expected release metadata after success:

- `app_version = 0.29.0`
- `latest_migration = 28`
- `release_stage = supabase_staging_handoff`

## C. Configure Environment Safety

Create/sign in with the Owner account.

Open:

`/environment`

Set:

- Environment: `Staging`
- Allow staging test accounts: enabled
- Confirmation: `CONFIRM STAGING`

Do not enable Production Lock.

## D. Configure private staging variables

Use `.env.staging.example`.

Required:

```text
STAGING_SUPABASE_URL
STAGING_SUPABASE_ANON_KEY
STAGING_SUPABASE_SERVICE_ROLE_KEY
STAGING_DATABASE_URL
STAGING_TEST_EMAIL_DOMAIN
STAGING_TEST_PASSWORD
```

Do not put service-role/database credentials in public/browser variables.

## E. Connection test

Run:

```bash
npm run staging:preflight
npm run staging:connection-check
```

Expected:

- release state passes
- environment guardrail passes
- public website RPC passes
- product catalog RPC passes
- service-role Auth Admin test passes

## F. Five-role validation

Run:

```bash
npm run staging:full-check
```

This creates temporary staging accounts for:

- Owner
- Manager
- Cashier
- Baker
- Storekeeper

and then validates role behavior.

## G. Review evidence

Open:

- `/staging-connection`
- `/validation`
- `/validation-history`

Resolve every FAIL result.

Review WARN results before continuing.

## H. Continue to business readiness

After staging technical validation:

1. run full bakery workday E2E,
2. complete `/go-live-setup`,
3. prove backup/restore,
4. pass production build,
5. only then prepare Production Cutover.
