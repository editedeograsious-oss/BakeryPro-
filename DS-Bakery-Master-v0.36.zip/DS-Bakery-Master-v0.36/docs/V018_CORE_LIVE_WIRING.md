# DS Bakery v0.18 — Core Live Data Wiring

## Live-wired in this version

### Products
- reads shared product/catalog data
- reads recipe-derived food cost
- owner/manager can create a product through audited RPC

### Recipes
- reads active recipes and ingredient costs
- owner/manager can atomically replace the active recipe
- old active recipe is archived
- all ingredient rows are validated before the replacement

### Inventory
- reads shared raw-material stock
- stock value and low-stock flags are database-derived
- physical stock counts create `adjustment` ledger movements
- stock is not directly overwritten by the page
- purchase receiving remains the normal stock-in workflow

### POS
- live product list
- server-authoritative selling prices
- open cashier shift required
- idempotent request ID
- sequential sale number
- exact payment-ledger amount
- Mobile Money reference required
- duplicate completed Mobile Money reference blocked
- cash tender/change is kept out of sales revenue

### Cashier shifts
- cashier/owner/manager can start own shift
- only one open shift per cashier
- sales automatically attach to current open shift
- cashier can close own shift; owner/manager can close permitted shifts

### Daily closing
- non-mutating live snapshot before close
- configurable business timezone
- refunds reduce the correct payment method
- expected cash is calculated from ledger flows
- owner/manager close locks the daily snapshot

## Critical correctness fixes included
1. Paid completed sales can no longer be “cancelled” without a refund.
2. Refunds use a `sale_refunds` ledger rather than an invalid negative payment row.
3. Cash change is not posted as sales income.
4. Two financial SECURITY DEFINER report RPCs now enforce Owner/Manager internally.
5. POS retries can return the already-created sale through `client_request_id`.
6. Sale numbers now use a sequence instead of random digits.
7. Partial-refund reporting now reduces sales/COGS/profit proportionally until item-level refund allocation is added.

## Still not final production
The database migration must be executed against a real non-production Supabase project before these SQL assumptions can be called verified.

The remaining Phase 2/3 screens still need the same live-data conversion.

## Next integration stage
v0.19:
- production / baker tasks
- waste / production control
- purchases / supplier payables
- expenses / cash movements
