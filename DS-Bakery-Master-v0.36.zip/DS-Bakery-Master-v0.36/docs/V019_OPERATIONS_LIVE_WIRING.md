# DS Bakery v0.19 — Operations Live Data Wiring

## Live-wired in this version

### Production
- owner/manager creates today's production plan
- baker sees assigned production rows
- confirmation is atomic
- active recipe ID is snapshotted on the run
- ingredient stock is checked before any deduction
- confirmation has client-request idempotency

### Baker Tasks
- tasks are now persistent database records
- owner/manager creates tasks
- baker may complete/reopen assigned tasks
- task changes are audited

### Waste
- finished-product and raw-material waste use the live waste ledger
- raw-material waste reduces stock only after approval
- finished-product waste does not deduct ingredients twice
- linked run waste cannot exceed linked run output
- record operation has client-request idempotency

### Purchase Orders
- one RPC creates order + lines
- purchase number is generated server-side
- storekeeper can prepare
- owner/manager approves/rejects
- approval does not increase stock

### Purchase Receiving
- only approved POs can be received
- partial receiving supported
- stock changes through inventory ledger
- weighted-average ingredient cost continues to update
- receipt event has client-request idempotency

### Supplier Payables
- payment is allocated to a specific purchase
- owner/manager only
- bank/cash/MTN/Airtel methods
- non-cash reference required
- payment retry is idempotent
- supplier outstanding/overdue balance is ledger-derived

### Expenses
- owner/manager controlled RPC
- cash/Mobile Money methods
- Mobile Money reference required
- optional cashier-shift link
- retry idempotency
- expenses now have RLS

### Manual Cash In/Out
- Cashier uses own open shift
- Owner/Manager may use selected shift or general cash
- opening float is intentionally excluded from this screen
- retry idempotency
- feeds daily closing

## Daily-closing correctness expansion
v0.19 closing now includes:
- POS cash/Mobile Money
- POS refunds by original method
- customer-order deposits/payments
- manual cash in/out
- business expenses
- supplier cash/Mobile Money payments

Supplier payments are cashflow, not operating expense.

Expected cash:
`opening float + net POS cash + customer-order cash receipts + cash in - cash out - cash expenses - cash supplier payments`

## Security hardening
Prototype direct-write policies were removed for:
- products
- raw-material balances
- recipes / recipe items
- production-plan rows
- inventory transactions
- purchases / purchase lines / purchase payments

Live mutations now go through audited RPCs for these flows.

## Still requires real database validation
Migration 018 has been created but must be executed against a clean non-production Supabase project before SQL/runtime assumptions are considered verified.

## Next
v0.20 — Customer & Service Live Wiring:
- customers
- customer orders/deposits
- custom cakes
- delivery/riders
- loyalty
- WhatsApp communication
