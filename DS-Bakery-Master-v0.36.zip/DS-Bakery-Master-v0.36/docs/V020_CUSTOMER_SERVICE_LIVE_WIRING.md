# DS Bakery v0.20 — Customer & Service Live Data Wiring

## Customers
- live customer summary
- audited create/update RPC
- birthday and address
- WhatsApp marketing preference
- client-request idempotency for new customers
- broad direct-write customer policy removed

## Standard Customer Orders
- atomic order + product lines
- server-authoritative current product prices
- sequence-based order numbers
- deposit/payment ledger
- cash payments can link to cashier shift
- Mobile Money reference required
- payment retry idempotency
- strict forward status transitions
- paid orders cannot be silently cancelled

## Custom Cakes
- atomic customer order + placeholder order item + cake specification
- quote updates the authoritative order item
- configurable default production deposit: 50%
- manager/owner production approval gate
- private Supabase Storage reference images
- signed image viewing
- custom-cake lifecycle follows customer-order production status

## Delivery
- idempotent delivery-job creation
- owner/manager rider management through audited RPC
- Ready required before dispatch
- rider required before dispatch
- delivered/failed status
- Delivered never creates a payment
- custom-cake delivered status is synchronized

## Loyalty
- POS can optionally attach a customer
- POS and customer orders can both earn loyalty
- reward redemption is idempotent
- manual loyalty adjustments are idempotent
- points redemptions lock the customer row to reduce concurrent overspending
- owner can update earning/reward settings
- retention lifetime value includes linked POS plus customer orders
- birthday dates use the configured business date

## WhatsApp
- live queue from Ready / In Production / Out for Delivery / Birthday / Balance
- reusable live templates
- owner/manager template editing through audited RPC
- click-to-WhatsApp open logging is idempotent
- birthday/marketing template requires opt-in
- no claim of Sent/Delivered/Read until official provider API exists

## Cross-ledger Mobile Money reference control
Migration 019 introduces a shared Mobile Money reference registry.

Inbound:
- POS payments
- customer-order payments

Outbound:
- expenses
- supplier payments

A provider reference cannot be reused in the same direction across those ledgers.

`mobile_money_reference_conflicts` exposes historical duplicates that existed before the registry.

## Till reconciliation
Cashier shift expected cash now includes:
- opening float
- net POS cash
- customer-order cash receipts
- manual cash in/out
- cash expenses
- supplier cash payments

## Remaining gap
Customer-order refund processing is intentionally not invented in v0.20.

If an order already has a deposit/payment, cancellation is blocked until a dedicated customer-order refund workflow is added. This prevents a paid order from being cancelled while leaving the money ledger unresolved.

## Validation still required
Migration 019 must be executed on a real non-production Supabase project and the full role/E2E test suite must pass before production launch.
