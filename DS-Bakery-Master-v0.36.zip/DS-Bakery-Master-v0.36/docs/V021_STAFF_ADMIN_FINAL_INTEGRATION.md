# DS Bakery v0.21 — Staff/Admin & Final Integration

## Added

### Staff administration
- Owner-only live staff page
- Server-only staff invitation route
- Supabase service-role key remains server-side
- Role changes and enable/disable use audited database RPCs
- Owner account remains protected from self-role edits in the existing security layer

### Attendance
- Live clock-in / clock-out
- Business-date aware attendance calculations
- Configurable late grace period
- Attendance remains separate from cashier till shifts

### Staff schedules
- Persistent work shifts
- Idempotent shift creation
- Audited cancellation with reason
- Shift cannot be cancelled after clock-in

### Individual permissions
- Owner-only overrides
- Override reason required
- Effective permissions can be read only by the staff member themself or the owner
- Reports, delivery, communication, attendance-management and schedule-management now use permission checks
- Sensitive database RPC role checks remain in force

### Customer-order refunds
- Owner/Manager only
- Refund amount cannot exceed net amount paid
- Refund allocation reverses latest payments first
- Original payment method is preserved
- Optional open cashier till can be linked to cash refunds
- Daily closing subtracts customer-order refunds
- Cashier till expected cash subtracts linked order cash refunds
- Customer order balances and delivery balances use net payments
- Loyalty points are recalculated after refunds
- Customer order cancellation is allowed only after net payments are zero

### Live management reports
- Shared-ledger report RPC
- POS sales / COGS / gross profit
- recorded expenses
- estimated operating profit
- purchases
- approved waste
- customer-order value and outstanding balances
- supplier outstanding and overdue balances
- production planned vs produced
- product performance
- payment mix

### Audit history
- Live audit-log summary page
- Normal application screens do not delete audit history

## Important launch gate
v0.21 is an integration milestone, not proof of production readiness.

Before launch:
1. Run migrations 002–020 on a clean non-production Supabase project.
2. Run an upgrade test from the previous schema.
3. Create test users for every role.
4. Execute RLS/permission tests.
5. Run a full workday E2E scenario.
6. Run a production Next.js build.
7. Schedule backups.
8. Perform a restore test.
9. Configure `SUPABASE_SERVICE_ROLE_KEY` only on the server environment.
10. Review historical Mobile Money reference conflicts before enabling live use.
