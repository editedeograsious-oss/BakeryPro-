# DS Bakery v0.22 — Production Validation & Deployment Readiness

v0.22 changes the project from feature-building mode to launch-validation mode.

## New validation layer

### Owner Production Validation page
Checks the current runtime for:

- Supabase public configuration
- demo-mode status
- server-only service-role configuration
- backup database URL configuration
- database integrity checks from migration 021

### Database launch checks
Migration 021 checks:

- active Owner account exists
- business timezone is valid
- no product has multiple active recipes
- no raw material has negative stock
- purchase totals reconcile
- customer-order net payments remain valid
- linked finished-product waste does not exceed production output
- historical Mobile Money reference conflicts
- cashier shifts open longer than 18 hours
- stale staff schedules
- private custom-cake storage bucket
- release metadata

### Remaining static operational screens closed
The Supplier Directory and Stock Movement Ledger are now repository-backed in Live Mode.

Supplier changes use an audited RPC rather than the old broad direct-write policy.

The Stock Movement page is read-only; inventory changes continue through receiving, production, waste and physical-count workflows.

## Deployment assets

- `.env.production.example`
- `scripts/validate_project.mjs`
- `scripts/verify_backup.sh`
- `docs/DEPLOYMENT_RUNBOOK.md`
- `docs/ROLE_RLS_ACCEPTANCE_MATRIX.md`
- `docs/GO_LIVE_SIGNOFF.md`
- `supabase/tests/001_database_integrity.sql`
- `supabase/tests/002_security_inventory.sql`
- `supabase/tests/003_release_objects.sql`

## Release commands

Structural validation:

```bash
npm run validate
```

After dependencies are installed:

```bash
npm run typecheck
npm run build
```

Full release gate:

```bash
npm run release:check
```

## Release status

v0.22 does **not** declare the bakery production-ready by source inspection alone.

Production readiness requires evidence from:

1. real clean Supabase migration,
2. real upgrade migration,
3. role/RLS tests,
4. production build,
5. full workday E2E,
6. backup + restore proof,
7. deployment/domain/security validation.
