# DS Bakery v0.23 — Live Public Customer Website

v0.23 closes an important final-product gap: the public DS Bakery website is no longer a static sample menu.

## Public website live data

The public homepage now reads:

- active product name
- public product description
- current selling price
- product image URL
- category name/order
- public business contact/settings

It does **not** expose:

- ingredient recipes
- food cost
- gross margin
- stock quantities
- supplier information
- staff information
- audit history
- purchase/payable data

The public data boundary is implemented using two restricted SECURITY DEFINER RPCs:

- `public_site_info()`
- `public_product_catalog()`

Both are executable by `anon` and `authenticated`, but return only explicitly selected safe public fields.

## Public website settings

Owner/Manager can configure:

- business name
- tagline
- hero message
- phone
- WhatsApp phone
- email
- address text
- opening hours
- custom cake visibility
- delivery visibility

Changes use the audited `update_public_site_settings()` RPC.

## Customer ordering behavior

The public website does not create unauthenticated database orders.

Instead:

- customers browse the live menu
- product buttons can open a pre-filled WhatsApp message
- custom-cake enquiries can open WhatsApp with an appropriate request

This avoids anonymous order spam and keeps the real customer-order/deposit workflow inside the authenticated staff system.

## Security headers

v0.23 expands web security headers with:

- Content-Security-Policy
- HSTS in production
- Cross-Origin-Opener-Policy
- Cross-Origin-Resource-Policy
- X-DNS-Prefetch-Control
- X-Permitted-Cross-Domain-Policies
- existing frame, MIME, referrer and permissions protections

The CSP permits Supabase HTTPS/WebSocket connections and HTTPS product images.

## Production validation

Migration 022 updates release metadata to:

- app version `0.23.0`
- latest migration `22`

The launch-readiness checks now also verify that the public website configuration exists.

## Remaining launch work

The project still requires real staging evidence:

1. Run migrations 002–022 on a clean Supabase project.
2. Run upgrade migration 022 after a v0.22 database.
3. Test public anonymous catalog access.
4. Confirm anonymous users cannot read internal product/inventory/recipe tables directly.
5. Run full role/RLS acceptance.
6. Run production build.
7. Run backup/restore and E2E tests.
