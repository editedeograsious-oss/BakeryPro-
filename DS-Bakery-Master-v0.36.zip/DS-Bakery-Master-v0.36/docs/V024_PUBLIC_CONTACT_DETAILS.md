# DS Bakery v0.24 — Public Contact & Social Details

The DS Bakery public website now carries the supplied customer contact information.

## Location
Kiwafu Lugonjo

## Telephone
- 0708743663
- 0760547003

## WhatsApp
0760547003

## Email
dscakes3@gmail.com

## TikTok
Ds bakery

The TikTok item is shown with a TikTok-style icon. When the value is not a simple `@handle`, the public link opens a TikTok search for the displayed name instead of inventing an account URL.

## Public website behavior
- Telephone numbers are clickable `tel:` links.
- WhatsApp opens the configured pre-filled DS Bakery ordering message.
- Email opens the customer's email application.
- TikTok is shown as a social contact card.
- Kiwafu Lugonjo appears as the bakery location.

## Database
Migration 023 adds:
- `secondary_phone`
- `tiktok_handle`

and updates the public-site settings row with the supplied DS Bakery details.

Release state:
- app version: `0.24.0`
- latest migration: `023`
