# DS Bakery v0.25 — Staging Validation Harness

v0.25 is the first release focused on **repeatable staging evidence** rather than another large business feature.

## What changed

### Recorded validation runs
Migration 024 adds:

- `validation_runs`
- `validation_check_results`
- `validation_run_summary`
- `begin_validation_run(...)`
- `record_validation_check(...)`
- `complete_validation_run(...)`

Only the Owner can create/complete validation evidence. Owner and Manager can review history.

A completed run automatically becomes:

- `pass` — no failed or warning checks
- `warn` — no failures, but at least one warning
- `fail` — one or more failed checks

### Validation History
New staff page:

`/validation-history`

It shows:

- environment
- release version
- latest migration
- number of checks
- pass/warn/fail totals
- overall status
- who started the validation

### Automated staging test accounts
The staging helper can create temporary Auth users for:

- Owner
- Manager
- Cashier
- Baker
- Storekeeper

Command:

```bash
npm run staging:create-test-users
```

The script requires an explicit confirmation variable so it is harder to run accidentally.

### Automated staging smoke validation

Command:

```bash
npm run staging:validate
```

It tests:

1. all five staging users can sign in
2. anonymous public website info works
3. anonymous public catalog works
4. public catalog does not return known internal fields
5. direct anonymous reads of internal tables do not reveal rows
6. Owner/Manager report access
7. report denial for Cashier/Baker/Storekeeper
8. Owner-only production-validation RPC
9. production-validation denial for other roles
10. self-attendance RPC for every role
11. database launch-readiness checks

The result is written back into the validation evidence tables through the Owner account.

### Test-user cleanup

After staging acceptance:

```bash
npm run staging:cleanup-test-users
```

Cleanup requires a separate explicit confirmation variable.

## Safety boundary

The staging scripts are intentionally named with `STAGING_...` variables.

They should never be pointed at the live production bakery database.

Use a dedicated Supabase project or dedicated non-production environment for validation.

## Release state

- App version: `0.25.0`
- Latest migration: `024`
- Release stage: `staging_validation_harness`

A passing v0.25 staging validation run becomes part of the database launch-readiness evidence.
