# DS Bakery v0.26 — Environment Guardrails & Staging Bootstrap

v0.26 strengthens the step between source validation and real staging deployment.

## Why this release exists

The project now has staging test scripts, but test-user scripts must never be accidentally pointed at a production database.

v0.26 adds an explicit database environment state.

## Environment modes

`system_environment_config.environment_mode` supports:

- `unconfigured`
- `staging`
- `production`

A fresh installation begins as `unconfigured`.

Before running staging automation, the Owner must deliberately configure the database as **staging** and enable staging test accounts.

## Staging test-account gate

The staging user creator now refuses to run unless all are true:

- `environment_mode = staging`
- `allow_staging_test_accounts = true`
- `production_lock = false`

The staging validation script uses the same database guardrail.

## Production behavior

Production mode forces:

`allow_staging_test_accounts = false`

The Owner can then enable a **production lock**.

Once production lock is enabled, the ordinary application cannot move the environment back to staging.

This is designed to prevent an accidental test-user workflow against the live bakery database.

## Owner Environment Safety page

New route:

`/environment`

Owner can:

- configure Staging or Production
- enable/disable staging test accounts in staging
- add environment notes
- enable production lock after go-live validation

Explicit phrases are required:

- `CONFIRM STAGING`
- `CONFIRM PRODUCTION`
- `LOCK PRODUCTION`

## Staging bootstrap helpers

### Preflight

```bash
npm run staging:preflight
```

Checks:

- staging environment variables exist
- database reports v0.26.0 / migration 025
- environment mode is staging
- staging test accounts are enabled
- production lock is off

### Apply full schema to an empty staging database

Requires:

`STAGING_SCHEMA_CONFIRMATION=APPLY_SCHEMA_TO_EMPTY_STAGING_DB`

Then:

```bash
npm run staging:apply-schema
```

This uses `psql` and `STAGING_DATABASE_URL`.

### Upgrade a v0.25 staging database

Requires:

`STAGING_UPGRADE_CONFIRMATION=UPGRADE_STAGING_TO_V026`

Then:

```bash
npm run staging:upgrade-v026
```

The upgrade helper requires `pg_dump` and creates a backup before applying migration 025.

### Full staging smoke check

```bash
npm run staging:full-check
```

This runs:

1. staging preflight
2. temporary five-role account creation
3. automated staging validation

## Release state

- App version: `0.26.0`
- Latest migration: `025`
- Release stage: `environment_guardrails`

## Important

The guardrails reduce the chance of an accidental staging operation against production, but they do not replace operational discipline.

Always verify the staging project identity before using service-role or database-administrator credentials.
