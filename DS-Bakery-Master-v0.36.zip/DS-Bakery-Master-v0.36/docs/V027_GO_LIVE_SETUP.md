# DS Bakery v0.27 — Go-Live Setup & Business Readiness

v0.27 adds the final business-data readiness layer before production cutover.

## Why this release exists

Staging validation can prove technical access and RLS behavior, but the bakery still needs real operating data to be checked before the first production transaction.

The Go-Live Setup page combines automatic database checks with Owner confirmations.

## Automatic checks

The system checks:

- at least one active Owner exists
- active staff accounts exist
- at least one active product has a selling price
- active raw materials exist
- active suppliers exist
- no raw material has negative stock
- every active recipe-tracked product has an active recipe
- public contact details are complete
- a passing staging validation run exists
- deployment environment is configured

## Manual Owner checklist

The Owner verifies:

1. Product catalog and selling prices
2. Opening raw-material stock counts
3. Cash / MTN MoMo / Airtel Money payment workflows
4. Public website details and prices
5. Staff accounts and roles
6. Backup/restore plan

Saving the checklist clears a previous completion so changes are re-verified.

## Completion gate

Final completion requires all three:

- automatic gate = pass
- manual gate = pass
- staging validation gate = pass

The Owner must type:

`COMPLETE GO LIVE SETUP`

The action is audited.

## Production behavior

In Staging, incomplete go-live setup appears as a warning.

In Production, incomplete go-live setup becomes a launch-readiness failure.

This prevents an environment from being treated as production-ready before business setup is signed off.

## Staging helper

After the automated staging test:

```bash
npm run staging:go-live-readiness
```

This signs in with the staging Owner test account and prints the automatic/manual go-live readiness state.

## Release state

- App version: `0.27.0`
- Latest migration: `026`
- Release stage: `go_live_setup`
