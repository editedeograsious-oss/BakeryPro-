# DS Bakery v0.28 — Production Cutover & Transaction Safety

v0.28 adds a final database-level transaction gate for the first real production transaction.

## Why this release exists

By v0.27, the project had:

- environment separation
- staging validation
- go-live setup
- production lock

The remaining risk was that a production database could still receive critical operational writes before final live authorization.

v0.28 adds a dedicated Production Cutover state.

## Production Cutover page

Route:

`/production-cutover`

Owner and Manager can view cutover status.

Owner can authorize or resume live operations.

Owner or Manager can suspend live operations immediately.

## Authorization requirements

The Owner must type:

`AUTHORIZE LIVE OPERATIONS`

Authorization is rejected unless:

1. Environment is `production`
2. Production Lock is enabled
3. Go-Live Setup is completed

## Emergency suspension

Owner or Manager can suspend operations with a required reason.

When suspended:

- new critical production transactions are blocked
- Owner authorization is required to resume

Suspension and authorization are audited.

## Database transaction gate

The database trigger gate covers:

- sales
- POS payments
- POS refunds
- customer orders
- customer-order payments
- customer-order refunds
- purchases
- purchase lines
- supplier payments
- inventory transactions
- production runs
- waste events
- expenses
- cash movements

### Staging behavior

Staging remains writable for testing.

### Unconfigured environment

Critical business operations are blocked.

### Production behavior

Critical writes are allowed only when:

- Production Lock = enabled
- Go-Live Setup = completed
- Live Operations = authorized

## Why Cashier Shift and Delivery Status are not gated by this trigger

The cutover trigger focuses on new financial, stock and production transactions.

Operational cleanup actions such as closing a till or finishing an already-dispatched delivery should not become impossible during an emergency suspension.

## Release state

- App version: `0.28.0`
- Latest migration: `027`
- Release stage: `production_cutover`

## Correct production sequence

1. Complete staging validation.
2. Complete Go-Live Setup.
3. Pass build/E2E/backup-restore tests.
4. Configure real environment as Production.
5. Enable Production Lock.
6. Open Production Cutover.
7. Confirm all prerequisites.
8. Type `AUTHORIZE LIVE OPERATIONS`.
9. Perform a controlled first transaction.
10. Reconcile stock, cash and reports immediately after that first transaction.
