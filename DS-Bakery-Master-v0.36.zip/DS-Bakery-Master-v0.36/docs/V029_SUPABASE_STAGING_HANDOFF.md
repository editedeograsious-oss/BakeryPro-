# DS Bakery v0.29 — Supabase Staging Connection Handoff

v0.29 packages the project for the first real non-production Supabase connection.

## What this release adds

- Migration `028_supabase_staging_handoff.sql`
- `/staging-connection`
- masked server-environment readiness
- recorded staging-connection evidence
- anonymous public-site connectivity checks
- service-role admin connectivity check
- v0.29 staging upgrade helper
- staging full-check now includes connection testing before and after temporary test-user creation

## Staging Connection page

The page shows only safe connection status:

- whether the public Supabase URL is configured
- project host
- whether the anon key exists
- whether the server-only service-role key exists
- whether a database URL exists
- latest recorded connection evidence

It never prints secret values.

## Connection command

```bash
npm run staging:connection-check
```

The script verifies:

1. the staging Supabase URL is reachable,
2. the database reports DS Bakery v0.29.0 / migration 028,
3. Environment Safety says Staging,
4. anonymous `public_site_info()` works,
5. anonymous `public_product_catalog()` works,
6. the catalog response does not contain known private fields,
7. the service-role credential can reach the Auth Admin API.

If an Owner staging test account already exists, the script also records the check into `environment_connection_checks`.

## Full staging command

```bash
npm run staging:full-check
```

Current order:

1. staging preflight
2. connection check
3. create five temporary role users
4. connection check again and record evidence
5. role/RLS staging validation

## Supabase connection options

The preferred path is to connect the Supabase integration in ChatGPT and use it to create/manage the non-production project and apply the schema directly.

A manual alternative remains available:

1. create a Supabase staging project,
2. obtain its staging URL, anon key, service-role key and database connection string,
3. keep all secret values outside chat,
4. apply `supabase/schema.sql`,
5. sign in as Owner,
6. configure Environment Safety as Staging,
7. run the staging commands.

## Secret handling

Never paste these into normal chat messages:

- service-role key
- database password
- full database connection string
- real staff passwords

Store them in the private staging environment only.

## Release state

- App version: `0.29.0`
- Latest migration: `028`
- Release stage: `supabase_staging_handoff`
