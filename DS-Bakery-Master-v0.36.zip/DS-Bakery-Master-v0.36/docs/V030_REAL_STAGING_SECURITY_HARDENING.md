# DS Bakery v0.30 — Real Staging + Security Hardening

## Real staging milestone

A real Supabase project named **DS Bakery Staging** was created and all database migrations through 028 were applied successfully.

The staging database was then configured as:

- environment: `staging`
- staging test accounts: enabled
- production lock: off

Release metadata before security hardening was verified as v0.29.0 / migration 028.

## Migration fixes discovered during real execution

Real PostgreSQL execution exposed two source issues in migration 017 that static parsing did not catch:

1. `AT TIME ZONE` expressions required explicit parentheses around the timezone expression.
2. `sale_profit_lines` used view column typmods that were incompatible with the existing view definition.

Those source files were corrected before the migration succeeded.

## Security advisor review

Supabase security advisors found:

- four views using definer behavior
- five functions with mutable `search_path`
- broad anonymous access to SECURITY DEFINER functions

Migration 029 fixes these by:

- converting the four identified views to `security_invoker=true`
- pinning `search_path=public` on the five identified functions
- removing PUBLIC/anon execution from SECURITY DEFINER functions
- preserving authenticated RPC access
- re-enabling anonymous access only for:
  - `public_site_info()`
  - `public_product_catalog()`

The two anonymous RPC warnings remaining after hardening are intentional because those functions expose only customer-safe public website fields.

## Release

- app version: `0.30.0`
- latest migration: `029`
- release stage: `security_hardening`

## Still required

The database currently has no real/staging staff Auth users.

Next:
1. create the first Owner Auth account,
2. link its profile role to Owner,
3. create the remaining staging role accounts,
4. run role/RLS validation.
