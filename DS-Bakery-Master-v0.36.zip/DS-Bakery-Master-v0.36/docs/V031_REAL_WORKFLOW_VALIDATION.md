# DS Bakery v0.31 — Real Workflow Validation

Real staging workflow completed successfully on Supabase.

## Workflow exercised

Supplier → Raw Material → Recipe → Purchase Order → Approval → Receiving → Production Plan → Baker Confirmation → Waste → Customer → Cashier Shift → POS Sale → Customer Order → Customer Payment → Expense → Shift Close → Management Report.

## Issues discovered and fixed

1. Storekeeper had no safe live write path for raw materials.
   - Added `save_raw_material(...)` RPC guarded by `inventory:write`.
2. `launch_readiness_checks()` had ambiguous `status` references under real PostgreSQL execution.
   - Qualified table aliases in stale-shift/schedule checks.

## Verified staging outcomes

- 25 kg flour received.
- 10 units produced, consuming 5 kg flour.
- 20 kg flour remaining.
- 1 finished unit recorded as waste.
- POS sale: UGX 10,000.
- Unit cost snapshot: UGX 2,000.
- Gross profit snapshot: UGX 6,000.
- Customer order: UGX 15,000 fully paid.
- Expense: UGX 2,000.
- Cashier expected cash before close: UGX 43,000.
- Cashier shift closed.
- Management report reconciled:
  - sales 10,000
  - COGS 4,000
  - gross profit 6,000
  - expenses 2,000
  - operating profit 4,000
  - purchases 100,000
  - supplier outstanding 100,000
