# DS Bakery v0.35 — Deployment Preparation

## What is ready

- Railway deployment configuration added.
- `/api/health` is public for infrastructure health checks.
- Health checks use the intentionally public Supabase RPCs instead of direct internal table reads.
- Hosted deployments identify themselves as `staging` or `production`.
- Staging deployments are `noindex` / `nofollow`.
- Demo mode is explicitly disabled in hosted configuration.
- WhatsApp numbers in Uganda local format (`07...`) are converted to international `2567...` format for `wa.me`.
- Staff login no longer pre-fills a fake owner email.
- Deployment preflight rejects accidental browser exposure of service-role/database/password/secret variables.
- Real database release moved to v0.35 / migration 034.

## Railway discovery

An existing Railway project named `Ds-Bakery-Production` is already connected. It contains an older successful service `Ds-Bakery-Live` from repository `editedeograsious-oss/BakeryPro-V5`.

That service was deliberately **not modified** during v0.35 preparation.

The current DS Bakery Master should first be deployed as a separate staging service/URL, validated, and only then considered for production cutover.

## Still pending

- Install dependencies in a build environment.
- Run the full `npm run release:check`.
- Publish current v0.35 source to a deployment repository/branch.
- Create a separate Railway staging service.
- Verify `/api/health` over HTTPS.
- Verify public website rendering.
- Verify real Owner login and one restricted-role login.
- Record the staging URL in `deployment_readiness_state`.

No production cutover should occur before those checks pass.
