# DS Bakery v0.36 — Staging Hardening Consolidation

## Purpose

v0.36 turns the successful Railway/Supabase staging fixes into one clean master source tree. It removes the need for build-time source patches for the Owner dashboard, sidebar, middleware and TypeScript fixes.

## Consolidated application changes

- Practical Owner dashboard with live daily KPIs, payment breakdown, management alerts, low-stock items, best sellers, recent activity and quick actions.
- Business-focused sidebar grouped by daily operations, products/stock, production, purchasing, customers/growth, finance/reports, team, website, and System & Setup.
- Role-aware sidebar visibility for Owner, Manager, Cashier, Baker and Storekeeper.
- Supabase browser/server cookie typings corrected for strict TypeScript builds.
- Public catalog category keys explicitly normalized to strings.
- Canonical direct-source Railway Dockerfile added; staging patch overlays are no longer part of the master release.
- PostCSS 8.5.28 override retained because the staging security build verified `npm audit` with zero vulnerabilities.

## Consolidated database changes — migration 035

- Added/confirmed `dashboard:view` and `security:manage` permission defaults.
- Removed the duplicate `communication_logs_customer_created_idx` index.
- Eliminated the Supabase `auth_rls_initplan` performance warnings on audited policies.
- Split overlapping all-command policies into command-specific write policies, removing the audited multiple-permissive-policy warnings.
- Restricted direct authenticated execution of 12 internal helper SECURITY DEFINER functions that are intended to be invoked through audited parent RPCs.
- Release metadata advances to app version 0.36.0 / migration 035.

## Staging evidence already completed

- Owner/Manager/Cashier/Baker/Storekeeper role and RLS validation passed.
- End-to-end purchase → receiving → production → waste → POS/payment → expense → closing/report workflow passed.
- Cash, MTN MoMo and Airtel Money staging transactions passed with no Mobile Money reference conflicts.
- Railway production build and HTTPS health check passed.
- Owner browser login passed.
- npm audit reported zero vulnerabilities after the PostCSS override.
- Supabase database gate remains PASS.

## Intentionally still open before production

- Replace the 9 staging placeholder records with real bakery data.
- Verify real catalog, opening stock and final staff details.
- Complete and record a real backup/restore drill; the restore drill is not yet passed.
- Finish final public website visual verification.
- Execute controlled production cutover.
- Continue the function-by-function audit of remaining authenticated SECURITY DEFINER RPCs; do not mass-revoke them because many are intentional business APIs.
- Supabase leaked-password protection remains unavailable on the current Free plan.

## Security note

The two anonymous SECURITY DEFINER functions `public_product_catalog()` and `public_site_info()` remain intentionally callable by the public website and expose only public-facing catalog/site fields.
