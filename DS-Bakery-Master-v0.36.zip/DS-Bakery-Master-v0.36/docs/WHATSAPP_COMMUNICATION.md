# DS Bakery WhatsApp Communication

## Phase 3D mode
Phase 3D uses **click-to-WhatsApp**.

The app:
1. prepares the message,
2. normalizes the customer's phone number,
3. opens WhatsApp with the message pre-filled,
4. logs that WhatsApp was opened.

The app does **not** claim the message was sent, delivered or read.

## Why start this way
Official WhatsApp automation requires a Meta/WhatsApp Business setup, approved templates for some outbound messages, API credentials and possible messaging charges.

DS Bakery should not depend on that infrastructure for its first usable communication workflow.

## Message types
- Ready for pickup
- In production
- Out for delivery
- Birthday greeting
- Balance reminder
- Custom staff message

## Consent
Birthday/promotional templates require customer WhatsApp opt-in.

Transactional order messages should still respect the bakery's privacy/customer-contact policy.

## Official API later
If DS Bakery later connects the WhatsApp Business Platform:
- keep `communication_templates` as the internal template catalogue,
- add provider template IDs,
- use a server-only API route or Edge Function,
- never expose provider access tokens to the browser,
- store provider message IDs in `communication_logs.external_message_id`,
- update `api_sent`, `delivered`, or `failed` states only from actual provider responses/webhooks.
