export function costPerBaseUnit(purchaseCost: number, purchaseQtyBaseUnits: number) {
  if (purchaseQtyBaseUnits <= 0) return 0;
  return purchaseCost / purchaseQtyBaseUnits;
}

export function recipeBatchCost(items: Array<{ quantity: number; unitCost: number }>) {
  return items.reduce((sum, item) => sum + item.quantity * item.unitCost, 0);
}

export function unitFoodCost(batchCost: number, yieldQty: number) {
  if (yieldQty <= 0) return 0;
  return batchCost / yieldQty;
}

export function grossProfit(sellingPrice: number, foodCost: number) {
  return sellingPrice - foodCost;
}

export function grossMarginPct(sellingPrice: number, foodCost: number) {
  if (sellingPrice <= 0) return 0;
  return ((sellingPrice - foodCost) / sellingPrice) * 100;
}

export function ugx(value: number) {
  return `UGX ${Math.round(value).toLocaleString("en-UG")}`;
}
