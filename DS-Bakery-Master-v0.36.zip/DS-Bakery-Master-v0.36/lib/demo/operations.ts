export const demoProduction = [
  {id:"pp1",business_date:"2026-10-03",product_id:"p1",product_name:"Milk Bread",planned_qty:100,produced_qty:60,remaining_qty:40,completion_pct:60,shift:"morning",status:"in_progress",assigned_baker_id:"b1",baker_name:"James"},
  {id:"pp2",business_date:"2026-10-03",product_id:"p2",product_name:"Vanilla Cupcake",planned_qty:120,produced_qty:120,remaining_qty:0,completion_pct:100,shift:"morning",status:"complete",assigned_baker_id:"b2",baker_name:"Sarah"},
  {id:"pp3",business_date:"2026-10-03",product_id:"p3",product_name:"Black Forest Slice",planned_qty:100,produced_qty:70,remaining_qty:30,completion_pct:70,shift:"afternoon",status:"in_progress",assigned_baker_id:"b3",baker_name:"Daniel"},
];

export const demoBakers = [
  {id:"b1",full_name:"James"},
  {id:"b2",full_name:"Sarah"},
  {id:"b3",full_name:"Daniel"},
];

export const demoBakerTasks = [
  {id:"bt1",title:"Prepare milk bread dough",product_name:"Milk Bread",assigned_baker_id:"b1",baker_name:"James",due_at:"2026-10-03T07:30:00+03:00",status:"complete"},
  {id:"bt2",title:"Bake second bread batch — 40 loaves",product_name:"Milk Bread",assigned_baker_id:"b1",baker_name:"James",due_at:"2026-10-03T11:30:00+03:00",status:"todo"},
  {id:"bt3",title:"Finish cupcake icing",product_name:"Vanilla Cupcake",assigned_baker_id:"b2",baker_name:"Sarah",due_at:"2026-10-03T12:00:00+03:00",status:"todo"},
];

export const demoWaste = [
  {id:"w1",waste_type:"finished_product",item_name:"Vanilla Cupcake",product_id:"p2",raw_material_id:null,production_run_id:"run2",quantity:8,base_unit:"pcs",reason:"Damaged during icing",total_cost:10240,approval_status:"approved",recorded_by_name:"Sarah",recorded_at:"2026-10-03T10:10:00+03:00"},
  {id:"w2",waste_type:"finished_product",item_name:"Milk Bread",product_id:"p1",raw_material_id:null,production_run_id:"run1",quantity:4,base_unit:"pcs",reason:"Over-baked",total_cost:8480,approval_status:"approved",recorded_by_name:"James",recorded_at:"2026-10-03T09:30:00+03:00"},
  {id:"w3",waste_type:"raw_material",item_name:"Butter",product_id:null,raw_material_id:"m3",production_run_id:null,quantity:1500,base_unit:"g",reason:"Dropped / contaminated",total_cost:28500,approval_status:"approved",recorded_by_name:"Peter",recorded_at:"2026-10-03T09:45:00+03:00"},
  {id:"w4",waste_type:"finished_product",item_name:"Black Forest Slice",product_id:"p3",raw_material_id:null,production_run_id:"run3",quantity:18,base_unit:"pcs",reason:"Quality issue",total_cost:51480,approval_status:"pending",recorded_by_name:"Sarah",recorded_at:"2026-10-03T13:05:00+03:00"},
];

export const demoProductionControl = [
  {product_id:"p1",product_name:"Milk Bread",planned_qty:100,produced_qty:60,approved_waste_qty:4,estimated_sellable_output:56,production_variance:-40,waste_rate_pct:6.67,approved_waste_cost:8480},
  {product_id:"p2",product_name:"Vanilla Cupcake",planned_qty:120,produced_qty:120,approved_waste_qty:8,estimated_sellable_output:112,production_variance:0,waste_rate_pct:6.67,approved_waste_cost:10240},
  {product_id:"p3",product_name:"Black Forest Slice",planned_qty:100,produced_qty:70,approved_waste_qty:0,estimated_sellable_output:70,production_variance:-30,waste_rate_pct:0,approved_waste_cost:0},
];

export const demoPurchaseOrders = [
  {id:"po1",purchase_no:"PO-1045",supplier_id:"sup1",supplier_name:"Golden Millers",purchase_date:"2026-10-03",total_amount:1980000,status:"draft",approval_status:"pending",due_date:"2026-10-10",requested_by_name:"Peter",approved_by_name:null,payment_status:"unpaid",amount_paid:0},
  {id:"po2",purchase_no:"PO-1044",supplier_id:"sup2",supplier_name:"Fresh Dairy Uganda",purchase_date:"2026-10-02",total_amount:920000,status:"ordered",approval_status:"approved",due_date:"2026-10-07",requested_by_name:"Peter",approved_by_name:"Sarah",payment_status:"partial",amount_paid:300000},
  {id:"po3",purchase_no:"PO-1043",supplier_id:"sup3",supplier_name:"SweetSource Ltd",purchase_date:"2026-10-01",total_amount:590000,status:"partially_received",approval_status:"approved",due_date:"2026-10-10",requested_by_name:"Peter",approved_by_name:"Sarah",payment_status:"unpaid",amount_paid:0},
];

export const demoPurchaseLines = [
  {id:"pil1",purchase_id:"po2",purchase_no:"PO-1044",supplier_name:"Fresh Dairy Uganda",raw_material_id:"m4",material_name:"Milk",base_unit:"ml",ordered_qty_base:50000,received_qty_base:20000,remaining_qty_base:30000,unit_cost_base:2.4,line_total:120000,status:"ordered",approval_status:"approved"},
  {id:"pil2",purchase_id:"po3",purchase_no:"PO-1043",supplier_name:"SweetSource Ltd",raw_material_id:"m2",material_name:"Sugar",base_unit:"g",ordered_qty_base:50000,received_qty_base:25000,remaining_qty_base:25000,unit_cost_base:4.4,line_total:220000,status:"partially_received",approval_status:"approved"},
];

export const demoSuppliers = [
  {id:"sup1",name:"Golden Millers"},
  {id:"sup2",name:"Fresh Dairy Uganda"},
  {id:"sup3",name:"SweetSource Ltd"},
];

export const demoMaterialsForPO = [
  {id:"m1",name:"Flour",base_unit:"g"},
  {id:"m2",name:"Sugar",base_unit:"g"},
  {id:"m3",name:"Butter",base_unit:"g"},
  {id:"m4",name:"Milk",base_unit:"ml"},
];

export const demoSupplierAccounts = [
  {supplier_id:"sup1",supplier_name:"Golden Millers",phone:"",email:"",total_purchases:5480000,total_paid:3030000,outstanding_balance:2450000,overdue_balance:1450000,next_due_date:"2026-10-03"},
  {supplier_id:"sup2",supplier_name:"Fresh Dairy Uganda",phone:"",email:"",total_purchases:3120000,total_paid:2200000,outstanding_balance:920000,overdue_balance:0,next_due_date:"2026-10-07"},
  {supplier_id:"sup3",supplier_name:"SweetSource Ltd",phone:"",email:"",total_purchases:1980000,total_paid:1390000,outstanding_balance:590000,overdue_balance:0,next_due_date:"2026-10-10"},
];

export const demoSupplierStatement = [
  {supplier_id:"sup1",occurred_at:"2026-10-03T08:00:00+03:00",line_type:"purchase",source_id:"po1",reference:"PO-1042",supplier_invoice_no:"GM-8831",debit:1980000,credit:0,running_balance:1980000},
  {supplier_id:"sup1",occurred_at:"2026-10-03T12:00:00+03:00",line_type:"payment",source_id:"pay1",reference:"PAY-301",supplier_invoice_no:"GM-8831",debit:0,credit:530000,running_balance:1450000},
];

export const demoExpenses = [
  {id:"e1",category:"Transport",description:"Ingredient delivery",amount:45000,payment_method:"cash",reference:null,created_at:"2026-10-03T09:15:00+03:00",recorded_by_name:"Sarah",shift_label:"Grace"},
  {id:"e2",category:"Utilities",description:"Water refill",amount:60000,payment_method:"cash",reference:null,created_at:"2026-10-03T11:30:00+03:00",recorded_by_name:"Demo Owner",shift_label:null},
  {id:"e3",category:"Packaging",description:"Extra cake boxes",amount:81000,payment_method:"mtn_momo",reference:"MM-88320",created_at:"2026-10-02T14:00:00+03:00",recorded_by_name:"Sarah",shift_label:null},
];

export const demoCashMovements = [
  {id:"cm1",movement_type:"cash_in",amount:50000,reason:"Owner top-up",reference:null,created_by_name:"Demo Owner",shift_cashier_name:"Grace",created_at:"2026-10-03T10:00:00+03:00"},
  {id:"cm2",movement_type:"cash_out",amount:30000,reason:"Petty cash transport",reference:null,created_by_name:"Sarah",shift_cashier_name:"Grace",created_at:"2026-10-03T11:30:00+03:00"},
];

export const demoOpenShifts = [
  {id:"s1",cashier_id:"c1",cashier_name:"Grace",opened_at:"2026-10-03T07:30:00+03:00",opening_float:200000,status:"open"},
];
