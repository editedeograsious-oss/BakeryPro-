export const demoCustomers = [
  {customer_id:"c1",full_name:"Linda Nabirye",phone:"+256 700 111 222",email:"linda@example.com",address:"Entebbe",birthday:"1996-10-08",whatsapp_opt_in:true,order_count:7,total_order_value:860000,outstanding_balance:180000,last_order_at:"2026-10-03T10:00:00+03:00"},
  {customer_id:"c2",full_name:"Mark Ssemanda",phone:"+256 701 333 444",email:null,address:"Kampala",birthday:null,whatsapp_opt_in:false,order_count:4,total_order_value:445000,outstanding_balance:0,last_order_at:"2026-10-02T09:00:00+03:00"},
  {customer_id:"c3",full_name:"Joyce Namukasa",phone:"+256 702 555 666",email:"joyce@example.com",address:"Wakiso",birthday:"1994-10-29",whatsapp_opt_in:true,order_count:11,total_order_value:1260000,outstanding_balance:90000,last_order_at:"2026-10-01T15:00:00+03:00"},
  {customer_id:"c4",full_name:"Rose Nakato",phone:"+256 703 777 888",email:null,address:"Kampala",birthday:"2000-10-17",whatsapp_opt_in:true,order_count:1,total_order_value:85000,outstanding_balance:0,last_order_at:"2026-09-25T15:00:00+03:00"},
];

export const demoServiceProducts = [
  {id:"p1",name:"Milk Bread",selling_price:5000},
  {id:"p2",name:"Vanilla Cupcake",selling_price:3500},
  {id:"p3",name:"Black Forest Slice",selling_price:7000},
  {id:"p4",name:"Sausage Roll",selling_price:4000},
];

export const demoCustomerOrders = [
  {id:"o1",order_no:"ORD-20261003-000101",customer_id:"c1",customer_name:"Linda Nabirye",phone:"+256 700 111 222",status:"confirmed",fulfillment:"pickup",required_at:"2026-10-04T14:00:00+03:00",delivery_address:null,total_amount:380000,amount_paid:200000,balance_due:180000,item_count:2,item_summary:"Birthday Cake × 1, Vanilla Cupcake × 24",created_at:"2026-10-03T09:00:00+03:00"},
  {id:"o2",order_no:"ORD-20261003-000102",customer_id:"c3",customer_name:"Joyce Namukasa",phone:"+256 702 555 666",status:"in_production",fulfillment:"delivery",required_at:"2026-10-04T10:00:00+03:00",delivery_address:"Wakiso Town",total_amount:190000,amount_paid:100000,balance_due:90000,item_count:1,item_summary:"Black Forest Cake × 1",created_at:"2026-10-03T09:20:00+03:00"},
  {id:"o3",order_no:"ORD-20261003-000103",customer_id:"c2",customer_name:"Mark Ssemanda",phone:"+256 701 333 444",status:"ready",fulfillment:"pickup",required_at:"2026-10-03T16:30:00+03:00",delivery_address:null,total_amount:240000,amount_paid:240000,balance_due:0,item_count:1,item_summary:"Sausage Roll × 60",created_at:"2026-10-02T11:00:00+03:00"},
];

export const demoCustomCakes = [
  {custom_cake_id:"cc1",order_id:"o4",order_no:"ORD-20261003-000104",customer_id:"c1",customer_name:"Linda Nabirye",phone:"+256 700 111 222",required_at:"2026-10-05T15:00:00+03:00",fulfillment:"pickup",delivery_address:null,cake_size_label:"2 kg",servings:30,tiers:2,flavour:"Vanilla",filling:"Strawberry",frosting:"Buttercream",theme:"Gold & cream birthday",primary_color:"Gold",secondary_color:"Cream",inscription:"Happy Birthday Linda",reference_image_path:null,reference_image_url:null,special_instructions:"Elegant finish",production_notes:"Use stable two-tier supports",quote_amount:420000,deposit_required:210000,amount_paid:220000,balance_due:200000,design_status:"approved",order_status:"confirmed"},
  {custom_cake_id:"cc2",order_id:"o5",order_no:"ORD-20261003-000105",customer_id:"c3",customer_name:"Joyce Namukasa",phone:"+256 702 555 666",required_at:"2026-10-06T11:00:00+03:00",fulfillment:"pickup",delivery_address:null,cake_size_label:"1.5 kg",servings:20,tiers:1,flavour:"Black Forest",filling:"Cherry",frosting:"Cream",theme:"Football",primary_color:"Green",secondary_color:"White",inscription:"Happy Birthday Joel",reference_image_path:null,reference_image_url:null,special_instructions:null,production_notes:null,quote_amount:260000,deposit_required:130000,amount_paid:100000,balance_due:160000,design_status:"awaiting_deposit",order_status:"pending"},
];

export const demoRiders = [
  {rider_id:"r1",full_name:"Brian Rider",phone:"+256 705 111 222",vehicle_label:"Motorcycle UDX 123A",active:true,active_jobs:1,delivered_today:4},
  {rider_id:"r2",full_name:"Moses Rider",phone:"+256 706 333 444",vehicle_label:"Motorcycle UEA 808B",active:true,active_jobs:0,delivered_today:3},
];

export const demoDeliveries = [
  {id:"d1",order_id:"o2",order_no:"ORD-20261003-000102",customer_id:"c3",customer_name:"Joyce Namukasa",customer_phone:"+256 702 555 666",delivery_address:"Wakiso Town",scheduled_for:"2026-10-04T10:00:00+03:00",delivery_charge:15000,status:"assigned",rider_id:"r1",rider_name:"Brian Rider",rider_phone:"+256 705 111 222",total_amount:190000,amount_paid:100000,balance_due:90000,assigned_at:"2026-10-03T13:00:00+03:00",dispatched_at:null,delivered_at:null,failed_at:null,outcome_note:null},
];

export const demoRetention = [
  {customer_id:"c3",full_name:"Joyce Namukasa",phone:"+256 702 555 666",email:"joyce@example.com",birthday:"1994-10-29",order_count:11,lifetime_value:1260000,last_order_at:"2026-10-01T15:00:00+03:00",points_balance:1260,customer_segment:"VIP"},
  {customer_id:"c1",full_name:"Linda Nabirye",phone:"+256 700 111 222",email:"linda@example.com",birthday:"1996-10-08",order_count:7,lifetime_value:860000,last_order_at:"2026-10-03T10:00:00+03:00",points_balance:860,customer_segment:"Regular"},
  {customer_id:"c2",full_name:"Mark Ssemanda",phone:"+256 701 333 444",email:null,birthday:null,order_count:4,lifetime_value:445000,last_order_at:"2026-10-02T09:00:00+03:00",points_balance:445,customer_segment:"Returning"},
  {customer_id:"c4",full_name:"Rose Nakato",phone:"+256 703 777 888",email:null,birthday:"2000-10-17",order_count:1,lifetime_value:85000,last_order_at:"2026-09-25T15:00:00+03:00",points_balance:85,customer_segment:"New"},
];

export const demoBirthdays = [
  {customer_id:"c1",full_name:"Linda Nabirye",phone:"+256 700 111 222",birthday:"1996-10-08",next_birthday:"2026-10-08",days_until_birthday:5,points_balance:860},
  {customer_id:"c4",full_name:"Rose Nakato",phone:"+256 703 777 888",birthday:"2000-10-17",next_birthday:"2026-10-17",days_until_birthday:14,points_balance:85},
  {customer_id:"c3",full_name:"Joyce Namukasa",phone:"+256 702 555 666",birthday:"1994-10-29",next_birthday:"2026-10-29",days_until_birthday:26,points_balance:1260},
];

export const demoLoyaltyLedger = [
  {id:"lt1",customer_id:"c3",event_type:"order_earn",points_delta:190,value_amount:0,source_type:"customer_order",source_id:"o2",reason:"Points earned from completed customer order",created_at:"2026-10-03T12:00:00+03:00"},
  {id:"lt2",customer_id:"c1",event_type:"manual_adjustment",points_delta:25,value_amount:0,source_type:"manual",source_id:null,reason:"Customer-care bonus",created_at:"2026-10-02T12:00:00+03:00"},
];

export const demoLoyaltySettings = {id:1,earn_amount_per_point:1000,reward_points:100,reward_value:5000,birthday_reminder_days:30,vip_spend_threshold:1000000,regular_spend_threshold:500000,regular_order_threshold:5};

export const demoCommunicationTemplates = [
  {id:"t1",name:"Ready for pickup",template_type:"ready_for_pickup",body_template:"Hello {{customer_name}}, your DS Bakery order {{order_no}} is ready for collection. Balance due: UGX {{balance}}. Thank you for choosing DS Bakery.",requires_marketing_opt_in:false,active:true},
  {id:"t2",name:"In production",template_type:"in_production",body_template:"Hello {{customer_name}}, your DS Bakery order {{order_no}} is now in production. We will update you when it is ready.",requires_marketing_opt_in:false,active:true},
  {id:"t3",name:"Out for delivery",template_type:"out_for_delivery",body_template:"Hello {{customer_name}}, your DS Bakery order {{order_no}} is out for delivery. Please keep your phone available for the rider.",requires_marketing_opt_in:false,active:true},
  {id:"t4",name:"Birthday greeting",template_type:"birthday",body_template:"Happy birthday {{customer_name}}! DS Bakery wishes you a wonderful day. We appreciate having you as our customer.",requires_marketing_opt_in:true,active:true},
  {id:"t5",name:"Balance reminder",template_type:"balance_reminder",body_template:"Hello {{customer_name}}, order {{order_no}} has a remaining balance of UGX {{balance}}. Thank you.",requires_marketing_opt_in:false,active:true},
];

export const demoCommunicationQueue = [
  {queue_type:"ready_for_pickup",priority:100,customer_id:"c2",customer_name:"Mark Ssemanda",phone:"+256 701 333 444",whatsapp_opt_in:false,order_id:"o3",order_no:"ORD-20261003-000103",due_at:"2026-10-03T16:30:00+03:00",balance_due:0,reason:"Order is ready for pickup"},
  {queue_type:"in_production",priority:95,customer_id:"c3",customer_name:"Joyce Namukasa",phone:"+256 702 555 666",whatsapp_opt_in:true,order_id:"o2",order_no:"ORD-20261003-000102",due_at:"2026-10-04T10:00:00+03:00",balance_due:90000,reason:"Order is in production"},
  {queue_type:"birthday",priority:50,customer_id:"c1",customer_name:"Linda Nabirye",phone:"+256 700 111 222",whatsapp_opt_in:true,order_id:null,order_no:null,due_at:"2026-10-08T00:00:00+03:00",balance_due:0,reason:"Birthday in 5 days"},
];

export const demoCommunicationLogs = [
  {id:"cl1",customer_id:"c1",order_id:null,template_id:"t4",status:"opened_whatsapp",recipient_phone_snapshot:"+256 700 111 222",message_snapshot:"Happy birthday Linda!",initiated_by_name:"Grace",initiated_at:"2026-10-02T09:00:00+03:00"},
];
