import { createClient } from "@/lib/supabase/server";
import { deploymentEnvironment, hasSupabaseConfig, runtimeMode } from "@/lib/runtime";

export type HealthCheck = {
  key: string;
  label: string;
  status: "pass" | "warn" | "fail";
  detail: string;
};

export async function getSystemHealth(): Promise<{
  mode: "demo" | "live";
  environment: "local" | "staging" | "production";
  checks: HealthCheck[];
}> {
  const checks: HealthCheck[] = [];
  const mode = runtimeMode();
  const environment=deploymentEnvironment();

  if (!hasSupabaseConfig()) {
    checks.push({
      key: "env",
      label: "Supabase environment",
      status: "warn",
      detail: "Supabase URL/publishable key are not configured. The application is in demo mode.",
    });
    return { mode, environment, checks };
  }

  checks.push({
    key: "env",
    label: "Supabase environment",
    status: "pass",
    detail: `Supabase public connection settings are configured for ${environment}.`,
  });

  try {
    const supabase = await createClient();

    // Public-safe RPCs are intentionally executable by anon/authenticated users.
    const [{ error: infoError }, { error: catalogError }] = await Promise.all([
      supabase.rpc("public_site_info"),
      supabase.rpc("public_product_catalog"),
    ]);

    const publicRpcError=infoError||catalogError;
    checks.push({
      key: "database",
      label: "Database connection",
      status: publicRpcError ? "fail" : "pass",
      detail: publicRpcError
        ? `Public Supabase RPC failed: ${publicRpcError.message}`
        : "Database and public website RPCs responded successfully.",
    });

    const { data: userData, error: userError } = await supabase.auth.getUser();
    checks.push({
      key: "auth",
      label: "Authentication service",
      status: userError ? "warn" : "pass",
      detail: userError
        ? "Authentication service is reachable; no valid staff session is present."
        : userData.user
          ? `Authenticated staff session is present for ${userData.user.email ?? userData.user.id}.`
          : "Authentication service is reachable; no staff user is currently signed in.",
    });
  } catch (error) {
    checks.push({
      key: "database",
      label: "Database connection",
      status: "fail",
      detail: error instanceof Error ? error.message : "Unknown database error.",
    });
  }

  return { mode, environment, checks };
}
