export type StockState = {
  stockQty: number;
  currentUnitCost: number;
};

export function weightedAverageUnitCost(
  current: StockState,
  receivedQty: number,
  receivedUnitCost: number
) {
  if (receivedQty <= 0) return current.currentUnitCost;
  if (current.stockQty <= 0) return receivedUnitCost;

  const oldValue = current.stockQty * current.currentUnitCost;
  const incomingValue = receivedQty * receivedUnitCost;
  return (oldValue + incomingValue) / (current.stockQty + receivedQty);
}

export function isLowStock(stockQty: number, threshold: number) {
  return stockQty <= threshold;
}

export function stockStatus(stockQty: number, threshold: number) {
  if (stockQty <= 0) return "out";
  if (stockQty <= threshold) return "low";
  return "ok";
}
