export type CartLine = {
  productId: string;
  name: string;
  unitPrice: number;
  quantity: number;
};

export function lineTotal(line: CartLine) {
  return line.unitPrice * line.quantity;
}

export function subtotal(lines: CartLine[]) {
  return lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

export function discountAmount(
  subtotalValue: number,
  type: "amount" | "percent",
  value: number
) {
  if (value <= 0) return 0;
  if (type === "percent") {
    return Math.min(subtotalValue, subtotalValue * (value / 100));
  }
  return Math.min(subtotalValue, value);
}

export function grandTotal(
  subtotalValue: number,
  discountValue: number
) {
  return Math.max(0, subtotalValue - discountValue);
}

export function changeDue(amountReceived: number, total: number) {
  return Math.max(0, amountReceived - total);
}
