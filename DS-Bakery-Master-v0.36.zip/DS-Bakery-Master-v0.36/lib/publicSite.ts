export function normalizeWhatsAppPhone(value?:string|null){
  const digits=String(value??"").replace(/\D/g,"");
  if(!digits)return "";
  if(digits.startsWith("256"))return digits;
  if(digits.startsWith("0") && digits.length===10)return `256${digits.slice(1)}`;
  return digits;
}

export function buildPublicWhatsAppUrl(phone:string|undefined|null,message:string){
  const clean=normalizeWhatsAppPhone(phone);
  if(!clean)return null;
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
}

export function buildTikTokUrl(handle?:string|null){
  const value=String(handle??"").trim();
  if(!value)return null;
  const clean=value.replace(/^@/,"");
  if(!/\s/.test(clean)) return `https://www.tiktok.com/@${encodeURIComponent(clean)}`;
  return `https://www.tiktok.com/search?q=${encodeURIComponent(value)}`;
}
