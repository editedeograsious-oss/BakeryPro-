export type PeriodSummary = {
  sales: number;
  grossProfit: number;
  expenses: number;
  transactionCount: number;
};

export function estimatedOperatingProfit(summary: PeriodSummary) {
  return summary.grossProfit - summary.expenses;
}

export function expenseRatio(summary: PeriodSummary) {
  if (summary.sales <= 0) return 0;
  return (summary.expenses / summary.sales) * 100;
}

export function grossMargin(summary: PeriodSummary) {
  if (summary.sales <= 0) return 0;
  return (summary.grossProfit / summary.sales) * 100;
}
