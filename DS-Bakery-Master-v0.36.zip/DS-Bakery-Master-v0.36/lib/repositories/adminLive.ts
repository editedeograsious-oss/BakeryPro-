import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

const demoStaff=[
  {id:"s1",full_name:"Demo Owner",role:"owner",active:true,disabled_at:null,session_version:1,last_sign_in_at:null},
  {id:"s2",full_name:"Sarah",role:"manager",active:true,disabled_at:null,session_version:1,last_sign_in_at:null},
  {id:"s3",full_name:"Grace",role:"cashier",active:true,disabled_at:null,session_version:1,last_sign_in_at:null},
  {id:"s4",full_name:"James",role:"baker",active:true,disabled_at:null,session_version:1,last_sign_in_at:null},
  {id:"s5",full_name:"Peter",role:"storekeeper",active:false,disabled_at:"2026-10-01T16:12:00+03:00",session_version:2,last_sign_in_at:null},
];

const demoAttendance=[
  {shift_id:"ws1",staff_id:"s2",full_name:"Sarah",role:"manager",shift_date:"2026-10-03",scheduled_start:"07:00",scheduled_end:"16:00",work_station:"Operations",attendance_id:"a1",clock_in_at:"2026-10-03T06:56:00+03:00",clock_out_at:null,attendance_status:"on_time",late_minutes:0,display_status:"on_time"},
  {shift_id:"ws2",staff_id:"s3",full_name:"Grace",role:"cashier",shift_date:"2026-10-03",scheduled_start:"07:30",scheduled_end:"17:00",work_station:"Front POS",attendance_id:"a2",clock_in_at:"2026-10-03T07:42:00+03:00",clock_out_at:null,attendance_status:"late",late_minutes:7,display_status:"late"},
  {shift_id:"ws3",staff_id:"s4",full_name:"James",role:"baker",shift_date:"2026-10-03",scheduled_start:"06:00",scheduled_end:"15:00",work_station:"Kitchen",attendance_id:"a3",clock_in_at:"2026-10-03T05:58:00+03:00",clock_out_at:"2026-10-03T14:55:00+03:00",attendance_status:"completed",late_minutes:0,display_status:"completed"},
];

const demoSchedule=[
  {id:"ws4",staff_id:"s4",full_name:"James",role:"baker",shift_date:"2026-10-05",scheduled_start:"06:00",scheduled_end:"15:00",work_station:"Kitchen",status:"scheduled",notes:null},
  {id:"ws5",staff_id:"s3",full_name:"Grace",role:"cashier",shift_date:"2026-10-05",scheduled_start:"07:30",scheduled_end:"17:00",work_station:"Front POS",status:"scheduled",notes:null},
  {id:"ws6",staff_id:"s5",full_name:"Peter",role:"storekeeper",shift_date:"2026-10-05",scheduled_start:"08:00",scheduled_end:"17:00",work_station:"Store",status:"scheduled",notes:null},
];

const demoPermissions=[
  {permission_key:"reports:view",description:"View owner/manager reports",critical:true,role_default:false,individual_override:null,has_override:false,effective_allowed:false},
  {permission_key:"delivery:manage",description:"Manage delivery jobs",critical:false,role_default:true,individual_override:null,has_override:false,effective_allowed:true},
  {permission_key:"communication:send",description:"Open customer communication messages",critical:false,role_default:true,individual_override:null,has_override:false,effective_allowed:true},
  {permission_key:"products:write",description:"Change product details/prices",critical:true,role_default:false,individual_override:null,has_override:false,effective_allowed:false},
];

export async function getStaffAdminData(){
  if(isDemoMode()) return {staff:demoStaff,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("staff_security_status").select("*").order("full_name");
  if(error)throw error;
  return {staff:data??[],demo:false};
}

export async function getAttendancePageData(){
  if(isDemoMode()) return {rows:demoAttendance,settings:{late_grace_minutes:5},self:null,demo:true};
  const supabase=await createClient();
  const [{data:rows,error:rErr},{data:settings,error:sErr},{data:self,error:selfErr}]=await Promise.all([
    supabase.from("attendance_today").select("*").order("scheduled_start"),
    supabase.from("attendance_settings").select("*").eq("id",1).single(),
    supabase.rpc("my_attendance_status_today"),
  ]);
  if(rErr)throw rErr;if(sErr)throw sErr;if(selfErr)throw selfErr;
  return {rows:rows??[],settings,self,demo:false};
}

export async function getSchedulePageData(canManage:boolean){
  if(isDemoMode()) return {rows:demoSchedule,staff:demoStaff.filter(s=>s.active),demo:true};
  const supabase=await createClient();
  const {data:rows,error:rErr}=await supabase.from("staff_shift_schedule").select("*").gte("shift_date",new Date().toISOString().slice(0,10)).order("shift_date").order("scheduled_start");
  if(rErr)throw rErr;
  let staff:any[]=[];
  if(canManage){
    const {data,error}=await supabase.from("profiles").select("id,full_name,role,active").eq("active",true).order("full_name");
    if(error)throw error;
    staff=data??[];
  }
  return {rows:rows??[],staff,demo:false};
}

export async function getPermissionOverrideData(staffId?:string){
  if(isDemoMode()) return {staff:demoStaff.filter(s=>s.active&&s.role!=="owner"),permissions:demoPermissions,selectedId:staffId??"s3",demo:true};
  const supabase=await createClient();
  const {data:staff,error:sErr}=await supabase.from("profiles").select("id,full_name,role,active").eq("active",true).neq("role","owner").order("full_name");
  if(sErr)throw sErr;
  const selectedId=staffId??staff?.[0]?.id??null;
  let permissions:any[]=[];
  if(selectedId){
    const {data,error}=await supabase.rpc("effective_staff_permissions",{p_staff_id:selectedId});
    if(error)throw error;
    permissions=data??[];
  }
  return {staff:staff??[],permissions,selectedId,demo:false};
}

export async function getLiveReportData(period:"week"|"month"){
  if(isDemoMode()){
    const demo=period==="week"
      ? {sales:10800000,cogs:4900000,gross_profit:5900000,expenses:1090000,operating_profit:4810000,purchases:6100000,waste_cost:221000,transactions:286,customer_order_value:2050000,customer_order_outstanding:870000,supplier_outstanding:3960000,supplier_overdue:1450000,production_planned:1820,production_produced:1696}
      : {sales:42700000,cogs:19600000,gross_profit:23100000,expenses:4310000,operating_profit:18790000,purchases:22800000,waste_cost:812000,transactions:1124,customer_order_value:8740000,customer_order_outstanding:870000,supplier_outstanding:3960000,supplier_overdue:1450000,production_planned:7460,production_produced:7095};
    return {summary:demo,products:[],payments:[],expenses:[],demo:true};
  }
  const supabase=await createClient();
  const {data,error}=await supabase.rpc("management_report_v2",{p_period:period});
  if(error)throw error;
  return {summary:data?.summary??{},products:data?.products??[],payments:data?.payments??[],expenses:data?.expenses??[],demo:false};
}

export async function getActivityLogData(){
  if(isDemoMode()) return {rows:[
    {id:"al1",created_at:"2026-10-03T11:42:00+03:00",actor_name:"Sarah",action:"record_expense",entity:"Expense",entity_id:"e1"},
    {id:"al2",created_at:"2026-10-03T10:45:00+03:00",actor_name:"Peter",action:"receive_stock",entity:"Purchase",entity_id:"po1"},
    {id:"al3",created_at:"2026-10-03T10:31:00+03:00",actor_name:"Grace",action:"complete_sale",entity:"Sale",entity_id:"sale1"},
  ],demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("audit_log_summary").select("*").order("created_at",{ascending:false}).limit(300);
  if(error)throw error;
  return {rows:data??[],demo:false};
}
