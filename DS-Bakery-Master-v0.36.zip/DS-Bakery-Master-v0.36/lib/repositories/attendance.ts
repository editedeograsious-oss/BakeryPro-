import { createClient } from "@/lib/supabase/server";

export async function getTodayAttendance() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("attendance_today")
    .select("*")
    .order("scheduled_start");

  if (error) throw error;
  return data ?? [];
}

export async function getStaffSchedule(startDate: string, endDate: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("staff_shift_schedule")
    .select("*")
    .gte("shift_date", startDate)
    .lte("shift_date", endDate)
    .order("shift_date")
    .order("scheduled_start");

  if (error) throw error;
  return data ?? [];
}

export async function clockIn() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("clock_in_staff");
  if (error) throw error;
  return data;
}

export async function clockOut() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("clock_out_staff");
  if (error) throw error;
  return data;
}
