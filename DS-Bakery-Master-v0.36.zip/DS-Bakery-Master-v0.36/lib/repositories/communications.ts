import { createClient } from "@/lib/supabase/server";

export async function getCommunicationTemplates() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("communication_templates")
    .select("*")
    .eq("active", true)
    .order("template_type");

  if (error) throw error;
  return data ?? [];
}

export async function getCommunicationQueue() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("customer_communication_queue")
    .select("*")
    .order("priority", { ascending: false })
    .order("due_at", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function logWhatsAppOpen(args: {
  customerId: string;
  orderId?: string | null;
  templateId?: string | null;
  recipientPhone: string;
  message: string;
  clientRequestId?: string | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("log_whatsapp_open", {
    p_customer_id: args.customerId,
    p_order_id: args.orderId ?? null,
    p_template_id: args.templateId ?? null,
    p_recipient_phone: args.recipientPhone,
    p_message: args.message,
    p_client_request_id: args.clientRequestId ?? null,
  });

  if (error) throw error;
  return data;
}

export async function setWhatsAppPreference(
  customerId: string,
  optedIn: boolean
) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("set_customer_whatsapp_preference", {
    p_customer_id: customerId,
    p_opted_in: optedIn,
  });

  if (error) throw error;
  return data;
}
