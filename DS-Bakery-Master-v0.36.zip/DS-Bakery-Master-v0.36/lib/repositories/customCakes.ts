import { createClient } from "@/lib/supabase/server";

export async function getCustomCakeOrders() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("custom_cake_order_summary")
    .select("*")
    .order("required_at", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function saveCustomCakeQuote(args: {
  orderId: string;
  quoteAmount: number;
  productionNotes?: string | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("quote_custom_cake_order", {
    p_order_id: args.orderId,
    p_quote_amount: args.quoteAmount,
    p_production_notes: args.productionNotes ?? null,
  });

  if (error) throw error;
  return data;
}

export async function approveCustomCake(orderId: string) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("approve_custom_cake_for_production", {
    p_order_id: orderId,
  });

  if (error) throw error;
  return data;
}
