import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";
import {
  demoBirthdays,
  demoCommunicationLogs,
  demoCommunicationQueue,
  demoCommunicationTemplates,
  demoCustomCakes,
  demoCustomerOrders,
  demoCustomers,
  demoDeliveries,
  demoLoyaltyLedger,
  demoLoyaltySettings,
  demoRetention,
  demoRiders,
  demoServiceProducts,
} from "@/lib/demo/service";

export async function getCustomersPageData(){
  if(isDemoMode()) return {customers:demoCustomers,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("customer_summary").select("*").order("last_order_at",{ascending:false,nullsFirst:false});
  if(error) throw error;
  return {customers:data??[],demo:false};
}

export async function getCustomerOrdersPageData(){
  if(isDemoMode()) return {orders:demoCustomerOrders,customers:demoCustomers,products:demoServiceProducts,shifts:[],demo:true};
  const supabase=await createClient();
  const [
    {data:orders,error:oErr},
    {data:customers,error:cErr},
    {data:products,error:pErr},
    {data:shifts,error:sErr},
  ]=await Promise.all([
    supabase.from("customer_order_summary").select("*").order("required_at"),
    supabase.from("customers").select("id,full_name,phone").eq("active",true).order("full_name"),
    supabase.from("products").select("id,name,selling_price").eq("status","active").order("name"),
    supabase.from("cashier_shift_summary").select("id,cashier_id,cashier_name,status,opened_at").eq("status","open").order("opened_at"),
  ]);
  if(oErr)throw oErr;if(cErr)throw cErr;if(pErr)throw pErr;if(sErr)throw sErr;
  return {orders:orders??[],customers:customers??[],products:products??[],shifts:shifts??[],demo:false};
}

export async function getCustomCakePageData(){
  if(isDemoMode()) return {cakes:demoCustomCakes,customers:demoCustomers,shifts:[],demo:true};
  const supabase=await createClient();
  const [{data:cakes,error:cakeErr},{data:customers,error:cErr},{data:shifts,error:sErr}]=await Promise.all([
    supabase.from("custom_cake_order_summary").select("*").order("required_at"),
    supabase.from("customers").select("id,full_name,phone").eq("active",true).order("full_name"),
    supabase.from("cashier_shift_summary").select("id,cashier_id,cashier_name,status,opened_at").eq("status","open").order("opened_at"),
  ]);
  if(cakeErr)throw cakeErr;if(cErr)throw cErr;if(sErr)throw sErr;

  const withUrls=await Promise.all((cakes??[]).map(async (cake:any)=>{
    if(!cake.reference_image_path) return {...cake,reference_image_url:null};
    const {data,error}=await supabase.storage.from("custom-cake-references").createSignedUrl(cake.reference_image_path,900);
    return {...cake,reference_image_url:error?null:data?.signedUrl??null};
  }));

  return {cakes:withUrls,customers:customers??[],shifts:shifts??[],demo:false};
}

export async function getDeliveryPageData(){
  if(isDemoMode()) {
    const jobIds=new Set(demoDeliveries.map(j=>j.order_id));
    return {jobs:demoDeliveries,riders:demoRiders,orders:demoCustomerOrders.filter(o=>o.fulfillment==="delivery"&&!jobIds.has(o.id)),demo:true};
  }
  const supabase=await createClient();
  const [
    {data:jobs,error:jErr},
    {data:riders,error:rErr},
    {data:orders,error:oErr},
  ]=await Promise.all([
    supabase.from("delivery_job_summary").select("*").order("scheduled_for"),
    supabase.from("delivery_rider_summary").select("*").order("active_jobs").order("full_name"),
    supabase.from("customer_order_summary").select("*").eq("fulfillment","delivery").not("status","in","(completed,cancelled)").order("required_at"),
  ]);
  if(jErr)throw jErr;if(rErr)throw rErr;if(oErr)throw oErr;
  const jobOrderIds=new Set((jobs??[]).map((j:any)=>j.order_id));
  return {jobs:jobs??[],riders:riders??[],orders:(orders??[]).filter((o:any)=>!jobOrderIds.has(o.id)),demo:false};
}

export async function getRiderPageData(){
  if(isDemoMode()) return {riders:demoRiders,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("delivery_rider_summary").select("*").order("active",{ascending:false}).order("full_name");
  if(error)throw error;
  return {riders:data??[],demo:false};
}

export async function getLoyaltyPageData(){
  if(isDemoMode()) return {customers:demoRetention,ledger:demoLoyaltyLedger,settings:demoLoyaltySettings,orders:demoCustomerOrders,demo:true};
  const supabase=await createClient();
  const [
    {data:customers,error:cErr},
    {data:ledger,error:lErr},
    {data:settings,error:sErr},
    {data:orders,error:oErr},
  ]=await Promise.all([
    supabase.from("customer_retention_summary").select("*").order("lifetime_value",{ascending:false}),
    supabase.from("loyalty_point_transactions").select("*").order("created_at",{ascending:false}).limit(500),
    supabase.from("loyalty_settings").select("*").eq("id",1).single(),
    supabase.from("customer_order_summary").select("id,order_no,customer_id,status,total_amount,amount_paid,balance_due").not("status","in","(completed,cancelled)").order("required_at"),
  ]);
  if(cErr)throw cErr;if(lErr)throw lErr;if(sErr)throw sErr;if(oErr)throw oErr;
  return {customers:customers??[],ledger:ledger??[],settings,orders:orders??[],demo:false};
}

export async function getRetentionPageData(){
  if(isDemoMode()) return {customers:demoRetention,birthdays:demoBirthdays,demo:true};
  const supabase=await createClient();
  const [{data:customers,error:cErr},{data:birthdays,error:bErr}]=await Promise.all([
    supabase.from("customer_retention_summary").select("*").order("lifetime_value",{ascending:false}),
    supabase.from("upcoming_customer_birthdays").select("*").lte("days_until_birthday",30).order("days_until_birthday"),
  ]);
  if(cErr)throw cErr;if(bErr)throw bErr;
  return {customers:customers??[],birthdays:birthdays??[],demo:false};
}

export async function getCommunicationPageData(){
  if(isDemoMode()) return {queue:demoCommunicationQueue,templates:demoCommunicationTemplates,logs:demoCommunicationLogs,demo:true};
  const supabase=await createClient();
  const [
    {data:queue,error:qErr},
    {data:templates,error:tErr},
    {data:logs,error:lErr},
  ]=await Promise.all([
    supabase.from("customer_communication_queue").select("*").order("priority",{ascending:false}).order("due_at"),
    supabase.from("communication_templates").select("*").eq("active",true).order("template_type"),
    supabase.from("communication_log_summary").select("*").order("initiated_at",{ascending:false}).limit(100),
  ]);
  if(qErr)throw qErr;if(tErr)throw tErr;if(lErr)throw lErr;
  return {queue:queue??[],templates:templates??[],logs:logs??[],demo:false};
}

export async function getTemplatePageData(){
  if(isDemoMode()) return {templates:demoCommunicationTemplates,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("communication_templates").select("*").order("template_type").order("name");
  if(error)throw error;
  return {templates:data??[],demo:false};
}
