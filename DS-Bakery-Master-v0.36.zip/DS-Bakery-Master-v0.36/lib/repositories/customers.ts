import { createClient } from "@/lib/supabase/server";

export async function getCustomers() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("customer_summary")
    .select("*")
    .order("last_order_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function getCustomerOrders(status?: string) {
  const supabase = await createClient();

  let query = supabase
    .from("customer_order_summary")
    .select("*")
    .order("required_at", { ascending: true });

  if (status) query = query.eq("status", status);

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function recordOrderPayment(args: {
  orderId: string;
  amount: number;
  method: "cash" | "mtn_momo" | "airtel_money";
  reference?: string | null;
  shiftId?: string | null;
  clientRequestId?: string | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("record_customer_order_payment", {
    p_order_id: args.orderId,
    p_amount: args.amount,
    p_method: args.method,
    p_reference: args.reference ?? null,
    p_shift_id: args.shiftId ?? null,
    p_client_request_id: args.clientRequestId ?? null,
  });

  if (error) throw error;
  return data;
}

export async function updateOrderStatus(
  orderId: string,
  status:
    | "pending"
    | "confirmed"
    | "in_production"
    | "ready"
    | "completed"
    | "cancelled",
  reason?: string | null
) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("update_customer_order_status", {
    p_order_id: orderId,
    p_status: status,
    p_reason: reason ?? null,
  });

  if (error) throw error;
  return data;
}
