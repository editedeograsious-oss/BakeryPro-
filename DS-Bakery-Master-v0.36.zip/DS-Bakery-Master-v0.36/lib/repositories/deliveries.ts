import { createClient } from "@/lib/supabase/server";

export async function getDeliveryJobs() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("delivery_job_summary")
    .select("*")
    .order("scheduled_for", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function getDeliveryRiders() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("delivery_rider_summary")
    .select("*")
    .order("active_jobs", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function assignDeliveryRider(deliveryId: string, riderId: string) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("assign_delivery_rider", {
    p_delivery_id: deliveryId,
    p_rider_id: riderId,
  });

  if (error) throw error;
  return data;
}

export async function updateDeliveryStatus(
  deliveryId: string,
  status: "out_for_delivery" | "delivered" | "failed" | "cancelled",
  note?: string
) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("update_delivery_status", {
    p_delivery_id: deliveryId,
    p_status: status,
    p_note: note ?? null,
  });

  if (error) throw error;
  return data;
}
