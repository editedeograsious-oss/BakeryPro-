import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

export async function getEnvironmentConfig(){
  if(isDemoMode()){
    return {
      config:{
        environment_mode:"staging",
        allow_staging_test_accounts:true,
        production_lock:false,
        notes:"Demo preview",
        updated_at:null,
      },
      demo:true,
    };
  }

  const supabase=await createClient();
  const {data,error}=await supabase.rpc("environment_state");
  if(error)throw error;
  return {config:data??{},demo:false};
}
