import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

const demo={
  environment_mode:"staging",
  production_lock:false,
  automatic:{
    active_owner:true,
    active_staff_count:5,
    active_products:8,
    active_raw_materials:12,
    active_suppliers:3,
    negative_stock_count:0,
    recipe_gap_count:0,
    public_site_contact_ready:true,
    passing_staging_validation:false,
  },
  manual:{
    catalog_verified:false,
    opening_stock_verified:false,
    payment_methods_verified:false,
    public_site_verified:false,
    staff_accounts_verified:false,
    backup_plan_verified:false,
  },
  automatic_gate:"pass",
  manual_gate:"fail",
  staging_validation_gate:"warn",
  setup_completed:false,
  completed_at:null,
  notes:null,
};

export async function getGoLiveSetupData(){
  if(isDemoMode()) return {readiness:demo,demo:true};

  const supabase=await createClient();
  const {data,error}=await supabase.rpc("go_live_setup_readiness");
  if(error)throw error;
  return {readiness:data??demo,demo:false};
}
