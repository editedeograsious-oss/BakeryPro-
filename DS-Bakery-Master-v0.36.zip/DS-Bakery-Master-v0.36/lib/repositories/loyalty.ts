import { createClient } from "@/lib/supabase/server";

export async function getLoyaltyCustomers() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("customer_retention_summary")
    .select("*")
    .order("lifetime_value", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function getUpcomingBirthdays(days = 30) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("upcoming_customer_birthdays")
    .select("*")
    .lte("days_until_birthday", days)
    .order("days_until_birthday");

  if (error) throw error;
  return data ?? [];
}

export async function getLoyaltyLedger(customerId: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("loyalty_point_transactions")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function redeemOrderLoyalty(args: {
  orderId: string;
  points: number;
  clientRequestId?: string | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("redeem_loyalty_on_order", {
    p_order_id: args.orderId,
    p_points: args.points,
    p_client_request_id: args.clientRequestId ?? null,
  });

  if (error) throw error;
  return data;
}
