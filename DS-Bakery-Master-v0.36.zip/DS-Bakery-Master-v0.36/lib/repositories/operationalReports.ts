import { createClient } from "@/lib/supabase/server";

export async function getOperationalReport(period: "week" | "month") {
  const supabase = await createClient();

  const { data: summary, error: summaryError } = await supabase.rpc(
    "operational_report_summary",
    { p_period: period }
  );
  if (summaryError) throw summaryError;

  const [
    { data: production, error: productionError },
    { data: waste, error: wasteError },
    { data: suppliers, error: supplierError },
    { data: orders, error: orderError },
    { data: products, error: productError },
    { data: alerts, error: alertError },
  ] = await Promise.all([
    supabase.from("operational_production_performance").select("*").eq("period_key", period),
    supabase.from("operational_waste_performance").select("*").eq("period_key", period),
    supabase.from("supplier_account_summary").select("*").order("outstanding_balance",{ascending:false}).limit(8),
    supabase.from("customer_order_operational_summary").select("*").eq("period_key", period),
    supabase.from("operational_product_performance").select("*").eq("period_key", period).limit(10),
    supabase.rpc("management_alerts"),
  ]);

  if (productionError) throw productionError;
  if (wasteError) throw wasteError;
  if (supplierError) throw supplierError;
  if (orderError) throw orderError;
  if (productError) throw productError;
  if (alertError) throw alertError;

  return {
    summary,
    production: production ?? [],
    waste: waste ?? [],
    suppliers: suppliers ?? [],
    orders: orders ?? [],
    products: products ?? [],
    alerts: alerts ?? [],
  };
}
