import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";
import {
  demoBakers,demoBakerTasks,demoCashMovements,demoExpenses,demoMaterialsForPO,
  demoOpenShifts,demoProduction,demoProductionControl,demoPurchaseLines,
  demoPurchaseOrders,demoSupplierAccounts,demoSupplierStatement,demoSuppliers,demoWaste,
} from "@/lib/demo/operations";
import { demoMaterials,demoProducts } from "@/lib/demo/core";

export async function getProductionPageData(role: string) {
  if (isDemoMode()) {
    return { plan: demoProduction, products: demoProducts, bakers: demoBakers, demo: true };
  }

  const supabase=await createClient();
  const {data:businessDate,error:dateError}=await supabase.rpc("business_current_date");
  if(dateError) throw dateError;

  const requests:any[]=[
    supabase.from("production_progress_today").select("*").order("shift").order("product_name"),
    supabase.from("products").select("id,name").eq("status","active").order("name"),
  ];
  if(role==="owner"||role==="manager"){
    requests.push(supabase.from("profiles").select("id,full_name").eq("active",true).eq("role","baker").order("full_name"));
  }

  const results=await Promise.all(requests);
  if(results[0].error) throw results[0].error;
  if(results[1].error) throw results[1].error;
  if(results[2]?.error) throw results[2].error;

  return {
    businessDate,
    plan:results[0].data??[],
    products:results[1].data??[],
    bakers:results[2]?.data??[],
    demo:false,
  };
}

export async function getBakerTaskPageData() {
  if(isDemoMode()) return {tasks:demoBakerTasks,bakers:demoBakers,products:demoProducts,demo:true};
  const supabase=await createClient();
  const [{data:tasks,error:tErr},{data:products,error:pErr}]=await Promise.all([
    supabase.from("baker_task_summary").select("*").order("due_at",{ascending:true}),
    supabase.from("products").select("id,name").eq("status","active").order("name"),
  ]);
  if(tErr) throw tErr;
  if(pErr) throw pErr;

  const {data:bakers}=await supabase.from("profiles").select("id,full_name").eq("active",true).eq("role","baker").order("full_name");
  return {tasks:tasks??[],products:products??[],bakers:bakers??[],demo:false};
}

export async function getWastePageData() {
  if(isDemoMode()){
    return {
      events:demoWaste,products:demoProducts,materials:demoMaterials,
      runs:demoProduction.map((x,i)=>({id:`run${i+1}`,product_id:x.product_id,product_name:x.product_name,quantity_produced:x.produced_qty,confirmed_at:"2026-10-03T09:00:00+03:00"})),
      threshold:50000,demo:true,
    };
  }
  const supabase=await createClient();
  const [
    {data:events,error:eErr},
    {data:products,error:pErr},
    {data:materials,error:mErr},
    {data:runs,error:rErr},
    {data:settings,error:sErr},
  ]=await Promise.all([
    supabase.from("waste_event_summary").select("*").order("recorded_at",{ascending:false}).limit(100),
    supabase.from("products").select("id,name").eq("status","active").order("name"),
    supabase.from("raw_materials").select("id,name,base_unit,current_stock_qty").eq("status","active").order("name"),
    supabase.from("production_run_summary").select("*").order("confirmed_at",{ascending:false}).limit(100),
    supabase.from("waste_settings").select("approval_threshold").eq("id",1).maybeSingle(),
  ]);
  if(eErr) throw eErr;if(pErr)throw pErr;if(mErr)throw mErr;if(rErr)throw rErr;
  return {events:events??[],products:products??[],materials:materials??[],runs:runs??[],threshold:Number(settings?.approval_threshold??0),demo:false};
}

export async function getProductionControlPageData(){
  if(isDemoMode()) return {rows:demoProductionControl,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("production_control_today").select("*").order("product_name");
  if(error) throw error;
  return {rows:data??[],demo:false};
}

export async function getPurchaseOrderPageData(){
  if(isDemoMode()) return {orders:demoPurchaseOrders,suppliers:demoSuppliers,materials:demoMaterialsForPO,demo:true};
  const supabase=await createClient();
  const [
    {data:orders,error:oErr},
    {data:suppliers,error:sErr},
    {data:materials,error:mErr},
  ]=await Promise.all([
    supabase.from("purchase_order_summary").select("*").order("created_at",{ascending:false}).limit(100),
    supabase.from("suppliers").select("id,name").eq("active",true).order("name"),
    supabase.from("raw_materials").select("id,name,base_unit").eq("status","active").order("name"),
  ]);
  if(oErr)throw oErr;if(sErr)throw sErr;if(mErr)throw mErr;
  return {orders:orders??[],suppliers:suppliers??[],materials:materials??[],demo:false};
}

export async function getPurchaseReceivingData(){
  if(isDemoMode()) return {lines:demoPurchaseLines,demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("purchase_receiving_lines").select("*").gt("remaining_qty_base",0).order("purchase_date").order("purchase_no");
  if(error)throw error;
  return {lines:data??[],demo:false};
}

export async function getSupplierAccountsPageData(){
  if(isDemoMode()){
    return {
      accounts:demoSupplierAccounts,
      statements:demoSupplierStatement,
      payables:demoPurchaseOrders.filter(x=>x.approval_status==="approved"&&x.total_amount>x.amount_paid),
      shifts:demoOpenShifts,
      demo:true,
    };
  }
  const supabase=await createClient();
  const [
    {data:accounts,error:aErr},
    {data:statements,error:sErr},
    {data:payables,error:pErr},
    {data:shifts,error:shErr},
  ]=await Promise.all([
    supabase.from("supplier_account_summary").select("*").order("outstanding_balance",{ascending:false}),
    supabase.from("supplier_statement_lines").select("*").order("occurred_at",{ascending:false}).limit(300),
    supabase.from("supplier_open_payables").select("*").order("due_date").limit(200),
    supabase.from("cashier_shift_summary").select("id,cashier_id,cashier_name,opened_at,opening_float,status").eq("status","open").order("opened_at"),
  ]);
  if(aErr)throw aErr;if(sErr)throw sErr;if(pErr)throw pErr;if(shErr)throw shErr;
  return {accounts:accounts??[],statements:statements??[],payables:payables??[],shifts:shifts??[],demo:false};
}

export async function getExpensePageData(){
  if(isDemoMode()) return {expenses:demoExpenses,shifts:demoOpenShifts,demo:true};
  const supabase=await createClient();
  const [{data:expenses,error:eErr},{data:shifts,error:sErr}]=await Promise.all([
    supabase.from("expense_live_summary").select("*").order("created_at",{ascending:false}).limit(200),
    supabase.from("cashier_shift_summary").select("id,cashier_name,status,opened_at").eq("status","open").order("opened_at"),
  ]);
  if(eErr)throw eErr;if(sErr)throw sErr;
  return {expenses:expenses??[],shifts:shifts??[],demo:false};
}

export async function getCashMovementPageData(){
  if(isDemoMode()) return {movements:demoCashMovements,shifts:demoOpenShifts,demo:true};
  const supabase=await createClient();
  const [{data:movements,error:mErr},{data:shifts,error:sErr}]=await Promise.all([
    supabase.from("cash_movement_summary").select("*").order("created_at",{ascending:false}).limit(200),
    supabase.from("cashier_shift_summary").select("id,cashier_id,cashier_name,status,opened_at").eq("status","open").order("opened_at"),
  ]);
  if(mErr)throw mErr;if(sErr)throw sErr;
  return {movements:movements??[],shifts:shifts??[],demo:false};
}


export async function getSupplierDirectoryData(){
  if(isDemoMode()) return {suppliers:demoSuppliers.map((s:any)=>({
    id:s.id,name:s.name,phone:s.phone??null,email:s.email??null,notes:s.notes??null,active:true,
    outstanding_balance:0,overdue_balance:0,next_due_date:null
  })),demo:true};

  const supabase=await createClient();
  const [{data:suppliers,error:sErr},{data:accounts,error:aErr}]=await Promise.all([
    supabase.from("suppliers").select("id,name,phone,email,notes,active,created_at,updated_at").order("name"),
    supabase.from("supplier_account_summary").select("supplier_id,outstanding_balance,overdue_balance,next_due_date"),
  ]);
  if(sErr)throw sErr;if(aErr)throw aErr;

  const accountMap=new Map((accounts??[]).map((a:any)=>[a.supplier_id,a]));
  return {
    suppliers:(suppliers??[]).map((s:any)=>({...s,...(accountMap.get(s.id)??{outstanding_balance:0,overdue_balance:0,next_due_date:null})})),
    demo:false
  };
}

export async function getStockMovementLedgerData(){
  if(isDemoMode()) return {rows:[
    {id:"sm1",created_at:"2026-10-03T10:45:00+03:00",material_name:"Flour",base_unit:"g",tx_type:"purchase",quantity_delta:50000,unit_cost:3.6,reference_type:"purchase_receipt",reference_id:"demo-po",notes:"Approved purchase receipt",recorded_by_name:"Storekeeper"},
    {id:"sm2",created_at:"2026-10-03T08:10:00+03:00",material_name:"Butter",base_unit:"g",tx_type:"adjustment",quantity_delta:-300,unit_cost:null,reference_type:"stock_count",reference_id:"demo-count",notes:"Physical stock count",recorded_by_name:"Manager"},
    {id:"sm3",created_at:"2026-10-02T16:40:00+03:00",material_name:"Flour",base_unit:"g",tx_type:"usage",quantity_delta:-8600,unit_cost:null,reference_type:"production_run",reference_id:"demo-run",notes:"Recipe consumption",recorded_by_name:"Baker"},
  ],demo:true};

  const supabase=await createClient();
  const {data,error}=await supabase.from("inventory_movement_summary").select("*").order("created_at",{ascending:false}).limit(500);
  if(error)throw error;
  return {rows:data??[],demo:false};
}
