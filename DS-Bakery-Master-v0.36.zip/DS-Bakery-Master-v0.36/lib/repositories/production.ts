import { createClient } from "@/lib/supabase/server";

export async function getBakePlan(businessDate: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("production_plan_items")
    .select(`
      id,
      planned_qty,
      produced_qty,
      status,
      notes,
      assigned_baker_id,
      products(id,name,selling_price),
      profiles!production_plan_items_assigned_baker_id_fkey(id,full_name)
    `)
    .eq("business_date", businessDate)
    .order("created_at");

  if (error) throw error;
  return data ?? [];
}

export async function getBakerTasks(bakerId: string, businessDate: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("production_plan_items")
    .select(`
      id,
      planned_qty,
      produced_qty,
      status,
      notes,
      products(id,name)
    `)
    .eq("business_date", businessDate)
    .eq("assigned_baker_id", bakerId)
    .order("created_at");

  if (error) throw error;
  return data ?? [];
}

export async function confirmProduction(
  planItemId: string,
  quantityProduced: number
) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("confirm_production_run", {
    p_plan_item_id: planItemId,
    p_quantity_produced: quantityProduced,
  });

  if (error) throw error;
  return data;
}
