import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

const demo={
  environment_mode:"staging",
  production_lock:false,
  go_live_setup_completed:false,
  go_live_setup_completed_at:null,
  operations_enabled:false,
  authorized_at:null,
  suspended_at:null,
  suspension_reason:null,
  ready_to_authorize:false,
};

export async function getProductionCutoverData(){
  if(isDemoMode()) return {status:demo,demo:true};

  const supabase=await createClient();
  const {data,error}=await supabase.rpc("production_cutover_status");
  if(error)throw error;
  return {status:data??demo,demo:false};
}
