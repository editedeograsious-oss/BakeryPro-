import { createClient } from "@/lib/supabase/server";

export async function getOwnerDashboard(period: "day" | "week" | "month" = "day") {
  const supabase = await createClient();

  const { data: summary, error: summaryError } = await supabase
    .rpc("owner_dashboard_summary", { p_period: period });

  if (summaryError) throw summaryError;

  const [
    { data: bestSellers, error: bestError },
    { data: lowStock, error: lowError },
    { data: recentActivity, error: activityError },
    { data: trend, error: trendError }
  ] = await Promise.all([
    supabase.from("best_selling_products_30d").select("*").limit(5),
    supabase.from("low_stock_materials").select("*").order("stock_ratio").limit(8),
    supabase.from("audit_logs").select("id,action,entity,entity_id,created_at,actor_id").order("created_at",{ascending:false}).limit(10),
    supabase.rpc("sales_trend", { p_period: period })
  ]);

  if (bestError) throw bestError;
  if (lowError) throw lowError;
  if (activityError) throw activityError;
  if (trendError) throw trendError;

  return {
    summary,
    bestSellers: bestSellers ?? [],
    lowStock: lowStock ?? [],
    recentActivity: recentActivity ?? [],
    trend: trend ?? []
  };
}

export async function getManagementReport(
  startDate: string,
  endDate: string
) {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("management_report", {
    p_start_date: startDate,
    p_end_date: endDate
  });

  if (error) throw error;
  return data;
}
