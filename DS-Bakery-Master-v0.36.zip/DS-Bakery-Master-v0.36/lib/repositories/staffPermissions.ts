import { createClient } from "@/lib/supabase/server";

export async function getStaffEffectivePermissions(staffId: string) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("effective_staff_permissions", {
    p_staff_id: staffId,
  });

  if (error) throw error;
  return data ?? [];
}

export async function setStaffPermissionOverride(args: {
  staffId: string;
  permissionKey: string;
  allowed: boolean | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("set_staff_permission_override", {
    p_staff_id: args.staffId,
    p_permission_key: args.permissionKey,
    p_allowed: args.allowed,
  });

  if (error) throw error;
  return data;
}
