import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

const demoSummary={
  environment_mode:"staging",
  allow_staging_test_accounts:true,
  production_lock:false,
  release:{app_version:"0.29.0",latest_migration:28,release_stage:"supabase_staging_handoff"},
  latest_checks:[
    {check_type:"supabase_connectivity",status:"pending",detail:"Real staging connection not executed in demo mode.",recorded_at:null}
  ],
  pass_count:0,
  fail_count:0,
};

export async function getStagingConnectionData(){
  const env={
    publicUrlConfigured:Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL),
    anonKeyConfigured:Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
    serviceRoleConfigured:Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY),
    databaseUrlConfigured:Boolean(process.env.DATABASE_URL),
    projectHost:(()=>{
      try{
        return process.env.NEXT_PUBLIC_SUPABASE_URL
          ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).host
          : null;
      }catch{return null;}
    })(),
  };

  if(isDemoMode()) return {env,summary:demoSummary,demo:true};

  const supabase=await createClient();
  const {data,error}=await supabase.rpc("environment_connection_summary");
  if(error)throw error;
  return {env,summary:data??demoSummary,demo:false};
}
