import { createClient } from "@/lib/supabase/server";

export async function getInventorySummary() {
  const supabase = await createClient();

  const [{ data: materials, error: materialsError }, { data: lowStock, error: lowError }] =
    await Promise.all([
      supabase
        .from("raw_materials")
        .select("id,name,base_unit,current_stock_qty,low_stock_threshold,current_purchase_cost,purchase_pack_base_qty,status")
        .eq("status", "active")
        .order("name"),
      supabase
        .from("low_stock_materials")
        .select("*")
        .order("stock_ratio")
    ]);

  if (materialsError) throw materialsError;
  if (lowError) throw lowError;

  return {
    materials: materials ?? [],
    lowStock: lowStock ?? []
  };
}

export async function getRecentStockMovements(limit = 50) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("inventory_transactions")
    .select("id,tx_type,quantity_delta,unit_cost,notes,created_at,raw_materials(name,base_unit)")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data ?? [];
}

export async function getSuppliers() {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("supplier_balances")
    .select("*")
    .order("supplier_name");

  if (error) throw error;
  return data ?? [];
}

export async function getPurchases() {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("purchases")
    .select("id,purchase_no,purchase_date,status,payment_status,total_amount,amount_paid,suppliers(name)")
    .order("purchase_date", { ascending: false });

  if (error) throw error;
  return data ?? [];
}
