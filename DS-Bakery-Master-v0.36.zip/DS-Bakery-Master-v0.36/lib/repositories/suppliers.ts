import { createClient } from "@/lib/supabase/server";

export async function getSupplierAccounts() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("supplier_account_summary")
    .select("*")
    .order("outstanding_balance", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function getSupplierStatement(supplierId: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("supplier_statement_lines")
    .select("*")
    .eq("supplier_id", supplierId)
    .order("occurred_at");

  if (error) throw error;
  return data ?? [];
}

export async function recordSupplierPayment(args: {
  purchaseId: string;
  amount: number;
  method: string;
  reference?: string | null;
}) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("record_supplier_payment", {
    p_purchase_id: args.purchaseId,
    p_amount: args.amount,
    p_method: args.method,
    p_reference: args.reference ?? null,
  });

  if (error) throw error;
  return data;
}

export async function decidePurchaseOrder(
  purchaseId: string,
  decision: "approve" | "reject",
  note?: string
) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("decide_purchase_order", {
    p_purchase_id: purchaseId,
    p_decision: decision,
    p_note: note ?? null,
  });

  if (error) throw error;
  return data;
}
