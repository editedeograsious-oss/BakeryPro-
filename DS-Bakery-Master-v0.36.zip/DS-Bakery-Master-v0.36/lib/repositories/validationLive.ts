import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

export type ValidationCheck={
  check_key:string;
  status:"pass"|"warn"|"fail"|"pending";
  detail:string;
};

export async function getValidationData(){
  const envChecks:ValidationCheck[]=[
    {
      check_key:"supabase_public_env",
      status:process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?"pass":"warn",
      detail:process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
        ?"Supabase public URL and anon key are configured."
        :"Supabase public connection settings are not configured in this runtime."
    },
    {
      check_key:"demo_mode",
      status:process.env.NEXT_PUBLIC_DEMO_MODE==="false"?"pass":"warn",
      detail:process.env.NEXT_PUBLIC_DEMO_MODE==="false"
        ?"Demo mode is explicitly disabled."
        :"Set NEXT_PUBLIC_DEMO_MODE=false for production."
    },
    {
      check_key:"service_role_server_secret",
      status:process.env.SUPABASE_SERVICE_ROLE_KEY?"pass":"warn",
      detail:process.env.SUPABASE_SERVICE_ROLE_KEY
        ?"Server-only Supabase service-role secret is configured."
        :"SUPABASE_SERVICE_ROLE_KEY is not configured; live staff invitations will not work."
    },
    {
      check_key:"database_url",
      status:process.env.DATABASE_URL?"pass":"warn",
      detail:process.env.DATABASE_URL
        ?"DATABASE_URL is configured for backup/restore scripts."
        :"DATABASE_URL is not configured; independent logical backup scripts cannot run."
    },
  ];

  if(isDemoMode()){
    return {
      envChecks,
      dbChecks:[
        {check_key:"database_validation",status:"pending",detail:"Connect a non-production Supabase project and apply migrations 002–021 to run database integrity checks."}
      ] as ValidationCheck[],
      release:{app_version:"0.30.0",latest_migration:29,database_gate:"pending",fail_count:0,warn_count:0},
      demo:true
    };
  }

  const supabase=await createClient();
  const {data,error}=await supabase.rpc("launch_readiness_summary");
  if(error){
    return {
      envChecks,
      dbChecks:[{check_key:"launch_readiness_rpc",status:"fail",detail:error.message}] as ValidationCheck[],
      release:{app_version:"0.30.0",latest_migration:29,database_gate:"fail",fail_count:1,warn_count:0},
      demo:false
    };
  }

  return {
    envChecks,
    dbChecks:(data?.database_checks??[]) as ValidationCheck[],
    release:data??{},
    demo:false
  };
}


export async function getValidationHistory(){
  if(isDemoMode()){
    return {
      runs:[
        {id:"vr1",environment:"staging",app_version:"0.30.0",latest_migration:29,started_at:"2026-10-03T12:00:00+03:00",completed_at:"2026-10-03T12:08:00+03:00",overall_status:"pass",notes:"Example staging validation",started_by_name:"Demo Owner",check_count:22,pass_count:22,warn_count:0,fail_count:0,pending_count:0}
      ],
      demo:true
    };
  }
  const supabase=await createClient();
  const {data,error}=await supabase.from("validation_run_summary").select("*").order("started_at",{ascending:false}).limit(100);
  if(error)throw error;
  return {runs:data??[],demo:false};
}
