import { createClient } from "@/lib/supabase/server";

export async function getWasteEvents(limit = 100) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("waste_events")
    .select(`id,waste_type,quantity,reason,unit_cost_snapshot,total_cost,approval_status,recorded_at,approved_at,products(name),raw_materials(name,base_unit),profiles!waste_events_recorded_by_fkey(full_name)`)
    .order("recorded_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}

export async function recordWaste(args: {
  wasteType: "finished_product" | "raw_material";
  quantity: number;
  reason: string;
  productId?: string | null;
  rawMaterialId?: string | null;
  productionRunId?: string | null;
  notes?: string | null;
}) {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("record_waste_event", {
    p_waste_type: args.wasteType,
    p_quantity: args.quantity,
    p_reason: args.reason,
    p_product_id: args.productId ?? null,
    p_raw_material_id: args.rawMaterialId ?? null,
    p_production_run_id: args.productionRunId ?? null,
    p_notes: args.notes ?? null,
  });
  if (error) throw error;
  return data;
}

export async function decideWaste(wasteId: string, decision: "approve" | "reject", note?: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("decide_waste_event", {
    p_waste_id: wasteId, p_decision: decision, p_note: note ?? null,
  });
  if (error) throw error;
  return data;
}
