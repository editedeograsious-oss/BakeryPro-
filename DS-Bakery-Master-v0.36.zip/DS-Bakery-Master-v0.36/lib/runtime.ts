export type DeploymentEnvironment = "local" | "staging" | "production";

export function hasSupabaseConfig() {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );
}

export function deploymentEnvironment():DeploymentEnvironment {
  const raw=String(process.env.NEXT_PUBLIC_DEPLOYMENT_ENV||"").toLowerCase();
  if(raw==="staging"||raw==="production") return raw;
  return process.env.NODE_ENV==="production" ? "production" : "local";
}

export function isDemoMode() {
  return process.env.NEXT_PUBLIC_DEMO_MODE === "true" || !hasSupabaseConfig();
}

export function runtimeMode() {
  return isDemoMode() ? "demo" : "live";
}
