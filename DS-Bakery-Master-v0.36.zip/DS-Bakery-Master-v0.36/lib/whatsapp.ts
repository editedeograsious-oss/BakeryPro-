export function normalizeWhatsAppPhone(input: string) {
  const digits = input.replace(/\D/g, "");

  // Uganda-friendly convenience:
  // 07XXXXXXXX -> 2567XXXXXXXX
  if (digits.length === 10 && digits.startsWith("0")) {
    return `256${digits.slice(1)}`;
  }

  // 7XXXXXXXX -> 2567XXXXXXXX
  if (digits.length === 9 && digits.startsWith("7")) {
    return `256${digits}`;
  }

  return digits;
}

export function buildWhatsAppUrl(phone: string, message: string) {
  const normalized = normalizeWhatsAppPhone(phone);
  if (!normalized) throw new Error("Customer WhatsApp number is missing");
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
}

export type TemplateVariables = Record<string, string | number | null | undefined>;

export function renderMessageTemplate(
  template: string,
  variables: TemplateVariables
) {
  return template.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_, key) => {
    const value = variables[key];
    return value === null || value === undefined ? "" : String(value);
  });
}
