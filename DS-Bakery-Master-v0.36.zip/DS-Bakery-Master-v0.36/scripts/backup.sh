#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"

BACKUP_DIR="${BACKUP_DIR:-./backups}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP_DIR"

OUT="$BACKUP_DIR/ds_bakery_${STAMP}.dump"

pg_dump   --dbname="$DATABASE_URL"   --format=custom   --no-owner   --no-acl   --file="$OUT"

echo "Backup created: $OUT"
