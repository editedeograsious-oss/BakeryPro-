#!/usr/bin/env bash
set -euo pipefail

command -v docker >/dev/null 2>&1 || { echo "Docker is required by the Supabase CLI database dump workflow."; exit 1; }
command -v supabase >/dev/null 2>&1 || { echo "Supabase CLI is required."; exit 1; }
command -v sha256sum >/dev/null 2>&1 || command -v shasum >/dev/null 2>&1 || {
  echo "sha256sum or shasum is required for checksums."; exit 1;
}

: "${DATABASE_URL:?DATABASE_URL must be set in the trusted backup environment. Do not commit it.}"

echo "Backup preflight passed."
echo "The connection string is loaded from the environment and is not printed."
