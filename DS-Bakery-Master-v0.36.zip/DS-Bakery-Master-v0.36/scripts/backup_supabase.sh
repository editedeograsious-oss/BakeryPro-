#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="$BACKUP_DIR/ds_bakery_$STAMP"

command -v supabase >/dev/null 2>&1 || { echo "Supabase CLI is required."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Docker is required by Supabase CLI db dump."; exit 1; }

mkdir -p "$OUT_DIR"

supabase db dump --db-url "$DATABASE_URL" -f "$OUT_DIR/roles.sql" --role-only
supabase db dump --db-url "$DATABASE_URL" -f "$OUT_DIR/schema.sql"
supabase db dump --db-url "$DATABASE_URL" -f "$OUT_DIR/data.sql" --use-copy --data-only \
  -x "storage.buckets_vectors" -x "storage.vector_indexes"

for f in roles.sql schema.sql data.sql; do
  test -s "$OUT_DIR/$f" || { echo "Backup file missing or empty: $f"; exit 1; }
done

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$OUT_DIR" && sha256sum roles.sql schema.sql data.sql > SHA256SUMS)
else
  (cd "$OUT_DIR" && shasum -a 256 roles.sql schema.sql data.sql > SHA256SUMS)
fi

cat > "$OUT_DIR/README.txt" <<EOF
DS Bakery logical backup
Created UTC: $STAMP
Files: roles.sql, schema.sql, data.sql, SHA256SUMS
Keep this folder outside the application public directory and outside source control.
Test restores only against a non-production target first.
EOF

tar -C "$BACKUP_DIR" -czf "$BACKUP_DIR/ds_bakery_$STAMP.tar.gz" "ds_bakery_$STAMP"

echo "Backup created: $BACKUP_DIR/ds_bakery_$STAMP.tar.gz"
echo "Unpacked backup: $OUT_DIR"
