import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { execSync } from "node:child_process";

const require=createRequire(import.meta.url);
let ts;
try{
  ts=require("typescript");
}catch{
  const globalRoot=execSync("npm root -g",{encoding:"utf8"}).trim();
  ts=require(path.join(globalRoot,"typescript"));
}

const cwd=process.cwd();
const files=[];

function walk(dir){
  for(const name of fs.readdirSync(dir)){
    if(name==="node_modules"||name===".next")continue;
    const p=path.join(dir,name);
    const stat=fs.statSync(p);
    if(stat.isDirectory())walk(p);
    else if(/\.(ts|tsx)$/.test(name))files.push(p);
  }
}

walk(cwd);

const diagnostics=[];
for(const file of files){
  const source=fs.readFileSync(file,"utf8");
  const kind=file.endsWith(".tsx")?ts.ScriptKind.TSX:ts.ScriptKind.TS;
  const sf=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,kind);
  for(const d of sf.parseDiagnostics){
    diagnostics.push(`${path.relative(cwd,file)}: ${ts.flattenDiagnosticMessageText(d.messageText," ")}`);
  }
}

console.log(`Parsed ${files.length} TypeScript/TSX files.`);
if(diagnostics.length){
  console.error(diagnostics.join("\n"));
  process.exit(1);
}
console.log("Syntax diagnostics: 0");
