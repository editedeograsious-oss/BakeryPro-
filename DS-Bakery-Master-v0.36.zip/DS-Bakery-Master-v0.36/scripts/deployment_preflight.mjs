const requiredPublic=[
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  "NEXT_PUBLIC_DEPLOYMENT_ENV",
  "NEXT_PUBLIC_DEMO_MODE",
];

let failed=false;
for(const name of requiredPublic){
  if(!process.env[name]){
    console.error(`FAIL ${name} is missing`);
    failed=true;
  }else{
    console.log(`PASS ${name}`);
  }
}

const env=process.env.NEXT_PUBLIC_DEPLOYMENT_ENV;
if(!["staging","production"].includes(String(env))){
  console.error("FAIL NEXT_PUBLIC_DEPLOYMENT_ENV must be staging or production");
  failed=true;
}

if(process.env.NEXT_PUBLIC_DEMO_MODE!=="false"){
  console.error("FAIL NEXT_PUBLIC_DEMO_MODE must be false for hosted deployments");
  failed=true;
}

for(const name of Object.keys(process.env)){
  if(name.startsWith("NEXT_PUBLIC_") && /SERVICE_ROLE|DATABASE_URL|PASSWORD|SECRET/i.test(name)){
    console.error(`FAIL sensitive-looking variable is browser-exposed: ${name}`);
    failed=true;
  }
}

if(process.env.SUPABASE_SERVICE_ROLE_KEY){
  console.log("PASS server-only SUPABASE_SERVICE_ROLE_KEY is configured");
}else{
  console.log("WARN SUPABASE_SERVICE_ROLE_KEY is not configured; privileged staff-invite route may be unavailable");
}

if(failed){
  process.exit(1);
}
console.log("Deployment environment preflight PASSED.");
