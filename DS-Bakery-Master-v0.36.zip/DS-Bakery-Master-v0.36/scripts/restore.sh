#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <backup.dump>"
  exit 1
fi

BACKUP_FILE="$1"

echo "WARNING: restore can overwrite database objects."
echo "Use a TEST database first. Press Ctrl+C to cancel."
read -r _

pg_restore   --dbname="$DATABASE_URL"   --clean   --if-exists   --no-owner   --no-acl   "$BACKUP_FILE"

echo "Restore completed."
