#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <backup-folder>"
  exit 1
fi

DIR="$1"
: "${TARGET_DATABASE_URL:?TARGET_DATABASE_URL is required}"
: "${RESTORE_CONFIRM:?Set RESTORE_CONFIRM=RESTORE_TO_TEST_ONLY}"

if [ "$RESTORE_CONFIRM" != "RESTORE_TO_TEST_ONLY" ]; then
  echo "Restore blocked. This script is intentionally test-target only."
  exit 1
fi

command -v psql >/dev/null 2>&1 || { echo "psql is required."; exit 1; }

for f in roles.sql schema.sql data.sql; do
  test -s "$DIR/$f" || { echo "Missing or empty: $DIR/$f"; exit 1; }
done

echo "Restoring into the TARGET_DATABASE_URL provided in your secure environment."
echo "This must be a separate NON-PRODUCTION target."

psql \
  --single-transaction \
  --variable ON_ERROR_STOP=1 \
  --file "$DIR/roles.sql" \
  --file "$DIR/schema.sql" \
  --command 'SET session_replication_role = replica' \
  --file "$DIR/data.sql" \
  --dbname "$TARGET_DATABASE_URL"

psql "$TARGET_DATABASE_URL" --variable ON_ERROR_STOP=1 --file "$(dirname "$0")/verify_restore.sql"

echo "Test restore and verification completed."
