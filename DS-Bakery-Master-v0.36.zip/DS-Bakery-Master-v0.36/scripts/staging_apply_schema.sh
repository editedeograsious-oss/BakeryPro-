#!/usr/bin/env bash
set -euo pipefail

if [ "${STAGING_SCHEMA_CONFIRMATION:-}" != "APPLY_SCHEMA_TO_EMPTY_STAGING_DB" ]; then
  echo "Refusing to continue."
  echo "Set STAGING_SCHEMA_CONFIRMATION=APPLY_SCHEMA_TO_EMPTY_STAGING_DB"
  exit 1
fi

if [ -z "${STAGING_DATABASE_URL:-}" ]; then
  echo "STAGING_DATABASE_URL is required."
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  echo "psql is required but was not found."
  exit 1
fi

echo "Applying DS Bakery schema to the explicitly confirmed STAGING database..."
psql "$STAGING_DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/schema.sql
echo "Schema application completed."
