import { createClient } from "@supabase/supabase-js";

const url=process.env.STAGING_SUPABASE_URL;
const serviceKey=process.env.STAGING_SUPABASE_SERVICE_ROLE_KEY;
const domain=process.env.STAGING_TEST_EMAIL_DOMAIN;
const confirmation=process.env.STAGING_CLEANUP_CONFIRMATION;

if(!url||!serviceKey||!domain){
  throw new Error("Set STAGING_SUPABASE_URL, STAGING_SUPABASE_SERVICE_ROLE_KEY and STAGING_TEST_EMAIL_DOMAIN.");
}
if(confirmation!=="DELETE_STAGING_TEST_USERS"){
  throw new Error("Set STAGING_CLEANUP_CONFIRMATION=DELETE_STAGING_TEST_USERS.");
}

const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});
const roles=["owner","manager","cashier","baker","storekeeper"];
const {data,error}=await admin.auth.admin.listUsers({page:1,perPage:1000});
if(error)throw error;

for(const role of roles){
  const email=`ds-${role}-test@${domain}`.toLowerCase();
  const user=data.users.find(u=>String(u.email).toLowerCase()===email);
  if(!user)continue;
  const {error:deleteError}=await admin.auth.admin.deleteUser(user.id);
  if(deleteError)throw deleteError;
  console.log(`Deleted staging test user: ${email}`);
}
