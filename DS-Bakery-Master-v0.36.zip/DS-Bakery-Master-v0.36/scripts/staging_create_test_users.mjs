import { createClient } from "@supabase/supabase-js";

const url=process.env.STAGING_SUPABASE_URL;
const serviceKey=process.env.STAGING_SUPABASE_SERVICE_ROLE_KEY;
const password=process.env.STAGING_TEST_PASSWORD;
const domain=process.env.STAGING_TEST_EMAIL_DOMAIN;
const confirmation=process.env.STAGING_CONFIRMATION;

if(!url||!serviceKey||!password||!domain){
  throw new Error("Set STAGING_SUPABASE_URL, STAGING_SUPABASE_SERVICE_ROLE_KEY, STAGING_TEST_PASSWORD and STAGING_TEST_EMAIL_DOMAIN.");
}
if(confirmation!=="I_UNDERSTAND_THIS_CREATES_TEST_USERS"){
  throw new Error("Set STAGING_CONFIRMATION=I_UNDERSTAND_THIS_CREATES_TEST_USERS.");
}
if(password.length<12){
  throw new Error("STAGING_TEST_PASSWORD must be at least 12 characters.");
}

const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});


const {data:envState,error:envError}=await admin
  .from("system_environment_config")
  .select("environment_mode,allow_staging_test_accounts,production_lock")
  .eq("id",1)
  .single();

if(envError)throw new Error(`Could not read system environment guardrail: ${envError.message}`);
if(envState.environment_mode!=="staging"){
  throw new Error(`Refusing to create staging users because database environment_mode is ${envState.environment_mode}.`);
}
if(!envState.allow_staging_test_accounts){
  throw new Error("Refusing to create staging users because allow_staging_test_accounts is false.");
}
if(envState.production_lock){
  throw new Error("Refusing to create staging users because production_lock is enabled.");
}

const roles=["owner","manager","cashier","baker","storekeeper"];
const results=[];

for(const role of roles){
  const email=`ds-${role}-test@${domain}`.toLowerCase();

  const {data:list,error:listError}=await admin.auth.admin.listUsers({page:1,perPage:1000});
  if(listError)throw listError;
  let user=list.users.find(u=>String(u.email).toLowerCase()===email);

  if(!user){
    const {data,error}=await admin.auth.admin.createUser({
      email,
      password,
      email_confirm:true,
      user_metadata:{full_name:`DS ${role} test`,role},
    });
    if(error)throw error;
    user=data.user;
  }else{
    const {data,error}=await admin.auth.admin.updateUserById(user.id,{
      password,
      email_confirm:true,
      user_metadata:{full_name:`DS ${role} test`,role},
    });
    if(error)throw error;
    user=data.user;
  }

  const {error:profileError}=await admin.from("profiles").upsert({
    id:user.id,
    full_name:`DS ${role} test`,
    role,
    active:true,
    disabled_at:null,
    disabled_by:null,
  });
  if(profileError)throw profileError;

  results.push({role,email,user_id:user.id});
}

console.table(results);
console.log("Staging test accounts are ready. Use only in a non-production Supabase project.");
