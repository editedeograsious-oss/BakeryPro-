import { createClient } from "@supabase/supabase-js";

const url=process.env.STAGING_SUPABASE_URL;
const anonKey=process.env.STAGING_SUPABASE_ANON_KEY;
const password=process.env.STAGING_TEST_PASSWORD;
const domain=process.env.STAGING_TEST_EMAIL_DOMAIN;

if(!url||!anonKey||!password||!domain){
  throw new Error("Staging Supabase URL, anon key, test password and email domain are required.");
}

const client=createClient(url,anonKey,{auth:{autoRefreshToken:false,persistSession:false}});
const email=`ds-owner-test@${domain}`.toLowerCase();

const {error:loginError}=await client.auth.signInWithPassword({email,password});
if(loginError)throw new Error(`Owner staging login failed: ${loginError.message}`);

const {data,error}=await client.rpc("go_live_setup_readiness");
if(error)throw error;

console.log(JSON.stringify(data,null,2));

const failures=[];
if(data?.automatic_gate!=="pass")failures.push("automatic gate");
if(data?.staging_validation_gate!=="pass")failures.push("staging validation gate");

if(failures.length){
  console.error(`Go-live readiness still needs action: ${failures.join(", ")}.`);
  process.exit(1);
}

if(data?.manual_gate!=="pass"){
  console.log("Automatic/staging gates pass. Owner manual checklist is still incomplete.");
  process.exit(0);
}

console.log(data?.setup_completed
  ? "Go-live setup is fully completed."
  : "All gates pass; Owner can complete the final go-live setup sign-off.");
