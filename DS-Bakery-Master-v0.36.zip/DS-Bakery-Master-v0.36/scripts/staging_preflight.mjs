import { createClient } from "@supabase/supabase-js";

const required=[
  "STAGING_SUPABASE_URL",
  "STAGING_SUPABASE_ANON_KEY",
  "STAGING_SUPABASE_SERVICE_ROLE_KEY",
  "STAGING_TEST_EMAIL_DOMAIN",
  "STAGING_TEST_PASSWORD",
];

let failed=false;
for(const key of required){
  if(!process.env[key]){
    console.error(`FAIL ${key} is missing`);
    failed=true;
  }else{
    console.log(`PASS ${key} is configured`);
  }
}
if(failed)process.exit(1);

const url=process.env.STAGING_SUPABASE_URL;
const serviceKey=process.env.STAGING_SUPABASE_SERVICE_ROLE_KEY;
const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});

const {data:release,error:releaseError}=await admin
  .from("system_release_state")
  .select("app_version,latest_migration,release_stage")
  .eq("id",1)
  .single();

if(releaseError){
  console.error(`FAIL release state: ${releaseError.message}`);
  process.exit(1);
}

if(release.app_version!=="0.31.0"||Number(release.latest_migration)!==30){
  console.error(`FAIL release mismatch: database reports v${release.app_version} / migration ${release.latest_migration}`);
  process.exit(1);
}
console.log("PASS database release matches v0.31.0 / migration 030");

const {data:env,error:envError}=await admin
  .from("system_environment_config")
  .select("environment_mode,allow_staging_test_accounts,production_lock")
  .eq("id",1)
  .single();

if(envError){
  console.error(`FAIL environment state: ${envError.message}`);
  process.exit(1);
}

if(env.environment_mode!=="staging"){
  console.error(`FAIL database mode is ${env.environment_mode}; staging required`);
  process.exit(1);
}
if(!env.allow_staging_test_accounts){
  console.error("FAIL staging test accounts are disabled");
  process.exit(1);
}
if(env.production_lock){
  console.error("FAIL production lock is enabled");
  process.exit(1);
}

console.log("PASS staging environment guardrails");
console.log("Staging preflight PASSED.");
