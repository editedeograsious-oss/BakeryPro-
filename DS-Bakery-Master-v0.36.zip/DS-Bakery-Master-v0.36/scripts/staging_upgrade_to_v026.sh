#!/usr/bin/env bash
set -euo pipefail

if [ "${STAGING_UPGRADE_CONFIRMATION:-}" != "UPGRADE_STAGING_TO_V026" ]; then
  echo "Refusing to continue."
  echo "Set STAGING_UPGRADE_CONFIRMATION=UPGRADE_STAGING_TO_V026"
  exit 1
fi

if [ -z "${STAGING_DATABASE_URL:-}" ]; then
  echo "STAGING_DATABASE_URL is required."
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  echo "psql is required but was not found."
  exit 1
fi

if command -v pg_dump >/dev/null 2>&1; then
  mkdir -p "${BACKUP_DIR:-./backups}"
  stamp="$(date +%Y%m%d-%H%M%S)"
  backup="${BACKUP_DIR:-./backups}/ds-bakery-pre-v026-${stamp}.dump"
  echo "Creating pre-upgrade backup: $backup"
  pg_dump "$STAGING_DATABASE_URL" -Fc -f "$backup"
else
  echo "WARNING: pg_dump not found; upgrade will not continue without backup tooling."
  exit 1
fi

echo "Applying migration 025..."
psql "$STAGING_DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/025_environment_guardrails.sql
echo "Staging upgrade to v0.26 completed."
