#!/usr/bin/env bash
set -euo pipefail

if [ "${STAGING_UPGRADE_CONFIRMATION:-}" != "UPGRADE_STAGING_TO_V028" ]; then
  echo "Refusing to continue."
  echo "Set STAGING_UPGRADE_CONFIRMATION=UPGRADE_STAGING_TO_V028"
  exit 1
fi

if [ -z "${STAGING_DATABASE_URL:-}" ]; then
  echo "STAGING_DATABASE_URL is required."
  exit 1
fi

for cmd in psql pg_dump pg_restore; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "$cmd is required but was not found."
    exit 1
  fi
done

mkdir -p "${BACKUP_DIR:-./backups}"
stamp="$(date +%Y%m%d-%H%M%S)"
backup="${BACKUP_DIR:-./backups}/ds-bakery-pre-v028-${stamp}.dump"

echo "Creating pre-upgrade staging backup: $backup"
pg_dump "$STAGING_DATABASE_URL" -Fc -f "$backup"

echo "Verifying backup archive..."
pg_restore --list "$backup" >/dev/null

echo "Applying migration 027..."
psql "$STAGING_DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/027_production_cutover.sql

echo "Staging upgrade to v0.28 completed."
