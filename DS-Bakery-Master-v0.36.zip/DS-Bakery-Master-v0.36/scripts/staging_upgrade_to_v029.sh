#!/usr/bin/env bash
set -euo pipefail

if [ "${STAGING_UPGRADE_CONFIRMATION:-}" != "UPGRADE_STAGING_TO_V029" ]; then
  echo "Refusing to continue."
  echo "Set STAGING_UPGRADE_CONFIRMATION=UPGRADE_STAGING_TO_V029"
  exit 1
fi

if [ -z "${STAGING_DATABASE_URL:-}" ]; then
  echo "STAGING_DATABASE_URL is required."
  exit 1
fi

for cmd in psql pg_dump pg_restore; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "$cmd is required but was not found."
    exit 1
  fi
done

mkdir -p "${BACKUP_DIR:-./backups}"
stamp="$(date +%Y%m%d-%H%M%S)"
backup="${BACKUP_DIR:-./backups}/ds-bakery-pre-v029-${stamp}.dump"

echo "Creating pre-upgrade staging backup: $backup"
pg_dump "$STAGING_DATABASE_URL" -Fc -f "$backup"
pg_restore --list "$backup" >/dev/null

echo "Applying migration 028..."
psql "$STAGING_DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/028_supabase_staging_handoff.sql

echo "Staging upgrade to v0.29 completed."
