import { createClient } from "@supabase/supabase-js";

const url=process.env.STAGING_SUPABASE_URL;
const anonKey=process.env.STAGING_SUPABASE_ANON_KEY;
const password=process.env.STAGING_TEST_PASSWORD;
const domain=process.env.STAGING_TEST_EMAIL_DOMAIN;

if(!url||!anonKey||!password||!domain){
  throw new Error("Set STAGING_SUPABASE_URL, STAGING_SUPABASE_ANON_KEY, STAGING_TEST_PASSWORD and STAGING_TEST_EMAIL_DOMAIN.");
}


const serviceKey=process.env.STAGING_SUPABASE_SERVICE_ROLE_KEY;
if(!serviceKey){
  throw new Error("Set STAGING_SUPABASE_SERVICE_ROLE_KEY for environment guardrail checks.");
}
const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});
const {data:envState,error:envError}=await admin
  .from("system_environment_config")
  .select("environment_mode,allow_staging_test_accounts,production_lock")
  .eq("id",1)
  .single();
if(envError)throw new Error(`Could not read system environment guardrail: ${envError.message}`);
if(envState.environment_mode!=="staging"||!envState.allow_staging_test_accounts||envState.production_lock){
  throw new Error(`Staging validation refused: environment_mode=${envState.environment_mode}, allow_staging_test_accounts=${envState.allow_staging_test_accounts}, production_lock=${envState.production_lock}`);
}

const roles=["owner","manager","cashier","baker","storekeeper"];
const clients={};
const results=[];

function result(check_key,area,status,detail,evidence=""){
  const row={check_key,area,status,detail,evidence};
  results.push(row);
  const label=status.toUpperCase().padEnd(5);
  console.log(`${label} ${area} :: ${check_key} — ${detail}`);
  return row;
}

async function login(role){
  const client=createClient(url,anonKey,{auth:{autoRefreshToken:false,persistSession:false}});
  const email=`ds-${role}-test@${domain}`.toLowerCase();
  const {data,error}=await client.auth.signInWithPassword({email,password});
  if(error||!data.user)throw new Error(`${role} login failed: ${error?.message??"unknown error"}`);
  clients[role]=client;
  return data.user;
}

for(const role of roles){
  try{
    await login(role);
    result(`login_${role}`,"auth","pass",`${role} staging account signed in.`);
  }catch(e){
    result(`login_${role}`,"auth","fail",e.message);
  }
}

const anon=createClient(url,anonKey,{auth:{autoRefreshToken:false,persistSession:false}});

const {data:siteInfo,error:siteError}=await anon.rpc("public_site_info");
if(siteError){
  result("anonymous_public_site_info","public","fail",siteError.message);
}else{
  const expected={
    address_text:"Kiwafu Lugonjo",
    phone:"0708743663",
    secondary_phone:"0760547003",
    whatsapp_phone:"0760547003",
    email:"dscakes3@gmail.com",
  };
  const mismatches=Object.entries(expected).filter(([k,v])=>String(siteInfo?.[k]??"")!==v);
  result(
    "anonymous_public_site_info","public",
    mismatches.length?"warn":"pass",
    mismatches.length?`Public settings loaded, but ${mismatches.map(([k])=>k).join(", ")} differ from release defaults.`:"Public settings and DS Bakery contact defaults are available anonymously."
  );
}

const {data:catalog,error:catalogError}=await anon.rpc("public_product_catalog");
if(catalogError){
  result("anonymous_public_catalog","public","fail",catalogError.message);
}else{
  const forbidden=["current_stock_qty","cost","gross_profit","margin","recipe","supplier_id","created_by"];
  const leaked=(catalog??[]).flatMap(row=>forbidden.filter(k=>Object.prototype.hasOwnProperty.call(row,k)));
  result(
    "anonymous_public_catalog","public",
    leaked.length?"fail":"pass",
    leaked.length?`Forbidden public catalog keys detected: ${[...new Set(leaked)].join(", ")}`:`Public catalog returned ${(catalog??[]).length} active product row(s) with no known internal fields.`
  );
}

for(const table of ["profiles","raw_materials","recipes","suppliers","purchases","audit_logs"]){
  const {data,error}=await anon.from(table).select("*").limit(1);
  if(error){
    result(`anon_internal_${table}`,"rls","pass","Anonymous direct read is blocked.");
  }else if((data??[]).length===0){
    result(`anon_internal_${table}`,"rls","pass","Anonymous direct read returned no rows.");
  }else{
    result(`anon_internal_${table}`,"rls","fail","Anonymous direct read returned internal data.");
  }
}

for(const role of roles){
  const client=clients[role];
  if(!client)continue;

  const report=await client.rpc("management_report_v2",{p_period:"week"});
  const shouldReport=["owner","manager"].includes(role);
  result(
    `reports_${role}`,"roles",
    shouldReport?(report.error?"fail":"pass"):(report.error?"pass":"fail"),
    shouldReport
      ? (report.error?`Expected report access but received: ${report.error.message}`:"Report access allowed as expected.")
      : (report.error?"Report access denied as expected.":"Report access was unexpectedly allowed.")
  );

  const validation=await client.rpc("launch_readiness_summary");
  const shouldValidate=role==="owner";
  result(
    `launch_validation_${role}`,"roles",
    shouldValidate?(validation.error?"fail":"pass"):(validation.error?"pass":"fail"),
    shouldValidate
      ? (validation.error?`Owner validation failed: ${validation.error.message}`:"Owner validation RPC is accessible.")
      : (validation.error?"Owner-only validation correctly denied.":"Owner-only validation was unexpectedly allowed.")
  );

  const attendance=await client.rpc("my_attendance_status_today");
  result(
    `attendance_self_${role}`,"roles",
    attendance.error?"fail":"pass",
    attendance.error?attendance.error.message:"Self attendance status RPC is accessible."
  );
}

let ownerSummary=null;
if(clients.owner){
  const {data,error}=await clients.owner.rpc("launch_readiness_summary");
  if(error){
    result("database_launch_readiness","database","fail",error.message);
  }else{
    ownerSummary=data;
    const checks=Array.isArray(data?.database_checks)?data.database_checks:[];
    const failCount=checks.filter(c=>c.status==="fail").length;
    const actionableWarnings=checks.filter(c=>c.status==="warn"&&!["staging_validation_evidence","go_live_setup"].includes(c.check_key));
    const warnCount=actionableWarnings.length;
    result(
      "database_launch_readiness","database",
      failCount>0?"fail":warnCount>0?"warn":"pass",
      `Database readiness returned ${failCount} failure(s) and ${warnCount} actionable warning(s). The staging-evidence and go-live-setup warnings are ignored while creating this prerequisite staging run.`,
      JSON.stringify(data)
    );
  }
}

if(clients.owner){
  const owner=clients.owner;
  const {data:runId,error:startError}=await owner.rpc("begin_validation_run",{
    p_environment:"staging",
    p_notes:"Automated v0.25 staging smoke validation"
  });

  if(startError){
    result("record_validation_run","evidence","fail",startError.message);
  }else{
    for(const r of results){
      const {error}=await owner.rpc("record_validation_check",{
        p_run_id:runId,
        p_check_key:r.check_key,
        p_area:r.area,
        p_status:r.status,
        p_detail:r.detail,
        p_evidence:r.evidence||null,
      });
      if(error){
        console.error(`Could not record ${r.check_key}: ${error.message}`);
      }
    }

    const {data:overall,error:completeError}=await owner.rpc("complete_validation_run",{
      p_run_id:runId,
      p_notes:"Recorded automatically by scripts/staging_validate.mjs"
    });
    if(completeError){
      console.error(`Validation run could not be completed: ${completeError.message}`);
    }else{
      console.log(`Recorded validation run ${runId} with overall status: ${overall}`);
    }
  }
}

const failCount=results.filter(r=>r.status==="fail").length;
const warnCount=results.filter(r=>r.status==="warn").length;
console.log(`\nStaging smoke result: ${failCount} fail(s), ${warnCount} warning(s), ${results.length} checks.`);
if(failCount>0)process.exit(1);
