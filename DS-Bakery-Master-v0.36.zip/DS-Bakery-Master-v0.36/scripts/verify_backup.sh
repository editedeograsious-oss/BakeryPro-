#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <backup.dump>"
  exit 1
fi

BACKUP_FILE="$1"

if [ ! -s "$BACKUP_FILE" ]; then
  echo "Backup file is missing or empty: $BACKUP_FILE"
  exit 1
fi

pg_restore --list "$BACKUP_FILE" >/dev/null

echo "Backup archive is readable: $BACKUP_FILE"
echo "Archive verification is not a substitute for a real restore test."
