-- DS Bakery post-restore verification.
\echo 'DS Bakery restore verification'

select app_version,latest_migration,release_stage
from public.system_release_state
where id=1;

select
  (select count(*) from public.profiles) as profiles,
  (select count(*) from public.products) as products,
  (select count(*) from public.raw_materials) as raw_materials,
  (select count(*) from public.suppliers) as suppliers,
  (select count(*) from public.recipes) as recipes,
  (select count(*) from public.purchases) as purchases,
  (select count(*) from public.inventory_transactions) as inventory_transactions,
  (select count(*) from public.production_runs) as production_runs,
  (select count(*) from public.waste_events) as waste_events,
  (select count(*) from public.customers) as customers,
  (select count(*) from public.customer_orders) as customer_orders,
  (select count(*) from public.sales) as sales,
  (select count(*) from public.payments) as payments,
  (select count(*) from public.expenses) as expenses,
  (select count(*) from public.audit_logs) as audit_logs;

select count(*) as negative_stock_count
from public.raw_materials
where current_stock_qty<0;

select count(*) as active_owner_count
from public.profiles
where active=true and disabled_at is null and role='owner';

select count(*) as open_cashier_shift_count
from public.cashier_shifts
where status='open';

select count(*) as mobile_money_conflict_count
from public.mobile_money_reference_conflicts;

select count(*) as rls_disabled_public_tables
from pg_class c
join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public'
  and c.relkind='r'
  and not c.relrowsecurity;
