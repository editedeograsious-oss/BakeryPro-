#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <backup-folder>"
  exit 1
fi

DIR="$1"
for f in roles.sql schema.sql data.sql SHA256SUMS; do
  test -s "$DIR/$f" || { echo "Missing or empty: $DIR/$f"; exit 1; }
done

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$DIR" && sha256sum -c SHA256SUMS)
else
  (cd "$DIR" && shasum -a 256 -c SHA256SUMS)
fi

grep -q "CREATE" "$DIR/schema.sql" || { echo "schema.sql does not look like a schema dump"; exit 1; }
grep -Eq "COPY|INSERT" "$DIR/data.sql" || { echo "data.sql does not look like a data dump"; exit 1; }

echo "Backup files and checksums verified."
echo "This is archive verification only. A separate restore drill is still required."
