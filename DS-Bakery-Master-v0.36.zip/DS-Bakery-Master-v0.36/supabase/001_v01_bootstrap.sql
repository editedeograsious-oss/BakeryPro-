-- DS Bakery Master v0.1
create extension if not exists pgcrypto;

create type public.staff_role as enum ('owner','manager','cashier','baker','storekeeper');
create type public.record_status as enum ('active','inactive','archived');
create type public.inventory_tx_type as enum ('purchase','usage','adjustment','waste','return');
create type public.payment_method as enum ('cash','mtn_momo','airtel_money');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.staff_role not null default 'cashier',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  display_order int not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.product_categories(id),
  name text not null,
  sku text unique,
  description text,
  selling_price numeric(14,2) not null default 0 check (selling_price >= 0),
  track_recipe boolean not null default true,
  image_url text,
  notes text,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.raw_materials (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid,
  name text not null unique,
  sku text unique,
  base_unit text not null,
  purchase_pack_label text,
  purchase_pack_base_qty numeric(18,6) not null default 1 check (purchase_pack_base_qty > 0),
  current_purchase_cost numeric(14,2) not null default 0 check (current_purchase_cost >= 0),
  current_stock_qty numeric(18,6) not null default 0,
  low_stock_threshold numeric(18,6) not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  name text not null,
  yield_qty numeric(12,3) not null default 1 check (yield_qty > 0),
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index one_active_recipe_per_product on public.recipes(product_id) where active = true;

create table public.recipe_items (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_base_unit numeric(18,6) not null check (quantity_base_unit > 0),
  created_at timestamptz not null default now(),
  unique(recipe_id, raw_material_id)
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.raw_materials
  add constraint raw_material_supplier_fk
  foreign key (supplier_id) references public.suppliers(id);

create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  raw_material_id uuid not null references public.raw_materials(id),
  tx_type public.inventory_tx_type not null,
  quantity_delta numeric(18,6) not null,
  unit_cost numeric(14,6),
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'completed',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  cashier_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(12,3) not null,
  unit_price numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount >= 0),
  reference text,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  description text not null,
  amount numeric(14,2) not null check (amount >= 0),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity text not null,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_staff_role()
returns public.staff_role
language sql stable security definer set search_path=public
as $$ select role from public.profiles where id = auth.uid() $$;

alter table public.profiles enable row level security;
alter table public.product_categories enable row level security;
alter table public.products enable row level security;
alter table public.raw_materials enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_items enable row level security;
alter table public.suppliers enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.audit_logs enable row level security;

create policy "staff can read own profile" on public.profiles
for select using (id = auth.uid() or public.current_staff_role() in ('owner','manager'));

create policy "owner manages profiles" on public.profiles
for all using (public.current_staff_role() = 'owner')
with check (public.current_staff_role() = 'owner');

create policy "staff read active products" on public.products
for select using (status='active' or public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage products" on public.products
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "staff read categories" on public.product_categories
for select using (true);

create policy "owner manager manage categories" on public.product_categories
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "relevant staff read materials" on public.raw_materials
for select using (public.current_staff_role() in ('owner','manager','storekeeper','baker'));

create policy "storekeeper manager owner manage materials" on public.raw_materials
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "baker and managers read recipes" on public.recipes
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipes" on public.recipes
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "baker and managers read recipe items" on public.recipe_items
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipe items" on public.recipe_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "owner manager storekeeper read suppliers" on public.suppliers
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager storekeeper manage suppliers" on public.suppliers
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff read inventory tx" on public.inventory_transactions
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff create inventory tx" on public.inventory_transactions
for insert with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

create index products_category_idx on public.products(category_id);
create index recipe_items_recipe_idx on public.recipe_items(recipe_id);
create index inventory_tx_material_idx on public.inventory_transactions(raw_material_id, created_at desc);
create index audit_entity_idx on public.audit_logs(entity, entity_id, created_at desc);


