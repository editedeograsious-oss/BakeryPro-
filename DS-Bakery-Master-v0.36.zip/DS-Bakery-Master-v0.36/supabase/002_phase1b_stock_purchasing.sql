-- DS Bakery Phase 1B: stock & purchasing
-- Run after supabase/schema.sql from v0.1.

create type public.purchase_status as enum ('draft','ordered','partially_received','received','cancelled');
create type public.payment_status as enum ('unpaid','partial','paid');

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  purchase_no text not null unique,
  supplier_id uuid not null references public.suppliers(id),
  purchase_date date not null default current_date,
  supplier_reference text,
  status public.purchase_status not null default 'draft',
  payment_status public.payment_status not null default 'unpaid',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  amount_paid numeric(14,2) not null default 0 check (amount_paid >= 0),
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (amount_paid <= total_amount)
);

create table if not exists public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  ordered_qty_base numeric(18,6) not null check (ordered_qty_base > 0),
  received_qty_base numeric(18,6) not null default 0 check (received_qty_base >= 0),
  unit_cost_base numeric(14,6) not null check (unit_cost_base >= 0),
  line_total numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  unique(purchase_id, raw_material_id)
);

create table if not exists public.purchase_payments (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  amount numeric(14,2) not null check (amount > 0),
  method text not null,
  reference text,
  paid_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

-- Add purchase linkage to the stock ledger.
alter table public.inventory_transactions
  add column if not exists purchase_item_id uuid references public.purchase_items(id);

-- View current unit cost from the existing pack-cost fields.
create or replace view public.raw_material_costs as
select
  rm.*,
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_unit_cost,
  rm.current_stock_qty *
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_stock_value
from public.raw_materials rm;

create or replace view public.low_stock_materials as
select
  id,name,sku,base_unit,current_stock_qty,low_stock_threshold,
  case when low_stock_threshold > 0 then current_stock_qty / low_stock_threshold else null end as stock_ratio
from public.raw_materials
where status='active'
  and current_stock_qty <= low_stock_threshold;

create or replace view public.supplier_balances as
select
  s.id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(p.total_amount),0)::numeric(14,2) as total_purchases,
  coalesce(sum(p.amount_paid),0)::numeric(14,2) as total_paid,
  coalesce(sum(p.total_amount - p.amount_paid),0)::numeric(14,2) as outstanding_balance
from public.suppliers s
left join public.purchases p
  on p.supplier_id=s.id
 and p.status <> 'cancelled'
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- Central stock ledger trigger.
create or replace function public.apply_inventory_transaction()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  old_qty numeric(18,6);
  old_unit_cost numeric(14,6);
  incoming_cost numeric(14,6);
  new_unit_cost numeric(14,6);
begin
  select
    current_stock_qty,
    case when purchase_pack_base_qty > 0
      then current_purchase_cost / purchase_pack_base_qty
      else 0 end
  into old_qty, old_unit_cost
  from public.raw_materials
  where id = new.raw_material_id
  for update;

  -- For purchase receipts, update standard ingredient cost using weighted average.
  if new.tx_type = 'purchase' and new.quantity_delta > 0 and new.unit_cost is not null then
    incoming_cost := new.unit_cost;
    if old_qty <= 0 then
      new_unit_cost := incoming_cost;
    else
      new_unit_cost :=
        ((old_qty * old_unit_cost) + (new.quantity_delta * incoming_cost))
        / (old_qty + new.quantity_delta);
    end if;

    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      current_purchase_cost = new_unit_cost * purchase_pack_base_qty,
      updated_at = now()
    where id = new.raw_material_id;
  else
    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      updated_at = now()
    where id = new.raw_material_id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_apply_inventory_transaction on public.inventory_transactions;
create trigger trg_apply_inventory_transaction
after insert on public.inventory_transactions
for each row execute function public.apply_inventory_transaction();

-- Receive part or all of a purchase line and post the stock movement.
create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_remaining numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized';
  end if;

  if p_receive_qty_base <= 0 then
    raise exception 'Received quantity must be greater than zero';
  end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then
    raise exception 'Purchase item not found';
  end if;

  v_remaining := v_item.ordered_qty_base - v_item.received_qty_base;
  if p_receive_qty_base > v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  update public.purchase_items
  set received_qty_base = received_qty_base + p_receive_qty_base
  where id = p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase',v_item.purchase_id,v_item.id,auth.uid(),'Purchase receipt'
  );

  update public.purchases p
  set status =
    case
      when not exists (
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base < pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'receive_stock','purchase_item',p_purchase_item_id,
    jsonb_build_object('received_qty_base',p_receive_qty_base));
end;
$$;

create or replace function public.refresh_purchase_totals(p_purchase_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_total numeric(14,2);
  v_paid numeric(14,2);
begin
  select coalesce(sum(ordered_qty_base * unit_cost_base),0)::numeric(14,2)
    into v_total
  from public.purchase_items
  where purchase_id=p_purchase_id;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.purchase_payments
  where purchase_id=p_purchase_id;

  update public.purchases
  set
    subtotal=v_total,
    total_amount=greatest(v_total-discount,0),
    amount_paid=v_paid,
    payment_status=case
      when v_paid <= 0 then 'unpaid'::public.payment_status
      when v_paid >= greatest(v_total-discount,0) then 'paid'::public.payment_status
      else 'partial'::public.payment_status
    end,
    updated_at=now()
  where id=p_purchase_id;
end;
$$;

alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.purchase_payments enable row level security;

create policy "purchasing staff read purchases" on public.purchases
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchases" on public.purchases
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff read purchase items" on public.purchase_items
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchase items" on public.purchase_items
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read purchase payments" on public.purchase_payments
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager create purchase payments" on public.purchase_payments
for insert with check (public.current_staff_role() in ('owner','manager'));

create index if not exists purchases_supplier_idx on public.purchases(supplier_id,purchase_date desc);
create index if not exists purchase_items_purchase_idx on public.purchase_items(purchase_id);
create index if not exists purchase_payments_purchase_idx on public.purchase_payments(purchase_id);
