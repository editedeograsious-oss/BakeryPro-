-- DS Bakery Phase 1C: cashier POS

-- Add fields to existing sales table.
alter table public.sales
  add column if not exists sale_no text unique,
  add column if not exists held boolean not null default false,
  add column if not exists notes text,
  add column if not exists voided_at timestamptz,
  add column if not exists voided_by uuid references public.profiles(id),
  add column if not exists void_reason text,
  add column if not exists refund_total numeric(14,2) not null default 0;

alter table public.sale_items
  add column if not exists unit_cost_snapshot numeric(14,6),
  add column if not exists gross_profit_snapshot numeric(14,2);

alter table public.payments
  add column if not exists status text not null default 'completed',
  add column if not exists created_by uuid references public.profiles(id);

-- Secure approval PIN hash for owner/manager.
alter table public.profiles
  add column if not exists approval_pin_hash text;

create or replace function public.set_my_approval_pin(p_pin text)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can set an approval PIN';
  end if;
  if length(p_pin) < 4 or length(p_pin) > 10 then
    raise exception 'Approval PIN must be 4 to 10 characters';
  end if;

  update public.profiles
  set approval_pin_hash = crypt(p_pin, gen_salt('bf')),
      updated_at = now()
  where id = auth.uid();

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'set_approval_pin','profile',auth.uid(),jsonb_build_object('changed',true));
end;
$$;

create or replace function public.verify_approver_pin(p_pin text)
returns uuid
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
begin
  select id into v_approver
  from public.profiles
  where active=true
    and role in ('owner','manager')
    and approval_pin_hash is not null
    and approval_pin_hash = crypt(p_pin, approval_pin_hash)
  limit 1;

  if v_approver is null then
    raise exception 'Invalid approval PIN';
  end if;

  return v_approver;
end;
$$;

-- Helper sale number
create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(now(),'YYYYMMDD') || '-' ||
         lpad((floor(random()*100000))::int::text,5,'0')
$$;

-- Atomic sale creation.
create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text := public.next_sale_no();
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if jsonb_array_length(p_items) = 0 then
    raise exception 'Sale must contain at least one item';
  end if;

  -- Calculate subtotal from authoritative current product prices.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then
      raise exception 'Invalid or inactive product';
    end if;

    v_qty := greatest((v_item->>'quantity')::numeric,0);
    if v_qty <= 0 then raise exception 'Quantity must be greater than zero'; end if;
    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount > v_subtotal then p_discount := v_subtotal; end if;
  v_total := v_subtotal - p_discount;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;
      if v_method in ('mtn_momo','airtel_money') and coalesce(v_payment->>'reference','')='' then
        raise exception 'Mobile Money reference is required';
      end if;
      v_paid := v_paid + greatest((v_payment->>'amount')::numeric,0);
    end loop;

    if v_paid < v_total then
      raise exception 'Payments are less than sale total';
    end if;
  end if;

  insert into public.sales(id,sale_no,status,held,subtotal,discount,total,cashier_id,notes)
  values(v_sale_id,v_sale_no,case when p_hold then 'held' else 'completed' end,p_hold,v_subtotal,p_discount,v_total,auth.uid(),p_notes);

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select p.selling_price,
           coalesce((
             select sum(ri.quantity_base_unit * (rm.current_purchase_cost/rm.purchase_pack_base_qty)) / r.yield_qty
             from public.recipes r
             join public.recipe_items ri on ri.recipe_id=r.id
             join public.raw_materials rm on rm.id=ri.raw_material_id
             where r.product_id=p.id and r.active=true
             group by r.id,r.yield_qty
           ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(sale_id,method,amount,reference,created_by)
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(v_payment->>'reference',''),
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),case when p_hold then 'hold_sale' else 'complete_sale' end,'sale',v_sale_id,
    jsonb_build_object('sale_no',v_sale_no,'subtotal',v_subtotal,'discount',p_discount,'total',v_total));

  return v_sale_id;
end;
$$;

-- Cancel or refund with manager/owner PIN approval.
create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then
    raise exception 'Unsupported action';
  end if;

  if coalesce(trim(p_reason),'')='' then
    raise exception 'Reason is required';
  end if;

  v_approver := public.verify_approver_pin(p_approval_pin);

  select * into v_sale from public.sales where id=p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status='refunded' then raise exception 'Refunded sale cannot be cancelled'; end if;
    update public.sales
      set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    v_refund := coalesce(p_refund_amount,v_sale.total);
    if v_refund <= 0 or v_refund > (v_sale.total - v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    update public.sales
      set refund_total=refund_total+v_refund,
          status=case when refund_total+v_refund >= total then 'refunded' else 'partially_refunded' end
    where id=p_sale_id;

    insert into public.payments(sale_id,method,amount,reference,status,created_by)
    values(p_sale_id,'cash',-v_refund,'REFUND','refunded',v_approver);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;

alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.payments enable row level security;

drop policy if exists "sales staff read sales" on public.sales;
create policy "sales staff read sales" on public.sales
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sales" on public.sales;
create policy "sales staff create sales" on public.sales
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read sale items" on public.sale_items;
create policy "sales staff read sale items" on public.sale_items
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sale items" on public.sale_items;
create policy "sales staff create sale items" on public.sale_items
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read payments" on public.payments;
create policy "sales staff read payments" on public.payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create payments" on public.payments;
create policy "sales staff create payments" on public.payments
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sales_created_idx on public.sales(created_at desc);
create index if not exists sales_cashier_idx on public.sales(cashier_id,created_at desc);
create index if not exists sale_items_sale_idx on public.sale_items(sale_id);
create index if not exists payments_sale_idx on public.payments(sale_id);
