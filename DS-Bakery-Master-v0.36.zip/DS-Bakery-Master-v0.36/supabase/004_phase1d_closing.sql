-- DS Bakery Phase 1D: expenses, cashier shifts and daily closing

create type public.cash_movement_type as enum ('cash_in','cash_out');
create type public.shift_status as enum ('open','closed');
create type public.closing_status as enum ('draft','closed');

alter table public.expenses
  add column if not exists payment_method public.payment_method not null default 'cash',
  add column if not exists reference text,
  add column if not exists shift_id uuid;

create table if not exists public.cashier_shifts (
  id uuid primary key default gen_random_uuid(),
  cashier_id uuid not null references public.profiles(id),
  opened_by uuid not null references public.profiles(id),
  opened_at timestamptz not null default now(),
  opening_float numeric(14,2) not null default 0 check (opening_float >= 0),
  status public.shift_status not null default 'open',
  closed_at timestamptz,
  closed_by uuid references public.profiles(id),
  closing_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.cash_movements (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid references public.cashier_shifts(id),
  movement_type public.cash_movement_type not null,
  amount numeric(14,2) not null check (amount > 0),
  reason text not null,
  reference text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.sales
  add column if not exists shift_id uuid references public.cashier_shifts(id);

alter table public.expenses
  add constraint expenses_shift_fk
  foreign key (shift_id) references public.cashier_shifts(id);

create table if not exists public.daily_closings (
  id uuid primary key default gen_random_uuid(),
  business_date date not null unique,
  status public.closing_status not null default 'draft',

  opening_float numeric(14,2) not null default 0,
  cash_sales numeric(14,2) not null default 0,
  mtn_momo_sales numeric(14,2) not null default 0,
  airtel_money_sales numeric(14,2) not null default 0,

  cash_in numeric(14,2) not null default 0,
  cash_out numeric(14,2) not null default 0,
  cash_expenses numeric(14,2) not null default 0,
  momo_expenses numeric(14,2) not null default 0,

  expected_cash numeric(14,2) not null default 0,
  counted_cash numeric(14,2),
  cash_variance numeric(14,2),

  transaction_count int not null default 0,
  notes text,

  prepared_by uuid references public.profiles(id),
  closed_by uuid references public.profiles(id),
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result public.daily_closings;
  v_opening numeric(14,2);
  v_cash_sales numeric(14,2);
  v_mtn numeric(14,2);
  v_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count int;
  v_expected numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where opened_at::date = p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0),
    count(distinct s.id)
  into v_cash_sales,v_mtn,v_airtel,v_tx_count
  from public.sales s
  left join public.payments p on p.sale_id=s.id and p.status='completed'
  where s.created_at::date=p_business_date
    and s.status in ('completed','partially_refunded');

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where created_at::date=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where created_at::date=p_business_date;

  v_expected := v_opening + v_cash_sales + v_cash_in - v_cash_out - v_cash_exp;

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,v_opening,v_cash_sales,v_mtn,v_airtel,
    v_cash_in,v_cash_out,v_cash_exp,v_momo_exp,v_expected,
    v_tx_count,auth.uid()
  )
  on conflict (business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

create or replace function public.close_business_day(
  p_business_date date,
  p_counted_cash numeric,
  p_notes text default null
)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_close public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can close the business day';
  end if;

  select * into v_close
  from public.calculate_daily_closing(p_business_date);

  if v_close.status='closed' then
    raise exception 'Business day already closed';
  end if;

  update public.daily_closings
  set
    counted_cash=p_counted_cash,
    cash_variance=p_counted_cash-expected_cash,
    notes=p_notes,
    status='closed',
    closed_by=auth.uid(),
    closed_at=now(),
    updated_at=now()
  where business_date=p_business_date
  returning * into v_close;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_business_day','daily_closing',v_close.id,
    jsonb_build_object(
      'business_date',p_business_date,
      'expected_cash',v_close.expected_cash,
      'counted_cash',v_close.counted_cash,
      'variance',v_close.cash_variance
    )
  );

  return v_close;
end;
$$;

alter table public.cashier_shifts enable row level security;
alter table public.cash_movements enable row level security;
alter table public.daily_closings enable row level security;

create policy "sales staff read own shifts" on public.cashier_shifts
for select using (
  cashier_id=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "manager owner manage shifts" on public.cashier_shifts
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "cashier create own cash movement" on public.cash_movements
for insert with check (
  created_by=auth.uid()
  and public.current_staff_role() in ('owner','manager','cashier')
);

create policy "staff read permitted cash movements" on public.cash_movements
for select using (
  created_by=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "owner manager read closings" on public.daily_closings
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage closings" on public.daily_closings
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create index if not exists cashier_shifts_cashier_idx on public.cashier_shifts(cashier_id,opened_at desc);
create index if not exists cash_movements_shift_idx on public.cash_movements(shift_id,created_at desc);
create index if not exists daily_closings_date_idx on public.daily_closings(business_date desc);
