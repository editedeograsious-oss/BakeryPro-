-- DS Bakery Phase 1E: owner dashboard and reports

create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  si.quantity,
  si.line_total as sales_amount,
  coalesce(si.unit_cost_snapshot,0) * si.quantity as cogs_amount,
  coalesce(si.gross_profit_snapshot, si.line_total - (coalesce(si.unit_cost_snapshot,0) * si.quantity)) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
where s.status in ('completed','partially_refunded');

create or replace view public.best_selling_products_30d as
select
  product_id,
  product_name,
  sum(quantity)::numeric(14,3) as units_sold,
  sum(sales_amount)::numeric(14,2) as sales_amount,
  sum(gross_profit_amount)::numeric(14,2) as gross_profit_amount
from public.sale_profit_lines
where created_at >= now() - interval '30 days'
group by product_id,product_name
order by units_sold desc,sales_amount desc;

create or replace function public.period_start(p_period text)
returns timestamptz
language plpgsql
stable
as $$
begin
  case p_period
    when 'day' then return date_trunc('day',now());
    when 'week' then return date_trunc('week',now());
    when 'month' then return date_trunc('month',now());
    else raise exception 'Unsupported period';
  end case;
end;
$$;

create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language sql
security definer
set search_path=public
as $$
with bounds as (
  select public.period_start(p_period) as start_at
),
sales_summary as (
  select
    coalesce(sum(s.total - coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
    count(*)::bigint as transaction_count
  from public.sales s,bounds b
  where s.created_at >= b.start_at
    and s.status in ('completed','partially_refunded')
),
payment_summary as (
  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0)::numeric(14,2) as cash_sales,
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0)::numeric(14,2) as mtn_momo_sales,
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)::numeric(14,2) as airtel_money_sales
  from public.payments p
  join public.sales s on s.id=p.sale_id
  join bounds b on true
  where p.created_at >= b.start_at
    and p.status='completed'
    and s.status in ('completed','partially_refunded')
),
profit_summary as (
  select
    coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
  from public.sale_profit_lines spl,bounds b
  where spl.created_at >= b.start_at
),
expense_summary as (
  select
    coalesce(sum(amount),0)::numeric(14,2) as expenses
  from public.expenses e,bounds b
  where e.created_at >= b.start_at
)
select
  b.start_at,
  ss.sales,
  ps.cash_sales,
  ps.mtn_momo_sales,
  ps.airtel_money_sales,
  prs.gross_profit,
  es.expenses,
  (prs.gross_profit-es.expenses)::numeric(14,2) as estimated_operating_profit,
  ss.transaction_count,
  case when ss.transaction_count>0 then (ss.sales/ss.transaction_count)::numeric(14,2) else 0 end as average_sale
from bounds b,sales_summary ss,payment_summary ps,profit_summary prs,expense_summary es;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

create or replace function public.management_report(
  p_start_date date,
  p_end_date date
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sales numeric(14,2);
  v_cogs numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_purchases numeric(14,2);
  v_transactions bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_end_date < p_start_date then
    raise exception 'Invalid date range';
  end if;

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(cogs_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_cogs,v_gross
  from public.sale_profit_lines
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(total_amount),0)
  into v_purchases
  from public.purchases
  where purchase_date between p_start_date and p_end_date
    and status <> 'cancelled';

  select count(*)
  into v_transactions
  from public.sales
  where created_at >= p_start_date
    and created_at < (p_end_date + 1)
    and status in ('completed','partially_refunded');

  return jsonb_build_object(
    'start_date',p_start_date,
    'end_date',p_end_date,
    'sales',v_sales,
    'cogs',v_cogs,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'purchases',v_purchases,
    'transactions',v_transactions
  );
end;
$$;

grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;
grant execute on function public.management_report(date,date) to authenticated;

-- Owner and manager may read profitability views.
alter view public.sale_profit_lines set (security_invoker = true);
alter view public.best_selling_products_30d set (security_invoker = true);
