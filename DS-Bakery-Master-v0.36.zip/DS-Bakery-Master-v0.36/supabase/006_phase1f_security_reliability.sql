-- DS Bakery Phase 1F: security and reliability

alter table public.profiles
  add column if not exists disabled_at timestamptz,
  add column if not exists disabled_by uuid references public.profiles(id),
  add column if not exists session_version integer not null default 1,
  add column if not exists require_password_reset boolean not null default false;

-- Active role helper: disabled/inactive users resolve to NULL.
create or replace function public.current_staff_role()
returns public.staff_role
language sql
stable
security definer
set search_path=public
as $$
  select role
  from public.profiles
  where id=auth.uid()
    and active=true
    and disabled_at is null
$$;

create or replace function public.is_active_staff()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles
    where id=auth.uid()
      and active=true
      and disabled_at is null
  )
$$;

-- Owner-only staff status control.
create or replace function public.set_staff_active(
  p_staff_id uuid,
  p_active boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.profiles%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may enable or disable staff';
  end if;

  if p_staff_id = auth.uid() and p_active=false then
    raise exception 'Owner cannot disable own currently authenticated account';
  end if;

  select * into v_before from public.profiles where id=p_staff_id for update;
  if not found then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set
    active=p_active,
    disabled_at=case when p_active then null else now() end,
    disabled_by=case when p_active then null else auth.uid() end,
    session_version=session_version+1,
    updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_active then 'enable_staff' else 'disable_staff' end,
    'profile',
    p_staff_id,
    jsonb_build_object('active',v_before.active,'role',v_before.role),
    jsonb_build_object('active',p_active,'session_version',v_before.session_version+1)
  );
end;
$$;

create or replace function public.change_staff_role(
  p_staff_id uuid,
  p_role public.staff_role
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old_role public.staff_role;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may change staff roles';
  end if;

  if p_staff_id=auth.uid() then
    raise exception 'Owner cannot change own role from the active session';
  end if;

  select role into v_old_role from public.profiles where id=p_staff_id for update;
  if v_old_role is null then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set role=p_role,session_version=session_version+1,updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'change_staff_role','profile',p_staff_id,
    jsonb_build_object('role',v_old_role),
    jsonb_build_object('role',p_role)
  );
end;
$$;

-- View safe staff status metadata.
create or replace view public.staff_security_status
with (security_invoker=true)
as
select
  id,full_name,role,active,disabled_at,disabled_by,
  session_version,require_password_reset,created_at,updated_at
from public.profiles;

-- Owner/manager audit browsing. Inserts remain application/RPC controlled.
drop policy if exists "owner manager read audit logs" on public.audit_logs;
create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

-- Harden core financial tables: disabled users lose role through current_staff_role().
-- Existing policies continue to call current_staff_role(), so replacing that helper
-- applies disabled-profile enforcement across modules.

create index if not exists profiles_active_role_idx on public.profiles(active,role);
create index if not exists audit_actor_created_idx on public.audit_logs(actor_id,created_at desc);

grant execute on function public.set_staff_active(uuid,boolean) to authenticated;
grant execute on function public.change_staff_role(uuid,public.staff_role) to authenticated;
