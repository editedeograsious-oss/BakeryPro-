-- DS Bakery Phase 2A: kitchen production and baker tasks

create type public.production_status as enum ('planned','in_progress','complete','cancelled');
create type public.production_shift as enum ('morning','afternoon','evening');

create table if not exists public.production_plan_items (
  id uuid primary key default gen_random_uuid(),
  business_date date not null default current_date,
  product_id uuid not null references public.products(id),
  assigned_baker_id uuid references public.profiles(id),
  shift public.production_shift not null default 'morning',
  planned_qty numeric(14,3) not null check (planned_qty > 0),
  produced_qty numeric(14,3) not null default 0 check (produced_qty >= 0),
  status public.production_status not null default 'planned',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (produced_qty <= planned_qty)
);

create table if not exists public.production_runs (
  id uuid primary key default gen_random_uuid(),
  plan_item_id uuid not null references public.production_plan_items(id) on delete restrict,
  quantity_produced numeric(14,3) not null check (quantity_produced > 0),
  confirmed_by uuid not null references public.profiles(id),
  confirmed_at timestamptz not null default now()
);

create table if not exists public.production_consumptions (
  id uuid primary key default gen_random_uuid(),
  production_run_id uuid not null references public.production_runs(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_used_base numeric(18,6) not null check (quantity_used_base > 0),
  unit_cost_snapshot numeric(14,6) not null default 0,
  inventory_transaction_id uuid not null references public.inventory_transactions(id),
  created_at timestamptz not null default now()
);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_item record;
  v_required numeric(18,6);
  v_stock numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_quantity_produced <= 0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then
    raise exception 'Production plan item not found';
  end if;

  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id <> auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining := v_plan.planned_qty - v_plan.produced_qty;
  if p_quantity_produced > v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id
    and active=true
  limit 1;

  if not found then
    raise exception 'Product has no active recipe';
  end if;

  -- First pass: verify every required ingredient has enough stock.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;

    if v_item.current_stock_qty < v_required then
      raise exception 'Insufficient stock for raw material %', v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(id,plan_item_id,quantity_produced,confirmed_by)
  values(v_run_id,p_plan_item_id,p_quantity_produced,auth.uid());

  -- Second pass: post stock consumption ledger entries.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;
    v_unit_cost := v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,
      'usage',
      -v_required,
      v_unit_cost,
      'production_run',
      v_run_id,
      auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced >= planned_qty
        then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    'confirm_production',
    'production_run',
    v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty > 0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=current_date;

alter table public.production_plan_items enable row level security;
alter table public.production_runs enable row level security;
alter table public.production_consumptions enable row level security;

create policy "production staff read plan items" on public.production_plan_items
for select using (
  public.current_staff_role() in ('owner','manager')
  or (public.current_staff_role()='baker' and assigned_baker_id=auth.uid())
);

create policy "owner manager manage plan items" on public.production_plan_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "production staff read runs" on public.production_runs
for select using (
  public.current_staff_role() in ('owner','manager')
  or confirmed_by=auth.uid()
);

create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper','baker')
);

grant execute on function public.confirm_production_run(uuid,numeric) to authenticated;

create index if not exists production_plan_date_idx
  on public.production_plan_items(business_date,status);

create index if not exists production_plan_baker_idx
  on public.production_plan_items(assigned_baker_id,business_date);

create index if not exists production_runs_plan_idx
  on public.production_runs(plan_item_id,confirmed_at desc);

create index if not exists production_consumption_run_idx
  on public.production_consumptions(production_run_id);
