-- DS Bakery Phase 2B: waste & production control
create type public.waste_type as enum ('finished_product','raw_material');
create type public.waste_approval_status as enum ('pending','approved','rejected');

create table public.waste_settings (
  id integer primary key default 1 check (id=1),
  approval_threshold numeric(14,2) not null default 50000 check (approval_threshold >= 0),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);
insert into public.waste_settings(id,approval_threshold) values(1,50000) on conflict (id) do nothing;

create table public.waste_events (
  id uuid primary key default gen_random_uuid(),
  waste_type public.waste_type not null,
  product_id uuid references public.products(id),
  raw_material_id uuid references public.raw_materials(id),
  production_run_id uuid references public.production_runs(id),
  quantity numeric(18,6) not null check (quantity > 0),
  reason text not null,
  notes text,
  unit_cost_snapshot numeric(14,6) not null default 0,
  total_cost numeric(14,2) not null default 0,
  approval_status public.waste_approval_status not null default 'pending',
  recorded_by uuid not null references public.profiles(id),
  recorded_at timestamptz not null default now(),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  decision_note text,
  inventory_transaction_id uuid references public.inventory_transactions(id),
  check ((waste_type='finished_product' and product_id is not null and raw_material_id is null) or (waste_type='raw_material' and raw_material_id is not null and product_id is null))
);

create or replace function public.current_product_unit_cost(p_product_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(ri.quantity_base_unit * case when rm.purchase_pack_base_qty>0 then rm.current_purchase_cost/rm.purchase_pack_base_qty else 0 end)/r.yield_qty
  from public.recipes r join public.recipe_items ri on ri.recipe_id=r.id join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.product_id=p_product_id and r.active=true group by r.id,r.yield_qty limit 1),0)
$$;

create or replace function public.production_run_unit_cost(p_run_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(pc.quantity_used_base*pc.unit_cost_snapshot)/pr.quantity_produced
  from public.production_runs pr join public.production_consumptions pc on pc.production_run_id=pr.id
  where pr.id=p_run_id group by pr.id,pr.quantity_produced),0)
$$;

create or replace function public.apply_approved_raw_waste(p_waste_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_waste public.waste_events%rowtype; v_stock numeric; v_tx_id uuid;
begin
  select * into v_waste from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_waste.waste_type<>'raw_material' or v_waste.inventory_transaction_id is not null or v_waste.approval_status<>'approved' then return; end if;
  select current_stock_qty into v_stock from public.raw_materials where id=v_waste.raw_material_id for update;
  if v_stock < v_waste.quantity then raise exception 'Insufficient raw-material stock for waste approval'; end if;
  insert into public.inventory_transactions(raw_material_id,tx_type,quantity_delta,unit_cost,reference_type,reference_id,created_by,notes)
  values(v_waste.raw_material_id,'waste',-v_waste.quantity,v_waste.unit_cost_snapshot,'waste_event',v_waste.id,coalesce(v_waste.approved_by,v_waste.recorded_by),'Approved raw-material waste: '||v_waste.reason)
  returning id into v_tx_id;
  update public.waste_events set inventory_transaction_id=v_tx_id where id=v_waste.id;
end; $$;

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,p_quantity numeric,p_reason text,p_product_id uuid default null,p_raw_material_id uuid default null,p_production_run_id uuid default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_role public.staff_role; v_unit_cost numeric(14,6); v_total numeric(14,2); v_threshold numeric(14,2); v_status public.waste_approval_status; v_waste_id uuid:=gen_random_uuid(); v_run_product uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','baker','storekeeper') then raise exception 'Not authorized to record waste'; end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;
  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then raise exception 'Finished-product waste requires product only'; end if;
    if p_production_run_id is not null then
      select ppi.product_id into v_run_product from public.production_runs pr join public.production_plan_items ppi on ppi.id=pr.plan_item_id where pr.id=p_production_run_id;
      if v_run_product is null or v_run_product<>p_product_id then raise exception 'Production run does not match product'; end if;
      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else v_unit_cost:=public.current_product_unit_cost(p_product_id); end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then raise exception 'Raw-material waste requires raw material only'; end if;
    select case when purchase_pack_base_qty>0 then current_purchase_cost/purchase_pack_base_qty else 0 end into v_unit_cost from public.raw_materials where id=p_raw_material_id;
    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;
  v_total:=round((p_quantity*v_unit_cost)::numeric,2);
  select approval_threshold into v_threshold from public.waste_settings where id=1;
  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then v_status:='approved'; else v_status:='pending'; end if;
  insert into public.waste_events(id,waste_type,product_id,raw_material_id,production_run_id,quantity,reason,notes,unit_cost_snapshot,total_cost,approval_status,recorded_by,approved_by,approved_at)
  values(v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,p_quantity,p_reason,p_notes,v_unit_cost,v_total,v_status,auth.uid(),case when v_status='approved' then auth.uid() end,case when v_status='approved' then now() end);
  if v_status='approved' and p_waste_type='raw_material' then perform public.apply_approved_raw_waste(v_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'record_waste','waste_event',v_waste_id,jsonb_build_object('waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,'total_cost',v_total,'approval_status',v_status));
  return v_waste_id;
end; $$;

create or replace function public.decide_waste_event(p_waste_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_before public.waste_events%rowtype; v_new public.waste_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve/reject waste'; end if;
  if p_decision='approve' then v_new:='approved'; elsif p_decision='reject' then v_new:='rejected'; else raise exception 'Decision must be approve or reject'; end if;
  select * into v_before from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_before.approval_status<>'pending' then raise exception 'Only pending waste can be decided'; end if;
  update public.waste_events set approval_status=v_new,approved_by=auth.uid(),approved_at=now(),decision_note=p_note where id=p_waste_id;
  if v_new='approved' and v_before.waste_type='raw_material' then perform public.apply_approved_raw_waste(p_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data) values(auth.uid(),case when v_new='approved' then 'approve_waste' else 'reject_waste' end,'waste_event',p_waste_id,jsonb_build_object('approval_status',v_before.approval_status),jsonb_build_object('approval_status',v_new,'decision_note',p_note));
end; $$;

create or replace view public.production_control_today with (security_invoker=true) as
with plan as (
 select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty from public.production_plan_items where business_date=current_date and status<>'cancelled' group by product_id
), product_waste as (
 select product_id,coalesce(sum(quantity),0) approved_waste_qty,coalesce(sum(total_cost),0) approved_waste_cost from public.waste_events
 where waste_type='finished_product' and approval_status='approved' and recorded_at::date=current_date group by product_id
)
select p.id product_id,p.name product_name,pl.planned_qty,pl.produced_qty,coalesce(pw.approved_waste_qty,0) approved_waste_qty,
 greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,(pl.produced_qty-pl.planned_qty) production_variance,
 case when pl.produced_qty>0 then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2) else 0 end waste_rate_pct,
 coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl join public.products p on p.id=pl.product_id left join product_waste pw on pw.product_id=pl.product_id;

create or replace view public.waste_summary_30d with (security_invoker=true) as
select waste_type,approval_status,count(*) event_count,coalesce(sum(total_cost),0)::numeric(14,2) total_cost from public.waste_events where recorded_at>=now()-interval '30 days' group by waste_type,approval_status;

alter table public.waste_settings enable row level security;
alter table public.waste_events enable row level security;
create policy "management read waste settings" on public.waste_settings for select using (public.current_staff_role() in ('owner','manager'));
create policy "owner manage waste settings" on public.waste_settings for all using (public.current_staff_role()='owner') with check (public.current_staff_role()='owner');
create policy "staff read relevant waste" on public.waste_events for select using (public.current_staff_role() in ('owner','manager') or recorded_by=auth.uid() or (public.current_staff_role()='storekeeper' and waste_type='raw_material'));
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
create index waste_events_recorded_idx on public.waste_events(recorded_at desc);
create index waste_events_pending_idx on public.waste_events(approval_status,recorded_at desc);
create index waste_events_product_idx on public.waste_events(product_id,recorded_at desc) where product_id is not null;
create index waste_events_material_idx on public.waste_events(raw_material_id,recorded_at desc) where raw_material_id is not null;
