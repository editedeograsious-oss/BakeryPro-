-- DS Bakery Phase 2C: supplier accounts, payables and purchase-order approval

create type public.po_approval_status as enum ('pending','approved','rejected');

alter table public.purchases
  add column if not exists approval_status public.po_approval_status not null default 'pending',
  add column if not exists requested_by uuid references public.profiles(id),
  add column if not exists approved_by uuid references public.profiles(id),
  add column if not exists approved_at timestamptz,
  add column if not exists approval_note text,
  add column if not exists supplier_invoice_no text,
  add column if not exists invoice_date date,
  add column if not exists credit_terms_days integer not null default 0 check (credit_terms_days >= 0),
  add column if not exists due_date date;

update public.purchases
set requested_by=coalesce(requested_by,created_by),
    approval_status=case
      when status='draft' then 'pending'::public.po_approval_status
      else 'approved'::public.po_approval_status
    end
where requested_by is null
   or (approval_status='pending' and status<>'draft');

create or replace function public.set_purchase_due_date()
returns trigger
language plpgsql
set search_path=public
as $$
begin
  if new.due_date is null then
    new.due_date := coalesce(new.invoice_date,new.purchase_date) + new.credit_terms_days;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_set_purchase_due_date on public.purchases;
create trigger trg_set_purchase_due_date
before insert or update of invoice_date,purchase_date,credit_terms_days,due_date
on public.purchases
for each row execute function public.set_purchase_due_date();

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then
    v_approval := 'approved';
  elsif p_decision='reject' then
    v_approval := 'rejected';
  else
    raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status <> 'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',
    p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid := gen_random_uuid();
  v_remaining numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if coalesce(trim(p_method),'')='' then
    raise exception 'Payment method is required';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status <> 'approved' then raise exception 'Purchase order is not approved'; end if;

  v_remaining := v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount > v_remaining then
    raise exception 'Payment exceeds amount outstanding on purchase';
  end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by
  )
  values(
    v_payment_id,p_purchase_id,p_amount,p_method,nullif(trim(p_reference),''),now(),auth.uid()
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date < current_date
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled'
      and p.total_amount>p.amount_paid
    then p.due_date end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

create or replace view public.supplier_statement_lines
with (security_invoker=true)
as
with lines as (
  select
    p.supplier_id,
    p.purchase_date::timestamptz as occurred_at,
    'purchase'::text as line_type,
    p.id as source_id,
    p.purchase_no as reference,
    p.supplier_invoice_no,
    p.total_amount::numeric(14,2) as debit,
    0::numeric(14,2) as credit,
    p.total_amount::numeric(14,2) as balance_delta
  from public.purchases p
  where p.status<>'cancelled'
    and p.approval_status='approved'

  union all

  select
    p.supplier_id,
    pp.paid_at as occurred_at,
    'payment'::text as line_type,
    pp.id as source_id,
    coalesce(pp.reference,'Supplier payment') as reference,
    p.supplier_invoice_no,
    0::numeric(14,2) as debit,
    pp.amount::numeric(14,2) as credit,
    (-pp.amount)::numeric(14,2) as balance_delta
  from public.purchase_payments pp
  join public.purchases p on p.id=pp.purchase_id
)
select
  supplier_id,
  occurred_at,
  line_type,
  source_id,
  reference,
  supplier_invoice_no,
  debit,
  credit,
  sum(balance_delta) over(
    partition by supplier_id
    order by occurred_at,line_type,source_id
    rows between unbounded preceding and current row
  )::numeric(14,2) as running_balance
from lines;

create or replace view public.open_purchase_orders
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.total_amount,
  p.status,
  p.approval_status,
  p.due_date,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by
where p.status not in ('received','cancelled');

grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text) to authenticated;

create index if not exists purchases_due_idx
  on public.purchases(due_date,payment_status)
  where status<>'cancelled';

create index if not exists purchases_approval_idx
  on public.purchases(approval_status,status,created_at desc);

create index if not exists purchase_payments_paid_idx
  on public.purchase_payments(paid_at desc);
