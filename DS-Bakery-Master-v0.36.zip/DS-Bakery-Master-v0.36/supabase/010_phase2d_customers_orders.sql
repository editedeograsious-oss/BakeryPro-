-- DS Bakery Phase 2D: customers, customer orders, deposits and receipts

create type public.customer_order_status as enum (
  'pending','confirmed','in_production','ready','completed','cancelled'
);

create type public.fulfillment_type as enum ('pickup','delivery');

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text,
  email text,
  address text,
  birthday date,
  notes text,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists customers_phone_unique
  on public.customers(phone)
  where phone is not null;

create table if not exists public.customer_orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  customer_id uuid not null references public.customers(id),
  status public.customer_order_status not null default 'pending',
  fulfillment public.fulfillment_type not null default 'pickup',
  required_at timestamptz not null,
  delivery_address text,
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  discount numeric(14,2) not null default 0 check (discount >= 0),
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  cancelled_at timestamptz,
  cancellation_reason text
);

create table if not exists public.customer_order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  product_id uuid references public.products(id),
  description text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  line_total numeric(14,2) not null check (line_total >= 0),
  customization_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_order_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount > 0),
  reference text,
  payment_status text not null default 'completed',
  recorded_by uuid not null references public.profiles(id),
  paid_at timestamptz not null default now()
);

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' || to_char(now(),'YYMMDD') || '-' ||
         lpad((floor(random()*10000))::int::text,4,'0')
$$;

create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount into v_discount
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if p_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_remaining := v_order.total_amount-v_paid;

  if p_amount > v_remaining then
    raise exception 'Payment exceeds outstanding order balance';
  end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,recorded_by
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,
    nullif(trim(p_reference),''),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','cashier','baker') then
    raise exception 'Not authorized';
  end if;

  select * into v_before
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;

  if v_role='cashier' and p_status in ('in_production') then
    raise exception 'Cashier cannot move order into production';
  end if;

  if v_role='baker' and p_status not in ('in_production','ready') then
    raise exception 'Baker may only update production/ready status';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  co.created_at,
  co.updated_at
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  co.id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.status,co.fulfillment,co.required_at,co.delivery_address,
  co.total_amount,co.created_at,co.updated_at;

create or replace view public.customer_summary
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  count(distinct co.id)::bigint as order_count,
  coalesce(sum(co.total_amount),0)::numeric(14,2) as total_order_value,
  coalesce(sum((
    select co.total_amount -
      coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
    from public.customer_order_payments cop
    where cop.order_id=co.id
  )),0)::numeric(14,2) as outstanding_balance,
  max(co.created_at) as last_order_at
from public.customers c
left join public.customer_orders co
  on co.customer_id=c.id and co.status<>'cancelled'
where c.active=true
group by c.id,c.full_name,c.phone,c.email;

alter table public.customers enable row level security;
alter table public.customer_orders enable row level security;
alter table public.customer_order_items enable row level security;
alter table public.customer_order_payments enable row level security;

create policy "sales staff read customers" on public.customers
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff manage customers" on public.customers
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer orders" on public.customer_orders
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer orders" on public.customer_orders
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer order items" on public.customer_order_items
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer order items" on public.customer_order_items
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff read order payments" on public.customer_order_payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.record_customer_order_payment(
  uuid,numeric,public.payment_method,text
) to authenticated;

grant execute on function public.update_customer_order_status(
  uuid,public.customer_order_status
) to authenticated;

create index if not exists customer_orders_customer_idx
  on public.customer_orders(customer_id,created_at desc);

create index if not exists customer_orders_required_idx
  on public.customer_orders(status,required_at);

create index if not exists customer_order_items_order_idx
  on public.customer_order_items(order_id);

create index if not exists customer_order_payments_order_idx
  on public.customer_order_payments(order_id,paid_at desc);
