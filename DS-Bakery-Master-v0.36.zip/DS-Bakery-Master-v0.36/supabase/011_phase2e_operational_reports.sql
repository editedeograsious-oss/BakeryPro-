-- DS Bakery Phase 2E: weekly/monthly operational reporting

create or replace function public.operational_period_bounds(p_period text)
returns table(start_date date,end_date date)
language plpgsql
stable
as $$
begin
  if p_period='week' then
    start_date := date_trunc('week',current_date)::date;
    end_date := current_date;
  elsif p_period='month' then
    start_date := date_trunc('month',current_date)::date;
    end_date := current_date;
  else
    raise exception 'Unsupported period: %', p_period;
  end if;
  return next;
end;
$$;

create or replace function public.operational_report_summary(p_period text default 'week')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start date;
  v_end date;
  v_sales numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_planned numeric(18,3);
  v_produced numeric(18,3);
  v_waste_cost numeric(14,2);
  v_product_waste numeric(18,3);
  v_supplier_outstanding numeric(14,2);
  v_supplier_overdue numeric(14,2);
  v_customer_balance numeric(14,2);
  v_orders bigint;
  v_completed bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  select start_date,end_date into v_start,v_end
  from public.operational_period_bounds(p_period);

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_gross
  from public.sale_profit_lines
  where created_at::date between v_start and v_end;

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at::date between v_start and v_end;

  select
    coalesce(sum(planned_qty),0),
    coalesce(sum(produced_qty),0)
  into v_planned,v_produced
  from public.production_plan_items
  where business_date between v_start and v_end
    and status<>'cancelled';

  select
    coalesce(sum(total_cost),0),
    coalesce(sum(case when waste_type='finished_product' then quantity else 0 end),0)
  into v_waste_cost,v_product_waste
  from public.waste_events
  where approval_status='approved'
    and recorded_at::date between v_start and v_end;

  select
    coalesce(sum(outstanding_balance),0),
    coalesce(sum(overdue_balance),0)
  into v_supplier_outstanding,v_supplier_overdue
  from public.supplier_account_summary;

  select coalesce(sum(balance_due),0)
  into v_customer_balance
  from public.customer_order_summary
  where status not in ('completed','cancelled');

  select
    count(*),
    count(*) filter (where status='completed')
  into v_orders,v_completed
  from public.customer_orders
  where created_at::date between v_start and v_end;

  return jsonb_build_object(
    'period',p_period,
    'start_date',v_start,
    'end_date',v_end,
    'sales',v_sales,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'production_planned',v_planned,
    'production_produced',v_produced,
    'production_variance',v_produced-v_planned,
    'waste_cost',v_waste_cost,
    'finished_product_waste_qty',v_product_waste,
    'supplier_outstanding',v_supplier_outstanding,
    'supplier_overdue',v_supplier_overdue,
    'customer_order_balance',v_customer_balance,
    'orders_total',v_orders,
    'orders_completed',v_completed,
    'order_completion_rate',case when v_orders>0 then round((v_completed::numeric/v_orders)*100,2) else 0 end
  );
end;
$$;

create or replace view public.operational_production_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
),
waste as (
  select
    we.product_id,
    p.period_key,
    coalesce(sum(we.quantity),0) as waste_qty
  from public.waste_events we
  join periods p on we.recorded_at::date between p.start_date and p.end_date
  where we.waste_type='finished_product'
    and we.approval_status='approved'
  group by we.product_id,p.period_key
)
select
  per.period_key,
  ppi.product_id,
  pr.name as product_name,
  sum(ppi.planned_qty)::numeric(18,3) as planned_qty,
  sum(ppi.produced_qty)::numeric(18,3) as produced_qty,
  (sum(ppi.produced_qty)-sum(ppi.planned_qty))::numeric(18,3) as variance_qty,
  coalesce(w.waste_qty,0)::numeric(18,3) as approved_waste_qty,
  case when sum(ppi.produced_qty)>0
    then round((coalesce(w.waste_qty,0)/sum(ppi.produced_qty))*100,2)
    else 0 end as waste_rate_pct
from periods per
join public.production_plan_items ppi
  on ppi.business_date between per.start_date and per.end_date
join public.products pr on pr.id=ppi.product_id
left join waste w
  on w.product_id=ppi.product_id and w.period_key=per.period_key
where ppi.status<>'cancelled'
group by per.period_key,ppi.product_id,pr.name,w.waste_qty;

create or replace view public.operational_waste_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  we.waste_type,
  count(*)::bigint as event_count,
  coalesce(sum(we.quantity),0)::numeric(18,3) as quantity,
  coalesce(sum(we.total_cost),0)::numeric(14,2) as waste_cost
from periods per
join public.waste_events we
  on we.recorded_at::date between per.start_date and per.end_date
where we.approval_status='approved'
group by per.period_key,we.waste_type;

create or replace view public.customer_order_operational_summary
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  count(co.id)::bigint as orders_total,
  count(co.id) filter (where co.status='completed')::bigint as orders_completed,
  count(co.id) filter (where co.status='ready')::bigint as orders_ready,
  count(co.id) filter (where co.status='in_production')::bigint as orders_in_production,
  case when count(co.id)>0
    then round((count(co.id) filter (where co.status='completed')::numeric/count(co.id))*100,2)
    else 0 end as completion_rate
from periods per
left join public.customer_orders co
  on co.created_at::date between per.start_date and per.end_date
group by per.period_key;

create or replace view public.operational_product_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  spl.product_id,
  spl.product_name,
  sum(spl.quantity)::numeric(18,3) as units_sold,
  sum(spl.sales_amount)::numeric(14,2) as sales_amount,
  sum(spl.gross_profit_amount)::numeric(14,2) as gross_profit_amount
from periods per
join public.sale_profit_lines spl
  on spl.created_at::date between per.start_date and per.end_date
group by per.period_key,spl.product_id,spl.product_name
order by per.period_key,units_sold desc;

create or replace function public.management_alerts()
returns table(
  alert_type text,
  severity text,
  title text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  select
    'supplier'::text,
    'high'::text,
    'Overdue supplier balance'::text,
    s.supplier_name || ' overdue ' || to_char(s.overdue_balance,'FM999,999,999') || ' UGX'
  from public.supplier_account_summary s
  where s.overdue_balance>0

  union all

  select
    'stock',
    'high',
    'Low stock',
    l.name || ' at ' || l.current_stock_qty || ' ' || l.base_unit
  from public.low_stock_materials l

  union all

  select
    'production',
    'medium',
    'Production below plan',
    p.product_name || ' variance ' || p.variance_qty
  from public.operational_production_performance p
  where p.period_key='week'
    and p.variance_qty<0

  union all

  select
    'waste',
    'medium',
    'High waste rate',
    p.product_name || ' waste rate ' || p.waste_rate_pct || '%'
  from public.operational_production_performance p
  where p.period_key='week'
    and p.waste_rate_pct>=5;
end;
$$;

grant execute on function public.operational_report_summary(text) to authenticated;
grant execute on function public.management_alerts() to authenticated;
