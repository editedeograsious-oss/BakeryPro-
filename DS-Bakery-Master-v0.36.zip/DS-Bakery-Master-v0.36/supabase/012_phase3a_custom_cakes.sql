-- DS Bakery Phase 3A: custom cake specification, quote, image reference and production handoff

create type public.custom_cake_design_status as enum (
  'draft','quoted','awaiting_deposit','approved','in_production','ready','completed','cancelled'
);

create table if not exists public.custom_cake_specs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  cake_size_label text,
  servings integer check (servings is null or servings > 0),
  tiers integer not null default 1 check (tiers > 0),
  flavour text,
  filling text,
  frosting text,
  theme text,
  primary_color text,
  secondary_color text,
  inscription text,
  reference_image_path text,
  special_instructions text,
  production_notes text,
  quote_amount numeric(14,2) not null default 0 check (quote_amount >= 0),
  design_status public.custom_cake_design_status not null default 'draft',
  customer_approved_at timestamptz,
  production_approved_by uuid references public.profiles(id),
  production_approved_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;

  if p_quote_amount <= 0 then
    raise exception 'Quote amount must be greater than zero';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status
    end,
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    subtotal=p_quote_amount,
    total_amount=p_quote_amount,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(
  p_order_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount <= 0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_paid <= 0 then
    raise exception 'A deposit/payment is required before production approval';
  end if;

  update public.custom_cake_specs
  set
    design_status='approved',
    production_approved_by=auth.uid(),
    production_approved_at=now(),
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    status='confirmed',
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,
      'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid
    )
  );
end;
$$;

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id as custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (ccs.quote_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  ccs.design_status,
  co.status as order_status
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.required_at,co.fulfillment,co.delivery_address,
  ccs.cake_size_label,ccs.servings,ccs.tiers,ccs.flavour,ccs.filling,
  ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,
  ccs.production_notes,ccs.quote_amount,ccs.design_status,co.status;

alter table public.custom_cake_specs enable row level security;

create policy "relevant staff read custom cakes" on public.custom_cake_specs
for select using (
  public.current_staff_role() in ('owner','manager','cashier','baker')
);

create policy "sales staff create custom cakes" on public.custom_cake_specs
for insert with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "sales staff update custom cakes" on public.custom_cake_specs
for update using (
  public.current_staff_role() in ('owner','manager','cashier')
)
with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;

create index if not exists custom_cake_specs_status_idx
  on public.custom_cake_specs(design_status,updated_at desc);

-- Storage note:
-- Create a PRIVATE Supabase Storage bucket named `custom-cake-references`.
-- Store only the object path in reference_image_path.
-- Do not make customer reference images public by default.
