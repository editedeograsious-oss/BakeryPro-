-- DS Bakery Phase 3B: delivery jobs and rider assignment

create type public.delivery_status as enum (
  'pending','assigned','out_for_delivery','delivered','failed','cancelled'
);

create table if not exists public.delivery_riders (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  vehicle_label text,
  profile_id uuid unique references public.profiles(id),
  active boolean not null default true,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.customer_orders
  add column if not exists delivery_charge numeric(14,2) not null default 0
    check (delivery_charge >= 0);

create table if not exists public.delivery_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  rider_id uuid references public.delivery_riders(id),
  status public.delivery_status not null default 'pending',
  scheduled_for timestamptz,
  delivery_address_snapshot text not null,
  customer_name_snapshot text not null,
  customer_phone_snapshot text,
  delivery_charge numeric(14,2) not null default 0 check (delivery_charge >= 0),
  assigned_by uuid references public.profiles(id),
  assigned_at timestamptz,
  dispatched_by uuid references public.profiles(id),
  dispatched_at timestamptz,
  delivered_by uuid references public.profiles(id),
  delivered_at timestamptz,
  failed_at timestamptz,
  outcome_note text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Include delivery charge in order total calculation.
create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
  v_delivery numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount,delivery_charge
    into v_discount,v_delivery
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0)+coalesce(v_delivery,0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_delivery_charge < 0 then
    raise exception 'Delivery charge cannot be negative';
  end if;

  if coalesce(trim(p_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment <> 'delivery' then
    raise exception 'Order is not marked for delivery';
  end if;
  if v_order.status='cancelled' then
    raise exception 'Cannot create delivery for cancelled order';
  end if;

  select * into v_customer
  from public.customers
  where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_new_total := greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;

  if v_new_total < v_paid then
    raise exception 'New order total would be less than payments already recorded';
  end if;

  update public.customer_orders
  set
    delivery_charge=p_delivery_charge,
    total_amount=v_new_total,
    delivery_address=p_address,
    updated_at=now()
  where id=p_order_id;

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,
    delivery_address_snapshot,customer_name_snapshot,customer_phone_snapshot,
    delivery_charge,created_by
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    p_address,v_customer.full_name,v_customer.phone,
    p_delivery_charge,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at)
    )
  );

  return v_id;
end;
$$;

create or replace function public.assign_delivery_rider(
  p_delivery_id uuid,
  p_rider_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_rider public.delivery_riders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to assign riders';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;
  if v_job.status in ('delivered','cancelled') then
    raise exception 'Delivery job is closed';
  end if;

  select * into v_rider
  from public.delivery_riders
  where id=p_rider_id and active=true;

  if not found then raise exception 'Active rider not found'; end if;

  update public.delivery_jobs
  set
    rider_id=p_rider_id,
    status='assigned',
    assigned_by=auth.uid(),
    assigned_at=now(),
    updated_at=now()
  where id=p_delivery_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'assign_delivery_rider','delivery_job',p_delivery_id,
    jsonb_build_object('rider_id',p_rider_id,'rider_name',v_rider.full_name)
  );
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order
  from public.customer_orders
  where id=v_job.order_id
  for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then
      raise exception 'Delivery must be assigned or failed before dispatch';
    end if;
    if v_job.rider_id is null then
      raise exception 'Assign a rider before dispatch';
    end if;
    if v_order.status <> 'ready' then
      raise exception 'Customer order must be ready before dispatch';
    end if;

    update public.delivery_jobs
    set
      status='out_for_delivery',
      dispatched_by=auth.uid(),
      dispatched_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may be completed';
    end if;

    update public.delivery_jobs
    set
      status='delivered',
      delivered_by=auth.uid(),
      delivered_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set
      status='completed',
      completed_at=now(),
      updated_at=now()
    where id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may fail';
    end if;
    if coalesce(trim(p_note),'')='' then
      raise exception 'Failure reason is required';
    end if;

    update public.delivery_jobs
    set
      status='failed',
      failed_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then
      raise exception 'Delivered job cannot be cancelled';
    end if;

    update public.delivery_jobs
    set
      status='cancelled',
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

create or replace view public.delivery_job_summary
with (security_invoker=true)
as
select
  dj.id,
  dj.order_id,
  co.order_no,
  co.customer_id,
  dj.customer_name_snapshot as customer_name,
  dj.customer_phone_snapshot as customer_phone,
  dj.delivery_address_snapshot as delivery_address,
  dj.scheduled_for,
  dj.delivery_charge,
  dj.status,
  dj.rider_id,
  dr.full_name as rider_name,
  dr.phone as rider_phone,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  dj.assigned_at,
  dj.dispatched_at,
  dj.delivered_at,
  dj.failed_at,
  dj.outcome_note
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
left join public.delivery_riders dr on dr.id=dj.rider_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  dj.id,dj.order_id,co.order_no,co.customer_id,
  dj.customer_name_snapshot,dj.customer_phone_snapshot,
  dj.delivery_address_snapshot,dj.scheduled_for,dj.delivery_charge,
  dj.status,dj.rider_id,dr.full_name,dr.phone,co.total_amount,
  dj.assigned_at,dj.dispatched_at,dj.delivered_at,dj.failed_at,dj.outcome_note;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id as rider_id,
  dr.full_name,
  dr.phone,
  dr.vehicle_label,
  dr.active,
  count(dj.id) filter (
    where dj.status in ('assigned','out_for_delivery')
  )::bigint as active_jobs,
  count(dj.id) filter (
    where dj.status='delivered'
      and dj.delivered_at::date=current_date
  )::bigint as delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

alter table public.delivery_riders enable row level security;
alter table public.delivery_jobs enable row level security;

create policy "delivery staff read riders" on public.delivery_riders
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage riders" on public.delivery_riders
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "delivery staff read delivery jobs" on public.delivery_jobs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;

create index if not exists delivery_jobs_status_schedule_idx
  on public.delivery_jobs(status,scheduled_for);

create index if not exists delivery_jobs_rider_idx
  on public.delivery_jobs(rider_id,status);

create index if not exists delivery_riders_active_idx
  on public.delivery_riders(active,full_name);
