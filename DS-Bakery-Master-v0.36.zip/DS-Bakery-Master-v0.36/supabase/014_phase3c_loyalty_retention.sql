-- DS Bakery Phase 3C: loyalty, birthdays and customer retention

create type public.loyalty_event_type as enum (
  'sale_earn',
  'order_earn',
  'refund_adjustment',
  'reward_redemption',
  'birthday_bonus',
  'manual_adjustment'
);

alter table public.sales
  add column if not exists customer_id uuid references public.customers(id);

create table if not exists public.loyalty_settings (
  id integer primary key default 1 check (id=1),
  earn_amount_per_point numeric(14,2) not null default 1000 check (earn_amount_per_point > 0),
  reward_points integer not null default 100 check (reward_points > 0),
  reward_value numeric(14,2) not null default 5000 check (reward_value >= 0),
  birthday_reminder_days integer not null default 30 check (birthday_reminder_days between 1 and 90),
  vip_spend_threshold numeric(14,2) not null default 1000000 check (vip_spend_threshold >= 0),
  regular_spend_threshold numeric(14,2) not null default 500000 check (regular_spend_threshold >= 0),
  regular_order_threshold integer not null default 5 check (regular_order_threshold >= 1),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.loyalty_settings(id)
values(1)
on conflict (id) do nothing;

create table if not exists public.loyalty_point_transactions (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  event_type public.loyalty_event_type not null,
  points_delta integer not null check (points_delta <> 0),
  source_type text,
  source_id uuid,
  reason text not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace view public.customer_loyalty_balances
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  coalesce(sum(lpt.points_delta),0)::bigint as points_balance,
  max(lpt.created_at) as last_loyalty_activity_at
from public.customers c
left join public.loyalty_point_transactions lpt on lpt.customer_id=c.id
where c.active=true
group by c.id,c.full_name,c.phone;

create or replace function public.sync_sale_loyalty_points(p_sale_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale public.sales%rowtype;
  v_rate numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_sale from public.sales where id=p_sale_id;
  if not found or v_sale.customer_id is null then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  if v_sale.status in ('completed','partially_refunded') then
    v_expected := floor(greatest(v_sale.total-coalesce(v_sale.refund_total,0),0)/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_sale.customer_id
    and source_type='sale'
    and source_id=p_sale_id
    and event_type in ('sale_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_sale.customer_id,
      case when v_delta>0 then 'sale_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'sale',
      p_sale_id,
      case when v_delta>0 then 'Points earned from completed sale'
           else 'Points adjusted after sale refund/cancellation' end,
      v_sale.cashier_id
    );
  end if;
end;
$$;

create or replace function public.trg_sync_sale_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_sale_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_sales_loyalty_sync on public.sales;
create trigger trg_sales_loyalty_sync
after insert or update of customer_id,total,refund_total,status
on public.sales
for each row execute function public.trg_sync_sale_loyalty();

create or replace function public.sync_order_loyalty_points(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_rate numeric(14,2);
  v_paid numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_order
  from public.customer_orders
  where id=p_order_id;

  if not found then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_order.status='completed' and v_paid >= v_order.total_amount then
    v_expected := floor(v_order.total_amount/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_order.customer_id
    and source_type='customer_order'
    and source_id=p_order_id
    and event_type in ('order_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_order.customer_id,
      case when v_delta>0 then 'order_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'customer_order',
      p_order_id,
      case when v_delta>0 then 'Points earned from paid completed customer order'
           else 'Points adjusted after order status/payment change' end,
      v_order.created_by
    );
  end if;
end;
$$;

create or replace function public.trg_sync_order_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_customer_orders_loyalty_sync on public.customer_orders;
create trigger trg_customer_orders_loyalty_sync
after update of status,total_amount
on public.customer_orders
for each row execute function public.trg_sync_order_loyalty();

create or replace function public.trg_sync_order_payment_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.order_id);
  return new;
end;
$$;

drop trigger if exists trg_order_payments_loyalty_sync on public.customer_order_payments;
create trigger trg_order_payments_loyalty_sync
after insert or update of amount,payment_status
on public.customer_order_payments
for each row execute function public.trg_sync_order_payment_loyalty();

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment'
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if v_balance is null then raise exception 'Customer not found'; end if;
  if v_balance+p_points < 0 then raise exception 'Adjustment would make points negative'; end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,source_type,reason,created_by
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,'manual',p_reason,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object('customer_id',p_customer_id,'points_delta',p_points,'reason',p_reason)
  );

  return v_id;
end;
$$;

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then
    raise exception 'Cannot redeem on a closed order';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings
  where id=1;

  if p_points <= 0 or mod(p_points,v_reward_points) <> 0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points > v_balance then
    raise exception 'Insufficient loyalty points';
  end if;

  v_units := p_points/v_reward_points;
  v_discount := v_units*v_reward_value;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0) < v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,source_type,source_id,reason,created_by
  )
  values(
    v_order.customer_id,
    'reward_redemption',
    -p_points,
    'customer_order',
    p_order_id,
    'Loyalty reward applied to customer order',
    auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount)
  );

  return v_discount;
end;
$$;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.birthday,
  b.next_birthday,
  (b.next_birthday-current_date) as days_until_birthday,
  coalesce(lb.points_balance,0) as points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date as next_birthday
  from generate_series(
    current_date,
    current_date + interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d
  limit 1
) b
where c.active=true
  and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id as customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint as order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) as lifetime_value,
    max(co.created_at) filter (where co.status<>'cancelled') as last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (
  select * from public.loyalty_settings where id=1
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  os.order_count,
  os.lifetime_value,
  os.last_order_at,
  coalesce(lb.points_balance,0) as points_balance,
  case
    when os.lifetime_value >= s.vip_spend_threshold then 'VIP'
    when os.lifetime_value >= s.regular_spend_threshold
      or os.order_count >= s.regular_order_threshold then 'Regular'
    when os.order_count >= 2 then 'Returning'
    else 'New'
  end as customer_segment
from public.customers c
join order_stats os on os.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

alter table public.loyalty_settings enable row level security;
alter table public.loyalty_point_transactions enable row level security;

create policy "sales management read loyalty settings" on public.loyalty_settings
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "owner manage loyalty settings" on public.loyalty_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "sales management read loyalty ledger" on public.loyalty_point_transactions
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.adjust_customer_loyalty_points(
  uuid,integer,text,public.loyalty_event_type
) to authenticated;

grant execute on function public.redeem_loyalty_on_order(uuid,integer) to authenticated;

create index if not exists loyalty_customer_created_idx
  on public.loyalty_point_transactions(customer_id,created_at desc);

create index if not exists loyalty_source_idx
  on public.loyalty_point_transactions(source_type,source_id)
  where source_id is not null;
