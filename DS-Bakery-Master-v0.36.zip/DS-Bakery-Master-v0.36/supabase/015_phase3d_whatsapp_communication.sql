-- DS Bakery Phase 3D: WhatsApp customer communication

create type public.communication_template_type as enum (
  'ready_for_pickup',
  'in_production',
  'out_for_delivery',
  'birthday',
  'balance_reminder',
  'custom'
);

create type public.communication_event_status as enum (
  'prepared',
  'opened_whatsapp',
  'api_sent',
  'delivered',
  'failed'
);

alter table public.customers
  add column if not exists whatsapp_opt_in boolean not null default false,
  add column if not exists whatsapp_opt_in_at timestamptz,
  add column if not exists whatsapp_opt_out_at timestamptz;

create table if not exists public.communication_templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  template_type public.communication_template_type not null,
  body_template text not null,
  requires_marketing_opt_in boolean not null default false,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.communication_templates(
  name,template_type,body_template,requires_marketing_opt_in
)
select * from (values
  ('Ready for pickup','ready_for_pickup'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is ready for collection. Balance due: UGX {{balance}}. Thank you for choosing DS Bakery.',false),
  ('In production','in_production'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is now in production. We will update you when it is ready.',false),
  ('Out for delivery','out_for_delivery'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is out for delivery. Please keep your phone available for the rider.',false),
  ('Birthday greeting','birthday'::public.communication_template_type,
   'Happy birthday {{customer_name}}! DS Bakery wishes you a wonderful day. We appreciate having you as our customer.',true),
  ('Balance reminder','balance_reminder'::public.communication_template_type,
   'Hello {{customer_name}}, a friendly reminder that order {{order_no}} has a remaining balance of UGX {{balance}}. Thank you.',false)
) v(name,template_type,body_template,requires_marketing_opt_in)
where not exists (
  select 1 from public.communication_templates ct
  where ct.template_type=v.template_type
);

create table if not exists public.communication_logs (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  order_id uuid references public.customer_orders(id),
  template_id uuid references public.communication_templates(id),
  channel text not null default 'whatsapp',
  status public.communication_event_status not null default 'prepared',
  recipient_phone_snapshot text not null,
  message_snapshot text not null,
  initiated_by uuid not null references public.profiles(id),
  initiated_at timestamptz not null default now(),
  external_message_id text,
  delivered_at timestamptz,
  failure_reason text
);

create or replace function public.set_customer_whatsapp_preference(
  p_customer_id uuid,
  p_opted_in boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before boolean;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update communication preference';
  end if;

  select whatsapp_opt_in into v_before
  from public.customers
  where id=p_customer_id
  for update;

  if not found then raise exception 'Customer not found'; end if;

  update public.customers
  set
    whatsapp_opt_in=p_opted_in,
    whatsapp_opt_in_at=case when p_opted_in then now() else whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case when not p_opted_in then now() else null end,
    updated_at=now()
  where id=p_customer_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_whatsapp_preference','customer',p_customer_id,
    jsonb_build_object('whatsapp_opt_in',v_before),
    jsonb_build_object('whatsapp_opt_in',p_opted_in)
  );
end;
$$;

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then
    raise exception 'Recipient phone is required';
  end if;
  if coalesce(trim(p_message),'')='' then
    raise exception 'Message is required';
  end if;

  select * into v_customer
  from public.customers
  where id=p_customer_id;

  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template
    from public.communication_templates
    where id=p_template_id and active=true;

    if not found then raise exception 'Active communication template not found'; end if;

    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders
    where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,status,
    recipient_phone_snapshot,message_snapshot,initiated_by
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'opened_whatsapp',
    p_recipient_phone,p_message,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,
      'order_id',p_order_id,
      'template_id',p_template_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text as queue_type,
  100 as priority,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id as order_id,
  co.order_no,
  co.required_at as due_at,
  cos.balance_due,
  'Order is ready for pickup'::text as reason
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready'

union all

select
  'out_for_delivery',
  90,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  dj.scheduled_for,
  cos.balance_due,
  'Order is out for delivery'
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where dj.status='out_for_delivery'

union all

select
  'birthday',
  50,
  b.customer_id,
  b.full_name,
  b.phone,
  c.whatsapp_opt_in,
  null::uuid,
  null::text,
  b.next_birthday::timestamptz,
  0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days'
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all

select
  'balance_reminder',
  40,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  co.required_at,
  cos.balance_due,
  'Customer order has outstanding balance'
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0
  and co.status not in ('cancelled');

alter table public.communication_templates enable row level security;
alter table public.communication_logs enable row level security;

create policy "authorized staff read communication templates"
on public.communication_templates
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage communication templates"
on public.communication_templates
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "authorized staff read communication logs"
on public.communication_logs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text) to authenticated;

create index if not exists communication_logs_customer_idx
  on public.communication_logs(customer_id,initiated_at desc);

create index if not exists communication_logs_order_idx
  on public.communication_logs(order_id,initiated_at desc)
  where order_id is not null;

create index if not exists communication_templates_type_idx
  on public.communication_templates(template_type,active);
