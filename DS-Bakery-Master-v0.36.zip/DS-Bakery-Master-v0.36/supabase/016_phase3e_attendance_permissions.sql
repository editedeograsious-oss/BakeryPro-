-- DS Bakery Phase 3E: attendance, staff scheduling and individual permissions

create type public.staff_shift_status as enum ('scheduled','completed','cancelled');
create type public.attendance_status as enum ('on_time','late','completed','absent','excused');

create table if not exists public.attendance_settings (
  id integer primary key default 1 check (id=1),
  late_grace_minutes integer not null default 5 check (late_grace_minutes between 0 and 120),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.attendance_settings(id,late_grace_minutes)
values(1,5)
on conflict (id) do nothing;

create table if not exists public.staff_work_shifts (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.profiles(id),
  shift_date date not null,
  scheduled_start time not null,
  scheduled_end time not null,
  work_station text,
  status public.staff_shift_status not null default 'scheduled',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (scheduled_end > scheduled_start),
  unique(staff_id,shift_date,scheduled_start)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid not null unique references public.staff_work_shifts(id) on delete restrict,
  staff_id uuid not null references public.profiles(id),
  clock_in_at timestamptz,
  clock_out_at timestamptz,
  status public.attendance_status,
  late_minutes integer not null default 0 check (late_minutes >= 0),
  note text,
  adjusted_by uuid references public.profiles(id),
  adjusted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (clock_out_at is null or clock_in_at is null or clock_out_at >= clock_in_at)
);

create or replace function public.clock_in_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.staff_work_shifts%rowtype;
  v_id uuid;
  v_grace integer;
  v_scheduled timestamptz;
  v_late integer;
begin
  if not public.is_active_staff() then
    raise exception 'Active staff account required';
  end if;

  select * into v_shift
  from public.staff_work_shifts
  where staff_id=auth.uid()
    and shift_date=current_date
    and status='scheduled'
  order by scheduled_start
  limit 1
  for update;

  if not found then
    raise exception 'No scheduled work shift found for today';
  end if;

  if exists(
    select 1 from public.attendance_records
    where shift_id=v_shift.id and clock_in_at is not null
  ) then
    raise exception 'Already clocked in for this shift';
  end if;

  select late_grace_minutes into v_grace
  from public.attendance_settings
  where id=1;

  v_scheduled := current_date + v_shift.scheduled_start;
  v_late := greatest(
    0,
    floor(extract(epoch from (now()-v_scheduled))/60)::integer - coalesce(v_grace,0)
  );

  insert into public.attendance_records(
    shift_id,staff_id,clock_in_at,status,late_minutes
  )
  values(
    v_shift.id,
    auth.uid(),
    now(),
    case when v_late>0 then 'late'::public.attendance_status else 'on_time'::public.attendance_status end,
    v_late
  )
  returning id into v_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_in','attendance_record',v_id,
    jsonb_build_object('shift_id',v_shift.id,'late_minutes',v_late)
  );

  return v_id;
end;
$$;

create or replace function public.clock_out_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_record public.attendance_records%rowtype;
begin
  select ar.* into v_record
  from public.attendance_records ar
  join public.staff_work_shifts sws on sws.id=ar.shift_id
  where ar.staff_id=auth.uid()
    and sws.shift_date=current_date
    and ar.clock_in_at is not null
    and ar.clock_out_at is null
  order by ar.clock_in_at desc
  limit 1
  for update of ar;

  if not found then
    raise exception 'No open attendance record found';
  end if;

  update public.attendance_records
  set
    clock_out_at=now(),
    status='completed',
    updated_at=now()
  where id=v_record.id;

  update public.staff_work_shifts
  set status='completed',updated_at=now()
  where id=v_record.shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_out','attendance_record',v_record.id,
    jsonb_build_object('clock_out_at',now())
  );

  return v_record.id;
end;
$$;

create or replace function public.adjust_attendance_record(
  p_attendance_id uuid,
  p_clock_in timestamptz,
  p_clock_out timestamptz,
  p_status public.attendance_status,
  p_note text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.attendance_records%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may adjust attendance';
  end if;

  if coalesce(trim(p_note),'')='' then
    raise exception 'Adjustment note is required';
  end if;

  select * into v_before
  from public.attendance_records
  where id=p_attendance_id
  for update;

  if not found then raise exception 'Attendance record not found'; end if;

  update public.attendance_records
  set
    clock_in_at=p_clock_in,
    clock_out_at=p_clock_out,
    status=p_status,
    note=p_note,
    adjusted_by=auth.uid(),
    adjusted_at=now(),
    updated_at=now()
  where id=p_attendance_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'adjust_attendance','attendance_record',p_attendance_id,
    jsonb_build_object(
      'clock_in_at',v_before.clock_in_at,
      'clock_out_at',v_before.clock_out_at,
      'status',v_before.status
    ),
    jsonb_build_object(
      'clock_in_at',p_clock_in,
      'clock_out_at',p_clock_out,
      'status',p_status,
      'note',p_note
    )
  );
end;
$$;

create or replace view public.staff_shift_schedule
with (security_invoker=true)
as
select
  sws.id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  sws.status,
  sws.notes
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id;

create or replace view public.attendance_today
with (security_invoker=true)
as
select
  sws.id as shift_id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  ar.id as attendance_id,
  ar.clock_in_at,
  ar.clock_out_at,
  ar.status as attendance_status,
  coalesce(ar.late_minutes,0) as late_minutes,
  case
    when ar.id is not null then ar.status::text
    when current_time > sws.scheduled_end then 'absent'
    else 'scheduled'
  end as display_status
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id
left join public.attendance_records ar on ar.shift_id=sws.id
where sws.shift_date=current_date
  and sws.status<>'cancelled';

-- Individual permission system
create table if not exists public.app_permissions (
  permission_key text primary key,
  description text not null,
  critical boolean not null default false
);

insert into public.app_permissions(permission_key,description,critical) values
  ('reports:view','View owner/manager reports',true),
  ('delivery:manage','Manage delivery jobs',false),
  ('communication:send','Open customer communication messages',false),
  ('products:write','Change product details/prices',true),
  ('inventory:write','Receive/adjust stock through allowed workflows',true),
  ('purchases:write','Create/manage purchase orders',true),
  ('attendance:manage','Adjust staff attendance',true),
  ('schedule:manage','Manage staff work schedules',true)
on conflict (permission_key) do nothing;

create table if not exists public.role_permission_defaults (
  role public.staff_role not null,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  primary key(role,permission_key)
);

insert into public.role_permission_defaults(role,permission_key,allowed) values
  ('owner','reports:view',true),
  ('owner','delivery:manage',true),
  ('owner','communication:send',true),
  ('owner','products:write',true),
  ('owner','inventory:write',true),
  ('owner','purchases:write',true),
  ('owner','attendance:manage',true),
  ('owner','schedule:manage',true),

  ('manager','reports:view',true),
  ('manager','delivery:manage',true),
  ('manager','communication:send',true),
  ('manager','products:write',true),
  ('manager','inventory:write',true),
  ('manager','purchases:write',true),
  ('manager','attendance:manage',true),
  ('manager','schedule:manage',true),

  ('cashier','reports:view',false),
  ('cashier','delivery:manage',true),
  ('cashier','communication:send',true),
  ('cashier','products:write',false),
  ('cashier','inventory:write',false),
  ('cashier','purchases:write',false),
  ('cashier','attendance:manage',false),
  ('cashier','schedule:manage',false),

  ('baker','reports:view',false),
  ('baker','delivery:manage',false),
  ('baker','communication:send',false),
  ('baker','products:write',false),
  ('baker','inventory:write',false),
  ('baker','purchases:write',false),
  ('baker','attendance:manage',false),
  ('baker','schedule:manage',false),

  ('storekeeper','reports:view',false),
  ('storekeeper','delivery:manage',false),
  ('storekeeper','communication:send',false),
  ('storekeeper','products:write',false),
  ('storekeeper','inventory:write',true),
  ('storekeeper','purchases:write',true),
  ('storekeeper','attendance:manage',false),
  ('storekeeper','schedule:manage',false)
on conflict (role,permission_key) do update set allowed=excluded.allowed;

create table if not exists public.staff_permission_overrides (
  staff_id uuid not null references public.profiles(id) on delete cascade,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  set_by uuid not null references public.profiles(id),
  set_at timestamptz not null default now(),
  reason text,
  primary key(staff_id,permission_key)
);

create or replace function public.effective_staff_permissions(p_staff_id uuid)
returns table(
  permission_key text,
  description text,
  critical boolean,
  role_default boolean,
  individual_override boolean,
  has_override boolean,
  effective_allowed boolean
)
language sql
security definer
set search_path=public
as $$
  select
    ap.permission_key,
    ap.description,
    ap.critical,
    coalesce(rpd.allowed,false) as role_default,
    spo.allowed as individual_override,
    (spo.staff_id is not null) as has_override,
    coalesce(spo.allowed,rpd.allowed,false) as effective_allowed
  from public.profiles p
  cross join public.app_permissions ap
  left join public.role_permission_defaults rpd
    on rpd.role=p.role and rpd.permission_key=ap.permission_key
  left join public.staff_permission_overrides spo
    on spo.staff_id=p.id and spo.permission_key=ap.permission_key
  where p.id=p_staff_id
$$;

create or replace function public.staff_has_permission(p_permission_key text)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((
    select e.effective_allowed
    from public.effective_staff_permissions(auth.uid()) e
    where e.permission_key=p_permission_key
  ),false)
$$;

create or replace function public.set_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text,
  p_allowed boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may set individual permission overrides';
  end if;

  if not exists(select 1 from public.profiles where id=p_staff_id and active=true) then
    raise exception 'Active staff profile not found';
  end if;

  if not exists(select 1 from public.app_permissions where permission_key=p_permission_key) then
    raise exception 'Unknown permission key';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.staff_permission_overrides(
    staff_id,permission_key,allowed,set_by,set_at
  )
  values(
    p_staff_id,p_permission_key,p_allowed,auth.uid(),now()
  )
  on conflict(staff_id,permission_key)
  do update set
    allowed=excluded.allowed,
    set_by=excluded.set_by,
    set_at=excluded.set_at;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_permission_override','profile',p_staff_id,
    case when v_old.staff_id is null then null
         else jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed) end,
    jsonb_build_object('permission_key',p_permission_key,'allowed',p_allowed)
  );
end;
$$;

create or replace function public.clear_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may clear individual permission overrides';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  if not found then return; end if;

  delete from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'clear_permission_override','profile',p_staff_id,
    jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed),
    jsonb_build_object('permission_key',p_permission_key,'override','cleared')
  );
end;
$$;

alter table public.attendance_settings enable row level security;
alter table public.staff_work_shifts enable row level security;
alter table public.attendance_records enable row level security;
alter table public.app_permissions enable row level security;
alter table public.role_permission_defaults enable row level security;
alter table public.staff_permission_overrides enable row level security;

create policy "staff read attendance settings" on public.attendance_settings
for select using (public.is_active_staff());

create policy "owner manage attendance settings" on public.attendance_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "staff read own or management schedules" on public.staff_work_shifts
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management schedules" on public.staff_work_shifts
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "staff read own or management attendance" on public.attendance_records
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management read permissions" on public.app_permissions
for select using (public.current_staff_role() in ('owner','manager'));

create policy "management read role defaults" on public.role_permission_defaults
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner read permission overrides" on public.staff_permission_overrides
for select using (public.current_staff_role()='owner');

grant execute on function public.clock_in_staff() to authenticated;
grant execute on function public.clock_out_staff() to authenticated;
grant execute on function public.adjust_attendance_record(uuid,timestamptz,timestamptz,public.attendance_status,text) to authenticated;
grant execute on function public.effective_staff_permissions(uuid) to authenticated;
grant execute on function public.staff_has_permission(text) to authenticated;
grant execute on function public.set_staff_permission_override(uuid,text,boolean) to authenticated;
grant execute on function public.clear_staff_permission_override(uuid,text) to authenticated;

create index if not exists staff_work_shifts_date_idx
  on public.staff_work_shifts(shift_date,staff_id,status);

create index if not exists attendance_staff_created_idx
  on public.attendance_records(staff_id,created_at desc);

create index if not exists permission_override_staff_idx
  on public.staff_permission_overrides(staff_id,permission_key);
