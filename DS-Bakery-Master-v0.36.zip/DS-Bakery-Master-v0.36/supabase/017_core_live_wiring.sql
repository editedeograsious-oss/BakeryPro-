-- DS Bakery v0.18 / Migration 017
-- Live data wiring for products, recipes, inventory, POS, cashier shifts and daily closing.
-- Also fixes cash-tender accounting, sale idempotency, refund cashflow, sale numbers and
-- owner/manager report RPC role checks.

create table if not exists public.business_settings (
  id integer primary key default 1 check (id=1),
  business_timezone text not null default 'Africa/Kampala',
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.business_settings(id,business_timezone)
values(1,'Africa/Kampala')
on conflict (id) do nothing;

create or replace function public.business_current_date()
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (now() at time zone (coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  )))::date
$$;

create or replace function public.business_date(p_timestamp timestamptz)
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (p_timestamp at time zone (coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  )))::date
$$;

-- Product/recipe costing views.
create or replace view public.product_cost_summary
with (security_invoker=true)
as
with costs as (
  select
    r.id as recipe_id,
    r.product_id,
    r.name as recipe_name,
    r.yield_qty,
    sum(
      ri.quantity_base_unit *
      case
        when rm.purchase_pack_base_qty > 0
          then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0
      end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id,r.product_id,r.name,r.yield_qty
)
select
  p.id,
  p.name,
  p.sku,
  pc.name as category_name,
  p.selling_price,
  p.status,
  c.recipe_id,
  c.recipe_name,
  c.yield_qty,
  c.batch_cost,
  case when c.yield_qty>0
    then round(c.batch_cost/c.yield_qty,2)
    else null end as unit_food_cost,
  case when c.yield_qty>0
    then round(p.selling_price-(c.batch_cost/c.yield_qty),2)
    else null end as gross_profit,
  case when p.selling_price>0 and c.yield_qty>0
    then round(((p.selling_price-(c.batch_cost/c.yield_qty))/p.selling_price)*100,2)
    else null end as gross_margin_pct
from public.products p
left join public.product_categories pc on pc.id=p.category_id
left join costs c on c.product_id=p.id;

create or replace view public.inventory_live_summary
with (security_invoker=true)
as
select
  rm.id,
  rm.name,
  rm.sku,
  rm.base_unit,
  rm.current_stock_qty,
  rm.low_stock_threshold,
  rm.current_purchase_cost,
  rm.purchase_pack_base_qty,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    rm.current_stock_qty *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as stock_value,
  (rm.current_stock_qty <= rm.low_stock_threshold) as low,
  rm.status
from public.raw_materials rm
where rm.status='active';

create or replace view public.recipe_cost_detail
with (security_invoker=true)
as
with rc as (
  select
    r.id as recipe_id,
    sum(
      ri.quantity_base_unit *
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id
)
select
  r.id as recipe_id,
  r.product_id,
  p.name as product_name,
  p.selling_price,
  r.name as recipe_name,
  r.yield_qty,
  ri.raw_material_id,
  rm.name as ingredient_name,
  rm.base_unit,
  ri.quantity_base_unit,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    ri.quantity_base_unit *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as line_cost,
  rc.batch_cost,
  round(rc.batch_cost/r.yield_qty,2)::numeric(14,2) as unit_food_cost,
  round(p.selling_price-(rc.batch_cost/r.yield_qty),2)::numeric(14,2) as gross_profit,
  case when p.selling_price>0
    then round(((p.selling_price-(rc.batch_cost/r.yield_qty))/p.selling_price)*100,2)
    else 0 end::numeric(8,2) as margin_pct
from public.recipes r
join public.products p on p.id=r.product_id
join public.recipe_items ri on ri.recipe_id=r.id
join public.raw_materials rm on rm.id=ri.raw_material_id
join rc on rc.recipe_id=r.id
where r.active=true;

-- Audited product save.
create or replace function public.save_product(
  p_product_id uuid,
  p_name text,
  p_category_id uuid,
  p_selling_price numeric,
  p_description text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := coalesce(p_product_id,gen_random_uuid());
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save products';
  end if;

  if coalesce(trim(p_name),'')='' then raise exception 'Product name is required'; end if;
  if p_selling_price<0 then raise exception 'Selling price cannot be negative'; end if;

  select to_jsonb(p) into v_before from public.products p where p.id=p_product_id;

  insert into public.products(
    id,category_id,name,description,selling_price,status,created_by
  )
  values(
    v_id,p_category_id,trim(p_name),p_description,p_selling_price,'active',auth.uid()
  )
  on conflict(id) do update set
    category_id=excluded.category_id,
    name=excluded.name,
    description=excluded.description,
    selling_price=excluded.selling_price,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_product_id is null then 'create_product' else 'update_product' end,
    'product',
    v_id,
    v_before,
    (select to_jsonb(p) from public.products p where p.id=v_id)
  );

  return v_id;
end;
$$;

-- Atomic active recipe replacement.
create or replace function public.save_active_recipe(
  p_product_id uuid,
  p_name text,
  p_yield_qty numeric,
  p_items jsonb
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_recipe_id uuid := gen_random_uuid();
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save recipes';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Recipe name is required'; end if;
  if p_yield_qty<=0 then raise exception 'Recipe yield must be greater than zero'; end if;
  if jsonb_array_length(p_items)=0 then raise exception 'Recipe needs at least one ingredient'; end if;

  -- Validate all ingredients before changing the active recipe.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id := (v_item->>'raw_material_id')::uuid;
    v_qty := (v_item->>'quantity_base_unit')::numeric;

    if v_qty<=0 then raise exception 'Ingredient quantity must be greater than zero'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid or inactive raw material';
    end if;
  end loop;

  update public.recipes
  set active=false,updated_at=now()
  where product_id=p_product_id and active=true;

  insert into public.recipes(id,product_id,name,yield_qty,active,created_by)
  values(v_recipe_id,p_product_id,trim(p_name),p_yield_qty,true,auth.uid());

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.recipe_items(recipe_id,raw_material_id,quantity_base_unit)
    values(
      v_recipe_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'quantity_base_unit')::numeric
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'replace_active_recipe','recipe',v_recipe_id,
    jsonb_build_object('product_id',p_product_id,'yield_qty',p_yield_qty,'items',p_items)
  );

  return v_recipe_id;
end;
$$;

-- Physical stock counts post a movement; they never directly overwrite stock.
create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid := gen_random_uuid();
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta := p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost := case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason
    )
  );

  return v_tx_id;
end;
$$;

-- Cashier shift RPCs. Cashiers may open/close only their own shift.
create or replace function public.start_cashier_shift(p_opening_float numeric default 0)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to start cashier shift';
  end if;
  if p_opening_float<0 then raise exception 'Opening float cannot be negative'; end if;

  if exists(
    select 1 from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
  ) then
    raise exception 'You already have an open cashier shift';
  end if;

  insert into public.cashier_shifts(
    id,cashier_id,opened_by,opening_float,status
  )
  values(v_id,auth.uid(),auth.uid(),p_opening_float,'open');

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'start_cashier_shift','cashier_shift',v_id,
    jsonb_build_object('opening_float',p_opening_float)
  );

  return v_id;
end;
$$;

create or replace function public.close_cashier_shift(
  p_shift_id uuid,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.cashier_shifts%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_shift
  from public.cashier_shifts
  where id=p_shift_id
  for update;

  if not found then raise exception 'Cashier shift not found'; end if;
  if v_shift.status='closed' then raise exception 'Cashier shift already closed'; end if;

  if v_role not in ('owner','manager')
     and not (v_role='cashier' and v_shift.cashier_id=auth.uid()) then
    raise exception 'Not authorized to close this shift';
  end if;

  update public.cashier_shifts
  set status='closed',closed_at=now(),closed_by=auth.uid(),closing_note=p_note
  where id=p_shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_cashier_shift','cashier_shift',p_shift_id,
    jsonb_build_object('note',p_note)
  );
end;
$$;

-- Safer sequential sale number.
create sequence if not exists public.sale_no_seq;

create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(
    now() at time zone (coalesce(
      (select business_timezone from public.business_settings where id=1),
      'UTC'
    )),
    'YYYYMMDD'
  ) || '-' || lpad(nextval('public.sale_no_seq')::text,7,'0')
$$;

alter table public.sales
  add column if not exists client_request_id uuid;

create unique index if not exists sales_client_request_unique
  on public.sales(client_request_id)
  where client_request_id is not null;

create unique index if not exists payments_mobile_reference_unique
  on public.payments(method,reference)
  where reference is not null
    and method in ('mtn_momo','airtel_money')
    and status='completed';

-- Replace old complete_sale signature with idempotent, shift-aware version.
drop function if exists public.complete_sale(jsonb,numeric,jsonb,text,boolean);

create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text;
  v_shift_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.sales
    where client_request_id=p_client_request_id;

    if v_existing is not null then return v_existing; end if;
  end if;

  select id into v_shift_id
  from public.cashier_shifts
  where cashier_id=auth.uid() and status='open'
  order by opened_at desc
  limit 1;

  if v_shift_id is null then
    raise exception 'Open cashier shift required';
  end if;

  if jsonb_array_length(p_items)=0 then
    raise exception 'Sale must contain at least one item';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then raise exception 'Invalid or inactive product'; end if;

    v_qty := (v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Quantity must be greater than zero'; end if;

    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount>v_subtotal then p_discount:=v_subtotal; end if;
  v_total := v_subtotal-p_discount;

  if not p_hold then
    if jsonb_array_length(p_payments)=0 then
      raise exception 'Payment is required';
    end if;

    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;

      if v_method in ('mtn_momo','airtel_money')
         and coalesce(trim(v_payment->>'reference'),'')='' then
        raise exception 'Mobile Money reference is required';
      end if;

      if (v_payment->>'amount')::numeric<=0 then
        raise exception 'Payment amount must be greater than zero';
      end if;

      v_paid := v_paid + (v_payment->>'amount')::numeric;
    end loop;

    -- Payment ledger records actual business receipt, not tender/change.
    if round(v_paid,2) <> round(v_total,2) then
      raise exception 'Payment ledger amount must equal sale total';
    end if;
  end if;

  v_sale_no:=public.next_sale_no();

  insert into public.sales(
    id,sale_no,status,held,subtotal,discount,total,cashier_id,shift_id,notes,client_request_id
  )
  values(
    v_sale_id,v_sale_no,
    case when p_hold then 'held' else 'completed' end,
    p_hold,v_subtotal,p_discount,v_total,auth.uid(),v_shift_id,p_notes,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select
      p.selling_price,
      coalesce((
        select sum(
          ri.quantity_base_unit *
          case when rm.purchase_pack_base_qty>0
            then rm.current_purchase_cost/rm.purchase_pack_base_qty
            else 0 end
        )/r.yield_qty
        from public.recipes r
        join public.recipe_items ri on ri.recipe_id=r.id
        join public.raw_materials rm on rm.id=ri.raw_material_id
        where r.product_id=p.id and r.active=true
        group by r.id,r.yield_qty
      ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(
        sale_id,method,amount,reference,status,created_by
      )
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(trim(v_payment->>'reference'),''),
        'completed',
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    case when p_hold then 'hold_sale' else 'complete_sale' end,
    'sale',
    v_sale_id,
    jsonb_build_object(
      'sale_no',v_sale_no,
      'subtotal',v_subtotal,
      'discount',p_discount,
      'total',v_total,
      'shift_id',v_shift_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_sale_id;
end;
$$;

-- Correct refund cashflow: no negative payment row, preserve original payment method.
create table if not exists public.sale_refunds (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount>0),
  reason text not null,
  approved_by uuid not null references public.profiles(id),
  refunded_at timestamptz not null default now()
);

alter table public.sale_refunds enable row level security;

drop policy if exists "sales staff read sale refunds" on public.sale_refunds;
create policy "sales staff read sale refunds" on public.sale_refunds
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sale_refunds_sale_idx on public.sale_refunds(sale_id,refunded_at desc);

create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
  v_method public.payment_method;
  v_method_count integer;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then raise exception 'Unsupported action'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  v_approver:=public.verify_approver_pin(p_approval_pin);

  select * into v_sale
  from public.sales
  where id=p_sale_id
  for update;

  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status<>'held' then
      raise exception 'Paid/completed sales must be refunded rather than cancelled';
    end if;

    update public.sales
    set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    if v_sale.status not in ('completed','partially_refunded') then
      raise exception 'Only completed sales may be refunded';
    end if;

    v_refund:=coalesce(p_refund_amount,v_sale.total-v_sale.refund_total);
    if v_refund<=0 or v_refund>(v_sale.total-v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    select count(distinct method)
    into v_method_count
    from public.payments
    where sale_id=p_sale_id and status='completed';

    if v_method_count<>1 then
      raise exception 'Mixed-payment refund needs explicit allocation and is not enabled yet';
    end if;

    select method
    into v_method
    from public.payments
    where sale_id=p_sale_id and status='completed'
    limit 1;

    update public.sales
    set
      refund_total=refund_total+v_refund,
      status=case
        when refund_total+v_refund>=total then 'refunded'
        else 'partially_refunded'
      end
    where id=p_sale_id;

    insert into public.sale_refunds(
      sale_id,method,amount,reason,approved_by
    )
    values(
      p_sale_id,v_method,v_refund,p_reason,v_approver
    );
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;


-- Reporting view uses a proportional allocation for partial refunds until item-level
-- refund allocation is implemented. Fully refunded sales contribute zero.
create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  (si.quantity * f.net_factor)::numeric(12,3) as quantity,
  (si.line_total * f.net_factor)::numeric(14,2) as sales_amount,
  ((coalesce(si.unit_cost_snapshot,0) * si.quantity) * f.net_factor) as cogs_amount,
  (
    coalesce(
      si.gross_profit_snapshot,
      si.line_total-(coalesce(si.unit_cost_snapshot,0)*si.quantity)
    ) * f.net_factor
  ) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
cross join lateral (
  select case
    when s.total<=0 then 0::numeric
    else greatest(s.total-coalesce(s.refund_total,0),0)/s.total
  end as net_factor
) f
where s.status in ('completed','partially_refunded','refunded');

-- Cashier shift summary.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,
  cs.cashier_id,
  p.full_name as cashier_name,
  cs.opened_at,
  cs.opening_float,
  cs.status,
  cs.closed_at,
  count(distinct s.id)::bigint as transaction_count,
  coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as gross_sales,
  (
    coalesce(sum(pay.cash_amount),0) -
    coalesce(sum(ref.cash_refund),0)
  )::numeric(14,2) as cash_sales
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id
left join public.sales s
  on s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
left join lateral (
  select coalesce(sum(py.amount),0) as cash_amount
  from public.payments py
  where py.sale_id=s.id and py.status='completed' and py.method='cash'
) pay on true
left join lateral (
  select coalesce(sum(sr.amount),0) as cash_refund
  from public.sale_refunds sr
  where sr.sale_id=s.id and sr.method='cash'
) ref on true
group by cs.id,cs.cashier_id,p.full_name,cs.opened_at,cs.opening_float,cs.status,cs.closed_at;

-- Non-mutating closing preview.
create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_cash_receipts numeric(14,2);
  v_mtn_receipts numeric(14,2);
  v_airtel_receipts numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_total_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)
  into v_cash_receipts,v_mtn_receipts,v_airtel_receipts
  from public.payments p
  where p.status='completed'
    and public.business_date(p.created_at)=p_business_date;

  select
    coalesce(sum(case when sr.method='cash' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='mtn_momo' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='airtel_money' then sr.amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds sr
  where public.business_date(sr.refunded_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(
      case when status in ('completed','partially_refunded','refunded')
        then total-coalesce(refund_total,0) else 0 end
    ),0)
  into v_tx_count,v_total_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_cash_receipts-v_cash_refunds,
    'mtn_momo_sales',v_mtn_receipts-v_mtn_refunds,
    'airtel_money_sales',v_airtel_receipts-v_airtel_refunds,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_cash_receipts-v_cash_refunds)+v_cash_in-v_cash_out-v_cash_exp,
    'transaction_count',v_tx_count,
    'total_sales',v_total_sales
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- Fix two financial SECURITY DEFINER functions that previously lacked internal role checks.
create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  with bounds as (
    select public.period_start(p_period) as start_at
  ),
  sales_summary as (
    select
      coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
      count(*)::bigint as transaction_count
    from public.sales s,bounds b
    where s.created_at>=b.start_at
      and s.status in ('completed','partially_refunded','refunded')
  ),
  payment_summary as (
    select
      (
        coalesce(sum(case when p.method='cash' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='cash' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as cash_sales,
      (
        coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='mtn_momo' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as mtn_momo_sales,
      (
        coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='airtel_money' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as airtel_money_sales
    from public.payments p,bounds b
    where p.created_at>=b.start_at and p.status='completed'
  ),
  profit_summary as (
    select coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
    from public.sale_profit_lines spl,bounds b
    where spl.created_at>=b.start_at
  ),
  expense_summary as (
    select coalesce(sum(amount),0)::numeric(14,2) as expenses
    from public.expenses e,bounds b
    where e.created_at>=b.start_at
  )
  select
    b.start_at,
    ss.sales,
    ps.cash_sales,
    ps.mtn_momo_sales,
    ps.airtel_money_sales,
    prs.gross_profit,
    es.expenses,
    (prs.gross_profit-es.expenses)::numeric(14,2),
    ss.transaction_count,
    case when ss.transaction_count>0
      then round(ss.sales/ss.transaction_count,2)
      else 0 end::numeric(14,2)
  from bounds b
  cross join sales_summary ss
  cross join payment_summary ps
  cross join profit_summary prs
  cross join expense_summary es;
end;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'',''refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

-- Tighten sensitive RPC execution. SECURITY DEFINER functions still perform their own role checks.
revoke all on function public.save_product(uuid,text,uuid,numeric,text) from public;
revoke all on function public.save_active_recipe(uuid,text,numeric,jsonb) from public;
revoke all on function public.record_stock_count(uuid,numeric,text) from public;
revoke all on function public.start_cashier_shift(numeric) from public;
revoke all on function public.close_cashier_shift(uuid,text) from public;
revoke all on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) from public;
revoke all on function public.approve_sale_action(uuid,text,text,text,numeric) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;
revoke all on function public.close_business_day(date,numeric,text) from public;
revoke all on function public.owner_dashboard_summary(text) from public;
revoke all on function public.sales_trend(text) from public;

grant execute on function public.business_current_date() to authenticated;
grant execute on function public.save_product(uuid,text,uuid,numeric,text) to authenticated;
grant execute on function public.save_active_recipe(uuid,text,numeric,jsonb) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text) to authenticated;
grant execute on function public.start_cashier_shift(numeric) to authenticated;
grant execute on function public.close_cashier_shift(uuid,text) to authenticated;
grant execute on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) to authenticated;
grant execute on function public.approve_sale_action(uuid,text,text,text,numeric) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;
grant execute on function public.close_business_day(date,numeric,text) to authenticated;
grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;

-- Business settings are management-only.
alter table public.business_settings enable row level security;

drop policy if exists "management read business settings" on public.business_settings;
create policy "management read business settings" on public.business_settings
for select using (public.current_staff_role() in ('owner','manager'));

drop policy if exists "owner manage business settings" on public.business_settings;
create policy "owner manage business settings" on public.business_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');
