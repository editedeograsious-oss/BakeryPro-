-- DS Bakery v0.19 / Migration 018
-- Operations live wiring: production, baker tasks, waste, purchasing/payables,
-- expenses, cash movements, plus closing cashflow completeness.

-- =====================================================================
-- PRODUCTION + BAKER TASKS
-- =====================================================================

alter table public.production_plan_items
  add column if not exists client_request_id uuid;

create unique index if not exists production_plan_client_request_unique
  on public.production_plan_items(client_request_id)
  where client_request_id is not null;

alter table public.production_runs
  add column if not exists recipe_id uuid references public.recipes(id),
  add column if not exists client_request_id uuid;

create unique index if not exists production_runs_client_request_unique
  on public.production_runs(client_request_id)
  where client_request_id is not null;

create type public.baker_task_status as enum ('todo','complete','cancelled');

create table if not exists public.baker_tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  assigned_baker_id uuid not null references public.profiles(id),
  product_id uuid references public.products(id),
  plan_item_id uuid references public.production_plan_items(id) on delete set null,
  due_at timestamptz,
  status public.baker_task_status not null default 'todo',
  notes text,
  created_by uuid not null references public.profiles(id),
  completed_by uuid references public.profiles(id),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.create_production_plan_item(
  p_business_date date,
  p_product_id uuid,
  p_assigned_baker_id uuid,
  p_shift public.production_shift,
  p_planned_qty numeric,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_existing uuid;
  v_date date := coalesce(p_business_date,public.business_current_date());
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create production plans';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_plan_items
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_planned_qty<=0 then
    raise exception 'Planned quantity must be greater than zero';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;

  if p_assigned_baker_id is not null and not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not an active baker';
  end if;

  insert into public.production_plan_items(
    id,business_date,product_id,assigned_baker_id,shift,
    planned_qty,produced_qty,status,notes,created_by,client_request_id
  )
  values(
    v_id,v_date,p_product_id,p_assigned_baker_id,p_shift,
    p_planned_qty,0,'planned',p_notes,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_production_plan','production_plan_item',v_id,
    jsonb_build_object(
      'business_date',v_date,
      'product_id',p_product_id,
      'assigned_baker_id',p_assigned_baker_id,
      'shift',p_shift,
      'planned_qty',p_planned_qty,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.confirm_production_run(uuid,numeric);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_existing uuid;
  v_item record;
  v_required numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_runs
    where client_request_id=p_client_request_id;

    if v_existing is not null then
      return v_existing;
    end if;
  end if;

  if p_quantity_produced<=0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then raise exception 'Production plan item not found'; end if;
  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id is distinct from auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining:=v_plan.planned_qty-v_plan.produced_qty;
  if p_quantity_produced>v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id and active=true;

  if not found then raise exception 'Product has no active recipe'; end if;

  -- Lock and validate every ingredient before any movement is inserted.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;

    if v_item.current_stock_qty<v_required then
      raise exception 'Insufficient stock for raw material %',v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(
    id,plan_item_id,recipe_id,quantity_produced,confirmed_by,client_request_id
  )
  values(
    v_run_id,p_plan_item_id,v_recipe.id,p_quantity_produced,auth.uid(),p_client_request_id
  );

  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;
    v_unit_cost:=v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,'usage',-v_required,v_unit_cost,
      'production_run',v_run_id,auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced>=planned_qty then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'confirm_production','production_run',v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'recipe_id',v_recipe.id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty>0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=public.business_current_date();

create or replace view public.production_run_summary
with (security_invoker=true)
as
select
  pr.id,
  pr.plan_item_id,
  pr.recipe_id,
  ppi.product_id,
  p.name as product_name,
  pr.quantity_produced,
  pr.confirmed_by,
  prof.full_name as confirmed_by_name,
  pr.confirmed_at
from public.production_runs pr
join public.production_plan_items ppi on ppi.id=pr.plan_item_id
join public.products p on p.id=ppi.product_id
left join public.profiles prof on prof.id=pr.confirmed_by;

create or replace function public.create_baker_task(
  p_title text,
  p_assigned_baker_id uuid,
  p_product_id uuid default null,
  p_plan_item_id uuid default null,
  p_due_at timestamptz default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create baker tasks';
  end if;

  if coalesce(trim(p_title),'')='' then raise exception 'Task title is required'; end if;

  if not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not active';
  end if;

  insert into public.baker_tasks(
    id,title,assigned_baker_id,product_id,plan_item_id,due_at,notes,created_by
  )
  values(
    v_id,trim(p_title),p_assigned_baker_id,p_product_id,p_plan_item_id,p_due_at,p_notes,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_baker_task','baker_task',v_id,
    jsonb_build_object('title',p_title,'assigned_baker_id',p_assigned_baker_id,'due_at',p_due_at)
  );

  return v_id;
end;
$$;

create or replace function public.set_baker_task_status(
  p_task_id uuid,
  p_status public.baker_task_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_task public.baker_tasks%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_task
  from public.baker_tasks
  where id=p_task_id
  for update;

  if not found then raise exception 'Baker task not found'; end if;

  if v_role in ('owner','manager') then
    null;
  elsif v_role='baker' and v_task.assigned_baker_id=auth.uid() and p_status in ('todo','complete') then
    null;
  else
    raise exception 'Not authorized to update this task';
  end if;

  update public.baker_tasks
  set
    status=p_status,
    completed_by=case when p_status='complete' then auth.uid() else null end,
    completed_at=case when p_status='complete' then now() else null end,
    updated_at=now()
  where id=p_task_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_baker_task_status','baker_task',p_task_id,
    jsonb_build_object('status',v_task.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.baker_task_summary
with (security_invoker=true)
as
select
  bt.id,
  bt.title,
  bt.assigned_baker_id,
  bp.full_name as baker_name,
  bt.product_id,
  p.name as product_name,
  bt.plan_item_id,
  bt.due_at,
  bt.status,
  bt.notes,
  bt.completed_at,
  bt.created_at
from public.baker_tasks bt
left join public.profiles bp on bp.id=bt.assigned_baker_id
left join public.products p on p.id=bt.product_id;

alter table public.baker_tasks enable row level security;

create policy "staff read relevant baker tasks" on public.baker_tasks
for select using (
  public.current_staff_role() in ('owner','manager')
  or assigned_baker_id=auth.uid()
);

drop policy if exists "production staff read consumption" on public.production_consumptions;
create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper')
  or (
    public.current_staff_role()='baker'
    and exists(
      select 1
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=production_consumptions.production_run_id
        and (pr.confirmed_by=auth.uid() or ppi.assigned_baker_id=auth.uid())
    )
  )
);

-- =====================================================================
-- WASTE + PRODUCTION CONTROL
-- =====================================================================

alter table public.waste_events
  add column if not exists client_request_id uuid;

create unique index if not exists waste_events_client_request_unique
  on public.waste_events(client_request_id)
  where client_request_id is not null;

drop policy if exists "management read waste settings" on public.waste_settings;
create policy "relevant staff read waste settings" on public.waste_settings
for select using (public.current_staff_role() in ('owner','manager','baker','storekeeper'));

drop function if exists public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid);

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,
  p_quantity numeric,
  p_reason text,
  p_product_id uuid default null,
  p_raw_material_id uuid default null,
  p_production_run_id uuid default null,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_unit_cost numeric(14,6);
  v_total numeric(14,2);
  v_threshold numeric(14,2);
  v_status public.waste_approval_status;
  v_waste_id uuid:=gen_random_uuid();
  v_run_product uuid;
  v_run_qty numeric;
  v_existing_waste numeric;
  v_existing uuid;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing
    from public.waste_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','baker','storekeeper') then
    raise exception 'Not authorized to record waste';
  end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;

  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then
      raise exception 'Finished-product waste requires product only';
    end if;

    if p_production_run_id is not null then
      select ppi.product_id,pr.quantity_produced
      into v_run_product,v_run_qty
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=p_production_run_id;

      if v_run_product is null or v_run_product<>p_product_id then
        raise exception 'Production run does not match product';
      end if;

      select coalesce(sum(quantity),0)
      into v_existing_waste
      from public.waste_events
      where production_run_id=p_production_run_id
        and waste_type='finished_product'
        and approval_status<>'rejected';

      if v_existing_waste+p_quantity>v_run_qty then
        raise exception 'Waste quantity exceeds remaining output of linked production run';
      end if;

      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else
      v_unit_cost:=public.current_product_unit_cost(p_product_id);
    end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then
      raise exception 'Raw-material waste requires raw material only';
    end if;

    select case when purchase_pack_base_qty>0
      then current_purchase_cost/purchase_pack_base_qty else 0 end
    into v_unit_cost
    from public.raw_materials
    where id=p_raw_material_id;

    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;

  v_total:=round((p_quantity*v_unit_cost)::numeric,2);

  select approval_threshold into v_threshold
  from public.waste_settings
  where id=1;

  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then
    v_status:='approved';
  else
    v_status:='pending';
  end if;

  insert into public.waste_events(
    id,waste_type,product_id,raw_material_id,production_run_id,
    quantity,reason,notes,unit_cost_snapshot,total_cost,
    approval_status,recorded_by,approved_by,approved_at,client_request_id
  )
  values(
    v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,
    p_quantity,trim(p_reason),p_notes,v_unit_cost,v_total,
    v_status,auth.uid(),
    case when v_status='approved' then auth.uid() end,
    case when v_status='approved' then now() end,
    p_client_request_id
  );

  if v_status='approved' and p_waste_type='raw_material' then
    perform public.apply_approved_raw_waste(v_waste_id);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_waste','waste_event',v_waste_id,
    jsonb_build_object(
      'waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,
      'total_cost',v_total,'approval_status',v_status,'production_run_id',p_production_run_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_waste_id;
end;
$$;

create or replace view public.waste_event_summary
with (security_invoker=true)
as
select
  we.id,
  we.waste_type,
  we.product_id,
  we.raw_material_id,
  we.production_run_id,
  coalesce(p.name,rm.name) as item_name,
  case when we.waste_type='finished_product' then 'pcs' else rm.base_unit end as base_unit,
  we.quantity,
  we.reason,
  we.notes,
  we.unit_cost_snapshot,
  we.total_cost,
  we.approval_status,
  we.recorded_by,
  prof.full_name as recorded_by_name,
  we.recorded_at,
  we.approved_by,
  we.approved_at,
  we.decision_note
from public.waste_events we
left join public.products p on p.id=we.product_id
left join public.raw_materials rm on rm.id=we.raw_material_id
left join public.profiles prof on prof.id=we.recorded_by;

create or replace view public.production_control_today
with (security_invoker=true)
as
with plan as (
  select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty
  from public.production_plan_items
  where business_date=public.business_current_date()
    and status<>'cancelled'
  group by product_id
),
product_waste as (
  select
    product_id,
    coalesce(sum(quantity),0) approved_waste_qty,
    coalesce(sum(total_cost),0) approved_waste_cost
  from public.waste_events
  where waste_type='finished_product'
    and approval_status='approved'
    and public.business_date(recorded_at)=public.business_current_date()
  group by product_id
)
select
  p.id product_id,
  p.name product_name,
  pl.planned_qty,
  pl.produced_qty,
  coalesce(pw.approved_waste_qty,0) approved_waste_qty,
  greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,
  (pl.produced_qty-pl.planned_qty) production_variance,
  case when pl.produced_qty>0
    then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2)
    else 0 end waste_rate_pct,
  coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl
join public.products p on p.id=pl.product_id
left join product_waste pw on pw.product_id=pl.product_id;

-- =====================================================================
-- PURCHASE ORDERS / RECEIVING / SUPPLIER PAYABLES
-- =====================================================================

alter table public.purchases
  add column if not exists client_request_id uuid;

create unique index if not exists purchases_client_request_unique
  on public.purchases(client_request_id)
  where client_request_id is not null;

alter table public.purchase_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists purchase_payments_client_request_unique
  on public.purchase_payments(client_request_id)
  where client_request_id is not null;

create unique index if not exists purchase_payments_reference_unique
  on public.purchase_payments(lower(method),reference)
  where reference is not null and lower(method)<>'cash';

create table if not exists public.purchase_receipt_events (
  id uuid primary key default gen_random_uuid(),
  purchase_item_id uuid not null references public.purchase_items(id) on delete restrict,
  quantity_received numeric(18,6) not null check (quantity_received>0),
  client_request_id uuid,
  received_by uuid not null references public.profiles(id),
  received_at timestamptz not null default now()
);

create unique index if not exists purchase_receipt_request_unique
  on public.purchase_receipt_events(client_request_id)
  where client_request_id is not null;

create sequence if not exists public.purchase_no_seq;

create or replace function public.next_purchase_no()
returns text
language sql
volatile
as $$
  select 'PO-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.purchase_no_seq')::text,6,'0')
$$;

create or replace function public.create_purchase_order(
  p_supplier_id uuid,
  p_purchase_date date,
  p_supplier_invoice_no text,
  p_invoice_date date,
  p_credit_terms_days integer,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
  v_cost numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to create purchase orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchases
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.suppliers where id=p_supplier_id and active=true) then
    raise exception 'Active supplier not found';
  end if;

  if p_credit_terms_days<0 then raise exception 'Credit terms cannot be negative'; end if;
  if coalesce(p_discount,0)<0 then raise exception 'Discount cannot be negative'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Purchase order needs at least one item';
  end if;

  -- Validate all lines before creating the order.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id:=(v_item->>'raw_material_id')::uuid;
    v_qty:=(v_item->>'ordered_qty_base')::numeric;
    v_cost:=(v_item->>'unit_cost_base')::numeric;

    if v_qty<=0 then raise exception 'Ordered quantity must be greater than zero'; end if;
    if v_cost<0 then raise exception 'Unit cost cannot be negative'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid raw material';
    end if;
  end loop;

  insert into public.purchases(
    id,purchase_no,supplier_id,purchase_date,supplier_reference,
    status,payment_status,subtotal,discount,total_amount,amount_paid,notes,
    created_by,requested_by,approval_status,supplier_invoice_no,invoice_date,
    credit_terms_days,client_request_id
  )
  values(
    v_id,public.next_purchase_no(),p_supplier_id,coalesce(p_purchase_date,public.business_current_date()),null,
    'draft','unpaid',0,coalesce(p_discount,0),0,0,p_notes,
    auth.uid(),auth.uid(),'pending',nullif(trim(p_supplier_invoice_no),''),p_invoice_date,
    p_credit_terms_days,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.purchase_items(
      purchase_id,raw_material_id,ordered_qty_base,received_qty_base,
      unit_cost_base,line_total
    )
    values(
      v_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'ordered_qty_base')::numeric,
      0,
      (v_item->>'unit_cost_base')::numeric,
      ((v_item->>'ordered_qty_base')::numeric*(v_item->>'unit_cost_base')::numeric)
    );
  end loop;

  perform public.refresh_purchase_totals(v_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_purchase_order','purchase',v_id,
    jsonb_build_object(
      'supplier_id',p_supplier_id,
      'items',p_items,
      'discount',coalesce(p_discount,0),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then v_approval:='approved';
  elsif p_decision='reject' then v_approval:='rejected';
  else raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status<>'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  if v_approval='approved' then
    if not exists(select 1 from public.purchase_items where purchase_id=p_purchase_id) then
      raise exception 'Purchase order has no lines';
    end if;
    if v_before.total_amount<=0 then
      raise exception 'Purchase order total must be greater than zero';
    end if;
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

drop function if exists public.receive_purchase_item(uuid,numeric);

create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_purchase public.purchases%rowtype;
  v_remaining numeric;
  v_receipt_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to receive stock';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_receipt_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_receive_qty_base<=0 then raise exception 'Received quantity must be greater than zero'; end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then raise exception 'Purchase item not found'; end if;

  select * into v_purchase
  from public.purchases
  where id=v_item.purchase_id
  for update;

  if v_purchase.approval_status<>'approved' then
    raise exception 'Purchase order must be approved before receiving';
  end if;
  if v_purchase.status not in ('ordered','partially_received') then
    raise exception 'Purchase order is not open for receiving';
  end if;

  v_remaining:=v_item.ordered_qty_base-v_item.received_qty_base;
  if p_receive_qty_base>v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  insert into public.purchase_receipt_events(
    id,purchase_item_id,quantity_received,client_request_id,received_by
  )
  values(
    v_receipt_id,p_purchase_item_id,p_receive_qty_base,p_client_request_id,auth.uid()
  );

  update public.purchase_items
  set received_qty_base=received_qty_base+p_receive_qty_base
  where id=p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase_receipt',v_receipt_id,v_item.id,auth.uid(),'Approved purchase receipt'
  );

  update public.purchases p
  set
    status=case
      when not exists(
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base<pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'receive_stock','purchase_receipt',v_receipt_id,
    jsonb_build_object(
      'purchase_item_id',p_purchase_item_id,
      'quantity_received',p_receive_qty_base,
      'client_request_id',p_client_request_id
    )
  );

  return v_receipt_id;
end;
$$;

drop function if exists public.record_supplier_payment(uuid,numeric,text,text);

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid:=gen_random_uuid();
  v_remaining numeric(14,2);
  v_existing uuid;
  v_method text:=lower(trim(p_method));
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if v_method not in ('cash','bank','mtn_momo','airtel_money') then
    raise exception 'Unsupported supplier payment method';
  end if;
  if v_method<>'cash' and coalesce(trim(p_reference),'')='' then
    raise exception 'Reference is required for non-cash supplier payment';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status<>'approved' then raise exception 'Purchase order is not approved'; end if;

  perform public.refresh_purchase_totals(p_purchase_id);

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  v_remaining:=v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds amount outstanding on purchase'; end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by,shift_id,client_request_id
  )
  values(
    v_payment_id,p_purchase_id,p_amount,v_method,
    nullif(trim(p_reference),''),now(),auth.uid(),p_shift_id,p_client_request_id
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,'amount',p_amount,'method',v_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.trg_refresh_purchase_item_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_items_refresh_totals on public.purchase_items;
create trigger trg_purchase_items_refresh_totals
after insert or update or delete
on public.purchase_items
for each row execute function public.trg_refresh_purchase_item_totals();

create or replace function public.trg_refresh_purchase_payment_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_payments_refresh_totals on public.purchase_payments;
create trigger trg_purchase_payments_refresh_totals
after insert or update or delete
on public.purchase_payments
for each row execute function public.trg_refresh_purchase_payment_totals();

-- Recalculate historical purchase totals after enabling automatic refresh.
do $$
declare r record;
begin
  for r in select id from public.purchases loop
    perform public.refresh_purchase_totals(r.id);
  end loop;
end $$;

drop policy if exists "purchasing staff manage purchases" on public.purchases;
drop policy if exists "purchasing staff manage purchase items" on public.purchase_items;
drop policy if exists "owner manager create purchase payments" on public.purchase_payments;

alter table public.purchase_receipt_events enable row level security;
create policy "purchasing staff read receipts" on public.purchase_receipt_events
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create or replace view public.purchase_order_summary
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.supplier_invoice_no,
  p.invoice_date,
  p.credit_terms_days,
  p.due_date,
  p.status,
  p.payment_status,
  p.approval_status,
  p.subtotal,
  p.discount,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name,
  p.created_at
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by;

create or replace view public.purchase_receiving_lines
with (security_invoker=true)
as
select
  pi.id,
  pi.purchase_id,
  p.purchase_no,
  p.purchase_date,
  p.status,
  p.approval_status,
  p.supplier_id,
  s.name as supplier_name,
  pi.raw_material_id,
  rm.name as material_name,
  rm.base_unit,
  pi.ordered_qty_base,
  pi.received_qty_base,
  (pi.ordered_qty_base-pi.received_qty_base) as remaining_qty_base,
  pi.unit_cost_base,
  pi.line_total
from public.purchase_items pi
join public.purchases p on p.id=pi.purchase_id
join public.suppliers s on s.id=p.supplier_id
join public.raw_materials rm on rm.id=pi.raw_material_id
where p.approval_status='approved'
  and p.status in ('ordered','partially_received');

create or replace view public.supplier_open_payables
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.due_date,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.payment_status
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
where p.approval_status='approved'
  and p.status<>'cancelled'
  and p.total_amount>p.amount_paid;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date<public.business_current_date()
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled' and p.total_amount>p.amount_paid then p.due_date
  end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- =====================================================================
-- EXPENSES + MANUAL CASH MOVEMENTS
-- =====================================================================

alter table public.expenses
  add column if not exists client_request_id uuid;

create unique index if not exists expenses_client_request_unique
  on public.expenses(client_request_id)
  where client_request_id is not null;

alter table public.expenses enable row level security;

drop policy if exists "management read expenses" on public.expenses;
create policy "management read expenses" on public.expenses
for select using (public.current_staff_role() in ('owner','manager'));

create unique index if not exists expenses_mobile_reference_unique
  on public.expenses(payment_method,reference)
  where reference is not null and payment_method in ('mtn_momo','airtel_money');

create or replace function public.record_business_expense(
  p_category text,
  p_description text,
  p_amount numeric,
  p_payment_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record expenses';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.expenses where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_category),'')='' then raise exception 'Expense category is required'; end if;
  if coalesce(trim(p_description),'')='' then raise exception 'Expense description is required'; end if;
  if p_amount<=0 then raise exception 'Expense amount must be greater than zero'; end if;

  if p_payment_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money expense reference is required';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.expenses(
    id,category,description,amount,payment_method,reference,shift_id,created_by,client_request_id
  )
  values(
    v_id,trim(p_category),trim(p_description),p_amount,p_payment_method,
    nullif(trim(p_reference),''),p_shift_id,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_expense','expense',v_id,
    jsonb_build_object(
      'category',p_category,'amount',p_amount,'payment_method',p_payment_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.expense_live_summary
with (security_invoker=true)
as
select
  e.id,
  public.business_date(e.created_at) as business_date,
  e.category,
  e.description,
  e.amount,
  e.payment_method,
  e.reference,
  e.shift_id,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_label,
  e.created_by,
  rp.full_name as recorded_by_name,
  e.created_at
from public.expenses e
left join public.profiles rp on rp.id=e.created_by
left join public.cashier_shifts cs on cs.id=e.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

alter table public.cash_movements
  add column if not exists client_request_id uuid;

create unique index if not exists cash_movements_client_request_unique
  on public.cash_movements(client_request_id)
  where client_request_id is not null;

drop policy if exists "cashier create own cash movement" on public.cash_movements;

create or replace function public.record_cash_movement(
  p_movement_type public.cash_movement_type,
  p_amount numeric,
  p_reason text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing from public.cash_movements where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record cash movements';
  end if;
  if p_amount<=0 then raise exception 'Cash movement amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Cash movement reason is required'; end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc
    limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post movement to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.cash_movements(
    id,shift_id,movement_type,amount,reason,reference,created_by,client_request_id
  )
  values(
    v_id,v_shift_id,p_movement_type,p_amount,trim(p_reason),nullif(trim(p_reference),''),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_cash_movement','cash_movement',v_id,
    jsonb_build_object(
      'movement_type',p_movement_type,'amount',p_amount,'reason',p_reason,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.cash_movement_summary
with (security_invoker=true)
as
select
  cm.id,
  cm.shift_id,
  cm.movement_type,
  cm.amount,
  cm.reason,
  cm.reference,
  cm.created_by,
  rp.full_name as created_by_name,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_cashier_name,
  cm.created_at
from public.cash_movements cm
left join public.profiles rp on rp.id=cm.created_by
left join public.cashier_shifts cs on cs.id=cm.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

-- Stop authenticated staff from bypassing controlled inventory/purchase ledgers with direct inserts.
drop policy if exists "authorized staff create inventory tx" on public.inventory_transactions;


-- Stock-count corrections are also idempotent because a retry must not post the same adjustment twice.
alter table public.inventory_transactions
  add column if not exists client_request_id uuid;

create unique index if not exists inventory_tx_client_request_unique
  on public.inventory_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.record_stock_count(uuid,numeric,text);

create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.inventory_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta:=p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost:=case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by,client_request_id
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason,
      'client_request_id',p_client_request_id
    )
  );

  return v_tx_id;
end;
$$;


-- Direct table-write policies from the prototype are removed for core controlled ledgers.
-- The live pages use audited SECURITY DEFINER RPCs instead.
drop policy if exists "owner manager manage products" on public.products;
drop policy if exists "storekeeper manager owner manage materials" on public.raw_materials;
drop policy if exists "owner manager manage recipes" on public.recipes;
drop policy if exists "owner manager manage recipe items" on public.recipe_items;
drop policy if exists "owner manager manage plan items" on public.production_plan_items;

-- =====================================================================
-- DAILY CLOSING: INCLUDE CUSTOMER ORDER RECEIPTS + SUPPLIER PAYMENTS
-- =====================================================================

alter table public.daily_closings
  add column if not exists cash_order_receipts numeric(14,2) not null default 0,
  add column if not exists mtn_order_receipts numeric(14,2) not null default 0,
  add column if not exists airtel_order_receipts numeric(14,2) not null default 0,
  add column if not exists cash_supplier_payments numeric(14,2) not null default 0,
  add column if not exists mtn_supplier_payments numeric(14,2) not null default 0,
  add column if not exists airtel_supplier_payments numeric(14,2) not null default 0;

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_pos_cash numeric(14,2);
  v_pos_mtn numeric(14,2);
  v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2);
  v_order_mtn numeric(14,2);
  v_order_airtel numeric(14,2);
  v_supplier_cash numeric(14,2);
  v_supplier_mtn numeric(14,2);
  v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_pos_cash,v_pos_mtn,v_pos_airtel
  from public.payments
  where status='completed'
    and public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds
  where public.business_date(refunded_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_cash,v_order_mtn,v_order_airtel
  from public.customer_order_payments
  where payment_status='completed'
    and public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0)
  into v_supplier_cash,v_supplier_mtn,v_supplier_airtel
  from public.purchase_payments
  where public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(case when status in ('completed','partially_refunded','refunded')
      then total-coalesce(refund_total,0) else 0 end),0)
  into v_tx_count,v_pos_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_pos_cash-v_cash_refunds,
    'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,
    'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash,
    'mtn_order_receipts',v_order_mtn,
    'airtel_order_receipts',v_order_airtel,
    'cash_supplier_payments',v_supplier_cash,
    'mtn_supplier_payments',v_supplier_mtn,
    'airtel_supplier_payments',v_supplier_airtel,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',
      v_opening+(v_pos_cash-v_cash_refunds)+v_order_cash+v_cash_in
      -v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,
    'total_sales',v_pos_sales,
    'customer_order_receipts',v_order_cash+v_order_mtn+v_order_airtel
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_order_receipts,mtn_order_receipts,airtel_order_receipts,
    cash_supplier_payments,mtn_supplier_payments,airtel_supplier_payments,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_order_receipts')::numeric,
    (v_s->>'mtn_order_receipts')::numeric,
    (v_s->>'airtel_order_receipts')::numeric,
    (v_s->>'cash_supplier_payments')::numeric,
    (v_s->>'mtn_supplier_payments')::numeric,
    (v_s->>'airtel_supplier_payments')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_order_receipts=excluded.cash_order_receipts,
    mtn_order_receipts=excluded.mtn_order_receipts,
    airtel_order_receipts=excluded.airtel_order_receipts,
    cash_supplier_payments=excluded.cash_supplier_payments,
    mtn_supplier_payments=excluded.mtn_supplier_payments,
    airtel_supplier_payments=excluded.airtel_supplier_payments,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- =====================================================================
-- RLS / EXECUTE HARDENING
-- =====================================================================

revoke all on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) from public;
revoke all on function public.confirm_production_run(uuid,numeric,uuid) from public;
revoke all on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) from public;
revoke all on function public.set_baker_task_status(uuid,public.baker_task_status) from public;
revoke all on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) from public;
revoke all on function public.decide_waste_event(uuid,text,text) from public;
revoke all on function public.apply_approved_raw_waste(uuid) from public;
revoke all on function public.current_product_unit_cost(uuid) from public;
revoke all on function public.production_run_unit_cost(uuid) from public;
revoke all on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) from public;
revoke all on function public.decide_purchase_order(uuid,text,text) from public;
revoke all on function public.receive_purchase_item(uuid,numeric,uuid) from public;
revoke all on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) from public;
revoke all on function public.refresh_purchase_totals(uuid) from public;
revoke all on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) from public;
revoke all on function public.record_stock_count(uuid,numeric,text,uuid) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;

grant execute on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) to authenticated;
grant execute on function public.confirm_production_run(uuid,numeric,uuid) to authenticated;
grant execute on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) to authenticated;
grant execute on function public.set_baker_task_status(uuid,public.baker_task_status) to authenticated;
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
grant execute on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.receive_purchase_item(uuid,numeric,uuid) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text,uuid) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;

create index if not exists baker_tasks_assigned_due_idx
  on public.baker_tasks(assigned_baker_id,status,due_at);

create index if not exists production_runs_recipe_idx
  on public.production_runs(recipe_id,confirmed_at desc);

create index if not exists purchase_receipts_item_idx
  on public.purchase_receipt_events(purchase_item_id,received_at desc);

create index if not exists expenses_created_idx
  on public.expenses(created_at desc);
