-- DS Bakery v0.20 / Migration 019
-- Customer & service live wiring:
-- customers, customer orders/deposits, custom cakes, delivery/riders,
-- loyalty/retention, WhatsApp click-to-chat and shared Mobile Money reference control.

-- =====================================================================
-- SHARED MOBILE MONEY REFERENCE REGISTRY
-- =====================================================================

create table if not exists public.mobile_money_reference_registry (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('mtn_momo','airtel_money')),
  direction text not null check (direction in ('inbound','outbound')),
  reference text not null,
  source_type text not null,
  source_id uuid not null,
  created_at timestamptz not null default now()
);

create unique index if not exists mobile_money_reference_global_unique
  on public.mobile_money_reference_registry(provider,direction,lower(reference));

create unique index if not exists mobile_money_reference_source_unique
  on public.mobile_money_reference_registry(source_type,source_id);

create or replace function public.trg_register_mobile_money_reference()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_provider text;
  v_direction text;
  v_reference text;
begin
  if tg_table_name='payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='customer_order_payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='expenses' then
    v_provider:=new.payment_method::text;
    v_direction:='outbound';
    v_reference:=new.reference;
  elsif tg_table_name='purchase_payments' then
    v_provider:=lower(new.method);
    v_direction:='outbound';
    v_reference:=new.reference;
  else
    return new;
  end if;

  if v_provider not in ('mtn_momo','airtel_money')
     or coalesce(trim(v_reference),'')='' then
    return new;
  end if;

  insert into public.mobile_money_reference_registry(
    provider,direction,reference,source_type,source_id
  )
  values(
    v_provider,v_direction,trim(v_reference),tg_table_name,new.id
  );

  return new;
end;
$$;

drop trigger if exists trg_payments_mobile_registry on public.payments;
create trigger trg_payments_mobile_registry
after insert on public.payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_customer_order_payments_mobile_registry on public.customer_order_payments;
create trigger trg_customer_order_payments_mobile_registry
after insert on public.customer_order_payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_expenses_mobile_registry on public.expenses;
create trigger trg_expenses_mobile_registry
after insert on public.expenses
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_purchase_payments_mobile_registry on public.purchase_payments;
create trigger trg_purchase_payments_mobile_registry
after insert on public.purchase_payments
for each row execute function public.trg_register_mobile_money_reference();

-- Backfill existing references. ON CONFLICT preserves migration progress while a conflict view
-- makes any historical duplicates visible for reconciliation.
insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'payments',id
from public.payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'customer_order_payments',id
from public.customer_order_payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select payment_method::text,'outbound',trim(reference),'expenses',id
from public.expenses
where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select lower(method),'outbound',trim(reference),'purchase_payments',id
from public.purchase_payments
where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

create or replace view public.mobile_money_reference_conflicts
with (security_invoker=true)
as
with refs as (
  select method::text provider,'inbound'::text direction,lower(trim(reference)) reference,'payments' source_table,id
  from public.payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select method::text,'inbound',lower(trim(reference)),'customer_order_payments',id
  from public.customer_order_payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select payment_method::text,'outbound',lower(trim(reference)),'expenses',id
  from public.expenses where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select lower(method),'outbound',lower(trim(reference)),'purchase_payments',id
  from public.purchase_payments where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
)
select provider,direction,reference,count(*)::bigint as occurrence_count,
       string_agg(source_table || ':' || id::text,', ' order by source_table) as sources
from refs
group by provider,direction,reference
having count(*)>1;

alter table public.mobile_money_reference_registry enable row level security;
create policy "management read mobile money registry"
on public.mobile_money_reference_registry
for select using (public.current_staff_role() in ('owner','manager'));


-- Private custom-cake reference bucket when this migration runs inside Supabase.
do $storage$
begin
  if to_regclass('storage.buckets') is not null and to_regclass('storage.objects') is not null then
    execute 'insert into storage.buckets(id,name,public) values (''custom-cake-references'',''custom-cake-references'',false)
             on conflict(id) do update set public=false';

    execute 'drop policy if exists "ds bakery custom cake read" on storage.objects';
    execute 'create policy "ds bakery custom cake read" on storage.objects
             for select using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'',''baker'')
             )';

    execute 'drop policy if exists "ds bakery custom cake upload" on storage.objects';
    execute 'create policy "ds bakery custom cake upload" on storage.objects
             for insert with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake update" on storage.objects';
    execute 'create policy "ds bakery custom cake update" on storage.objects
             for update using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             ) with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake delete" on storage.objects';
    execute 'create policy "ds bakery custom cake delete" on storage.objects
             for delete using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'')
             )';
  end if;
end
$storage$;

-- =====================================================================
-- CUSTOMERS
-- =====================================================================

alter table public.customers
  add column if not exists client_request_id uuid;

create unique index if not exists customers_client_request_unique
  on public.customers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_customer(
  p_customer_id uuid,
  p_full_name text,
  p_phone text,
  p_email text,
  p_address text,
  p_birthday date,
  p_notes text,
  p_whatsapp_opt_in boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_customer_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to save customers';
  end if;
  if coalesce(trim(p_full_name),'')='' then raise exception 'Customer name is required'; end if;

  if p_customer_id is null and p_client_request_id is not null then
    select id into v_existing from public.customers where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(c) into v_before from public.customers c where c.id=p_customer_id;

  insert into public.customers(
    id,full_name,phone,email,address,birthday,notes,active,created_by,
    whatsapp_opt_in,whatsapp_opt_in_at,whatsapp_opt_out_at,client_request_id
  )
  values(
    v_id,trim(p_full_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_address),''),p_birthday,p_notes,true,auth.uid(),
    coalesce(p_whatsapp_opt_in,false),
    case when p_whatsapp_opt_in then now() end,
    null,
    p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,
    phone=excluded.phone,
    email=excluded.email,
    address=excluded.address,
    birthday=excluded.birthday,
    notes=excluded.notes,
    whatsapp_opt_in=excluded.whatsapp_opt_in,
    whatsapp_opt_in_at=case
      when excluded.whatsapp_opt_in and not customers.whatsapp_opt_in then now()
      else customers.whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case
      when not excluded.whatsapp_opt_in and customers.whatsapp_opt_in then now()
      when excluded.whatsapp_opt_in then null
      else customers.whatsapp_opt_out_at end,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_customer_id is null then 'create_customer' else 'update_customer' end,
    'customer',v_id,v_before,
    (select to_jsonb(c) from public.customers c where c.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "sales staff manage customers" on public.customers;

create or replace view public.customer_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) total_order_value,
    coalesce(sum(
      case when co.status<>'cancelled' then
        co.total_amount-coalesce((
          select sum(cop.amount) from public.customer_order_payments cop
          where cop.order_id=co.id and cop.payment_status='completed'
        ),0)
      else 0 end
    ),0)::numeric(14,2) outstanding_balance,
    max(co.created_at) filter (where co.status<>'cancelled') last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  group by c.id
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  coalesce(os.order_count,0) order_count,
  coalesce(os.total_order_value,0)::numeric(14,2) total_order_value,
  coalesce(os.outstanding_balance,0)::numeric(14,2) outstanding_balance,
  os.last_order_at,
  c.address,
  c.birthday,
  c.notes,
  c.whatsapp_opt_in
from public.customers c
left join order_stats os on os.customer_id=c.id
where c.active=true;

-- =====================================================================
-- CUSTOMER ORDERS / DEPOSITS
-- =====================================================================

create sequence if not exists public.customer_order_no_seq;

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.customer_order_no_seq')::text,6,'0')
$$;

alter table public.customer_orders
  add column if not exists client_request_id uuid;

create unique index if not exists customer_orders_client_request_unique
  on public.customer_orders(client_request_id)
  where client_request_id is not null;

alter table public.customer_order_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists customer_order_payments_client_request_unique
  on public.customer_order_payments(client_request_id)
  where client_request_id is not null;

create or replace function public.create_customer_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty numeric;
  v_subtotal numeric(14,2):=0;
  v_discount numeric(14,2):=greatest(coalesce(p_discount,0),0);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create customer orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.customer_orders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Order needs at least one product';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty:=(v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Order quantity must be greater than zero'; end if;

    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if not found then raise exception 'Invalid or inactive product'; end if;
    v_subtotal:=v_subtotal+(v_product.selling_price*v_qty);
  end loop;

  if v_discount>v_subtotal then raise exception 'Discount cannot exceed subtotal'; end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    v_subtotal,v_discount,greatest(v_subtotal-v_discount,0),p_notes,auth.uid(),p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid;

    v_qty:=(v_item->>'quantity')::numeric;

    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(
      v_id,v_product.id,v_product.name,v_qty,v_product.selling_price,
      v_product.selling_price*v_qty,nullif(trim(v_item->>'customization_notes'),'')
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_customer_order','customer_order',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'fulfillment',p_fulfillment,
      'required_at',p_required_at,'subtotal',v_subtotal,'discount',v_discount,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.record_customer_order_payment(uuid,numeric,public.payment_method,text);

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.customer_order_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_method in ('mtn_momo','airtel_money') and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post payment to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_remaining:=v_order.total_amount-v_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds outstanding order balance'; end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,payment_status,recorded_by,paid_at,shift_id,client_request_id
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,nullif(trim(p_reference),''),
    'completed',auth.uid(),now(),v_shift_id,p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,'amount',p_amount,'method',p_method,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

drop function if exists public.update_customer_order_status(uuid,public.customer_order_status);

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
  v_paid numeric(14,2);
  v_valid boolean:=false;
  v_cake_status public.custom_cake_design_status;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;

  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_before.status in ('completed','cancelled') then raise exception 'Order is already closed'; end if;
  if p_status=v_before.status then return; end if;

  if p_status='cancelled' then
    if v_role not in ('owner','manager','cashier') then raise exception 'Baker cannot cancel customer orders'; end if;
    if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;
    select coalesce(sum(amount),0) into v_paid
    from public.customer_order_payments where order_id=p_order_id and payment_status='completed';
    if v_paid>0 then
      raise exception 'Paid orders cannot be cancelled until a customer-order refund workflow is completed';
    end if;
    v_valid:=true;
  elsif v_role='baker' then
    v_valid:=(v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready');
  elsif v_role='cashier' then
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  else
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  end if;

  if not v_valid then raise exception 'Invalid order status transition'; end if;

  if p_status='in_production' and exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    select design_status into v_cake_status from public.custom_cake_specs where order_id=p_order_id;
    if v_cake_status<>'approved' then raise exception 'Custom cake must be approved before production'; end if;
  end if;

  if p_status='completed' and v_before.fulfillment='delivery' then
    raise exception 'Delivery orders are completed through the delivery workflow';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    cancellation_reason=case when p_status='cancelled' then trim(p_reason) else cancellation_reason end,
    updated_at=now()
  where id=p_order_id;

  if exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    update public.custom_cake_specs
    set
      design_status=case
        when p_status='in_production' then 'in_production'::public.custom_cake_design_status
        when p_status='ready' then 'ready'::public.custom_cake_design_status
        when p_status='completed' then 'completed'::public.custom_cake_design_status
        when p_status='cancelled' then 'cancelled'::public.custom_cake_design_status
        else design_status end,
      updated_at=now()
    where order_id=p_order_id;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status,'reason',p_reason)
  );
end;
$$;

drop policy if exists "sales staff manage customer orders" on public.customer_orders;
drop policy if exists "sales staff manage customer order items" on public.customer_order_items;
drop policy if exists "sales staff create customer order payments" on public.customer_order_payments;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
with items as (
  select
    coi.order_id,
    count(*)::bigint item_count,
    string_agg(
      coi.description || ' × ' ||
      trim(to_char(coi.quantity,'FM999999990.###')),
      ', ' order by coi.created_at
    ) item_summary
  from public.customer_order_items coi
  group by coi.order_id
),
paid as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) amount_paid
  from public.customer_order_payments
  where payment_status='completed'
  group by order_id
)
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(pa.amount_paid,0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(pa.amount_paid,0))::numeric(14,2) balance_due,
  co.created_at,
  co.updated_at,
  co.delivery_charge,
  co.subtotal,
  co.discount,
  coalesce(i.item_count,0)::bigint item_count,
  coalesce(i.item_summary,'') item_summary,
  co.notes
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join items i on i.order_id=co.id
left join paid pa on pa.order_id=co.id;

-- Optional customer attachment at POS is performed atomically around the existing sale RPC.
create or replace function public.complete_sale_with_customer(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null,
  p_customer_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid;
  v_existing_customer uuid;
begin
  if p_customer_id is not null and not exists(
    select 1 from public.customers where id=p_customer_id and active=true
  ) then
    raise exception 'Active customer not found';
  end if;

  v_sale_id:=public.complete_sale(
    p_items,p_discount,p_payments,p_notes,p_hold,p_client_request_id
  );

  if p_customer_id is not null then
    select customer_id into v_existing_customer
    from public.sales where id=v_sale_id for update;

    if v_existing_customer is not null and v_existing_customer<>p_customer_id then
      raise exception 'Idempotent sale already belongs to another customer';
    end if;

    update public.sales
    set customer_id=p_customer_id
    where id=v_sale_id and customer_id is null;

    perform public.sync_sale_loyalty_points(v_sale_id);
  end if;

  return v_sale_id;
end;
$$;

-- Cashier-shift reconciliation now includes customer-order cash, expenses,
-- supplier payments and manual cash movements linked to the till.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,cs.cashier_id,p.full_name cashier_name,cs.opened_at,cs.opening_float,
  cs.status,cs.closed_at,

  (select count(*)::bigint
   from public.sales s
   where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ) transaction_count,

  coalesce((
    select sum(s.total-coalesce(s.refund_total,0))
    from public.sales s
    where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ),0)::numeric(14,2) gross_sales,

  (
    coalesce((
      select sum(py.amount)
      from public.payments py
      join public.sales s on s.id=py.sale_id
      where s.shift_id=cs.id and py.status='completed' and py.method='cash'
    ),0)
    -
    coalesce((
      select sum(sr.amount)
      from public.sale_refunds sr
      join public.sales s on s.id=sr.sale_id
      where s.shift_id=cs.id and sr.method='cash'
    ),0)
  )::numeric(14,2) cash_sales,

  coalesce((
    select sum(cop.amount)
    from public.customer_order_payments cop
    where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'
  ),0)::numeric(14,2) order_cash_receipts,

  coalesce((
    select sum(case when cm.movement_type='cash_in' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_in,

  coalesce((
    select sum(case when cm.movement_type='cash_out' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_out,

  coalesce((
    select sum(e.amount)
    from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'
  ),0)::numeric(14,2) cash_expenses,

  coalesce((
    select sum(pp.amount)
    from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'
  ),0)::numeric(14,2) supplier_cash_payments,

  (
    cs.opening_float
    + (
      coalesce((
        select sum(py.amount)
        from public.payments py
        join public.sales s on s.id=py.sale_id
        where s.shift_id=cs.id and py.status='completed' and py.method='cash'
      ),0)
      -
      coalesce((
        select sum(sr.amount)
        from public.sale_refunds sr
        join public.sales s on s.id=sr.sale_id
        where s.shift_id=cs.id and sr.method='cash'
      ),0)
    )
    + coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
    + coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_in'),0)
    - coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_out'),0)
    - coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)
    - coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)
  )::numeric(14,2) expected_cash
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id;

revoke all on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) from public;
grant execute on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) to authenticated;

-- =====================================================================
-- CUSTOM CAKES
-- =====================================================================

alter table public.custom_cake_specs
  add column if not exists order_item_id uuid references public.customer_order_items(id),
  add column if not exists client_request_id uuid;

create unique index if not exists custom_cake_client_request_unique
  on public.custom_cake_specs(client_request_id)
  where client_request_id is not null;

create table if not exists public.custom_cake_settings (
  id integer primary key default 1 check(id=1),
  deposit_percent numeric(5,2) not null default 50 check(deposit_percent>0 and deposit_percent<=100),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.custom_cake_settings(id,deposit_percent)
values(1,50)
on conflict(id) do nothing;

-- Backfill an order item for earlier custom-cake rows so refresh_customer_order_total remains authoritative.
do $$
declare
  r record;
  v_item_id uuid;
begin
  for r in
    select ccs.id,ccs.order_id,ccs.quote_amount
    from public.custom_cake_specs ccs
    where ccs.order_item_id is null
  loop
    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(r.order_id,null,'Custom Cake',1,r.quote_amount,r.quote_amount,'Custom cake specification')
    returning id into v_item_id;

    update public.custom_cake_specs set order_item_id=v_item_id where id=r.id;
    perform public.refresh_customer_order_total(r.order_id);
  end loop;
end $$;

create or replace function public.create_custom_cake_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_cake_size_label text,
  p_servings integer,
  p_tiers integer,
  p_flavour text,
  p_filling text,
  p_frosting text,
  p_theme text,
  p_primary_color text,
  p_secondary_color text,
  p_inscription text,
  p_special_instructions text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order_id uuid:=gen_random_uuid();
  v_spec_id uuid:=gen_random_uuid();
  v_item_id uuid;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create custom cake orders';
  end if;

  if p_client_request_id is not null then
    select order_id into v_existing
    from public.custom_cake_specs
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if coalesce(p_tiers,1)<=0 then raise exception 'Tiers must be greater than zero'; end if;
  if p_servings is not null and p_servings<=0 then raise exception 'Servings must be greater than zero'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_order_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    0,0,0,'Custom cake order',auth.uid(),p_client_request_id
  );

  insert into public.customer_order_items(
    order_id,product_id,description,quantity,unit_price,line_total,customization_notes
  )
  values(
    v_order_id,null,'Custom Cake',1,0,0,'Custom cake specification'
  )
  returning id into v_item_id;

  insert into public.custom_cake_specs(
    id,order_id,order_item_id,cake_size_label,servings,tiers,flavour,filling,frosting,
    theme,primary_color,secondary_color,inscription,special_instructions,quote_amount,
    design_status,created_by,client_request_id
  )
  values(
    v_spec_id,v_order_id,v_item_id,nullif(trim(p_cake_size_label),''),p_servings,coalesce(p_tiers,1),
    nullif(trim(p_flavour),''),nullif(trim(p_filling),''),nullif(trim(p_frosting),''),
    nullif(trim(p_theme),''),nullif(trim(p_primary_color),''),nullif(trim(p_secondary_color),''),
    nullif(trim(p_inscription),''),p_special_instructions,0,'draft',auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_custom_cake','custom_cake_spec',v_spec_id,
    jsonb_build_object('order_id',v_order_id,'customer_id',p_customer_id,'required_at',p_required_at)
  );

  return v_order_id;
end;
$$;

create or replace function public.save_custom_cake_reference_path(
  p_order_id uuid,
  p_reference_image_path text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_before text;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update custom cake reference image';
  end if;
  if coalesce(trim(p_reference_image_path),'')='' then raise exception 'Reference image path is required'; end if;

  select reference_image_path into v_before
  from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake not found'; end if;

  update public.custom_cake_specs
  set reference_image_path=trim(p_reference_image_path),updated_at=now()
  where order_id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_custom_cake_reference','customer_order',p_order_id,
    jsonb_build_object('reference_image_path',v_before),
    jsonb_build_object('reference_image_path',p_reference_image_path)
  );
end;
$$;

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;
  if p_quote_amount<=0 then raise exception 'Quote amount must be greater than zero'; end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(p_quote_amount-v_order.discount,0)+v_order.delivery_charge;
  if v_new_total<v_paid then raise exception 'Quote would reduce order total below payments already recorded'; end if;

  update public.customer_order_items
  set unit_price=p_quote_amount,line_total=p_quote_amount
  where id=v_spec.order_item_id;

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status end,
    updated_at=now()
  where order_id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
  v_pct numeric(5,2);
  v_required numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount<=0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  select deposit_percent into v_pct from public.custom_cake_settings where id=1;
  v_required:=round(v_spec.quote_amount*coalesce(v_pct,50)/100,2);

  if v_paid<v_required then
    raise exception 'Required deposit has not been reached';
  end if;

  update public.custom_cake_specs
  set design_status='approved',production_approved_by=auth.uid(),
      production_approved_at=now(),updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set status='confirmed',updated_at=now()
  where id=p_order_id and status='pending';

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid,'deposit_required',v_required
    )
  );
end;
$$;

drop policy if exists "sales staff create custom cakes" on public.custom_cake_specs;
drop policy if exists "sales staff update custom cakes" on public.custom_cake_specs;

alter table public.custom_cake_settings enable row level security;
create policy "relevant staff read custom cake settings"
on public.custom_cake_settings
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0))::numeric(14,2) balance_due,
  ccs.design_status,
  co.status order_status,
  round(ccs.quote_amount*cs.deposit_percent/100,2)::numeric(14,2) deposit_required
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
cross join public.custom_cake_settings cs
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,co.required_at,
  co.fulfillment,co.delivery_address,ccs.cake_size_label,ccs.servings,ccs.tiers,
  ccs.flavour,ccs.filling,ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,ccs.production_notes,
  ccs.quote_amount,cs.deposit_percent,ccs.design_status,co.status,co.total_amount;

-- =====================================================================
-- DELIVERY / RIDERS
-- =====================================================================

alter table public.delivery_riders
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_riders_client_request_unique
  on public.delivery_riders(client_request_id)
  where client_request_id is not null;

alter table public.delivery_jobs
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_jobs_client_request_unique
  on public.delivery_jobs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_delivery_rider(
  p_rider_id uuid,
  p_full_name text,
  p_phone text,
  p_vehicle_label text,
  p_active boolean,
  p_notes text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_rider_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage riders';
  end if;
  if coalesce(trim(p_full_name),'')='' or coalesce(trim(p_phone),'')='' then
    raise exception 'Rider name and phone are required';
  end if;

  if p_rider_id is null and p_client_request_id is not null then
    select id into v_existing from public.delivery_riders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(r) into v_before from public.delivery_riders r where r.id=p_rider_id;

  insert into public.delivery_riders(
    id,full_name,phone,vehicle_label,active,notes,created_by,client_request_id
  )
  values(
    v_id,trim(p_full_name),trim(p_phone),nullif(trim(p_vehicle_label),''),
    coalesce(p_active,true),p_notes,auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,phone=excluded.phone,vehicle_label=excluded.vehicle_label,
    active=excluded.active,notes=excluded.notes,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_rider_id is null then 'create_delivery_rider' else 'update_delivery_rider' end,
    'delivery_rider',v_id,v_before,
    (select to_jsonb(r) from public.delivery_riders r where r.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.create_delivery_job(uuid,numeric,text,timestamptz);

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.delivery_jobs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_delivery_charge<0 then raise exception 'Delivery charge cannot be negative'; end if;
  if coalesce(trim(p_address),'')='' then raise exception 'Delivery address is required'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment<>'delivery' then raise exception 'Order is not marked for delivery'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot create delivery for cancelled order'; end if;
  if exists(select 1 from public.delivery_jobs where order_id=p_order_id) then
    raise exception 'Delivery job already exists for this order';
  end if;

  select * into v_customer from public.customers where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;
  if v_new_total<v_paid then raise exception 'New order total would be less than payments already recorded'; end if;

  update public.customer_orders
  set delivery_charge=p_delivery_charge,delivery_address=trim(p_address),updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,delivery_address_snapshot,
    customer_name_snapshot,customer_phone_snapshot,delivery_charge,created_by,client_request_id
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    trim(p_address),v_customer.full_name,v_customer.phone,p_delivery_charge,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job from public.delivery_jobs where id=p_delivery_id for update;
  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order from public.customer_orders where id=v_job.order_id for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then raise exception 'Delivery must be assigned or failed before dispatch'; end if;
    if v_job.rider_id is null then raise exception 'Assign a rider before dispatch'; end if;
    if v_order.status<>'ready' then raise exception 'Customer order must be ready before dispatch'; end if;

    update public.delivery_jobs
    set status='out_for_delivery',dispatched_by=auth.uid(),dispatched_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may be completed'; end if;

    update public.delivery_jobs
    set status='delivered',delivered_by=auth.uid(),delivered_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set status='completed',completed_at=now(),updated_at=now()
    where id=v_job.order_id;

    update public.custom_cake_specs
    set design_status='completed',updated_at=now()
    where order_id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may fail'; end if;
    if coalesce(trim(p_note),'')='' then raise exception 'Failure reason is required'; end if;

    update public.delivery_jobs
    set status='failed',failed_at=now(),outcome_note=trim(p_note),updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then raise exception 'Delivered job cannot be cancelled'; end if;

    update public.delivery_jobs
    set status='cancelled',outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;
  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

drop policy if exists "owner manager manage riders" on public.delivery_riders;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id rider_id,dr.full_name,dr.phone,dr.vehicle_label,dr.active,
  count(dj.id) filter(where dj.status in ('assigned','out_for_delivery'))::bigint active_jobs,
  count(dj.id) filter(
    where dj.status='delivered' and public.business_date(dj.delivered_at)=public.business_current_date()
  )::bigint delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

-- =====================================================================
-- LOYALTY / RETENTION
-- =====================================================================

alter table public.loyalty_point_transactions
  add column if not exists value_amount numeric(14,2) not null default 0,
  add column if not exists client_request_id uuid;

create unique index if not exists loyalty_client_request_unique
  on public.loyalty_point_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.redeem_loyalty_on_order(uuid,integer);

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer,
  p_client_request_id uuid default null
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
  v_existing numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  if p_client_request_id is not null then
    select value_amount into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id and event_type='reward_redemption';
    if v_existing is not null then return v_existing; end if;
  end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then raise exception 'Cannot redeem on a closed order'; end if;

  perform 1 from public.customers where id=v_order.customer_id for update;

  select points_balance into v_balance
  from public.customer_loyalty_balances where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings where id=1;

  if p_points<=0 or mod(p_points,v_reward_points)<>0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points>v_balance then raise exception 'Insufficient loyalty points'; end if;

  v_units:=p_points/v_reward_points;
  v_discount:=v_units*v_reward_value;

  if v_discount>greatest(v_order.subtotal-v_order.discount,0) then
    raise exception 'Reward discount exceeds remaining merchandise value';
  end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0)<v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,value_amount,source_type,source_id,
    reason,created_by,client_request_id
  )
  values(
    v_order.customer_id,'reward_redemption',-p_points,v_discount,
    'customer_order',p_order_id,'Loyalty reward applied to customer order',
    auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount,'client_request_id',p_client_request_id)
  );

  return v_discount;
end;
$$;

drop function if exists public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type);

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment',
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  perform 1 from public.customers where id=p_customer_id for update;
  if not found then raise exception 'Customer not found'; end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if coalesce(v_balance,0)+p_points<0 then
    raise exception 'Adjustment would make points negative';
  end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,value_amount,source_type,
    reason,created_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,0,'manual',
    trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'points_delta',p_points,
      'reason',p_reason,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_loyalty_settings(
  p_earn_amount_per_point numeric,
  p_reward_points integer,
  p_reward_value numeric,
  p_birthday_reminder_days integer,
  p_vip_spend_threshold numeric,
  p_regular_spend_threshold numeric,
  p_regular_order_threshold integer
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update loyalty settings';
  end if;

  if p_earn_amount_per_point<=0 or p_reward_points<=0 or p_reward_value<0 then
    raise exception 'Invalid loyalty earning/reward settings';
  end if;
  if p_birthday_reminder_days<1 or p_birthday_reminder_days>90 then
    raise exception 'Birthday reminder days must be 1 to 90';
  end if;

  update public.loyalty_settings
  set
    earn_amount_per_point=p_earn_amount_per_point,
    reward_points=p_reward_points,
    reward_value=p_reward_value,
    birthday_reminder_days=p_birthday_reminder_days,
    vip_spend_threshold=p_vip_spend_threshold,
    regular_spend_threshold=p_regular_spend_threshold,
    regular_order_threshold=p_regular_order_threshold,
    updated_by=auth.uid(),updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'update_loyalty_settings','loyalty_settings',null,
    jsonb_build_object(
      'earn_amount_per_point',p_earn_amount_per_point,'reward_points',p_reward_points,
      'reward_value',p_reward_value,'birthday_reminder_days',p_birthday_reminder_days
    )
  );
end;
$$;

drop policy if exists "owner manage loyalty settings" on public.loyalty_settings;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id customer_id,c.full_name,c.phone,c.birthday,b.next_birthday,
  (b.next_birthday-public.business_current_date()) days_until_birthday,
  coalesce(lb.points_balance,0) points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date next_birthday
  from generate_series(
    public.business_current_date(),
    public.business_current_date()+interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d limit 1
) b
where c.active=true and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter(where co.status<>'cancelled')::bigint customer_order_count,
    coalesce(sum(co.total_amount) filter(where co.status<>'cancelled'),0)::numeric(14,2) customer_order_value,
    max(co.created_at) filter(where co.status<>'cancelled') last_customer_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
pos_stats as (
  select
    c.id customer_id,
    count(s.id) filter(where s.status in ('completed','partially_refunded','refunded'))::bigint pos_sale_count,
    coalesce(sum(
      case when s.status in ('completed','partially_refunded','refunded')
        then greatest(s.total-coalesce(s.refund_total,0),0) else 0 end
    ),0)::numeric(14,2) pos_sale_value,
    max(s.created_at) filter(where s.status in ('completed','partially_refunded','refunded')) last_pos_sale_at
  from public.customers c
  left join public.sales s on s.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (select * from public.loyalty_settings where id=1)
select
  c.id customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))::bigint order_count,
  (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))::numeric(14,2) lifetime_value,
  greatest(os.last_customer_order_at,ps.last_pos_sale_at) last_order_at,
  coalesce(lb.points_balance,0) points_balance,
  case
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.vip_spend_threshold then 'VIP'
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.regular_spend_threshold
      or (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=s.regular_order_threshold then 'Regular'
    when (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=2 then 'Returning'
    else 'New' end customer_segment,
  coalesce(os.customer_order_count,0)::bigint customer_order_count,
  coalesce(ps.pos_sale_count,0)::bigint pos_sale_count
from public.customers c
join order_stats os on os.customer_id=c.id
join pos_stats ps on ps.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

-- =====================================================================
-- WHATSAPP COMMUNICATION / TEMPLATES
-- =====================================================================

alter table public.communication_templates
  add column if not exists client_request_id uuid;

create unique index if not exists communication_templates_client_request_unique
  on public.communication_templates(client_request_id)
  where client_request_id is not null;

alter table public.communication_logs
  add column if not exists client_request_id uuid;

create unique index if not exists communication_logs_client_request_unique
  on public.communication_logs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_communication_template(
  p_template_id uuid,
  p_name text,
  p_template_type public.communication_template_type,
  p_body_template text,
  p_requires_marketing_opt_in boolean,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_template_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage communication templates';
  end if;
  if coalesce(trim(p_name),'')='' or coalesce(trim(p_body_template),'')='' then
    raise exception 'Template name and body are required';
  end if;

  if p_template_id is null and p_client_request_id is not null then
    select id into v_existing from public.communication_templates where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(t) into v_before from public.communication_templates t where t.id=p_template_id;

  insert into public.communication_templates(
    id,name,template_type,body_template,requires_marketing_opt_in,active,created_by,client_request_id
  )
  values(
    v_id,trim(p_name),p_template_type,trim(p_body_template),
    coalesce(p_requires_marketing_opt_in,false),coalesce(p_active,true),auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,template_type=excluded.template_type,body_template=excluded.body_template,
    requires_marketing_opt_in=excluded.requires_marketing_opt_in,active=excluded.active,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_template_id is null then 'create_communication_template' else 'update_communication_template' end,
    'communication_template',v_id,v_before,
    (select to_jsonb(t) from public.communication_templates t where t.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.log_whatsapp_open(uuid,uuid,uuid,text,text);

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.communication_logs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then raise exception 'Recipient phone is required'; end if;
  if coalesce(trim(p_message),'')='' then raise exception 'Message is required'; end if;

  select * into v_customer from public.customers where id=p_customer_id;
  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template from public.communication_templates
    where id=p_template_id and active=true;
    if not found then raise exception 'Active communication template not found'; end if;
    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,channel,status,
    recipient_phone_snapshot,message_snapshot,initiated_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'whatsapp','opened_whatsapp',
    trim(p_recipient_phone),p_message,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'order_id',p_order_id,
      'template_id',p_template_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager manage communication templates" on public.communication_templates;

create or replace view public.communication_log_summary
with (security_invoker=true)
as
select
  cl.id,cl.customer_id,c.full_name customer_name,cl.order_id,co.order_no,
  cl.template_id,ct.name template_name,ct.template_type,
  cl.status,cl.recipient_phone_snapshot,cl.message_snapshot,
  cl.initiated_by,p.full_name initiated_by_name,cl.initiated_at
from public.communication_logs cl
join public.customers c on c.id=cl.customer_id
left join public.customer_orders co on co.id=cl.order_id
left join public.communication_templates ct on ct.id=cl.template_id
left join public.profiles p on p.id=cl.initiated_by;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text queue_type,100 priority,co.customer_id,c.full_name customer_name,
  c.phone,c.whatsapp_opt_in,co.id order_id,co.order_no,co.required_at due_at,
  cos.balance_due,'Order is ready for pickup'::text reason,null::text rider_name
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready' and co.fulfillment='pickup'

union all
select
  'in_production',95,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,'Order is in production',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='in_production'

union all
select
  'out_for_delivery',90,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,dj.scheduled_for,cos.balance_due,'Order is out for delivery',dr.full_name
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
left join public.delivery_riders dr on dr.id=dj.rider_id
where dj.status='out_for_delivery'

union all
select
  'birthday',50,b.customer_id,b.full_name,b.phone,c.whatsapp_opt_in,
  null::uuid,null::text,b.next_birthday::timestamptz,0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days',null::text
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all
select
  'balance_reminder',40,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,
  'Customer order has outstanding balance',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0 and co.status<>'cancelled';

-- =====================================================================
-- EXECUTE / DIRECT-WRITE HARDENING
-- =====================================================================

revoke all on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) from public;
revoke all on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) from public;
revoke all on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.update_customer_order_status(uuid,public.customer_order_status,text) from public;
revoke all on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) from public;
revoke all on function public.save_custom_cake_reference_path(uuid,text) from public;
revoke all on function public.quote_custom_cake_order(uuid,numeric,text) from public;
revoke all on function public.approve_custom_cake_for_production(uuid) from public;
revoke all on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) from public;
revoke all on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) from public;
revoke all on function public.assign_delivery_rider(uuid,uuid) from public;
revoke all on function public.update_delivery_status(uuid,public.delivery_status,text) from public;
revoke all on function public.redeem_loyalty_on_order(uuid,integer,uuid) from public;
revoke all on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) from public;
revoke all on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) from public;
revoke all on function public.set_customer_whatsapp_preference(uuid,boolean) from public;
revoke all on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) from public;
revoke all on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) from public;

grant execute on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) to authenticated;
grant execute on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.update_customer_order_status(uuid,public.customer_order_status,text) to authenticated;
grant execute on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) to authenticated;
grant execute on function public.save_custom_cake_reference_path(uuid,text) to authenticated;
grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;
grant execute on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) to authenticated;
grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;
grant execute on function public.redeem_loyalty_on_order(uuid,integer,uuid) to authenticated;
grant execute on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) to authenticated;
grant execute on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) to authenticated;
grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) to authenticated;

create index if not exists customer_order_payments_shift_idx
  on public.customer_order_payments(shift_id,paid_at desc);

create index if not exists custom_cake_order_item_idx
  on public.custom_cake_specs(order_item_id);

create index if not exists communication_logs_customer_created_idx
  on public.communication_logs(customer_id,initiated_at desc);
