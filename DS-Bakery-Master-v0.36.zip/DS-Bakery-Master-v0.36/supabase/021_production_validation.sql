-- DS Bakery v0.22 / Migration 021
-- Production validation and launch-readiness diagnostics.
-- This migration is intentionally read-mostly: it adds release metadata and
-- owner-visible integrity checks without changing normal business workflows.

create table if not exists public.system_release_state (
  id integer primary key default 1 check(id=1),
  app_version text not null,
  latest_migration integer not null,
  release_stage text not null,
  updated_at timestamptz not null default now()
);

insert into public.system_release_state(id,app_version,latest_migration,release_stage)
values(1,'0.22.0',21,'production_validation')
on conflict(id) do update set
  app_version=excluded.app_version,
  latest_migration=excluded.latest_migration,
  release_stage=excluded.release_stage,
  updated_at=now();

alter table public.system_release_state enable row level security;

drop policy if exists "active staff read release state" on public.system_release_state;
create policy "active staff read release state"
on public.system_release_state
for select using(public.is_active_staff());

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  -- Exactly one or more active owners must exist.
  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1
      then v_owner_count::text || ' active owner account(s)'
      else 'No active owner account exists' end;

  -- Business timezone must be set to a real IANA timezone.
  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  -- Each active product may have at most one active recipe.
  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  -- No negative raw-material stock.
  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  -- Purchase totals should match lines, discount and recorded payments.
  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  -- Customer-order net paid cannot be negative or materially over total.
  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  -- Waste linked to a production run should never exceed run output.
  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  -- Duplicate Mobile Money references from legacy history must be reviewed.
  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  -- Long-open till shifts are a warning, not an automatic failure.
  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  -- Scheduled work shifts left behind in the past are operational cleanup warnings.
  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  -- Storage bucket should exist and remain private when Supabase Storage is installed.
  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  -- Release metadata.
  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.22.0' and latest_migration=21
    ) then 'pass' else 'fail' end,
    'Expected app version 0.22.0 / migration 021';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.22.0',
    'latest_migration',21,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;



-- =====================================================================
-- FINAL STATIC-PAGE CLOSURE: SUPPLIERS + STOCK MOVEMENT LEDGER
-- =====================================================================

alter table public.suppliers
  add column if not exists client_request_id uuid;

create unique index if not exists suppliers_client_request_unique
  on public.suppliers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_supplier(
  p_supplier_id uuid,
  p_name text,
  p_phone text,
  p_email text,
  p_notes text,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_supplier_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to manage suppliers';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Supplier name is required'; end if;

  if p_supplier_id is null and p_client_request_id is not null then
    select id into v_existing
    from public.suppliers
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(s) into v_before
  from public.suppliers s
  where s.id=p_supplier_id;

  insert into public.suppliers(
    id,name,phone,email,notes,active,client_request_id
  )
  values(
    v_id,trim(p_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_notes),''),coalesce(p_active,true),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,
    phone=excluded.phone,
    email=excluded.email,
    notes=excluded.notes,
    active=excluded.active,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_supplier_id is null then 'create_supplier' else 'update_supplier' end,
    'supplier',v_id,v_before,
    (select to_jsonb(s) from public.suppliers s where s.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager storekeeper manage suppliers" on public.suppliers;

create or replace view public.inventory_movement_summary
with (security_invoker=true)
as
select
  it.id,it.created_at,it.raw_material_id,rm.name material_name,rm.base_unit,
  it.tx_type,it.quantity_delta,it.unit_cost,it.reference_type,it.reference_id,
  it.notes,it.created_by,p.full_name recorded_by_name,p.role recorded_by_role
from public.inventory_transactions it
join public.raw_materials rm on rm.id=it.raw_material_id
left join public.profiles p on p.id=it.created_by;

revoke all on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) from public;
grant execute on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) to authenticated;

revoke all on function public.launch_readiness_checks() from public;
revoke all on function public.launch_readiness_summary() from public;
grant execute on function public.launch_readiness_checks() to authenticated;
grant execute on function public.launch_readiness_summary() to authenticated;
