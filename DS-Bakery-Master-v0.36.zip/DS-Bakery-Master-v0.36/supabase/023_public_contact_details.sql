-- DS Bakery v0.24 / Migration 023
-- Public contact/location and TikTok details.

alter table public.public_site_settings
  add column if not exists secondary_phone text,
  add column if not exists tiktok_handle text;

update public.public_site_settings
set
  phone='0708743663',
  secondary_phone='0760547003',
  whatsapp_phone='0760547003',
  email='dscakes3@gmail.com',
  address_text='Kiwafu Lugonjo',
  tiktok_handle='Ds bakery',
  updated_at=now()
where id=1;

create or replace function public.public_site_info()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'business_name',business_name,
    'tagline',tagline,
    'hero_message',hero_message,
    'phone',phone,
    'secondary_phone',secondary_phone,
    'whatsapp_phone',whatsapp_phone,
    'email',email,
    'address_text',address_text,
    'opening_hours',opening_hours,
    'tiktok_handle',tiktok_handle,
    'custom_cake_enabled',custom_cake_enabled,
    'delivery_enabled',delivery_enabled
  )
  from public.public_site_settings
  where id=1
$$;

drop function if exists public.update_public_site_settings(
  text,text,text,text,text,text,text,text,boolean,boolean
);

create or replace function public.update_public_site_settings(
  p_business_name text,
  p_tagline text,
  p_hero_message text,
  p_phone text,
  p_secondary_phone text,
  p_whatsapp_phone text,
  p_email text,
  p_address_text text,
  p_opening_hours text,
  p_tiktok_handle text,
  p_custom_cake_enabled boolean,
  p_delivery_enabled boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may update public website settings';
  end if;

  if coalesce(trim(p_business_name),'')='' then
    raise exception 'Business name is required';
  end if;

  select to_jsonb(s) into v_before
  from public.public_site_settings s
  where id=1;

  update public.public_site_settings
  set
    business_name=trim(p_business_name),
    tagline=coalesce(nullif(trim(p_tagline),''),'Fresh bakery products for every occasion'),
    hero_message=nullif(trim(p_hero_message),''),
    phone=nullif(trim(p_phone),''),
    secondary_phone=nullif(trim(p_secondary_phone),''),
    whatsapp_phone=nullif(trim(p_whatsapp_phone),''),
    email=nullif(trim(p_email),''),
    address_text=nullif(trim(p_address_text),''),
    opening_hours=nullif(trim(p_opening_hours),''),
    tiktok_handle=nullif(trim(p_tiktok_handle),''),
    custom_cake_enabled=coalesce(p_custom_cake_enabled,true),
    delivery_enabled=coalesce(p_delivery_enabled,true),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_public_site_settings','public_site_settings',null,
    v_before,(select to_jsonb(s) from public.public_site_settings s where id=1)
  );
end;
$$;

revoke all on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) from public;

grant execute on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) to authenticated;

update public.system_release_state
set app_version='0.24.0',
    latest_migration=23,
    release_stage='public_contact_details',
    updated_at=now()
where id=1;


-- Refresh launch-readiness release expectations for v0.24.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.24.0' and latest_migration=23
    ) then 'pass' else 'fail' end,
    'Expected app version 0.24.0 / migration 023';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.24.0',
    'latest_migration',23,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
