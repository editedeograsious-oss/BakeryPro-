-- DS Bakery v0.25 / Migration 024
-- Staging validation evidence, repeatable release checks and release-state update.

create table if not exists public.validation_runs (
  id uuid primary key default gen_random_uuid(),
  environment text not null check(environment in ('staging','production')),
  app_version text not null,
  latest_migration integer not null,
  started_by uuid not null references public.profiles(id),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  overall_status text not null default 'pending'
    check(overall_status in ('pending','pass','warn','fail')),
  notes text
);

create table if not exists public.validation_check_results (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.validation_runs(id) on delete cascade,
  check_key text not null,
  area text not null,
  status text not null check(status in ('pending','pass','warn','fail')),
  detail text,
  evidence text,
  checked_by uuid references public.profiles(id),
  checked_at timestamptz not null default now(),
  unique(run_id,check_key)
);

alter table public.validation_runs enable row level security;
alter table public.validation_check_results enable row level security;

drop policy if exists "management read validation runs" on public.validation_runs;
create policy "management read validation runs"
on public.validation_runs
for select using(public.current_staff_role() in ('owner','manager'));

drop policy if exists "management read validation results" on public.validation_check_results;
create policy "management read validation results"
on public.validation_check_results
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.begin_validation_run(
  p_environment text default 'staging',
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may start a validation run';
  end if;
  if p_environment not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  insert into public.validation_runs(
    id,environment,app_version,latest_migration,started_by,notes
  )
  values(
    v_id,p_environment,'0.25.0',24,auth.uid(),nullif(trim(p_notes),'')
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'begin_validation_run','validation_run',v_id,
    jsonb_build_object('environment',p_environment,'app_version','0.25.0','latest_migration',24)
  );

  return v_id;
end;
$$;

create or replace function public.record_validation_check(
  p_run_id uuid,
  p_check_key text,
  p_area text,
  p_status text,
  p_detail text default null,
  p_evidence text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid;
  v_run public.validation_runs%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record validation evidence';
  end if;
  if coalesce(trim(p_check_key),'')='' or coalesce(trim(p_area),'')='' then
    raise exception 'Check key and area are required';
  end if;
  if p_status not in ('pending','pass','warn','fail') then
    raise exception 'Invalid validation status';
  end if;

  select * into v_run
  from public.validation_runs
  where id=p_run_id
  for update;

  if not found then raise exception 'Validation run not found'; end if;
  if v_run.completed_at is not null then raise exception 'Validation run is already completed'; end if;

  insert into public.validation_check_results(
    run_id,check_key,area,status,detail,evidence,checked_by
  )
  values(
    p_run_id,trim(p_check_key),trim(p_area),p_status,
    nullif(trim(p_detail),''),nullif(trim(p_evidence),''),auth.uid()
  )
  on conflict(run_id,check_key) do update set
    area=excluded.area,
    status=excluded.status,
    detail=excluded.detail,
    evidence=excluded.evidence,
    checked_by=auth.uid(),
    checked_at=now()
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.complete_validation_run(
  p_run_id uuid,
  p_notes text default null
)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_fail bigint;
  v_warn bigint;
  v_pending bigint;
  v_total bigint;
  v_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may complete a validation run';
  end if;

  perform 1
  from public.validation_runs
  where id=p_run_id and completed_at is null
  for update;

  if not found then raise exception 'Open validation run not found'; end if;

  select
    count(*),
    count(*) filter(where status='fail'),
    count(*) filter(where status='warn'),
    count(*) filter(where status='pending')
  into v_total,v_fail,v_warn,v_pending
  from public.validation_check_results
  where run_id=p_run_id;

  if v_total=0 then raise exception 'Validation run has no recorded checks'; end if;
  if v_pending>0 then raise exception 'Validation run still contains pending checks'; end if;

  v_status:=case
    when v_fail>0 then 'fail'
    when v_warn>0 then 'warn'
    else 'pass'
  end;

  update public.validation_runs
  set completed_at=now(),
      overall_status=v_status,
      notes=coalesce(nullif(trim(p_notes),''),notes)
  where id=p_run_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'complete_validation_run','validation_run',p_run_id,
    jsonb_build_object(
      'overall_status',v_status,'check_count',v_total,
      'fail_count',v_fail,'warn_count',v_warn
    )
  );

  return v_status;
end;
$$;

create or replace view public.validation_run_summary
with (security_invoker=true)
as
select
  vr.id,vr.environment,vr.app_version,vr.latest_migration,
  vr.started_at,vr.completed_at,vr.overall_status,vr.notes,
  p.full_name started_by_name,
  count(vcr.id)::bigint check_count,
  count(vcr.id) filter(where vcr.status='pass')::bigint pass_count,
  count(vcr.id) filter(where vcr.status='warn')::bigint warn_count,
  count(vcr.id) filter(where vcr.status='fail')::bigint fail_count,
  count(vcr.id) filter(where vcr.status='pending')::bigint pending_count
from public.validation_runs vr
join public.profiles p on p.id=vr.started_by
left join public.validation_check_results vcr on vcr.run_id=vr.id
group by vr.id,p.full_name;

revoke all on function public.begin_validation_run(text,text) from public;
revoke all on function public.record_validation_check(uuid,text,text,text,text,text) from public;
revoke all on function public.complete_validation_run(uuid,text) from public;

grant execute on function public.begin_validation_run(text,text) to authenticated;
grant execute on function public.record_validation_check(uuid,text,text,text,text,text) to authenticated;
grant execute on function public.complete_validation_run(uuid,text) to authenticated;

update public.system_release_state
set app_version='0.25.0',
    latest_migration=24,
    release_stage='staging_validation_harness',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.25.0'
    and vr.latest_migration=24
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.25.0'
      else 'No completed passing staging validation run exists yet for v0.25.0' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.25.0' and latest_migration=24
    ) then 'pass' else 'fail' end,
    'Expected app version 0.25.0 / migration 024';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.25.0',
    'latest_migration',24,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
