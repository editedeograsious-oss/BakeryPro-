-- DS Bakery v0.26 / Migration 025
-- Environment guardrails for staging bootstrap and production cutover.

create table if not exists public.system_environment_config (
  id integer primary key default 1 check(id=1),
  environment_mode text not null default 'unconfigured'
    check(environment_mode in ('unconfigured','staging','production')),
  allow_staging_test_accounts boolean not null default false,
  production_lock boolean not null default false,
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.system_environment_config(
  id,environment_mode,allow_staging_test_accounts,production_lock
)
values(1,'unconfigured',false,false)
on conflict(id) do nothing;

alter table public.system_environment_config enable row level security;

drop policy if exists "owner manager read environment config" on public.system_environment_config;
create policy "owner manager read environment config"
on public.system_environment_config
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.configure_system_environment(
  p_environment_mode text,
  p_allow_staging_test_accounts boolean,
  p_notes text,
  p_confirmation text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.system_environment_config%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may configure the deployment environment';
  end if;

  if p_environment_mode not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  if p_environment_mode='staging' and p_confirmation<>'CONFIRM STAGING' then
    raise exception 'Type CONFIRM STAGING to configure staging mode';
  end if;

  if p_environment_mode='production' and p_confirmation<>'CONFIRM PRODUCTION' then
    raise exception 'Type CONFIRM PRODUCTION to configure production mode';
  end if;

  select * into v_before
  from public.system_environment_config
  where id=1
  for update;

  if v_before.production_lock and p_environment_mode<>'production' then
    raise exception 'Production lock is enabled; environment cannot be moved back to staging';
  end if;

  if p_environment_mode='production' and p_allow_staging_test_accounts then
    raise exception 'Staging test accounts cannot be enabled in production mode';
  end if;

  update public.system_environment_config
  set
    environment_mode=p_environment_mode,
    allow_staging_test_accounts=case when p_environment_mode='production' then false else coalesce(p_allow_staging_test_accounts,false) end,
    notes=nullif(trim(p_notes),''),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'configure_system_environment','system_environment_config',null,
    to_jsonb(v_before),
    (select to_jsonb(c) from public.system_environment_config c where c.id=1)
  );
end;
$$;

create or replace function public.enable_production_lock(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may enable production lock';
  end if;

  if p_confirmation<>'LOCK PRODUCTION' then
    raise exception 'Type LOCK PRODUCTION to enable production lock';
  end if;

  if not exists(
    select 1 from public.system_environment_config
    where id=1 and environment_mode='production'
  ) then
    raise exception 'Environment must already be production before locking';
  end if;

  update public.system_environment_config
  set production_lock=true,
      allow_staging_test_accounts=false,
      updated_by=auth.uid(),
      updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'enable_production_lock','system_environment_config',null,
    jsonb_build_object('environment_mode','production','production_lock',true)
  );
end;
$$;

create or replace function public.environment_state()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'environment_mode',environment_mode,
    'allow_staging_test_accounts',allow_staging_test_accounts,
    'production_lock',production_lock,
    'notes',notes,
    'updated_at',updated_at
  )
  from public.system_environment_config
  where id=1
$$;

revoke all on function public.configure_system_environment(text,boolean,text,text) from public;
revoke all on function public.enable_production_lock(text) from public;
revoke all on function public.environment_state() from public;

grant execute on function public.configure_system_environment(text,boolean,text,text) to authenticated;
grant execute on function public.enable_production_lock(text) to authenticated;
grant execute on function public.environment_state() to authenticated;

update public.system_release_state
set app_version='0.26.0',
    latest_migration=25,
    release_stage='environment_guardrails',
    updated_at=now()
where id=1;

-- Refresh launch readiness to require explicit environment configuration.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.26.0'
    and vr.latest_migration=25
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0'
      else 'No completed passing staging validation run exists yet for v0.26.0' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.26.0' and latest_migration=25
    ) then 'pass' else 'fail' end,
    'Expected app version 0.26.0 / migration 025';
end;
$$;


create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.26.0',
    'latest_migration',25,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
