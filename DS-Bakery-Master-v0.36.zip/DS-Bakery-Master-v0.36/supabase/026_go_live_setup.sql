-- DS Bakery v0.27 / Migration 026
-- Go-live setup checklist and readiness sign-off.

create table if not exists public.go_live_setup_state (
  id integer primary key default 1 check(id=1),
  catalog_verified boolean not null default false,
  opening_stock_verified boolean not null default false,
  payment_methods_verified boolean not null default false,
  public_site_verified boolean not null default false,
  staff_accounts_verified boolean not null default false,
  backup_plan_verified boolean not null default false,
  notes text,
  verified_by uuid references public.profiles(id),
  verified_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz not null default now()
);

insert into public.go_live_setup_state(id)
values(1)
on conflict(id) do nothing;

alter table public.go_live_setup_state enable row level security;

drop policy if exists "owner manager read go live setup" on public.go_live_setup_state;
create policy "owner manager read go live setup"
on public.go_live_setup_state
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.go_live_setup_readiness()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_state public.go_live_setup_state%rowtype;
  v_env public.system_environment_config%rowtype;
  v_owner_count bigint;
  v_product_count bigint;
  v_material_count bigint;
  v_recipe_gap bigint;
  v_supplier_count bigint;
  v_staff_count bigint;
  v_negative_stock bigint;
  v_public_ok boolean;
  v_validation_pass boolean;
  v_auto_pass boolean;
  v_manual_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_state from public.go_live_setup_state where id=1;
  select * into v_env from public.system_environment_config where id=1;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  select count(*) into v_staff_count
  from public.profiles
  where active=true and disabled_at is null;

  select count(*) into v_product_count
  from public.products
  where status='active' and selling_price>0;

  select count(*) into v_material_count
  from public.raw_materials
  where status='active';

  select count(*) into v_supplier_count
  from public.suppliers
  where active=true;

  select count(*) into v_negative_stock
  from public.raw_materials
  where current_stock_qty<0;

  select count(*) into v_recipe_gap
  from public.products p
  where p.status='active'
    and p.track_recipe=true
    and not exists(
      select 1 from public.recipes r
      where r.product_id=p.id and r.active=true
    );

  select exists(
    select 1
    from public.public_site_settings
    where id=1
      and coalesce(trim(business_name),'')<>''
      and coalesce(trim(phone),'')<>''
      and coalesce(trim(whatsapp_phone),'')<>''
      and coalesce(trim(address_text),'')<>''
  ) into v_public_ok;

  select exists(
    select 1
    from public.validation_runs
    where environment='staging'
      and overall_status='pass'
      and completed_at is not null
      and app_version in ('0.26.0','0.27.0')
      and latest_migration>=25
  ) into v_validation_pass;

  v_auto_pass :=
    v_owner_count>=1
    and v_staff_count>=1
    and v_product_count>=1
    and v_material_count>=1
    and v_supplier_count>=1
    and v_negative_stock=0
    and v_recipe_gap=0
    and v_public_ok
    and v_env.environment_mode<>'unconfigured';

  v_manual_pass :=
    v_state.catalog_verified
    and v_state.opening_stock_verified
    and v_state.payment_methods_verified
    and v_state.public_site_verified
    and v_state.staff_accounts_verified
    and v_state.backup_plan_verified;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'automatic',jsonb_build_object(
      'active_owner',v_owner_count>=1,
      'active_staff_count',v_staff_count,
      'active_products',v_product_count,
      'active_raw_materials',v_material_count,
      'active_suppliers',v_supplier_count,
      'negative_stock_count',v_negative_stock,
      'recipe_gap_count',v_recipe_gap,
      'public_site_contact_ready',v_public_ok,
      'passing_staging_validation',v_validation_pass
    ),
    'manual',jsonb_build_object(
      'catalog_verified',v_state.catalog_verified,
      'opening_stock_verified',v_state.opening_stock_verified,
      'payment_methods_verified',v_state.payment_methods_verified,
      'public_site_verified',v_state.public_site_verified,
      'staff_accounts_verified',v_state.staff_accounts_verified,
      'backup_plan_verified',v_state.backup_plan_verified
    ),
    'automatic_gate',case when v_auto_pass then 'pass' else 'fail' end,
    'manual_gate',case when v_manual_pass then 'pass' else 'fail' end,
    'staging_validation_gate',case when v_validation_pass then 'pass' else 'warn' end,
    'setup_completed',v_state.completed_at is not null,
    'completed_at',v_state.completed_at,
    'notes',v_state.notes
  );
end;
$$;

create or replace function public.update_go_live_setup_checklist(
  p_catalog_verified boolean,
  p_opening_stock_verified boolean,
  p_payment_methods_verified boolean,
  p_public_site_verified boolean,
  p_staff_accounts_verified boolean,
  p_backup_plan_verified boolean,
  p_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update the go-live checklist';
  end if;

  select * into v_before
  from public.go_live_setup_state
  where id=1
  for update;

  update public.go_live_setup_state
  set
    catalog_verified=coalesce(p_catalog_verified,false),
    opening_stock_verified=coalesce(p_opening_stock_verified,false),
    payment_methods_verified=coalesce(p_payment_methods_verified,false),
    public_site_verified=coalesce(p_public_site_verified,false),
    staff_accounts_verified=coalesce(p_staff_accounts_verified,false),
    backup_plan_verified=coalesce(p_backup_plan_verified,false),
    notes=nullif(trim(p_notes),''),
    verified_by=auth.uid(),
    verified_at=now(),
    completed_at=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_go_live_checklist','go_live_setup_state',null,
    to_jsonb(v_before),
    (select to_jsonb(s) from public.go_live_setup_state s where s.id=1)
  );
end;
$$;

create or replace function public.complete_go_live_setup(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_ready jsonb;
  v_state public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may complete go-live setup';
  end if;

  if p_confirmation<>'COMPLETE GO LIVE SETUP' then
    raise exception 'Type COMPLETE GO LIVE SETUP exactly';
  end if;

  select * into v_state
  from public.go_live_setup_state
  where id=1
  for update;

  v_ready:=public.go_live_setup_readiness();

  if coalesce(v_ready->>'automatic_gate','fail')<>'pass' then
    raise exception 'Automatic go-live checks are not complete';
  end if;

  if coalesce(v_ready->>'manual_gate','fail')<>'pass' then
    raise exception 'Manual go-live checklist is incomplete';
  end if;

  if coalesce(v_ready->>'staging_validation_gate','warn')<>'pass' then
    raise exception 'A passing staging validation run is required';
  end if;

  update public.go_live_setup_state
  set completed_at=now(),
      verified_by=auth.uid(),
      verified_at=now(),
      updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'complete_go_live_setup','go_live_setup_state',null,
    jsonb_build_object('completed_at',now(),'readiness',v_ready)
  );
end;
$$;

revoke all on function public.go_live_setup_readiness() from public;
revoke all on function public.update_go_live_setup_checklist(boolean,boolean,boolean,boolean,boolean,boolean,text) from public;
revoke all on function public.complete_go_live_setup(text) from public;

grant execute on function public.go_live_setup_readiness() to authenticated;
grant execute on function public.update_go_live_setup_checklist(boolean,boolean,boolean,boolean,boolean,boolean,text) to authenticated;
grant execute on function public.complete_go_live_setup(text) to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.27.0'
    and vr.latest_migration=26
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.27.0' and latest_migration=26
    ) then 'pass' else 'fail' end,
    'Expected app version 0.27.0 / migration 026';
end;
$$;



update public.system_release_state
set app_version='0.27.0',
    latest_migration=26,
    release_stage='go_live_setup',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.27.0',
    'latest_migration',26,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
