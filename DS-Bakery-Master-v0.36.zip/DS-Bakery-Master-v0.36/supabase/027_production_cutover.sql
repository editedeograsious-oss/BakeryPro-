-- DS Bakery v0.28 / Migration 027
-- Production cutover authorization and transactional safety gate.

create table if not exists public.production_cutover_state (
  id integer primary key default 1 check(id=1),
  operations_enabled boolean not null default false,
  authorized_by uuid references public.profiles(id),
  authorized_at timestamptz,
  suspended_by uuid references public.profiles(id),
  suspended_at timestamptz,
  suspension_reason text,
  updated_at timestamptz not null default now()
);

insert into public.production_cutover_state(id)
values(1)
on conflict(id) do nothing;

alter table public.production_cutover_state enable row level security;

drop policy if exists "owner manager read production cutover" on public.production_cutover_state;
create policy "owner manager read production cutover"
on public.production_cutover_state
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.production_cutover_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup_completed',v_setup.completed_at is not null,
    'go_live_setup_completed_at',v_setup.completed_at,
    'operations_enabled',v_cut.operations_enabled,
    'authorized_at',v_cut.authorized_at,
    'suspended_at',v_cut.suspended_at,
    'suspension_reason',v_cut.suspension_reason,
    'ready_to_authorize',
      v_env.environment_mode='production'
      and v_env.production_lock
      and v_setup.completed_at is not null
  );
end;
$$;

create or replace function public.authorize_production_operations(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_cut public.production_cutover_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may authorize production operations';
  end if;

  if p_confirmation<>'AUTHORIZE LIVE OPERATIONS' then
    raise exception 'Type AUTHORIZE LIVE OPERATIONS exactly';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1
  for update;

  select * into v_setup
  from public.go_live_setup_state
  where id=1
  for update;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  if v_env.environment_mode<>'production' then
    raise exception 'Environment must be Production';
  end if;

  if not v_env.production_lock then
    raise exception 'Production Lock must be enabled before live operations';
  end if;

  if v_setup.completed_at is null then
    raise exception 'Go-Live Setup must be completed first';
  end if;

  update public.production_cutover_state
  set
    operations_enabled=true,
    authorized_by=auth.uid(),
    authorized_at=now(),
    suspended_by=null,
    suspended_at=null,
    suspension_reason=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'authorize_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.suspend_production_operations(p_reason text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_cut public.production_cutover_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager required';
  end if;

  if coalesce(trim(p_reason),'')='' then
    raise exception 'Suspension reason is required';
  end if;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  update public.production_cutover_state
  set
    operations_enabled=false,
    suspended_by=auth.uid(),
    suspended_at=now(),
    suspension_reason=trim(p_reason),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'suspend_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.assert_business_operation_allowed()
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
begin
  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  if v_env.environment_mode='staging' then
    return;
  end if;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Business operations are blocked until the environment is configured';
  end if;

  if v_env.environment_mode='production' then
    if not v_env.production_lock then
      raise exception 'Business operations are blocked until Production Lock is enabled';
    end if;

    if v_setup.completed_at is null then
      raise exception 'Business operations are blocked until Go-Live Setup is completed';
    end if;

    if not v_cut.operations_enabled then
      raise exception 'Live business operations are currently disabled';
    end if;

    return;
  end if;

  raise exception 'Unknown system environment state';
end;
$$;

create or replace function public.trg_business_operation_gate()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.assert_business_operation_allowed();
  if tg_op='DELETE' then
    return old;
  end if;
  return new;
end;
$$;

-- Critical transactional tables. Staging stays usable; production requires final authorization.
do $$
declare
  v_table text;
  v_trigger text;
begin
  foreach v_table in array ARRAY[
    'sales',
    'payments',
    'sale_refunds',
    'customer_orders',
    'customer_order_payments',
    'customer_order_refunds',
    'purchases',
    'purchase_items',
    'purchase_payments',
    'inventory_transactions',
    'production_runs',
    'waste_events',
    'expenses',
    'cash_movements'
  ]
  loop
    if to_regclass('public.'||v_table) is not null then
      v_trigger:='trg_business_operation_gate_'||v_table;
      execute format('drop trigger if exists %I on public.%I',v_trigger,v_table);
      execute format(
        'create trigger %I before insert or update or delete on public.%I for each row execute function public.trg_business_operation_gate()',
        v_trigger,v_table
      );
    end if;
  end loop;
end $$;

revoke all on function public.production_cutover_status() from public;
revoke all on function public.authorize_production_operations(text) from public;
revoke all on function public.suspend_production_operations(text) from public;
revoke all on function public.assert_business_operation_allowed() from public;

grant execute on function public.production_cutover_status() to authenticated;
grant execute on function public.authorize_production_operations(text) to authenticated;
grant execute on function public.suspend_production_operations(text) to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.28.0'
    and vr.latest_migration=27
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.28.0' and latest_migration=27
    ) then 'pass' else 'fail' end,
    'Expected app version 0.28.0 / migration 027';
end;
$$;





update public.system_release_state
set app_version='0.28.0',
    latest_migration=27,
    release_stage='production_cutover',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  select * into v_cut
  from public.production_cutover_state
  where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select
      'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select
      'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.28.0',
    'latest_migration',27,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
