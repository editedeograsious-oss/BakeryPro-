-- DS Bakery v0.29 / Migration 028
-- Supabase staging-connection evidence and environment handoff.

create table if not exists public.environment_connection_checks (
  id uuid primary key default gen_random_uuid(),
  environment_mode text not null check(environment_mode in ('staging','production')),
  check_type text not null,
  status text not null check(status in ('pass','warn','fail')),
  detail text,
  metadata jsonb,
  app_version text not null,
  latest_migration integer not null,
  recorded_by uuid references public.profiles(id),
  recorded_at timestamptz not null default now()
);

alter table public.environment_connection_checks enable row level security;

drop policy if exists "owner manager read environment connection checks" on public.environment_connection_checks;
create policy "owner manager read environment connection checks"
on public.environment_connection_checks
for select using(public.current_staff_role() in ('owner','manager'));

create index if not exists environment_connection_checks_lookup_idx
on public.environment_connection_checks(environment_mode,check_type,recorded_at desc);

create or replace function public.record_environment_connection_check(
  p_check_type text,
  p_status text,
  p_detail text default null,
  p_metadata jsonb default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record environment connection evidence';
  end if;

  if coalesce(trim(p_check_type),'')='' then
    raise exception 'Check type is required';
  end if;

  if p_status not in ('pass','warn','fail') then
    raise exception 'Invalid connection-check status';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Configure the environment before recording connection evidence';
  end if;

  insert into public.environment_connection_checks(
    id,environment_mode,check_type,status,detail,metadata,
    app_version,latest_migration,recorded_by
  )
  values(
    v_id,v_env.environment_mode,trim(p_check_type),p_status,
    nullif(trim(p_detail),''),p_metadata,
    '0.29.0',28,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_environment_connection_check','environment_connection_check',v_id,
    jsonb_build_object(
      'environment_mode',v_env.environment_mode,
      'check_type',p_check_type,
      'status',p_status,
      'app_version','0.29.0',
      'latest_migration',28
    )
  );

  return v_id;
end;
$$;

create or replace function public.environment_connection_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_latest jsonb;
  v_pass_count bigint;
  v_fail_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select coalesce(jsonb_agg(to_jsonb(x) order by x.recorded_at desc),'[]'::jsonb)
  into v_latest
  from (
    select distinct on (ecc.check_type)
      ecc.id,ecc.environment_mode,ecc.check_type,ecc.status,ecc.detail,
      ecc.metadata,ecc.app_version,ecc.latest_migration,ecc.recorded_at
    from public.environment_connection_checks ecc
    order by ecc.check_type,ecc.recorded_at desc
  ) x;

  select
    count(*) filter(where status='pass'),
    count(*) filter(where status='fail')
  into v_pass_count,v_fail_count
  from public.environment_connection_checks
  where environment_mode=v_env.environment_mode
    and app_version='0.29.0'
    and latest_migration=28;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'allow_staging_test_accounts',v_env.allow_staging_test_accounts,
    'production_lock',v_env.production_lock,
    'release',jsonb_build_object(
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration,
      'release_stage',v_release.release_stage
    ),
    'latest_checks',v_latest,
    'pass_count',v_pass_count,
    'fail_count',v_fail_count,
    'checked_at',now()
  );
end;
$$;

revoke all on function public.record_environment_connection_check(text,text,text,jsonb) from public;
revoke all on function public.environment_connection_summary() from public;

grant execute on function public.record_environment_connection_check(text,text,text,jsonb) to authenticated;
grant execute on function public.environment_connection_summary() to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.29.0'
    and vr.latest_migration=28
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.29.0' and latest_migration=28
    ) then 'pass' else 'fail' end,
    'Expected app version 0.29.0 / migration 028';
end;
$$;







update public.system_release_state
set app_version='0.29.0',
    latest_migration=28,
    release_stage='supabase_staging_handoff',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
  v_connection_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;

  v_setup:=public.go_live_setup_readiness();

  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_connection_status:=case
    when v_env.environment_mode='production' then 'pass'
    when exists(
      select 1 from public.environment_connection_checks
      where environment_mode='staging'
        and check_type='supabase_connectivity'
        and status='pass'
        and app_version='0.29.0'
        and latest_migration=28
    ) then 'pass'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
           else 'Environment mode: '||v_env.environment_mode end
    union all
    select
      'staging_connection_evidence'::text,
      v_connection_status,
      case
        when v_env.environment_mode='production' then 'Staging connection evidence was a pre-production gate'
        when v_connection_status='pass' then 'Passing Supabase staging connectivity evidence exists'
        else 'Run the real Supabase staging connectivity check'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select
      'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select
      'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.29.0',
    'latest_migration',28,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
