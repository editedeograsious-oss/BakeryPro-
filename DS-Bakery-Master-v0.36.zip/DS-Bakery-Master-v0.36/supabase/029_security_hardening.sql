-- DS Bakery v0.30 / Migration 029
-- Security hardening after real Supabase staging advisor review.

alter view if exists public.raw_material_costs set (security_invoker=true);
alter view if exists public.low_stock_materials set (security_invoker=true);
alter view if exists public.supplier_balances set (security_invoker=true);
alter view if exists public.sale_profit_lines set (security_invoker=true);

alter function public.next_sale_no() set search_path=public;
alter function public.period_start(text) set search_path=public;
alter function public.next_customer_order_no() set search_path=public;
alter function public.operational_period_bounds(text) set search_path=public;
alter function public.next_purchase_no() set search_path=public;

do $$
declare
  r record;
begin
  for r in
    select
      p.oid::regprocedure as signature,
      pg_get_function_result(p.oid) as result_type
    from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public'
      and p.prosecdef=true
  loop
    execute format('revoke all on function %s from public',r.signature);
    execute format('revoke all on function %s from anon',r.signature);
    execute format('revoke all on function %s from authenticated',r.signature);

    if r.result_type <> 'trigger' then
      execute format('grant execute on function %s to authenticated',r.signature);
    end if;
  end loop;
end
$$;

grant execute on function public.public_site_info() to anon,authenticated;
grant execute on function public.public_product_catalog() to anon,authenticated;

update public.system_release_state
set app_version='0.30.0',
    latest_migration=29,
    release_stage='security_hardening',
    updated_at=now()
where id=1;
