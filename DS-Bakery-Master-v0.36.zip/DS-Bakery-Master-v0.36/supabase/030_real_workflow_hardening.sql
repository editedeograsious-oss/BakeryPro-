-- DS Bakery v0.31 / Migration 030
-- Real staging workflow hardening.

create or replace function public.save_raw_material(
  p_raw_material_id uuid,
  p_supplier_id uuid,
  p_name text,
  p_sku text,
  p_base_unit text,
  p_purchase_pack_label text,
  p_purchase_pack_base_qty numeric,
  p_low_stock_threshold numeric
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_raw_material_id,gen_random_uuid());
  v_before jsonb;
begin
  if not public.staff_has_permission('inventory:write') then
    raise exception 'Not authorized to manage raw materials';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Raw material name is required'; end if;
  if coalesce(trim(p_base_unit),'')='' then raise exception 'Base unit is required'; end if;
  if coalesce(p_purchase_pack_base_qty,0)<=0 then raise exception 'Purchase pack quantity must be greater than zero'; end if;
  if coalesce(p_low_stock_threshold,0)<0 then raise exception 'Low stock threshold cannot be negative'; end if;
  if p_supplier_id is not null and not exists(select 1 from public.suppliers where id=p_supplier_id and active=true) then
    raise exception 'Active supplier not found';
  end if;

  select to_jsonb(rm) into v_before
  from public.raw_materials rm
  where rm.id=p_raw_material_id;

  insert into public.raw_materials(
    id,supplier_id,name,sku,base_unit,purchase_pack_label,purchase_pack_base_qty,
    current_purchase_cost,current_stock_qty,low_stock_threshold,status,created_by
  )
  values(
    v_id,p_supplier_id,trim(p_name),nullif(trim(p_sku),''),
    trim(p_base_unit),nullif(trim(p_purchase_pack_label),''),
    p_purchase_pack_base_qty,0,0,p_low_stock_threshold,'active',auth.uid()
  )
  on conflict(id) do update set
    supplier_id=excluded.supplier_id,
    name=excluded.name,
    sku=excluded.sku,
    base_unit=excluded.base_unit,
    purchase_pack_label=excluded.purchase_pack_label,
    purchase_pack_base_qty=excluded.purchase_pack_base_qty,
    low_stock_threshold=excluded.low_stock_threshold,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_raw_material_id is null then 'create_raw_material' else 'update_raw_material' end,
    'raw_material',v_id,v_before,
    (select to_jsonb(rm) from public.raw_materials rm where rm.id=v_id)
  );

  return v_id;
end;
$$;

revoke all on function public.save_raw_material(uuid,uuid,text,text,text,text,numeric,numeric) from public,anon;
grant execute on function public.save_raw_material(uuid,uuid,text,text,text,text,numeric,numeric) to authenticated;


create or replace function public.launch_readiness_checks()
returns table(check_key text, status text, detail text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select 'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz from public.business_settings where id=1;

  return query select 'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (select product_id from public.recipes where active=true group by product_id having count(*)>1) x;
  return query select 'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count from public.raw_materials rm where rm.current_stock_qty<0;
  return query select 'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0))>0.01
     or abs(p.total_amount-greatest(coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0))>0.01
     or abs(p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0))>0.01;
  return query select 'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;
  return query select 'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((select sum(we.quantity) from public.waste_events we
                  where we.production_run_id=pr.id
                    and we.waste_type='finished_product'
                    and we.approval_status<>'rejected'),0)>pr.quantity_produced;
  return query select 'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count from public.mobile_money_reference_conflicts;
  return query select 'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts cs
  where cs.status='open' and cs.opened_at<now()-interval '18 hours';
  return query select 'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts sws
  where sws.status='scheduled' and sws.shift_date<public.business_current_date();
  return query select 'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references''' into v_storage_public;
    return query select 'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case when v_storage_public is false then 'custom-cake-references bucket is private'
           when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
           else 'custom-cake-references bucket is missing' end;
  else
    return query select 'custom_cake_storage','warn','Supabase Storage schema is unavailable in this database session';
  end if;

  return query select 'public_site_settings',
    case when exists(select 1 from public.public_site_settings pss where pss.id=1 and coalesce(trim(pss.business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings pss where pss.id=1 and coalesce(trim(pss.business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.completed_at is not null;

  return query select 'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1 then 'A completed passing staging validation run exists'
         else 'No completed passing staging validation run exists yet' end;

  return query select 'release_state',
    case when exists(select 1 from public.system_release_state srs where srs.id=1) then 'pass' else 'fail' end,
    'Release-state row exists';
end;
$$;

revoke all on function public.launch_readiness_checks() from public,anon;
grant execute on function public.launch_readiness_checks() to authenticated;

update public.system_release_state
set app_version='0.31.0',
    latest_migration=30,
    release_stage='real_workflow_validation',
    updated_at=now()
where id=1;
