-- DS Bakery v0.32 / Migration 031
-- Formal staging-validation evidence and dynamic release metadata.

create or replace function public.begin_validation_run(
  p_environment text default 'staging',
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_release public.system_release_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may start a validation run';
  end if;
  if p_environment not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  select * into v_release from public.system_release_state where id=1;
  if not found then raise exception 'System release state is missing'; end if;

  insert into public.validation_runs(
    id,environment,app_version,latest_migration,started_by,notes
  )
  values(
    v_id,p_environment,v_release.app_version,v_release.latest_migration,
    auth.uid(),nullif(trim(p_notes),'')
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'begin_validation_run','validation_run',v_id,
    jsonb_build_object(
      'environment',p_environment,
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration
    )
  );

  return v_id;
end;
$$;

create or replace function public.record_environment_connection_check(
  p_check_type text,
  p_status text,
  p_detail text default null,
  p_metadata jsonb default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record environment connection evidence';
  end if;
  if coalesce(trim(p_check_type),'')='' then raise exception 'Check type is required'; end if;
  if p_status not in ('pass','warn','fail') then raise exception 'Invalid connection-check status'; end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Configure the environment before recording connection evidence';
  end if;

  insert into public.environment_connection_checks(
    id,environment_mode,check_type,status,detail,metadata,
    app_version,latest_migration,recorded_by
  )
  values(
    v_id,v_env.environment_mode,trim(p_check_type),p_status,
    nullif(trim(p_detail),''),p_metadata,
    v_release.app_version,v_release.latest_migration,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_environment_connection_check','environment_connection_check',v_id,
    jsonb_build_object(
      'environment_mode',v_env.environment_mode,
      'check_type',p_check_type,
      'status',p_status,
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration
    )
  );

  return v_id;
end;
$$;

create or replace function public.environment_connection_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_latest jsonb;
  v_pass_count bigint;
  v_fail_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select coalesce(jsonb_agg(to_jsonb(x) order by x.recorded_at desc),'[]'::jsonb)
  into v_latest
  from (
    select distinct on (ecc.check_type)
      ecc.id,ecc.environment_mode,ecc.check_type,ecc.status,ecc.detail,
      ecc.metadata,ecc.app_version,ecc.latest_migration,ecc.recorded_at
    from public.environment_connection_checks ecc
    where ecc.environment_mode=v_env.environment_mode
    order by ecc.check_type,ecc.recorded_at desc
  ) x;

  select
    count(*) filter(where ecc.status='pass'),
    count(*) filter(where ecc.status='fail')
  into v_pass_count,v_fail_count
  from public.environment_connection_checks ecc
  where ecc.environment_mode=v_env.environment_mode
    and ecc.app_version=v_release.app_version
    and ecc.latest_migration=v_release.latest_migration;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'allow_staging_test_accounts',v_env.allow_staging_test_accounts,
    'production_lock',v_env.production_lock,
    'release',jsonb_build_object(
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration,
      'release_stage',v_release.release_stage
    ),
    'latest_checks',v_latest,
    'pass_count',v_pass_count,
    'fail_count',v_fail_count,
    'checked_at',now()
  );
end;
$$;

create or replace function public.go_live_setup_readiness()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_state public.go_live_setup_state%rowtype;
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_owner_count bigint;
  v_product_count bigint;
  v_material_count bigint;
  v_recipe_gap bigint;
  v_supplier_count bigint;
  v_staff_count bigint;
  v_negative_stock bigint;
  v_public_ok boolean;
  v_validation_pass boolean;
  v_auto_pass boolean;
  v_manual_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_state from public.go_live_setup_state where id=1;
  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select count(*) into v_owner_count from public.profiles where active=true and disabled_at is null and role='owner';
  select count(*) into v_staff_count from public.profiles where active=true and disabled_at is null;
  select count(*) into v_product_count from public.products where status='active' and selling_price>0;
  select count(*) into v_material_count from public.raw_materials where status='active';
  select count(*) into v_supplier_count from public.suppliers where active=true;
  select count(*) into v_negative_stock from public.raw_materials where current_stock_qty<0;

  select count(*) into v_recipe_gap
  from public.products p
  where p.status='active'
    and p.track_recipe=true
    and not exists(select 1 from public.recipes r where r.product_id=p.id and r.active=true);

  select exists(
    select 1 from public.public_site_settings
    where id=1
      and coalesce(trim(business_name),'')<>''
      and coalesce(trim(phone),'')<>''
      and coalesce(trim(whatsapp_phone),'')<>''
      and coalesce(trim(address_text),'')<>''
  ) into v_public_ok;

  select exists(
    select 1
    from public.validation_runs vr
    where vr.environment='staging'
      and vr.overall_status='pass'
      and vr.completed_at is not null
      and vr.app_version=v_release.app_version
      and vr.latest_migration=v_release.latest_migration
  ) into v_validation_pass;

  v_auto_pass :=
    v_owner_count>=1
    and v_staff_count>=1
    and v_product_count>=1
    and v_material_count>=1
    and v_supplier_count>=1
    and v_negative_stock=0
    and v_recipe_gap=0
    and v_public_ok
    and v_env.environment_mode<>'unconfigured';

  v_manual_pass :=
    v_state.catalog_verified
    and v_state.opening_stock_verified
    and v_state.payment_methods_verified
    and v_state.public_site_verified
    and v_state.staff_accounts_verified
    and v_state.backup_plan_verified;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'automatic',jsonb_build_object(
      'active_owner',v_owner_count>=1,
      'active_staff_count',v_staff_count,
      'active_products',v_product_count,
      'active_raw_materials',v_material_count,
      'active_suppliers',v_supplier_count,
      'negative_stock_count',v_negative_stock,
      'recipe_gap_count',v_recipe_gap,
      'public_site_contact_ready',v_public_ok,
      'passing_staging_validation',v_validation_pass
    ),
    'manual',jsonb_build_object(
      'catalog_verified',v_state.catalog_verified,
      'opening_stock_verified',v_state.opening_stock_verified,
      'payment_methods_verified',v_state.payment_methods_verified,
      'public_site_verified',v_state.public_site_verified,
      'staff_accounts_verified',v_state.staff_accounts_verified,
      'backup_plan_verified',v_state.backup_plan_verified
    ),
    'automatic_gate',case when v_auto_pass then 'pass' else 'fail' end,
    'manual_gate',case when v_manual_pass then 'pass' else 'fail' end,
    'staging_validation_gate',case when v_validation_pass then 'pass' else 'warn' end,
    'setup_completed',v_state.completed_at is not null,
    'completed_at',v_state.completed_at,
    'notes',v_state.notes
  );
end;
$$;

update public.system_release_state
set app_version='0.32.0',
    latest_migration=31,
    release_stage='formal_staging_validation',
    updated_at=now()
where id=1;
