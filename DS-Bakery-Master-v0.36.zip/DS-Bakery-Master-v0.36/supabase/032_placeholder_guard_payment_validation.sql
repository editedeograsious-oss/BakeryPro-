-- DS Bakery v0.33 / Migration 032
-- Staging placeholder guard and payment-method validation.

create or replace function public.staging_placeholder_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_products bigint;
  v_materials bigint;
  v_suppliers bigint;
  v_customers bigint;
  v_staff bigint;
  v_total bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select count(*) into v_products
  from public.products
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_materials
  from public.raw_materials
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_suppliers
  from public.suppliers
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_customers
  from public.customers
  where upper(full_name) like 'STAGING TEST%';

  select count(*) into v_staff
  from public.profiles
  where full_name in (
    'DS Bakery Owner',
    'DS Bakery Manager',
    'DS Bakery Cashier',
    'DS Bakery Baker',
    'DS Bakery Storekeeper'
  );

  v_total:=v_products+v_materials+v_suppliers+v_customers+v_staff;

  return jsonb_build_object(
    'total_placeholder_records',v_total,
    'products',v_products,
    'raw_materials',v_materials,
    'suppliers',v_suppliers,
    'customers',v_customers,
    'generic_staging_staff',v_staff,
    'clear_for_production',v_total=0
  );
end;
$$;

create or replace function public.payment_method_validation_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_cash bigint;
  v_mtn bigint;
  v_airtel bigint;
  v_conflicts bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select count(*) into v_cash
  from public.payments
  where status='completed' and method='cash';

  select count(*) into v_mtn
  from public.payments
  where status='completed' and method='mtn_momo';

  select count(*) into v_airtel
  from public.payments
  where status='completed' and method='airtel_money';

  select count(*) into v_conflicts
  from public.mobile_money_reference_conflicts;

  return jsonb_build_object(
    'cash_tested',v_cash>0,
    'mtn_momo_tested',v_mtn>0,
    'airtel_money_tested',v_airtel>0,
    'mobile_money_reference_conflicts',v_conflicts,
    'all_methods_verified',v_cash>0 and v_mtn>0 and v_airtel>0 and v_conflicts=0
  );
end;
$$;

create or replace function public.production_cutover_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_placeholders jsonb;
  v_placeholder_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  v_placeholders:=public.staging_placeholder_summary();
  v_placeholder_count:=coalesce((v_placeholders->>'total_placeholder_records')::bigint,0);

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup_completed',v_setup.completed_at is not null,
    'go_live_setup_completed_at',v_setup.completed_at,
    'operations_enabled',v_cut.operations_enabled,
    'authorized_at',v_cut.authorized_at,
    'suspended_at',v_cut.suspended_at,
    'suspension_reason',v_cut.suspension_reason,
    'placeholder_count',v_placeholder_count,
    'placeholders',v_placeholders,
    'ready_to_authorize',
      v_env.environment_mode='production'
      and v_env.production_lock
      and v_setup.completed_at is not null
      and v_placeholder_count=0
  );
end;
$$;

create or replace function public.authorize_production_operations(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_placeholder_count bigint;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may authorize production operations';
  end if;

  if p_confirmation<>'AUTHORIZE LIVE OPERATIONS' then
    raise exception 'Type AUTHORIZE LIVE OPERATIONS exactly';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1
  for update;

  select * into v_setup
  from public.go_live_setup_state
  where id=1
  for update;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  v_placeholder_count:=coalesce(
    (public.staging_placeholder_summary()->>'total_placeholder_records')::bigint,
    0
  );

  if v_env.environment_mode<>'production' then
    raise exception 'Environment must be Production';
  end if;

  if not v_env.production_lock then
    raise exception 'Production Lock must be enabled before live operations';
  end if;

  if v_setup.completed_at is null then
    raise exception 'Go-Live Setup must be completed first';
  end if;

  if v_placeholder_count>0 then
    raise exception 'Replace or remove all staging placeholder records before live operations';
  end if;

  update public.production_cutover_state
  set
    operations_enabled=true,
    authorized_by=auth.uid(),
    authorized_at=now(),
    suspended_by=null,
    suspended_at=null,
    suspension_reason=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'authorize_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
  v_connection_status text;
  v_placeholders jsonb;
  v_placeholder_count bigint;
  v_placeholder_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;
  select * into v_cut from public.production_cutover_state where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_placeholders:=public.staging_placeholder_summary();
  v_placeholder_count:=coalesce((v_placeholders->>'total_placeholder_records')::bigint,0);

  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_connection_status:=case
    when v_env.environment_mode='production' then 'pass'
    when exists(
      select 1
      from public.environment_connection_checks ecc
      where ecc.environment_mode='staging'
        and ecc.check_type='supabase_connectivity'
        and ecc.status='pass'
        and ecc.app_version=v_release.app_version
        and ecc.latest_migration=v_release.latest_migration
    ) then 'pass'
    else 'warn'
  end;

  v_placeholder_status:=case
    when v_placeholder_count=0 then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select 'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
           else 'Environment mode: '||v_env.environment_mode end
    union all
    select 'staging_connection_evidence'::text,
      v_connection_status,
      case
        when v_env.environment_mode='production' then 'Staging connection evidence was a pre-production gate'
        when v_connection_status='pass' then 'Passing Supabase staging connectivity evidence exists'
        else 'Run the real Supabase staging connectivity check'
      end
    union all
    select 'staging_placeholder_data'::text,
      v_placeholder_status,
      case
        when v_placeholder_count=0 then 'No staging placeholder records remain'
        when v_env.environment_mode='production' then v_placeholder_count::text||' staging placeholder record(s) must be replaced before production'
        else v_placeholder_count::text||' staging placeholder record(s) remain; acceptable in staging but must be replaced before production'
      end
    union all
    select 'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select 'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select 'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version',v_release.app_version,
    'latest_migration',v_release.latest_migration,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'placeholders',v_placeholders,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;

revoke all on function public.staging_placeholder_summary() from public,anon;
revoke all on function public.payment_method_validation_summary() from public,anon;
grant execute on function public.staging_placeholder_summary() to authenticated;
grant execute on function public.payment_method_validation_summary() to authenticated;

update public.system_release_state
set app_version='0.33.0',
    latest_migration=32,
    release_stage='placeholder_guard_payment_validation',
    updated_at=now()
where id=1;
