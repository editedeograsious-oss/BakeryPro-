-- DS Bakery v0.34 / Migration 033
-- Backup and recovery readiness.

create table if not exists public.backup_recovery_events(
  id uuid primary key default gen_random_uuid(),
  event_type text not null check(event_type in ('plan_prepared','backup_created','backup_verified','restore_drill')),
  status text not null check(status in ('pass','warn','fail')),
  backup_label text null,
  checksum text null,
  notes text null,
  recorded_by uuid null references public.profiles(id),
  recorded_at timestamptz not null default now()
);

alter table public.backup_recovery_events enable row level security;

drop policy if exists "owner manager read backup recovery events" on public.backup_recovery_events;
create policy "owner manager read backup recovery events"
on public.backup_recovery_events for select
to authenticated
using (public.current_staff_role() in ('owner','manager'));

create or replace function public.record_backup_recovery_event(
  p_event_type text,
  p_status text,
  p_backup_label text default null,
  p_checksum text default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record backup/recovery evidence';
  end if;

  if p_event_type not in ('plan_prepared','backup_created','backup_verified','restore_drill') then
    raise exception 'Invalid backup/recovery event type';
  end if;
  if p_status not in ('pass','warn','fail') then
    raise exception 'Invalid backup/recovery event status';
  end if;

  insert into public.backup_recovery_events(
    id,event_type,status,backup_label,checksum,notes,recorded_by
  )
  values(
    v_id,p_event_type,p_status,
    nullif(trim(p_backup_label),''),
    nullif(trim(p_checksum),''),
    nullif(trim(p_notes),''),
    auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_backup_recovery_event','backup_recovery_event',v_id,
    jsonb_build_object(
      'event_type',p_event_type,
      'status',p_status,
      'backup_label',p_backup_label,
      'checksum',p_checksum
    )
  );

  return v_id;
end;
$$;

create or replace function public.recovery_verification_manifest()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_release public.system_release_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_release from public.system_release_state where id=1;

  return jsonb_build_object(
    'generated_at',now(),
    'app_version',v_release.app_version,
    'latest_migration',v_release.latest_migration,
    'release_stage',v_release.release_stage,
    'critical_counts',jsonb_build_object(
      'profiles',(select count(*) from public.profiles),
      'products',(select count(*) from public.products),
      'raw_materials',(select count(*) from public.raw_materials),
      'suppliers',(select count(*) from public.suppliers),
      'recipes',(select count(*) from public.recipes),
      'purchases',(select count(*) from public.purchases),
      'inventory_transactions',(select count(*) from public.inventory_transactions),
      'production_runs',(select count(*) from public.production_runs),
      'waste_events',(select count(*) from public.waste_events),
      'customers',(select count(*) from public.customers),
      'customer_orders',(select count(*) from public.customer_orders),
      'sales',(select count(*) from public.sales),
      'payments',(select count(*) from public.payments),
      'expenses',(select count(*) from public.expenses),
      'audit_logs',(select count(*) from public.audit_logs)
    ),
    'integrity',jsonb_build_object(
      'negative_stock_count',(select count(*) from public.raw_materials where current_stock_qty<0),
      'active_owner_count',(select count(*) from public.profiles where active=true and disabled_at is null and role='owner'),
      'open_cashier_shift_count',(select count(*) from public.cashier_shifts where status='open'),
      'mobile_money_conflict_count',(select count(*) from public.mobile_money_reference_conflicts),
      'validation_pass_count',(select count(*) from public.validation_runs where overall_status='pass' and completed_at is not null)
    ),
    'financial_totals',jsonb_build_object(
      'completed_sales_total',(select coalesce(sum(total),0) from public.sales where status='completed'),
      'completed_payments_total',(select coalesce(sum(amount),0) from public.payments where status='completed'),
      'customer_order_payments_total',(select coalesce(sum(amount),0) from public.customer_order_payments where payment_status='completed'),
      'expenses_total',(select coalesce(sum(amount),0) from public.expenses)
    )
  );
end;
$$;

create or replace function public.backup_recovery_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_latest_backup jsonb;
  v_latest_verify jsonb;
  v_latest_restore jsonb;
  v_restore_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select to_jsonb(x) into v_latest_backup
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='backup_created'
    order by recorded_at desc limit 1
  ) x;

  select to_jsonb(x) into v_latest_verify
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='backup_verified'
    order by recorded_at desc limit 1
  ) x;

  select to_jsonb(x) into v_latest_restore
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='restore_drill'
    order by recorded_at desc limit 1
  ) x;

  v_restore_pass:=exists(
    select 1 from public.backup_recovery_events
    where event_type='restore_drill' and status='pass'
  );

  return jsonb_build_object(
    'strategy','supabase_cli_logical_backup_plus_provider_backup',
    'latest_backup',v_latest_backup,
    'latest_backup_verification',v_latest_verify,
    'latest_restore_drill',v_latest_restore,
    'restore_drill_passed',v_restore_pass,
    'go_live_backup_gate',case when v_restore_pass then 'pass' else 'pending' end
  );
end;
$$;

revoke all on function public.record_backup_recovery_event(text,text,text,text,text) from public,anon;
revoke all on function public.recovery_verification_manifest() from public,anon;
revoke all on function public.backup_recovery_status() from public,anon;
grant execute on function public.record_backup_recovery_event(text,text,text,text,text) to authenticated;
grant execute on function public.recovery_verification_manifest() to authenticated;
grant execute on function public.backup_recovery_status() to authenticated;

update public.system_release_state
set app_version='0.34.0',
    latest_migration=33,
    release_stage='backup_recovery_readiness',
    updated_at=now()
where id=1;
