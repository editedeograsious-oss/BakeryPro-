-- DS Bakery v0.35 / Migration 034
-- Deployment preparation and staging-host readiness tracking.

create table if not exists public.deployment_readiness_state(
  id smallint primary key default 1 check(id=1),
  target_host text null,
  target_environment text not null default 'staging' check(target_environment in ('staging','production')),
  staging_url text null,
  source_prepared boolean not null default false,
  runtime_env_prepared boolean not null default false,
  healthcheck_prepared boolean not null default false,
  build_verified boolean not null default false,
  healthcheck_verified boolean not null default false,
  public_site_verified boolean not null default false,
  auth_login_verified boolean not null default false,
  notes text null,
  updated_by uuid null references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.deployment_readiness_state(id,target_host,target_environment,notes)
values(1,'Railway','staging','Production deployment preparation started. Existing Railway production service has not been modified.')
on conflict(id) do nothing;

alter table public.deployment_readiness_state enable row level security;

drop policy if exists "owner manager read deployment readiness" on public.deployment_readiness_state;
create policy "owner manager read deployment readiness"
on public.deployment_readiness_state for select
to authenticated
using (public.current_staff_role() in ('owner','manager'));

create or replace function public.update_deployment_readiness(
  p_target_host text,
  p_target_environment text,
  p_staging_url text,
  p_source_prepared boolean,
  p_runtime_env_prepared boolean,
  p_healthcheck_prepared boolean,
  p_build_verified boolean,
  p_healthcheck_verified boolean,
  p_public_site_verified boolean,
  p_auth_login_verified boolean,
  p_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update deployment readiness';
  end if;
  if p_target_environment not in ('staging','production') then
    raise exception 'Target environment must be staging or production';
  end if;

  update public.deployment_readiness_state
  set
    target_host=nullif(trim(p_target_host),''),
    target_environment=p_target_environment,
    staging_url=nullif(trim(p_staging_url),''),
    source_prepared=coalesce(p_source_prepared,false),
    runtime_env_prepared=coalesce(p_runtime_env_prepared,false),
    healthcheck_prepared=coalesce(p_healthcheck_prepared,false),
    build_verified=coalesce(p_build_verified,false),
    healthcheck_verified=coalesce(p_healthcheck_verified,false),
    public_site_verified=coalesce(p_public_site_verified,false),
    auth_login_verified=coalesce(p_auth_login_verified,false),
    notes=nullif(trim(p_notes),''),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'update_deployment_readiness','deployment_readiness_state',null,
    (select to_jsonb(d) from public.deployment_readiness_state d where d.id=1)
  );
end;
$$;

create or replace function public.deployment_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.deployment_readiness_state%rowtype;
  v_required_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v from public.deployment_readiness_state where id=1;

  v_required_pass :=
    v.source_prepared
    and v.runtime_env_prepared
    and v.healthcheck_prepared
    and v.build_verified
    and v.healthcheck_verified
    and v.public_site_verified
    and v.auth_login_verified;

  return jsonb_build_object(
    'target_host',v.target_host,
    'target_environment',v.target_environment,
    'staging_url',v.staging_url,
    'source_prepared',v.source_prepared,
    'runtime_env_prepared',v.runtime_env_prepared,
    'healthcheck_prepared',v.healthcheck_prepared,
    'build_verified',v.build_verified,
    'healthcheck_verified',v.healthcheck_verified,
    'public_site_verified',v.public_site_verified,
    'auth_login_verified',v.auth_login_verified,
    'deployment_gate',case when v_required_pass then 'pass' else 'pending' end,
    'notes',v.notes,
    'updated_at',v.updated_at
  );
end;
$$;

revoke all on function public.update_deployment_readiness(text,text,text,boolean,boolean,boolean,boolean,boolean,boolean,boolean,text) from public,anon;
revoke all on function public.deployment_readiness_summary() from public,anon;
grant execute on function public.update_deployment_readiness(text,text,text,boolean,boolean,boolean,boolean,boolean,boolean,boolean,text) to authenticated;
grant execute on function public.deployment_readiness_summary() to authenticated;

update public.system_release_state
set app_version='0.35.0',
    latest_migration=34,
    release_stage='deployment_preparation',
    updated_at=now()
where id=1;
