-- DS Bakery v0.36 / Migration 035
-- Staging hardening consolidation: dashboard permissions, RLS performance/policy cleanup,
-- duplicate-index removal, and restricted execution of internal helper RPCs.

-- Dashboard/security permission keys required by the practical Owner dashboard and access checks.
insert into public.app_permissions(permission_key,description,critical)
values
  ('dashboard:view','View the management dashboard',false),
  ('security:manage','Manage security controls and security settings',true)
on conflict (permission_key) do update
set description=excluded.description,
    critical=excluded.critical;

insert into public.role_permission_defaults(role,permission_key,allowed)
values
  ('owner','dashboard:view',true),
  ('manager','dashboard:view',true),
  ('cashier','dashboard:view',false),
  ('baker','dashboard:view',false),
  ('storekeeper','dashboard:view',false),
  ('owner','security:manage',true),
  ('manager','security:manage',false),
  ('cashier','security:manage',false),
  ('baker','security:manage',false),
  ('storekeeper','security:manage',false)
on conflict (role,permission_key) do update set allowed=excluded.allowed;

-- Confirmed duplicate index.
drop index if exists public.communication_logs_customer_created_idx;

-- RLS: use a single read policy plus command-specific write policies where possible.
drop policy if exists "owner manages profiles" on public.profiles;
drop policy if exists "owner insert profiles" on public.profiles;
drop policy if exists "owner update profiles" on public.profiles;
drop policy if exists "owner delete profiles" on public.profiles;
drop policy if exists "staff can read own profile" on public.profiles;
create policy "staff can read own profile" on public.profiles for select to authenticated
using (id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "owner insert profiles" on public.profiles for insert to authenticated
with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update profiles" on public.profiles for update to authenticated
using (public.current_staff_role()='owner'::public.staff_role)
with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete profiles" on public.profiles for delete to authenticated
using (public.current_staff_role()='owner'::public.staff_role);

-- Auth init-plan optimization on hot read paths.
drop policy if exists "staff read permitted cash movements" on public.cash_movements;
create policy "staff read permitted cash movements" on public.cash_movements for select
using (created_by=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

drop policy if exists "production staff read plan items" on public.production_plan_items;
create policy "production staff read plan items" on public.production_plan_items for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or (public.current_staff_role()='baker'::public.staff_role and assigned_baker_id=(select auth.uid())));

drop policy if exists "production staff read runs" on public.production_runs;
create policy "production staff read runs" on public.production_runs for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or confirmed_by=(select auth.uid()));

drop policy if exists "staff read relevant waste" on public.waste_events;
create policy "staff read relevant waste" on public.waste_events for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or recorded_by=(select auth.uid()) or (public.current_staff_role()='storekeeper'::public.staff_role and waste_type='raw_material'::public.waste_type));

drop policy if exists "staff read own or management attendance" on public.attendance_records;
create policy "staff read own or management attendance" on public.attendance_records for select
using (staff_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

drop policy if exists "staff read relevant baker tasks" on public.baker_tasks;
create policy "staff read relevant baker tasks" on public.baker_tasks for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or assigned_baker_id=(select auth.uid()));

drop policy if exists "production staff read consumption" on public.production_consumptions;
create policy "production staff read consumption" on public.production_consumptions for select
using (
  public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role,'storekeeper'::public.staff_role])
  or (
    public.current_staff_role()='baker'::public.staff_role
    and exists (
      select 1
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=production_consumptions.production_run_id
        and (pr.confirmed_by=(select auth.uid()) or ppi.assigned_baker_id=(select auth.uid()))
    )
  )
);

-- Attendance settings.
drop policy if exists "owner manage attendance settings" on public.attendance_settings;
drop policy if exists "owner insert attendance settings" on public.attendance_settings;
drop policy if exists "owner update attendance settings" on public.attendance_settings;
drop policy if exists "owner delete attendance settings" on public.attendance_settings;
alter policy "staff read attendance settings" on public.attendance_settings to authenticated;
create policy "owner insert attendance settings" on public.attendance_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update attendance settings" on public.attendance_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete attendance settings" on public.attendance_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Business settings.
drop policy if exists "owner manage business settings" on public.business_settings;
drop policy if exists "owner insert business settings" on public.business_settings;
drop policy if exists "owner update business settings" on public.business_settings;
drop policy if exists "owner delete business settings" on public.business_settings;
alter policy "management read business settings" on public.business_settings to authenticated;
create policy "owner insert business settings" on public.business_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update business settings" on public.business_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete business settings" on public.business_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Cashier shifts.
drop policy if exists "manager owner manage shifts" on public.cashier_shifts;
drop policy if exists "management insert cashier shifts" on public.cashier_shifts;
drop policy if exists "management update cashier shifts" on public.cashier_shifts;
drop policy if exists "management delete cashier shifts" on public.cashier_shifts;
drop policy if exists "sales staff read own shifts" on public.cashier_shifts;
create policy "sales staff read own shifts" on public.cashier_shifts for select to authenticated
using (cashier_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management insert cashier shifts" on public.cashier_shifts for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update cashier shifts" on public.cashier_shifts for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete cashier shifts" on public.cashier_shifts for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Daily closings.
drop policy if exists "owner manager manage closings" on public.daily_closings;
drop policy if exists "management insert daily closings" on public.daily_closings;
drop policy if exists "management update daily closings" on public.daily_closings;
drop policy if exists "management delete daily closings" on public.daily_closings;
alter policy "owner manager read closings" on public.daily_closings to authenticated;
create policy "management insert daily closings" on public.daily_closings for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update daily closings" on public.daily_closings for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete daily closings" on public.daily_closings for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Product categories.
drop policy if exists "owner manager manage categories" on public.product_categories;
drop policy if exists "management insert product categories" on public.product_categories;
drop policy if exists "management update product categories" on public.product_categories;
drop policy if exists "management delete product categories" on public.product_categories;
alter policy "staff read categories" on public.product_categories to authenticated;
create policy "management insert product categories" on public.product_categories for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update product categories" on public.product_categories for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete product categories" on public.product_categories for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Staff work shifts.
drop policy if exists "management schedules" on public.staff_work_shifts;
drop policy if exists "management insert work shifts" on public.staff_work_shifts;
drop policy if exists "management update work shifts" on public.staff_work_shifts;
drop policy if exists "management delete work shifts" on public.staff_work_shifts;
drop policy if exists "staff read own or management schedules" on public.staff_work_shifts;
create policy "staff read own or management schedules" on public.staff_work_shifts for select to authenticated
using (staff_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management insert work shifts" on public.staff_work_shifts for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update work shifts" on public.staff_work_shifts for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete work shifts" on public.staff_work_shifts for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Waste settings.
drop policy if exists "owner manage waste settings" on public.waste_settings;
drop policy if exists "owner insert waste settings" on public.waste_settings;
drop policy if exists "owner update waste settings" on public.waste_settings;
drop policy if exists "owner delete waste settings" on public.waste_settings;
alter policy "relevant staff read waste settings" on public.waste_settings to authenticated;
create policy "owner insert waste settings" on public.waste_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update waste settings" on public.waste_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete waste settings" on public.waste_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Internal helpers are callable only through audited parent RPCs or server-side service role paths.
revoke execute on function public.apply_approved_raw_waste(uuid) from authenticated;
revoke execute on function public.calculate_daily_closing(date) from authenticated;
revoke execute on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) from authenticated;
revoke execute on function public.current_product_unit_cost(uuid) from authenticated;
revoke execute on function public.launch_readiness_checks() from authenticated;
revoke execute on function public.production_run_unit_cost(uuid) from authenticated;
revoke execute on function public.refresh_customer_order_total(uuid) from authenticated;
revoke execute on function public.refresh_purchase_totals(uuid) from authenticated;
revoke execute on function public.staging_placeholder_summary() from authenticated;
revoke execute on function public.sync_order_loyalty_points(uuid) from authenticated;
revoke execute on function public.sync_sale_loyalty_points(uuid) from authenticated;
revoke execute on function public.verify_approver_pin(text) from authenticated;

update public.system_release_state
set app_version='0.36.0',
    latest_migration=35,
    release_stage='staging_hardening_consolidation',
    updated_at=now()
where id=1;
