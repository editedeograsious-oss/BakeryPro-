

-- SOURCE FILE: 001_v01_bootstrap.sql

-- DS Bakery Master v0.1
create extension if not exists pgcrypto;

create type public.staff_role as enum ('owner','manager','cashier','baker','storekeeper');
create type public.record_status as enum ('active','inactive','archived');
create type public.inventory_tx_type as enum ('purchase','usage','adjustment','waste','return');
create type public.payment_method as enum ('cash','mtn_momo','airtel_money');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.staff_role not null default 'cashier',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  display_order int not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.product_categories(id),
  name text not null,
  sku text unique,
  description text,
  selling_price numeric(14,2) not null default 0 check (selling_price >= 0),
  track_recipe boolean not null default true,
  image_url text,
  notes text,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.raw_materials (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid,
  name text not null unique,
  sku text unique,
  base_unit text not null,
  purchase_pack_label text,
  purchase_pack_base_qty numeric(18,6) not null default 1 check (purchase_pack_base_qty > 0),
  current_purchase_cost numeric(14,2) not null default 0 check (current_purchase_cost >= 0),
  current_stock_qty numeric(18,6) not null default 0,
  low_stock_threshold numeric(18,6) not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  name text not null,
  yield_qty numeric(12,3) not null default 1 check (yield_qty > 0),
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index one_active_recipe_per_product on public.recipes(product_id) where active = true;

create table public.recipe_items (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_base_unit numeric(18,6) not null check (quantity_base_unit > 0),
  created_at timestamptz not null default now(),
  unique(recipe_id, raw_material_id)
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.raw_materials
  add constraint raw_material_supplier_fk
  foreign key (supplier_id) references public.suppliers(id);

create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  raw_material_id uuid not null references public.raw_materials(id),
  tx_type public.inventory_tx_type not null,
  quantity_delta numeric(18,6) not null,
  unit_cost numeric(14,6),
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'completed',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  cashier_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(12,3) not null,
  unit_price numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount >= 0),
  reference text,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  description text not null,
  amount numeric(14,2) not null check (amount >= 0),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity text not null,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_staff_role()
returns public.staff_role
language sql stable security definer set search_path=public
as $$ select role from public.profiles where id = auth.uid() $$;

alter table public.profiles enable row level security;
alter table public.product_categories enable row level security;
alter table public.products enable row level security;
alter table public.raw_materials enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_items enable row level security;
alter table public.suppliers enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.audit_logs enable row level security;

create policy "staff can read own profile" on public.profiles
for select using (id = auth.uid() or public.current_staff_role() in ('owner','manager'));

create policy "owner manages profiles" on public.profiles
for all using (public.current_staff_role() = 'owner')
with check (public.current_staff_role() = 'owner');

create policy "staff read active products" on public.products
for select using (status='active' or public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage products" on public.products
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "staff read categories" on public.product_categories
for select using (true);

create policy "owner manager manage categories" on public.product_categories
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "relevant staff read materials" on public.raw_materials
for select using (public.current_staff_role() in ('owner','manager','storekeeper','baker'));

create policy "storekeeper manager owner manage materials" on public.raw_materials
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "baker and managers read recipes" on public.recipes
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipes" on public.recipes
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "baker and managers read recipe items" on public.recipe_items
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipe items" on public.recipe_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "owner manager storekeeper read suppliers" on public.suppliers
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager storekeeper manage suppliers" on public.suppliers
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff read inventory tx" on public.inventory_transactions
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff create inventory tx" on public.inventory_transactions
for insert with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

create index products_category_idx on public.products(category_id);
create index recipe_items_recipe_idx on public.recipe_items(recipe_id);
create index inventory_tx_material_idx on public.inventory_transactions(raw_material_id, created_at desc);
create index audit_entity_idx on public.audit_logs(entity, entity_id, created_at desc);




-- SOURCE FILE: 002_phase1b_stock_purchasing.sql

-- DS Bakery Phase 1B: stock & purchasing
-- Run after supabase/schema.sql from v0.1.

create type public.purchase_status as enum ('draft','ordered','partially_received','received','cancelled');
create type public.payment_status as enum ('unpaid','partial','paid');

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  purchase_no text not null unique,
  supplier_id uuid not null references public.suppliers(id),
  purchase_date date not null default current_date,
  supplier_reference text,
  status public.purchase_status not null default 'draft',
  payment_status public.payment_status not null default 'unpaid',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  amount_paid numeric(14,2) not null default 0 check (amount_paid >= 0),
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (amount_paid <= total_amount)
);

create table if not exists public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  ordered_qty_base numeric(18,6) not null check (ordered_qty_base > 0),
  received_qty_base numeric(18,6) not null default 0 check (received_qty_base >= 0),
  unit_cost_base numeric(14,6) not null check (unit_cost_base >= 0),
  line_total numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  unique(purchase_id, raw_material_id)
);

create table if not exists public.purchase_payments (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  amount numeric(14,2) not null check (amount > 0),
  method text not null,
  reference text,
  paid_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

-- Add purchase linkage to the stock ledger.
alter table public.inventory_transactions
  add column if not exists purchase_item_id uuid references public.purchase_items(id);

-- View current unit cost from the existing pack-cost fields.
create or replace view public.raw_material_costs as
select
  rm.*,
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_unit_cost,
  rm.current_stock_qty *
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_stock_value
from public.raw_materials rm;

create or replace view public.low_stock_materials as
select
  id,name,sku,base_unit,current_stock_qty,low_stock_threshold,
  case when low_stock_threshold > 0 then current_stock_qty / low_stock_threshold else null end as stock_ratio
from public.raw_materials
where status='active'
  and current_stock_qty <= low_stock_threshold;

create or replace view public.supplier_balances as
select
  s.id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(p.total_amount),0)::numeric(14,2) as total_purchases,
  coalesce(sum(p.amount_paid),0)::numeric(14,2) as total_paid,
  coalesce(sum(p.total_amount - p.amount_paid),0)::numeric(14,2) as outstanding_balance
from public.suppliers s
left join public.purchases p
  on p.supplier_id=s.id
 and p.status <> 'cancelled'
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- Central stock ledger trigger.
create or replace function public.apply_inventory_transaction()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  old_qty numeric(18,6);
  old_unit_cost numeric(14,6);
  incoming_cost numeric(14,6);
  new_unit_cost numeric(14,6);
begin
  select
    current_stock_qty,
    case when purchase_pack_base_qty > 0
      then current_purchase_cost / purchase_pack_base_qty
      else 0 end
  into old_qty, old_unit_cost
  from public.raw_materials
  where id = new.raw_material_id
  for update;

  -- For purchase receipts, update standard ingredient cost using weighted average.
  if new.tx_type = 'purchase' and new.quantity_delta > 0 and new.unit_cost is not null then
    incoming_cost := new.unit_cost;
    if old_qty <= 0 then
      new_unit_cost := incoming_cost;
    else
      new_unit_cost :=
        ((old_qty * old_unit_cost) + (new.quantity_delta * incoming_cost))
        / (old_qty + new.quantity_delta);
    end if;

    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      current_purchase_cost = new_unit_cost * purchase_pack_base_qty,
      updated_at = now()
    where id = new.raw_material_id;
  else
    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      updated_at = now()
    where id = new.raw_material_id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_apply_inventory_transaction on public.inventory_transactions;
create trigger trg_apply_inventory_transaction
after insert on public.inventory_transactions
for each row execute function public.apply_inventory_transaction();

-- Receive part or all of a purchase line and post the stock movement.
create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_remaining numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized';
  end if;

  if p_receive_qty_base <= 0 then
    raise exception 'Received quantity must be greater than zero';
  end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then
    raise exception 'Purchase item not found';
  end if;

  v_remaining := v_item.ordered_qty_base - v_item.received_qty_base;
  if p_receive_qty_base > v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  update public.purchase_items
  set received_qty_base = received_qty_base + p_receive_qty_base
  where id = p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase',v_item.purchase_id,v_item.id,auth.uid(),'Purchase receipt'
  );

  update public.purchases p
  set status =
    case
      when not exists (
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base < pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'receive_stock','purchase_item',p_purchase_item_id,
    jsonb_build_object('received_qty_base',p_receive_qty_base));
end;
$$;

create or replace function public.refresh_purchase_totals(p_purchase_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_total numeric(14,2);
  v_paid numeric(14,2);
begin
  select coalesce(sum(ordered_qty_base * unit_cost_base),0)::numeric(14,2)
    into v_total
  from public.purchase_items
  where purchase_id=p_purchase_id;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.purchase_payments
  where purchase_id=p_purchase_id;

  update public.purchases
  set
    subtotal=v_total,
    total_amount=greatest(v_total-discount,0),
    amount_paid=v_paid,
    payment_status=case
      when v_paid <= 0 then 'unpaid'::public.payment_status
      when v_paid >= greatest(v_total-discount,0) then 'paid'::public.payment_status
      else 'partial'::public.payment_status
    end,
    updated_at=now()
  where id=p_purchase_id;
end;
$$;

alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.purchase_payments enable row level security;

create policy "purchasing staff read purchases" on public.purchases
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchases" on public.purchases
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff read purchase items" on public.purchase_items
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchase items" on public.purchase_items
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read purchase payments" on public.purchase_payments
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager create purchase payments" on public.purchase_payments
for insert with check (public.current_staff_role() in ('owner','manager'));

create index if not exists purchases_supplier_idx on public.purchases(supplier_id,purchase_date desc);
create index if not exists purchase_items_purchase_idx on public.purchase_items(purchase_id);
create index if not exists purchase_payments_purchase_idx on public.purchase_payments(purchase_id);


-- SOURCE FILE: 003_phase1c_pos.sql

-- DS Bakery Phase 1C: cashier POS

-- Add fields to existing sales table.
alter table public.sales
  add column if not exists sale_no text unique,
  add column if not exists held boolean not null default false,
  add column if not exists notes text,
  add column if not exists voided_at timestamptz,
  add column if not exists voided_by uuid references public.profiles(id),
  add column if not exists void_reason text,
  add column if not exists refund_total numeric(14,2) not null default 0;

alter table public.sale_items
  add column if not exists unit_cost_snapshot numeric(14,6),
  add column if not exists gross_profit_snapshot numeric(14,2);

alter table public.payments
  add column if not exists status text not null default 'completed',
  add column if not exists created_by uuid references public.profiles(id);

-- Secure approval PIN hash for owner/manager.
alter table public.profiles
  add column if not exists approval_pin_hash text;

create or replace function public.set_my_approval_pin(p_pin text)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can set an approval PIN';
  end if;
  if length(p_pin) < 4 or length(p_pin) > 10 then
    raise exception 'Approval PIN must be 4 to 10 characters';
  end if;

  update public.profiles
  set approval_pin_hash = crypt(p_pin, gen_salt('bf')),
      updated_at = now()
  where id = auth.uid();

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'set_approval_pin','profile',auth.uid(),jsonb_build_object('changed',true));
end;
$$;

create or replace function public.verify_approver_pin(p_pin text)
returns uuid
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
begin
  select id into v_approver
  from public.profiles
  where active=true
    and role in ('owner','manager')
    and approval_pin_hash is not null
    and approval_pin_hash = crypt(p_pin, approval_pin_hash)
  limit 1;

  if v_approver is null then
    raise exception 'Invalid approval PIN';
  end if;

  return v_approver;
end;
$$;

-- Helper sale number
create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(now(),'YYYYMMDD') || '-' ||
         lpad((floor(random()*100000))::int::text,5,'0')
$$;

-- Atomic sale creation.
create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text := public.next_sale_no();
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if jsonb_array_length(p_items) = 0 then
    raise exception 'Sale must contain at least one item';
  end if;

  -- Calculate subtotal from authoritative current product prices.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then
      raise exception 'Invalid or inactive product';
    end if;

    v_qty := greatest((v_item->>'quantity')::numeric,0);
    if v_qty <= 0 then raise exception 'Quantity must be greater than zero'; end if;
    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount > v_subtotal then p_discount := v_subtotal; end if;
  v_total := v_subtotal - p_discount;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;
      if v_method in ('mtn_momo','airtel_money') and coalesce(v_payment->>'reference','')='' then
        raise exception 'Mobile Money reference is required';
      end if;
      v_paid := v_paid + greatest((v_payment->>'amount')::numeric,0);
    end loop;

    if v_paid < v_total then
      raise exception 'Payments are less than sale total';
    end if;
  end if;

  insert into public.sales(id,sale_no,status,held,subtotal,discount,total,cashier_id,notes)
  values(v_sale_id,v_sale_no,case when p_hold then 'held' else 'completed' end,p_hold,v_subtotal,p_discount,v_total,auth.uid(),p_notes);

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select p.selling_price,
           coalesce((
             select sum(ri.quantity_base_unit * (rm.current_purchase_cost/rm.purchase_pack_base_qty)) / r.yield_qty
             from public.recipes r
             join public.recipe_items ri on ri.recipe_id=r.id
             join public.raw_materials rm on rm.id=ri.raw_material_id
             where r.product_id=p.id and r.active=true
             group by r.id,r.yield_qty
           ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(sale_id,method,amount,reference,created_by)
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(v_payment->>'reference',''),
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),case when p_hold then 'hold_sale' else 'complete_sale' end,'sale',v_sale_id,
    jsonb_build_object('sale_no',v_sale_no,'subtotal',v_subtotal,'discount',p_discount,'total',v_total));

  return v_sale_id;
end;
$$;

-- Cancel or refund with manager/owner PIN approval.
create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then
    raise exception 'Unsupported action';
  end if;

  if coalesce(trim(p_reason),'')='' then
    raise exception 'Reason is required';
  end if;

  v_approver := public.verify_approver_pin(p_approval_pin);

  select * into v_sale from public.sales where id=p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status='refunded' then raise exception 'Refunded sale cannot be cancelled'; end if;
    update public.sales
      set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    v_refund := coalesce(p_refund_amount,v_sale.total);
    if v_refund <= 0 or v_refund > (v_sale.total - v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    update public.sales
      set refund_total=refund_total+v_refund,
          status=case when refund_total+v_refund >= total then 'refunded' else 'partially_refunded' end
    where id=p_sale_id;

    insert into public.payments(sale_id,method,amount,reference,status,created_by)
    values(p_sale_id,'cash',-v_refund,'REFUND','refunded',v_approver);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;

alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.payments enable row level security;

drop policy if exists "sales staff read sales" on public.sales;
create policy "sales staff read sales" on public.sales
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sales" on public.sales;
create policy "sales staff create sales" on public.sales
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read sale items" on public.sale_items;
create policy "sales staff read sale items" on public.sale_items
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sale items" on public.sale_items;
create policy "sales staff create sale items" on public.sale_items
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read payments" on public.payments;
create policy "sales staff read payments" on public.payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create payments" on public.payments;
create policy "sales staff create payments" on public.payments
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sales_created_idx on public.sales(created_at desc);
create index if not exists sales_cashier_idx on public.sales(cashier_id,created_at desc);
create index if not exists sale_items_sale_idx on public.sale_items(sale_id);
create index if not exists payments_sale_idx on public.payments(sale_id);


-- SOURCE FILE: 004_phase1d_closing.sql

-- DS Bakery Phase 1D: expenses, cashier shifts and daily closing

create type public.cash_movement_type as enum ('cash_in','cash_out');
create type public.shift_status as enum ('open','closed');
create type public.closing_status as enum ('draft','closed');

alter table public.expenses
  add column if not exists payment_method public.payment_method not null default 'cash',
  add column if not exists reference text,
  add column if not exists shift_id uuid;

create table if not exists public.cashier_shifts (
  id uuid primary key default gen_random_uuid(),
  cashier_id uuid not null references public.profiles(id),
  opened_by uuid not null references public.profiles(id),
  opened_at timestamptz not null default now(),
  opening_float numeric(14,2) not null default 0 check (opening_float >= 0),
  status public.shift_status not null default 'open',
  closed_at timestamptz,
  closed_by uuid references public.profiles(id),
  closing_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.cash_movements (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid references public.cashier_shifts(id),
  movement_type public.cash_movement_type not null,
  amount numeric(14,2) not null check (amount > 0),
  reason text not null,
  reference text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.sales
  add column if not exists shift_id uuid references public.cashier_shifts(id);

alter table public.expenses
  add constraint expenses_shift_fk
  foreign key (shift_id) references public.cashier_shifts(id);

create table if not exists public.daily_closings (
  id uuid primary key default gen_random_uuid(),
  business_date date not null unique,
  status public.closing_status not null default 'draft',

  opening_float numeric(14,2) not null default 0,
  cash_sales numeric(14,2) not null default 0,
  mtn_momo_sales numeric(14,2) not null default 0,
  airtel_money_sales numeric(14,2) not null default 0,

  cash_in numeric(14,2) not null default 0,
  cash_out numeric(14,2) not null default 0,
  cash_expenses numeric(14,2) not null default 0,
  momo_expenses numeric(14,2) not null default 0,

  expected_cash numeric(14,2) not null default 0,
  counted_cash numeric(14,2),
  cash_variance numeric(14,2),

  transaction_count int not null default 0,
  notes text,

  prepared_by uuid references public.profiles(id),
  closed_by uuid references public.profiles(id),
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result public.daily_closings;
  v_opening numeric(14,2);
  v_cash_sales numeric(14,2);
  v_mtn numeric(14,2);
  v_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count int;
  v_expected numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where opened_at::date = p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0),
    count(distinct s.id)
  into v_cash_sales,v_mtn,v_airtel,v_tx_count
  from public.sales s
  left join public.payments p on p.sale_id=s.id and p.status='completed'
  where s.created_at::date=p_business_date
    and s.status in ('completed','partially_refunded');

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where created_at::date=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where created_at::date=p_business_date;

  v_expected := v_opening + v_cash_sales + v_cash_in - v_cash_out - v_cash_exp;

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,v_opening,v_cash_sales,v_mtn,v_airtel,
    v_cash_in,v_cash_out,v_cash_exp,v_momo_exp,v_expected,
    v_tx_count,auth.uid()
  )
  on conflict (business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

create or replace function public.close_business_day(
  p_business_date date,
  p_counted_cash numeric,
  p_notes text default null
)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_close public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can close the business day';
  end if;

  select * into v_close
  from public.calculate_daily_closing(p_business_date);

  if v_close.status='closed' then
    raise exception 'Business day already closed';
  end if;

  update public.daily_closings
  set
    counted_cash=p_counted_cash,
    cash_variance=p_counted_cash-expected_cash,
    notes=p_notes,
    status='closed',
    closed_by=auth.uid(),
    closed_at=now(),
    updated_at=now()
  where business_date=p_business_date
  returning * into v_close;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_business_day','daily_closing',v_close.id,
    jsonb_build_object(
      'business_date',p_business_date,
      'expected_cash',v_close.expected_cash,
      'counted_cash',v_close.counted_cash,
      'variance',v_close.cash_variance
    )
  );

  return v_close;
end;
$$;

alter table public.cashier_shifts enable row level security;
alter table public.cash_movements enable row level security;
alter table public.daily_closings enable row level security;

create policy "sales staff read own shifts" on public.cashier_shifts
for select using (
  cashier_id=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "manager owner manage shifts" on public.cashier_shifts
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "cashier create own cash movement" on public.cash_movements
for insert with check (
  created_by=auth.uid()
  and public.current_staff_role() in ('owner','manager','cashier')
);

create policy "staff read permitted cash movements" on public.cash_movements
for select using (
  created_by=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "owner manager read closings" on public.daily_closings
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage closings" on public.daily_closings
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create index if not exists cashier_shifts_cashier_idx on public.cashier_shifts(cashier_id,opened_at desc);
create index if not exists cash_movements_shift_idx on public.cash_movements(shift_id,created_at desc);
create index if not exists daily_closings_date_idx on public.daily_closings(business_date desc);


-- SOURCE FILE: 005_phase1e_dashboard_reports.sql

-- DS Bakery Phase 1E: owner dashboard and reports

create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  si.quantity,
  si.line_total as sales_amount,
  coalesce(si.unit_cost_snapshot,0) * si.quantity as cogs_amount,
  coalesce(si.gross_profit_snapshot, si.line_total - (coalesce(si.unit_cost_snapshot,0) * si.quantity)) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
where s.status in ('completed','partially_refunded');

create or replace view public.best_selling_products_30d as
select
  product_id,
  product_name,
  sum(quantity)::numeric(14,3) as units_sold,
  sum(sales_amount)::numeric(14,2) as sales_amount,
  sum(gross_profit_amount)::numeric(14,2) as gross_profit_amount
from public.sale_profit_lines
where created_at >= now() - interval '30 days'
group by product_id,product_name
order by units_sold desc,sales_amount desc;

create or replace function public.period_start(p_period text)
returns timestamptz
language plpgsql
stable
as $$
begin
  case p_period
    when 'day' then return date_trunc('day',now());
    when 'week' then return date_trunc('week',now());
    when 'month' then return date_trunc('month',now());
    else raise exception 'Unsupported period';
  end case;
end;
$$;

create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language sql
security definer
set search_path=public
as $$
with bounds as (
  select public.period_start(p_period) as start_at
),
sales_summary as (
  select
    coalesce(sum(s.total - coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
    count(*)::bigint as transaction_count
  from public.sales s,bounds b
  where s.created_at >= b.start_at
    and s.status in ('completed','partially_refunded')
),
payment_summary as (
  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0)::numeric(14,2) as cash_sales,
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0)::numeric(14,2) as mtn_momo_sales,
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)::numeric(14,2) as airtel_money_sales
  from public.payments p
  join public.sales s on s.id=p.sale_id
  join bounds b on true
  where p.created_at >= b.start_at
    and p.status='completed'
    and s.status in ('completed','partially_refunded')
),
profit_summary as (
  select
    coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
  from public.sale_profit_lines spl,bounds b
  where spl.created_at >= b.start_at
),
expense_summary as (
  select
    coalesce(sum(amount),0)::numeric(14,2) as expenses
  from public.expenses e,bounds b
  where e.created_at >= b.start_at
)
select
  b.start_at,
  ss.sales,
  ps.cash_sales,
  ps.mtn_momo_sales,
  ps.airtel_money_sales,
  prs.gross_profit,
  es.expenses,
  (prs.gross_profit-es.expenses)::numeric(14,2) as estimated_operating_profit,
  ss.transaction_count,
  case when ss.transaction_count>0 then (ss.sales/ss.transaction_count)::numeric(14,2) else 0 end as average_sale
from bounds b,sales_summary ss,payment_summary ps,profit_summary prs,expense_summary es;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

create or replace function public.management_report(
  p_start_date date,
  p_end_date date
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sales numeric(14,2);
  v_cogs numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_purchases numeric(14,2);
  v_transactions bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_end_date < p_start_date then
    raise exception 'Invalid date range';
  end if;

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(cogs_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_cogs,v_gross
  from public.sale_profit_lines
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(total_amount),0)
  into v_purchases
  from public.purchases
  where purchase_date between p_start_date and p_end_date
    and status <> 'cancelled';

  select count(*)
  into v_transactions
  from public.sales
  where created_at >= p_start_date
    and created_at < (p_end_date + 1)
    and status in ('completed','partially_refunded');

  return jsonb_build_object(
    'start_date',p_start_date,
    'end_date',p_end_date,
    'sales',v_sales,
    'cogs',v_cogs,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'purchases',v_purchases,
    'transactions',v_transactions
  );
end;
$$;

grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;
grant execute on function public.management_report(date,date) to authenticated;

-- Owner and manager may read profitability views.
alter view public.sale_profit_lines set (security_invoker = true);
alter view public.best_selling_products_30d set (security_invoker = true);


-- SOURCE FILE: 006_phase1f_security_reliability.sql

-- DS Bakery Phase 1F: security and reliability

alter table public.profiles
  add column if not exists disabled_at timestamptz,
  add column if not exists disabled_by uuid references public.profiles(id),
  add column if not exists session_version integer not null default 1,
  add column if not exists require_password_reset boolean not null default false;

-- Active role helper: disabled/inactive users resolve to NULL.
create or replace function public.current_staff_role()
returns public.staff_role
language sql
stable
security definer
set search_path=public
as $$
  select role
  from public.profiles
  where id=auth.uid()
    and active=true
    and disabled_at is null
$$;

create or replace function public.is_active_staff()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles
    where id=auth.uid()
      and active=true
      and disabled_at is null
  )
$$;

-- Owner-only staff status control.
create or replace function public.set_staff_active(
  p_staff_id uuid,
  p_active boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.profiles%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may enable or disable staff';
  end if;

  if p_staff_id = auth.uid() and p_active=false then
    raise exception 'Owner cannot disable own currently authenticated account';
  end if;

  select * into v_before from public.profiles where id=p_staff_id for update;
  if not found then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set
    active=p_active,
    disabled_at=case when p_active then null else now() end,
    disabled_by=case when p_active then null else auth.uid() end,
    session_version=session_version+1,
    updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_active then 'enable_staff' else 'disable_staff' end,
    'profile',
    p_staff_id,
    jsonb_build_object('active',v_before.active,'role',v_before.role),
    jsonb_build_object('active',p_active,'session_version',v_before.session_version+1)
  );
end;
$$;

create or replace function public.change_staff_role(
  p_staff_id uuid,
  p_role public.staff_role
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old_role public.staff_role;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may change staff roles';
  end if;

  if p_staff_id=auth.uid() then
    raise exception 'Owner cannot change own role from the active session';
  end if;

  select role into v_old_role from public.profiles where id=p_staff_id for update;
  if v_old_role is null then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set role=p_role,session_version=session_version+1,updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'change_staff_role','profile',p_staff_id,
    jsonb_build_object('role',v_old_role),
    jsonb_build_object('role',p_role)
  );
end;
$$;

-- View safe staff status metadata.
create or replace view public.staff_security_status
with (security_invoker=true)
as
select
  id,full_name,role,active,disabled_at,disabled_by,
  session_version,require_password_reset,created_at,updated_at
from public.profiles;

-- Owner/manager audit browsing. Inserts remain application/RPC controlled.
drop policy if exists "owner manager read audit logs" on public.audit_logs;
create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

-- Harden core financial tables: disabled users lose role through current_staff_role().
-- Existing policies continue to call current_staff_role(), so replacing that helper
-- applies disabled-profile enforcement across modules.

create index if not exists profiles_active_role_idx on public.profiles(active,role);
create index if not exists audit_actor_created_idx on public.audit_logs(actor_id,created_at desc);

grant execute on function public.set_staff_active(uuid,boolean) to authenticated;
grant execute on function public.change_staff_role(uuid,public.staff_role) to authenticated;


-- SOURCE FILE: 007_phase2a_kitchen_production.sql

-- DS Bakery Phase 2A: kitchen production and baker tasks

create type public.production_status as enum ('planned','in_progress','complete','cancelled');
create type public.production_shift as enum ('morning','afternoon','evening');

create table if not exists public.production_plan_items (
  id uuid primary key default gen_random_uuid(),
  business_date date not null default current_date,
  product_id uuid not null references public.products(id),
  assigned_baker_id uuid references public.profiles(id),
  shift public.production_shift not null default 'morning',
  planned_qty numeric(14,3) not null check (planned_qty > 0),
  produced_qty numeric(14,3) not null default 0 check (produced_qty >= 0),
  status public.production_status not null default 'planned',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (produced_qty <= planned_qty)
);

create table if not exists public.production_runs (
  id uuid primary key default gen_random_uuid(),
  plan_item_id uuid not null references public.production_plan_items(id) on delete restrict,
  quantity_produced numeric(14,3) not null check (quantity_produced > 0),
  confirmed_by uuid not null references public.profiles(id),
  confirmed_at timestamptz not null default now()
);

create table if not exists public.production_consumptions (
  id uuid primary key default gen_random_uuid(),
  production_run_id uuid not null references public.production_runs(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_used_base numeric(18,6) not null check (quantity_used_base > 0),
  unit_cost_snapshot numeric(14,6) not null default 0,
  inventory_transaction_id uuid not null references public.inventory_transactions(id),
  created_at timestamptz not null default now()
);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_item record;
  v_required numeric(18,6);
  v_stock numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_quantity_produced <= 0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then
    raise exception 'Production plan item not found';
  end if;

  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id <> auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining := v_plan.planned_qty - v_plan.produced_qty;
  if p_quantity_produced > v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id
    and active=true
  limit 1;

  if not found then
    raise exception 'Product has no active recipe';
  end if;

  -- First pass: verify every required ingredient has enough stock.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;

    if v_item.current_stock_qty < v_required then
      raise exception 'Insufficient stock for raw material %', v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(id,plan_item_id,quantity_produced,confirmed_by)
  values(v_run_id,p_plan_item_id,p_quantity_produced,auth.uid());

  -- Second pass: post stock consumption ledger entries.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;
    v_unit_cost := v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,
      'usage',
      -v_required,
      v_unit_cost,
      'production_run',
      v_run_id,
      auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced >= planned_qty
        then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    'confirm_production',
    'production_run',
    v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty > 0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=current_date;

alter table public.production_plan_items enable row level security;
alter table public.production_runs enable row level security;
alter table public.production_consumptions enable row level security;

create policy "production staff read plan items" on public.production_plan_items
for select using (
  public.current_staff_role() in ('owner','manager')
  or (public.current_staff_role()='baker' and assigned_baker_id=auth.uid())
);

create policy "owner manager manage plan items" on public.production_plan_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "production staff read runs" on public.production_runs
for select using (
  public.current_staff_role() in ('owner','manager')
  or confirmed_by=auth.uid()
);

create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper','baker')
);

grant execute on function public.confirm_production_run(uuid,numeric) to authenticated;

create index if not exists production_plan_date_idx
  on public.production_plan_items(business_date,status);

create index if not exists production_plan_baker_idx
  on public.production_plan_items(assigned_baker_id,business_date);

create index if not exists production_runs_plan_idx
  on public.production_runs(plan_item_id,confirmed_at desc);

create index if not exists production_consumption_run_idx
  on public.production_consumptions(production_run_id);


-- SOURCE FILE: 008_phase2b_waste_production_control.sql

-- DS Bakery Phase 2B: waste & production control
create type public.waste_type as enum ('finished_product','raw_material');
create type public.waste_approval_status as enum ('pending','approved','rejected');

create table public.waste_settings (
  id integer primary key default 1 check (id=1),
  approval_threshold numeric(14,2) not null default 50000 check (approval_threshold >= 0),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);
insert into public.waste_settings(id,approval_threshold) values(1,50000) on conflict (id) do nothing;

create table public.waste_events (
  id uuid primary key default gen_random_uuid(),
  waste_type public.waste_type not null,
  product_id uuid references public.products(id),
  raw_material_id uuid references public.raw_materials(id),
  production_run_id uuid references public.production_runs(id),
  quantity numeric(18,6) not null check (quantity > 0),
  reason text not null,
  notes text,
  unit_cost_snapshot numeric(14,6) not null default 0,
  total_cost numeric(14,2) not null default 0,
  approval_status public.waste_approval_status not null default 'pending',
  recorded_by uuid not null references public.profiles(id),
  recorded_at timestamptz not null default now(),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  decision_note text,
  inventory_transaction_id uuid references public.inventory_transactions(id),
  check ((waste_type='finished_product' and product_id is not null and raw_material_id is null) or (waste_type='raw_material' and raw_material_id is not null and product_id is null))
);

create or replace function public.current_product_unit_cost(p_product_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(ri.quantity_base_unit * case when rm.purchase_pack_base_qty>0 then rm.current_purchase_cost/rm.purchase_pack_base_qty else 0 end)/r.yield_qty
  from public.recipes r join public.recipe_items ri on ri.recipe_id=r.id join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.product_id=p_product_id and r.active=true group by r.id,r.yield_qty limit 1),0)
$$;

create or replace function public.production_run_unit_cost(p_run_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(pc.quantity_used_base*pc.unit_cost_snapshot)/pr.quantity_produced
  from public.production_runs pr join public.production_consumptions pc on pc.production_run_id=pr.id
  where pr.id=p_run_id group by pr.id,pr.quantity_produced),0)
$$;

create or replace function public.apply_approved_raw_waste(p_waste_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_waste public.waste_events%rowtype; v_stock numeric; v_tx_id uuid;
begin
  select * into v_waste from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_waste.waste_type<>'raw_material' or v_waste.inventory_transaction_id is not null or v_waste.approval_status<>'approved' then return; end if;
  select current_stock_qty into v_stock from public.raw_materials where id=v_waste.raw_material_id for update;
  if v_stock < v_waste.quantity then raise exception 'Insufficient raw-material stock for waste approval'; end if;
  insert into public.inventory_transactions(raw_material_id,tx_type,quantity_delta,unit_cost,reference_type,reference_id,created_by,notes)
  values(v_waste.raw_material_id,'waste',-v_waste.quantity,v_waste.unit_cost_snapshot,'waste_event',v_waste.id,coalesce(v_waste.approved_by,v_waste.recorded_by),'Approved raw-material waste: '||v_waste.reason)
  returning id into v_tx_id;
  update public.waste_events set inventory_transaction_id=v_tx_id where id=v_waste.id;
end; $$;

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,p_quantity numeric,p_reason text,p_product_id uuid default null,p_raw_material_id uuid default null,p_production_run_id uuid default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_role public.staff_role; v_unit_cost numeric(14,6); v_total numeric(14,2); v_threshold numeric(14,2); v_status public.waste_approval_status; v_waste_id uuid:=gen_random_uuid(); v_run_product uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','baker','storekeeper') then raise exception 'Not authorized to record waste'; end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;
  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then raise exception 'Finished-product waste requires product only'; end if;
    if p_production_run_id is not null then
      select ppi.product_id into v_run_product from public.production_runs pr join public.production_plan_items ppi on ppi.id=pr.plan_item_id where pr.id=p_production_run_id;
      if v_run_product is null or v_run_product<>p_product_id then raise exception 'Production run does not match product'; end if;
      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else v_unit_cost:=public.current_product_unit_cost(p_product_id); end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then raise exception 'Raw-material waste requires raw material only'; end if;
    select case when purchase_pack_base_qty>0 then current_purchase_cost/purchase_pack_base_qty else 0 end into v_unit_cost from public.raw_materials where id=p_raw_material_id;
    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;
  v_total:=round((p_quantity*v_unit_cost)::numeric,2);
  select approval_threshold into v_threshold from public.waste_settings where id=1;
  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then v_status:='approved'; else v_status:='pending'; end if;
  insert into public.waste_events(id,waste_type,product_id,raw_material_id,production_run_id,quantity,reason,notes,unit_cost_snapshot,total_cost,approval_status,recorded_by,approved_by,approved_at)
  values(v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,p_quantity,p_reason,p_notes,v_unit_cost,v_total,v_status,auth.uid(),case when v_status='approved' then auth.uid() end,case when v_status='approved' then now() end);
  if v_status='approved' and p_waste_type='raw_material' then perform public.apply_approved_raw_waste(v_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'record_waste','waste_event',v_waste_id,jsonb_build_object('waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,'total_cost',v_total,'approval_status',v_status));
  return v_waste_id;
end; $$;

create or replace function public.decide_waste_event(p_waste_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_before public.waste_events%rowtype; v_new public.waste_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve/reject waste'; end if;
  if p_decision='approve' then v_new:='approved'; elsif p_decision='reject' then v_new:='rejected'; else raise exception 'Decision must be approve or reject'; end if;
  select * into v_before from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_before.approval_status<>'pending' then raise exception 'Only pending waste can be decided'; end if;
  update public.waste_events set approval_status=v_new,approved_by=auth.uid(),approved_at=now(),decision_note=p_note where id=p_waste_id;
  if v_new='approved' and v_before.waste_type='raw_material' then perform public.apply_approved_raw_waste(p_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data) values(auth.uid(),case when v_new='approved' then 'approve_waste' else 'reject_waste' end,'waste_event',p_waste_id,jsonb_build_object('approval_status',v_before.approval_status),jsonb_build_object('approval_status',v_new,'decision_note',p_note));
end; $$;

create or replace view public.production_control_today with (security_invoker=true) as
with plan as (
 select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty from public.production_plan_items where business_date=current_date and status<>'cancelled' group by product_id
), product_waste as (
 select product_id,coalesce(sum(quantity),0) approved_waste_qty,coalesce(sum(total_cost),0) approved_waste_cost from public.waste_events
 where waste_type='finished_product' and approval_status='approved' and recorded_at::date=current_date group by product_id
)
select p.id product_id,p.name product_name,pl.planned_qty,pl.produced_qty,coalesce(pw.approved_waste_qty,0) approved_waste_qty,
 greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,(pl.produced_qty-pl.planned_qty) production_variance,
 case when pl.produced_qty>0 then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2) else 0 end waste_rate_pct,
 coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl join public.products p on p.id=pl.product_id left join product_waste pw on pw.product_id=pl.product_id;

create or replace view public.waste_summary_30d with (security_invoker=true) as
select waste_type,approval_status,count(*) event_count,coalesce(sum(total_cost),0)::numeric(14,2) total_cost from public.waste_events where recorded_at>=now()-interval '30 days' group by waste_type,approval_status;

alter table public.waste_settings enable row level security;
alter table public.waste_events enable row level security;
create policy "management read waste settings" on public.waste_settings for select using (public.current_staff_role() in ('owner','manager'));
create policy "owner manage waste settings" on public.waste_settings for all using (public.current_staff_role()='owner') with check (public.current_staff_role()='owner');
create policy "staff read relevant waste" on public.waste_events for select using (public.current_staff_role() in ('owner','manager') or recorded_by=auth.uid() or (public.current_staff_role()='storekeeper' and waste_type='raw_material'));
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
create index waste_events_recorded_idx on public.waste_events(recorded_at desc);
create index waste_events_pending_idx on public.waste_events(approval_status,recorded_at desc);
create index waste_events_product_idx on public.waste_events(product_id,recorded_at desc) where product_id is not null;
create index waste_events_material_idx on public.waste_events(raw_material_id,recorded_at desc) where raw_material_id is not null;


-- SOURCE FILE: 009_phase2c_supplier_payables_purchase_orders.sql

-- DS Bakery Phase 2C: supplier accounts, payables and purchase-order approval

create type public.po_approval_status as enum ('pending','approved','rejected');

alter table public.purchases
  add column if not exists approval_status public.po_approval_status not null default 'pending',
  add column if not exists requested_by uuid references public.profiles(id),
  add column if not exists approved_by uuid references public.profiles(id),
  add column if not exists approved_at timestamptz,
  add column if not exists approval_note text,
  add column if not exists supplier_invoice_no text,
  add column if not exists invoice_date date,
  add column if not exists credit_terms_days integer not null default 0 check (credit_terms_days >= 0),
  add column if not exists due_date date;

update public.purchases
set requested_by=coalesce(requested_by,created_by),
    approval_status=case
      when status='draft' then 'pending'::public.po_approval_status
      else 'approved'::public.po_approval_status
    end
where requested_by is null
   or (approval_status='pending' and status<>'draft');

create or replace function public.set_purchase_due_date()
returns trigger
language plpgsql
set search_path=public
as $$
begin
  if new.due_date is null then
    new.due_date := coalesce(new.invoice_date,new.purchase_date) + new.credit_terms_days;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_set_purchase_due_date on public.purchases;
create trigger trg_set_purchase_due_date
before insert or update of invoice_date,purchase_date,credit_terms_days,due_date
on public.purchases
for each row execute function public.set_purchase_due_date();

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then
    v_approval := 'approved';
  elsif p_decision='reject' then
    v_approval := 'rejected';
  else
    raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status <> 'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',
    p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid := gen_random_uuid();
  v_remaining numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if coalesce(trim(p_method),'')='' then
    raise exception 'Payment method is required';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status <> 'approved' then raise exception 'Purchase order is not approved'; end if;

  v_remaining := v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount > v_remaining then
    raise exception 'Payment exceeds amount outstanding on purchase';
  end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by
  )
  values(
    v_payment_id,p_purchase_id,p_amount,p_method,nullif(trim(p_reference),''),now(),auth.uid()
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date < current_date
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled'
      and p.total_amount>p.amount_paid
    then p.due_date end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

create or replace view public.supplier_statement_lines
with (security_invoker=true)
as
with lines as (
  select
    p.supplier_id,
    p.purchase_date::timestamptz as occurred_at,
    'purchase'::text as line_type,
    p.id as source_id,
    p.purchase_no as reference,
    p.supplier_invoice_no,
    p.total_amount::numeric(14,2) as debit,
    0::numeric(14,2) as credit,
    p.total_amount::numeric(14,2) as balance_delta
  from public.purchases p
  where p.status<>'cancelled'
    and p.approval_status='approved'

  union all

  select
    p.supplier_id,
    pp.paid_at as occurred_at,
    'payment'::text as line_type,
    pp.id as source_id,
    coalesce(pp.reference,'Supplier payment') as reference,
    p.supplier_invoice_no,
    0::numeric(14,2) as debit,
    pp.amount::numeric(14,2) as credit,
    (-pp.amount)::numeric(14,2) as balance_delta
  from public.purchase_payments pp
  join public.purchases p on p.id=pp.purchase_id
)
select
  supplier_id,
  occurred_at,
  line_type,
  source_id,
  reference,
  supplier_invoice_no,
  debit,
  credit,
  sum(balance_delta) over(
    partition by supplier_id
    order by occurred_at,line_type,source_id
    rows between unbounded preceding and current row
  )::numeric(14,2) as running_balance
from lines;

create or replace view public.open_purchase_orders
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.total_amount,
  p.status,
  p.approval_status,
  p.due_date,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by
where p.status not in ('received','cancelled');

grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text) to authenticated;

create index if not exists purchases_due_idx
  on public.purchases(due_date,payment_status)
  where status<>'cancelled';

create index if not exists purchases_approval_idx
  on public.purchases(approval_status,status,created_at desc);

create index if not exists purchase_payments_paid_idx
  on public.purchase_payments(paid_at desc);


-- SOURCE FILE: 010_phase2d_customers_orders.sql

-- DS Bakery Phase 2D: customers, customer orders, deposits and receipts

create type public.customer_order_status as enum (
  'pending','confirmed','in_production','ready','completed','cancelled'
);

create type public.fulfillment_type as enum ('pickup','delivery');

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text,
  email text,
  address text,
  birthday date,
  notes text,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists customers_phone_unique
  on public.customers(phone)
  where phone is not null;

create table if not exists public.customer_orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  customer_id uuid not null references public.customers(id),
  status public.customer_order_status not null default 'pending',
  fulfillment public.fulfillment_type not null default 'pickup',
  required_at timestamptz not null,
  delivery_address text,
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  discount numeric(14,2) not null default 0 check (discount >= 0),
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  cancelled_at timestamptz,
  cancellation_reason text
);

create table if not exists public.customer_order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  product_id uuid references public.products(id),
  description text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  line_total numeric(14,2) not null check (line_total >= 0),
  customization_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_order_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount > 0),
  reference text,
  payment_status text not null default 'completed',
  recorded_by uuid not null references public.profiles(id),
  paid_at timestamptz not null default now()
);

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' || to_char(now(),'YYMMDD') || '-' ||
         lpad((floor(random()*10000))::int::text,4,'0')
$$;

create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount into v_discount
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if p_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_remaining := v_order.total_amount-v_paid;

  if p_amount > v_remaining then
    raise exception 'Payment exceeds outstanding order balance';
  end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,recorded_by
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,
    nullif(trim(p_reference),''),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','cashier','baker') then
    raise exception 'Not authorized';
  end if;

  select * into v_before
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;

  if v_role='cashier' and p_status in ('in_production') then
    raise exception 'Cashier cannot move order into production';
  end if;

  if v_role='baker' and p_status not in ('in_production','ready') then
    raise exception 'Baker may only update production/ready status';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  co.created_at,
  co.updated_at
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  co.id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.status,co.fulfillment,co.required_at,co.delivery_address,
  co.total_amount,co.created_at,co.updated_at;

create or replace view public.customer_summary
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  count(distinct co.id)::bigint as order_count,
  coalesce(sum(co.total_amount),0)::numeric(14,2) as total_order_value,
  coalesce(sum((
    select co.total_amount -
      coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
    from public.customer_order_payments cop
    where cop.order_id=co.id
  )),0)::numeric(14,2) as outstanding_balance,
  max(co.created_at) as last_order_at
from public.customers c
left join public.customer_orders co
  on co.customer_id=c.id and co.status<>'cancelled'
where c.active=true
group by c.id,c.full_name,c.phone,c.email;

alter table public.customers enable row level security;
alter table public.customer_orders enable row level security;
alter table public.customer_order_items enable row level security;
alter table public.customer_order_payments enable row level security;

create policy "sales staff read customers" on public.customers
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff manage customers" on public.customers
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer orders" on public.customer_orders
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer orders" on public.customer_orders
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer order items" on public.customer_order_items
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer order items" on public.customer_order_items
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff read order payments" on public.customer_order_payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.record_customer_order_payment(
  uuid,numeric,public.payment_method,text
) to authenticated;

grant execute on function public.update_customer_order_status(
  uuid,public.customer_order_status
) to authenticated;

create index if not exists customer_orders_customer_idx
  on public.customer_orders(customer_id,created_at desc);

create index if not exists customer_orders_required_idx
  on public.customer_orders(status,required_at);

create index if not exists customer_order_items_order_idx
  on public.customer_order_items(order_id);

create index if not exists customer_order_payments_order_idx
  on public.customer_order_payments(order_id,paid_at desc);


-- SOURCE FILE: 011_phase2e_operational_reports.sql

-- DS Bakery Phase 2E: weekly/monthly operational reporting

create or replace function public.operational_period_bounds(p_period text)
returns table(start_date date,end_date date)
language plpgsql
stable
as $$
begin
  if p_period='week' then
    start_date := date_trunc('week',current_date)::date;
    end_date := current_date;
  elsif p_period='month' then
    start_date := date_trunc('month',current_date)::date;
    end_date := current_date;
  else
    raise exception 'Unsupported period: %', p_period;
  end if;
  return next;
end;
$$;

create or replace function public.operational_report_summary(p_period text default 'week')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start date;
  v_end date;
  v_sales numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_planned numeric(18,3);
  v_produced numeric(18,3);
  v_waste_cost numeric(14,2);
  v_product_waste numeric(18,3);
  v_supplier_outstanding numeric(14,2);
  v_supplier_overdue numeric(14,2);
  v_customer_balance numeric(14,2);
  v_orders bigint;
  v_completed bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  select start_date,end_date into v_start,v_end
  from public.operational_period_bounds(p_period);

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_gross
  from public.sale_profit_lines
  where created_at::date between v_start and v_end;

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at::date between v_start and v_end;

  select
    coalesce(sum(planned_qty),0),
    coalesce(sum(produced_qty),0)
  into v_planned,v_produced
  from public.production_plan_items
  where business_date between v_start and v_end
    and status<>'cancelled';

  select
    coalesce(sum(total_cost),0),
    coalesce(sum(case when waste_type='finished_product' then quantity else 0 end),0)
  into v_waste_cost,v_product_waste
  from public.waste_events
  where approval_status='approved'
    and recorded_at::date between v_start and v_end;

  select
    coalesce(sum(outstanding_balance),0),
    coalesce(sum(overdue_balance),0)
  into v_supplier_outstanding,v_supplier_overdue
  from public.supplier_account_summary;

  select coalesce(sum(balance_due),0)
  into v_customer_balance
  from public.customer_order_summary
  where status not in ('completed','cancelled');

  select
    count(*),
    count(*) filter (where status='completed')
  into v_orders,v_completed
  from public.customer_orders
  where created_at::date between v_start and v_end;

  return jsonb_build_object(
    'period',p_period,
    'start_date',v_start,
    'end_date',v_end,
    'sales',v_sales,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'production_planned',v_planned,
    'production_produced',v_produced,
    'production_variance',v_produced-v_planned,
    'waste_cost',v_waste_cost,
    'finished_product_waste_qty',v_product_waste,
    'supplier_outstanding',v_supplier_outstanding,
    'supplier_overdue',v_supplier_overdue,
    'customer_order_balance',v_customer_balance,
    'orders_total',v_orders,
    'orders_completed',v_completed,
    'order_completion_rate',case when v_orders>0 then round((v_completed::numeric/v_orders)*100,2) else 0 end
  );
end;
$$;

create or replace view public.operational_production_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
),
waste as (
  select
    we.product_id,
    p.period_key,
    coalesce(sum(we.quantity),0) as waste_qty
  from public.waste_events we
  join periods p on we.recorded_at::date between p.start_date and p.end_date
  where we.waste_type='finished_product'
    and we.approval_status='approved'
  group by we.product_id,p.period_key
)
select
  per.period_key,
  ppi.product_id,
  pr.name as product_name,
  sum(ppi.planned_qty)::numeric(18,3) as planned_qty,
  sum(ppi.produced_qty)::numeric(18,3) as produced_qty,
  (sum(ppi.produced_qty)-sum(ppi.planned_qty))::numeric(18,3) as variance_qty,
  coalesce(w.waste_qty,0)::numeric(18,3) as approved_waste_qty,
  case when sum(ppi.produced_qty)>0
    then round((coalesce(w.waste_qty,0)/sum(ppi.produced_qty))*100,2)
    else 0 end as waste_rate_pct
from periods per
join public.production_plan_items ppi
  on ppi.business_date between per.start_date and per.end_date
join public.products pr on pr.id=ppi.product_id
left join waste w
  on w.product_id=ppi.product_id and w.period_key=per.period_key
where ppi.status<>'cancelled'
group by per.period_key,ppi.product_id,pr.name,w.waste_qty;

create or replace view public.operational_waste_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  we.waste_type,
  count(*)::bigint as event_count,
  coalesce(sum(we.quantity),0)::numeric(18,3) as quantity,
  coalesce(sum(we.total_cost),0)::numeric(14,2) as waste_cost
from periods per
join public.waste_events we
  on we.recorded_at::date between per.start_date and per.end_date
where we.approval_status='approved'
group by per.period_key,we.waste_type;

create or replace view public.customer_order_operational_summary
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  count(co.id)::bigint as orders_total,
  count(co.id) filter (where co.status='completed')::bigint as orders_completed,
  count(co.id) filter (where co.status='ready')::bigint as orders_ready,
  count(co.id) filter (where co.status='in_production')::bigint as orders_in_production,
  case when count(co.id)>0
    then round((count(co.id) filter (where co.status='completed')::numeric/count(co.id))*100,2)
    else 0 end as completion_rate
from periods per
left join public.customer_orders co
  on co.created_at::date between per.start_date and per.end_date
group by per.period_key;

create or replace view public.operational_product_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  spl.product_id,
  spl.product_name,
  sum(spl.quantity)::numeric(18,3) as units_sold,
  sum(spl.sales_amount)::numeric(14,2) as sales_amount,
  sum(spl.gross_profit_amount)::numeric(14,2) as gross_profit_amount
from periods per
join public.sale_profit_lines spl
  on spl.created_at::date between per.start_date and per.end_date
group by per.period_key,spl.product_id,spl.product_name
order by per.period_key,units_sold desc;

create or replace function public.management_alerts()
returns table(
  alert_type text,
  severity text,
  title text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  select
    'supplier'::text,
    'high'::text,
    'Overdue supplier balance'::text,
    s.supplier_name || ' overdue ' || to_char(s.overdue_balance,'FM999,999,999') || ' UGX'
  from public.supplier_account_summary s
  where s.overdue_balance>0

  union all

  select
    'stock',
    'high',
    'Low stock',
    l.name || ' at ' || l.current_stock_qty || ' ' || l.base_unit
  from public.low_stock_materials l

  union all

  select
    'production',
    'medium',
    'Production below plan',
    p.product_name || ' variance ' || p.variance_qty
  from public.operational_production_performance p
  where p.period_key='week'
    and p.variance_qty<0

  union all

  select
    'waste',
    'medium',
    'High waste rate',
    p.product_name || ' waste rate ' || p.waste_rate_pct || '%'
  from public.operational_production_performance p
  where p.period_key='week'
    and p.waste_rate_pct>=5;
end;
$$;

grant execute on function public.operational_report_summary(text) to authenticated;
grant execute on function public.management_alerts() to authenticated;


-- SOURCE FILE: 012_phase3a_custom_cakes.sql

-- DS Bakery Phase 3A: custom cake specification, quote, image reference and production handoff

create type public.custom_cake_design_status as enum (
  'draft','quoted','awaiting_deposit','approved','in_production','ready','completed','cancelled'
);

create table if not exists public.custom_cake_specs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  cake_size_label text,
  servings integer check (servings is null or servings > 0),
  tiers integer not null default 1 check (tiers > 0),
  flavour text,
  filling text,
  frosting text,
  theme text,
  primary_color text,
  secondary_color text,
  inscription text,
  reference_image_path text,
  special_instructions text,
  production_notes text,
  quote_amount numeric(14,2) not null default 0 check (quote_amount >= 0),
  design_status public.custom_cake_design_status not null default 'draft',
  customer_approved_at timestamptz,
  production_approved_by uuid references public.profiles(id),
  production_approved_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;

  if p_quote_amount <= 0 then
    raise exception 'Quote amount must be greater than zero';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status
    end,
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    subtotal=p_quote_amount,
    total_amount=p_quote_amount,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(
  p_order_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount <= 0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_paid <= 0 then
    raise exception 'A deposit/payment is required before production approval';
  end if;

  update public.custom_cake_specs
  set
    design_status='approved',
    production_approved_by=auth.uid(),
    production_approved_at=now(),
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    status='confirmed',
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,
      'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid
    )
  );
end;
$$;

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id as custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (ccs.quote_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  ccs.design_status,
  co.status as order_status
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.required_at,co.fulfillment,co.delivery_address,
  ccs.cake_size_label,ccs.servings,ccs.tiers,ccs.flavour,ccs.filling,
  ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,
  ccs.production_notes,ccs.quote_amount,ccs.design_status,co.status;

alter table public.custom_cake_specs enable row level security;

create policy "relevant staff read custom cakes" on public.custom_cake_specs
for select using (
  public.current_staff_role() in ('owner','manager','cashier','baker')
);

create policy "sales staff create custom cakes" on public.custom_cake_specs
for insert with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "sales staff update custom cakes" on public.custom_cake_specs
for update using (
  public.current_staff_role() in ('owner','manager','cashier')
)
with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;

create index if not exists custom_cake_specs_status_idx
  on public.custom_cake_specs(design_status,updated_at desc);

-- Storage note:
-- Create a PRIVATE Supabase Storage bucket named `custom-cake-references`.
-- Store only the object path in reference_image_path.
-- Do not make customer reference images public by default.


-- SOURCE FILE: 013_phase3b_delivery_riders.sql

-- DS Bakery Phase 3B: delivery jobs and rider assignment

create type public.delivery_status as enum (
  'pending','assigned','out_for_delivery','delivered','failed','cancelled'
);

create table if not exists public.delivery_riders (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  vehicle_label text,
  profile_id uuid unique references public.profiles(id),
  active boolean not null default true,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.customer_orders
  add column if not exists delivery_charge numeric(14,2) not null default 0
    check (delivery_charge >= 0);

create table if not exists public.delivery_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  rider_id uuid references public.delivery_riders(id),
  status public.delivery_status not null default 'pending',
  scheduled_for timestamptz,
  delivery_address_snapshot text not null,
  customer_name_snapshot text not null,
  customer_phone_snapshot text,
  delivery_charge numeric(14,2) not null default 0 check (delivery_charge >= 0),
  assigned_by uuid references public.profiles(id),
  assigned_at timestamptz,
  dispatched_by uuid references public.profiles(id),
  dispatched_at timestamptz,
  delivered_by uuid references public.profiles(id),
  delivered_at timestamptz,
  failed_at timestamptz,
  outcome_note text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Include delivery charge in order total calculation.
create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
  v_delivery numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount,delivery_charge
    into v_discount,v_delivery
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0)+coalesce(v_delivery,0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_delivery_charge < 0 then
    raise exception 'Delivery charge cannot be negative';
  end if;

  if coalesce(trim(p_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment <> 'delivery' then
    raise exception 'Order is not marked for delivery';
  end if;
  if v_order.status='cancelled' then
    raise exception 'Cannot create delivery for cancelled order';
  end if;

  select * into v_customer
  from public.customers
  where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_new_total := greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;

  if v_new_total < v_paid then
    raise exception 'New order total would be less than payments already recorded';
  end if;

  update public.customer_orders
  set
    delivery_charge=p_delivery_charge,
    total_amount=v_new_total,
    delivery_address=p_address,
    updated_at=now()
  where id=p_order_id;

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,
    delivery_address_snapshot,customer_name_snapshot,customer_phone_snapshot,
    delivery_charge,created_by
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    p_address,v_customer.full_name,v_customer.phone,
    p_delivery_charge,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at)
    )
  );

  return v_id;
end;
$$;

create or replace function public.assign_delivery_rider(
  p_delivery_id uuid,
  p_rider_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_rider public.delivery_riders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to assign riders';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;
  if v_job.status in ('delivered','cancelled') then
    raise exception 'Delivery job is closed';
  end if;

  select * into v_rider
  from public.delivery_riders
  where id=p_rider_id and active=true;

  if not found then raise exception 'Active rider not found'; end if;

  update public.delivery_jobs
  set
    rider_id=p_rider_id,
    status='assigned',
    assigned_by=auth.uid(),
    assigned_at=now(),
    updated_at=now()
  where id=p_delivery_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'assign_delivery_rider','delivery_job',p_delivery_id,
    jsonb_build_object('rider_id',p_rider_id,'rider_name',v_rider.full_name)
  );
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order
  from public.customer_orders
  where id=v_job.order_id
  for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then
      raise exception 'Delivery must be assigned or failed before dispatch';
    end if;
    if v_job.rider_id is null then
      raise exception 'Assign a rider before dispatch';
    end if;
    if v_order.status <> 'ready' then
      raise exception 'Customer order must be ready before dispatch';
    end if;

    update public.delivery_jobs
    set
      status='out_for_delivery',
      dispatched_by=auth.uid(),
      dispatched_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may be completed';
    end if;

    update public.delivery_jobs
    set
      status='delivered',
      delivered_by=auth.uid(),
      delivered_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set
      status='completed',
      completed_at=now(),
      updated_at=now()
    where id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may fail';
    end if;
    if coalesce(trim(p_note),'')='' then
      raise exception 'Failure reason is required';
    end if;

    update public.delivery_jobs
    set
      status='failed',
      failed_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then
      raise exception 'Delivered job cannot be cancelled';
    end if;

    update public.delivery_jobs
    set
      status='cancelled',
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

create or replace view public.delivery_job_summary
with (security_invoker=true)
as
select
  dj.id,
  dj.order_id,
  co.order_no,
  co.customer_id,
  dj.customer_name_snapshot as customer_name,
  dj.customer_phone_snapshot as customer_phone,
  dj.delivery_address_snapshot as delivery_address,
  dj.scheduled_for,
  dj.delivery_charge,
  dj.status,
  dj.rider_id,
  dr.full_name as rider_name,
  dr.phone as rider_phone,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  dj.assigned_at,
  dj.dispatched_at,
  dj.delivered_at,
  dj.failed_at,
  dj.outcome_note
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
left join public.delivery_riders dr on dr.id=dj.rider_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  dj.id,dj.order_id,co.order_no,co.customer_id,
  dj.customer_name_snapshot,dj.customer_phone_snapshot,
  dj.delivery_address_snapshot,dj.scheduled_for,dj.delivery_charge,
  dj.status,dj.rider_id,dr.full_name,dr.phone,co.total_amount,
  dj.assigned_at,dj.dispatched_at,dj.delivered_at,dj.failed_at,dj.outcome_note;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id as rider_id,
  dr.full_name,
  dr.phone,
  dr.vehicle_label,
  dr.active,
  count(dj.id) filter (
    where dj.status in ('assigned','out_for_delivery')
  )::bigint as active_jobs,
  count(dj.id) filter (
    where dj.status='delivered'
      and dj.delivered_at::date=current_date
  )::bigint as delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

alter table public.delivery_riders enable row level security;
alter table public.delivery_jobs enable row level security;

create policy "delivery staff read riders" on public.delivery_riders
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage riders" on public.delivery_riders
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "delivery staff read delivery jobs" on public.delivery_jobs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;

create index if not exists delivery_jobs_status_schedule_idx
  on public.delivery_jobs(status,scheduled_for);

create index if not exists delivery_jobs_rider_idx
  on public.delivery_jobs(rider_id,status);

create index if not exists delivery_riders_active_idx
  on public.delivery_riders(active,full_name);


-- SOURCE FILE: 014_phase3c_loyalty_retention.sql

-- DS Bakery Phase 3C: loyalty, birthdays and customer retention

create type public.loyalty_event_type as enum (
  'sale_earn',
  'order_earn',
  'refund_adjustment',
  'reward_redemption',
  'birthday_bonus',
  'manual_adjustment'
);

alter table public.sales
  add column if not exists customer_id uuid references public.customers(id);

create table if not exists public.loyalty_settings (
  id integer primary key default 1 check (id=1),
  earn_amount_per_point numeric(14,2) not null default 1000 check (earn_amount_per_point > 0),
  reward_points integer not null default 100 check (reward_points > 0),
  reward_value numeric(14,2) not null default 5000 check (reward_value >= 0),
  birthday_reminder_days integer not null default 30 check (birthday_reminder_days between 1 and 90),
  vip_spend_threshold numeric(14,2) not null default 1000000 check (vip_spend_threshold >= 0),
  regular_spend_threshold numeric(14,2) not null default 500000 check (regular_spend_threshold >= 0),
  regular_order_threshold integer not null default 5 check (regular_order_threshold >= 1),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.loyalty_settings(id)
values(1)
on conflict (id) do nothing;

create table if not exists public.loyalty_point_transactions (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  event_type public.loyalty_event_type not null,
  points_delta integer not null check (points_delta <> 0),
  source_type text,
  source_id uuid,
  reason text not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace view public.customer_loyalty_balances
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  coalesce(sum(lpt.points_delta),0)::bigint as points_balance,
  max(lpt.created_at) as last_loyalty_activity_at
from public.customers c
left join public.loyalty_point_transactions lpt on lpt.customer_id=c.id
where c.active=true
group by c.id,c.full_name,c.phone;

create or replace function public.sync_sale_loyalty_points(p_sale_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale public.sales%rowtype;
  v_rate numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_sale from public.sales where id=p_sale_id;
  if not found or v_sale.customer_id is null then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  if v_sale.status in ('completed','partially_refunded') then
    v_expected := floor(greatest(v_sale.total-coalesce(v_sale.refund_total,0),0)/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_sale.customer_id
    and source_type='sale'
    and source_id=p_sale_id
    and event_type in ('sale_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_sale.customer_id,
      case when v_delta>0 then 'sale_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'sale',
      p_sale_id,
      case when v_delta>0 then 'Points earned from completed sale'
           else 'Points adjusted after sale refund/cancellation' end,
      v_sale.cashier_id
    );
  end if;
end;
$$;

create or replace function public.trg_sync_sale_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_sale_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_sales_loyalty_sync on public.sales;
create trigger trg_sales_loyalty_sync
after insert or update of customer_id,total,refund_total,status
on public.sales
for each row execute function public.trg_sync_sale_loyalty();

create or replace function public.sync_order_loyalty_points(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_rate numeric(14,2);
  v_paid numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_order
  from public.customer_orders
  where id=p_order_id;

  if not found then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_order.status='completed' and v_paid >= v_order.total_amount then
    v_expected := floor(v_order.total_amount/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_order.customer_id
    and source_type='customer_order'
    and source_id=p_order_id
    and event_type in ('order_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_order.customer_id,
      case when v_delta>0 then 'order_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'customer_order',
      p_order_id,
      case when v_delta>0 then 'Points earned from paid completed customer order'
           else 'Points adjusted after order status/payment change' end,
      v_order.created_by
    );
  end if;
end;
$$;

create or replace function public.trg_sync_order_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_customer_orders_loyalty_sync on public.customer_orders;
create trigger trg_customer_orders_loyalty_sync
after update of status,total_amount
on public.customer_orders
for each row execute function public.trg_sync_order_loyalty();

create or replace function public.trg_sync_order_payment_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.order_id);
  return new;
end;
$$;

drop trigger if exists trg_order_payments_loyalty_sync on public.customer_order_payments;
create trigger trg_order_payments_loyalty_sync
after insert or update of amount,payment_status
on public.customer_order_payments
for each row execute function public.trg_sync_order_payment_loyalty();

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment'
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if v_balance is null then raise exception 'Customer not found'; end if;
  if v_balance+p_points < 0 then raise exception 'Adjustment would make points negative'; end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,source_type,reason,created_by
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,'manual',p_reason,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object('customer_id',p_customer_id,'points_delta',p_points,'reason',p_reason)
  );

  return v_id;
end;
$$;

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then
    raise exception 'Cannot redeem on a closed order';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings
  where id=1;

  if p_points <= 0 or mod(p_points,v_reward_points) <> 0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points > v_balance then
    raise exception 'Insufficient loyalty points';
  end if;

  v_units := p_points/v_reward_points;
  v_discount := v_units*v_reward_value;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0) < v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,source_type,source_id,reason,created_by
  )
  values(
    v_order.customer_id,
    'reward_redemption',
    -p_points,
    'customer_order',
    p_order_id,
    'Loyalty reward applied to customer order',
    auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount)
  );

  return v_discount;
end;
$$;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.birthday,
  b.next_birthday,
  (b.next_birthday-current_date) as days_until_birthday,
  coalesce(lb.points_balance,0) as points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date as next_birthday
  from generate_series(
    current_date,
    current_date + interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d
  limit 1
) b
where c.active=true
  and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id as customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint as order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) as lifetime_value,
    max(co.created_at) filter (where co.status<>'cancelled') as last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (
  select * from public.loyalty_settings where id=1
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  os.order_count,
  os.lifetime_value,
  os.last_order_at,
  coalesce(lb.points_balance,0) as points_balance,
  case
    when os.lifetime_value >= s.vip_spend_threshold then 'VIP'
    when os.lifetime_value >= s.regular_spend_threshold
      or os.order_count >= s.regular_order_threshold then 'Regular'
    when os.order_count >= 2 then 'Returning'
    else 'New'
  end as customer_segment
from public.customers c
join order_stats os on os.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

alter table public.loyalty_settings enable row level security;
alter table public.loyalty_point_transactions enable row level security;

create policy "sales management read loyalty settings" on public.loyalty_settings
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "owner manage loyalty settings" on public.loyalty_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "sales management read loyalty ledger" on public.loyalty_point_transactions
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.adjust_customer_loyalty_points(
  uuid,integer,text,public.loyalty_event_type
) to authenticated;

grant execute on function public.redeem_loyalty_on_order(uuid,integer) to authenticated;

create index if not exists loyalty_customer_created_idx
  on public.loyalty_point_transactions(customer_id,created_at desc);

create index if not exists loyalty_source_idx
  on public.loyalty_point_transactions(source_type,source_id)
  where source_id is not null;


-- SOURCE FILE: 015_phase3d_whatsapp_communication.sql

-- DS Bakery Phase 3D: WhatsApp customer communication

create type public.communication_template_type as enum (
  'ready_for_pickup',
  'in_production',
  'out_for_delivery',
  'birthday',
  'balance_reminder',
  'custom'
);

create type public.communication_event_status as enum (
  'prepared',
  'opened_whatsapp',
  'api_sent',
  'delivered',
  'failed'
);

alter table public.customers
  add column if not exists whatsapp_opt_in boolean not null default false,
  add column if not exists whatsapp_opt_in_at timestamptz,
  add column if not exists whatsapp_opt_out_at timestamptz;

create table if not exists public.communication_templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  template_type public.communication_template_type not null,
  body_template text not null,
  requires_marketing_opt_in boolean not null default false,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.communication_templates(
  name,template_type,body_template,requires_marketing_opt_in
)
select * from (values
  ('Ready for pickup','ready_for_pickup'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is ready for collection. Balance due: UGX {{balance}}. Thank you for choosing DS Bakery.',false),
  ('In production','in_production'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is now in production. We will update you when it is ready.',false),
  ('Out for delivery','out_for_delivery'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is out for delivery. Please keep your phone available for the rider.',false),
  ('Birthday greeting','birthday'::public.communication_template_type,
   'Happy birthday {{customer_name}}! DS Bakery wishes you a wonderful day. We appreciate having you as our customer.',true),
  ('Balance reminder','balance_reminder'::public.communication_template_type,
   'Hello {{customer_name}}, a friendly reminder that order {{order_no}} has a remaining balance of UGX {{balance}}. Thank you.',false)
) v(name,template_type,body_template,requires_marketing_opt_in)
where not exists (
  select 1 from public.communication_templates ct
  where ct.template_type=v.template_type
);

create table if not exists public.communication_logs (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  order_id uuid references public.customer_orders(id),
  template_id uuid references public.communication_templates(id),
  channel text not null default 'whatsapp',
  status public.communication_event_status not null default 'prepared',
  recipient_phone_snapshot text not null,
  message_snapshot text not null,
  initiated_by uuid not null references public.profiles(id),
  initiated_at timestamptz not null default now(),
  external_message_id text,
  delivered_at timestamptz,
  failure_reason text
);

create or replace function public.set_customer_whatsapp_preference(
  p_customer_id uuid,
  p_opted_in boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before boolean;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update communication preference';
  end if;

  select whatsapp_opt_in into v_before
  from public.customers
  where id=p_customer_id
  for update;

  if not found then raise exception 'Customer not found'; end if;

  update public.customers
  set
    whatsapp_opt_in=p_opted_in,
    whatsapp_opt_in_at=case when p_opted_in then now() else whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case when not p_opted_in then now() else null end,
    updated_at=now()
  where id=p_customer_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_whatsapp_preference','customer',p_customer_id,
    jsonb_build_object('whatsapp_opt_in',v_before),
    jsonb_build_object('whatsapp_opt_in',p_opted_in)
  );
end;
$$;

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then
    raise exception 'Recipient phone is required';
  end if;
  if coalesce(trim(p_message),'')='' then
    raise exception 'Message is required';
  end if;

  select * into v_customer
  from public.customers
  where id=p_customer_id;

  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template
    from public.communication_templates
    where id=p_template_id and active=true;

    if not found then raise exception 'Active communication template not found'; end if;

    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders
    where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,status,
    recipient_phone_snapshot,message_snapshot,initiated_by
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'opened_whatsapp',
    p_recipient_phone,p_message,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,
      'order_id',p_order_id,
      'template_id',p_template_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text as queue_type,
  100 as priority,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id as order_id,
  co.order_no,
  co.required_at as due_at,
  cos.balance_due,
  'Order is ready for pickup'::text as reason
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready'

union all

select
  'out_for_delivery',
  90,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  dj.scheduled_for,
  cos.balance_due,
  'Order is out for delivery'
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where dj.status='out_for_delivery'

union all

select
  'birthday',
  50,
  b.customer_id,
  b.full_name,
  b.phone,
  c.whatsapp_opt_in,
  null::uuid,
  null::text,
  b.next_birthday::timestamptz,
  0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days'
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all

select
  'balance_reminder',
  40,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  co.required_at,
  cos.balance_due,
  'Customer order has outstanding balance'
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0
  and co.status not in ('cancelled');

alter table public.communication_templates enable row level security;
alter table public.communication_logs enable row level security;

create policy "authorized staff read communication templates"
on public.communication_templates
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage communication templates"
on public.communication_templates
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "authorized staff read communication logs"
on public.communication_logs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text) to authenticated;

create index if not exists communication_logs_customer_idx
  on public.communication_logs(customer_id,initiated_at desc);

create index if not exists communication_logs_order_idx
  on public.communication_logs(order_id,initiated_at desc)
  where order_id is not null;

create index if not exists communication_templates_type_idx
  on public.communication_templates(template_type,active);


-- SOURCE FILE: 016_phase3e_attendance_permissions.sql

-- DS Bakery Phase 3E: attendance, staff scheduling and individual permissions

create type public.staff_shift_status as enum ('scheduled','completed','cancelled');
create type public.attendance_status as enum ('on_time','late','completed','absent','excused');

create table if not exists public.attendance_settings (
  id integer primary key default 1 check (id=1),
  late_grace_minutes integer not null default 5 check (late_grace_minutes between 0 and 120),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.attendance_settings(id,late_grace_minutes)
values(1,5)
on conflict (id) do nothing;

create table if not exists public.staff_work_shifts (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.profiles(id),
  shift_date date not null,
  scheduled_start time not null,
  scheduled_end time not null,
  work_station text,
  status public.staff_shift_status not null default 'scheduled',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (scheduled_end > scheduled_start),
  unique(staff_id,shift_date,scheduled_start)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid not null unique references public.staff_work_shifts(id) on delete restrict,
  staff_id uuid not null references public.profiles(id),
  clock_in_at timestamptz,
  clock_out_at timestamptz,
  status public.attendance_status,
  late_minutes integer not null default 0 check (late_minutes >= 0),
  note text,
  adjusted_by uuid references public.profiles(id),
  adjusted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (clock_out_at is null or clock_in_at is null or clock_out_at >= clock_in_at)
);

create or replace function public.clock_in_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.staff_work_shifts%rowtype;
  v_id uuid;
  v_grace integer;
  v_scheduled timestamptz;
  v_late integer;
begin
  if not public.is_active_staff() then
    raise exception 'Active staff account required';
  end if;

  select * into v_shift
  from public.staff_work_shifts
  where staff_id=auth.uid()
    and shift_date=current_date
    and status='scheduled'
  order by scheduled_start
  limit 1
  for update;

  if not found then
    raise exception 'No scheduled work shift found for today';
  end if;

  if exists(
    select 1 from public.attendance_records
    where shift_id=v_shift.id and clock_in_at is not null
  ) then
    raise exception 'Already clocked in for this shift';
  end if;

  select late_grace_minutes into v_grace
  from public.attendance_settings
  where id=1;

  v_scheduled := current_date + v_shift.scheduled_start;
  v_late := greatest(
    0,
    floor(extract(epoch from (now()-v_scheduled))/60)::integer - coalesce(v_grace,0)
  );

  insert into public.attendance_records(
    shift_id,staff_id,clock_in_at,status,late_minutes
  )
  values(
    v_shift.id,
    auth.uid(),
    now(),
    case when v_late>0 then 'late'::public.attendance_status else 'on_time'::public.attendance_status end,
    v_late
  )
  returning id into v_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_in','attendance_record',v_id,
    jsonb_build_object('shift_id',v_shift.id,'late_minutes',v_late)
  );

  return v_id;
end;
$$;

create or replace function public.clock_out_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_record public.attendance_records%rowtype;
begin
  select ar.* into v_record
  from public.attendance_records ar
  join public.staff_work_shifts sws on sws.id=ar.shift_id
  where ar.staff_id=auth.uid()
    and sws.shift_date=current_date
    and ar.clock_in_at is not null
    and ar.clock_out_at is null
  order by ar.clock_in_at desc
  limit 1
  for update of ar;

  if not found then
    raise exception 'No open attendance record found';
  end if;

  update public.attendance_records
  set
    clock_out_at=now(),
    status='completed',
    updated_at=now()
  where id=v_record.id;

  update public.staff_work_shifts
  set status='completed',updated_at=now()
  where id=v_record.shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_out','attendance_record',v_record.id,
    jsonb_build_object('clock_out_at',now())
  );

  return v_record.id;
end;
$$;

create or replace function public.adjust_attendance_record(
  p_attendance_id uuid,
  p_clock_in timestamptz,
  p_clock_out timestamptz,
  p_status public.attendance_status,
  p_note text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.attendance_records%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may adjust attendance';
  end if;

  if coalesce(trim(p_note),'')='' then
    raise exception 'Adjustment note is required';
  end if;

  select * into v_before
  from public.attendance_records
  where id=p_attendance_id
  for update;

  if not found then raise exception 'Attendance record not found'; end if;

  update public.attendance_records
  set
    clock_in_at=p_clock_in,
    clock_out_at=p_clock_out,
    status=p_status,
    note=p_note,
    adjusted_by=auth.uid(),
    adjusted_at=now(),
    updated_at=now()
  where id=p_attendance_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'adjust_attendance','attendance_record',p_attendance_id,
    jsonb_build_object(
      'clock_in_at',v_before.clock_in_at,
      'clock_out_at',v_before.clock_out_at,
      'status',v_before.status
    ),
    jsonb_build_object(
      'clock_in_at',p_clock_in,
      'clock_out_at',p_clock_out,
      'status',p_status,
      'note',p_note
    )
  );
end;
$$;

create or replace view public.staff_shift_schedule
with (security_invoker=true)
as
select
  sws.id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  sws.status,
  sws.notes
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id;

create or replace view public.attendance_today
with (security_invoker=true)
as
select
  sws.id as shift_id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  ar.id as attendance_id,
  ar.clock_in_at,
  ar.clock_out_at,
  ar.status as attendance_status,
  coalesce(ar.late_minutes,0) as late_minutes,
  case
    when ar.id is not null then ar.status::text
    when current_time > sws.scheduled_end then 'absent'
    else 'scheduled'
  end as display_status
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id
left join public.attendance_records ar on ar.shift_id=sws.id
where sws.shift_date=current_date
  and sws.status<>'cancelled';

-- Individual permission system
create table if not exists public.app_permissions (
  permission_key text primary key,
  description text not null,
  critical boolean not null default false
);

insert into public.app_permissions(permission_key,description,critical) values
  ('reports:view','View owner/manager reports',true),
  ('delivery:manage','Manage delivery jobs',false),
  ('communication:send','Open customer communication messages',false),
  ('products:write','Change product details/prices',true),
  ('inventory:write','Receive/adjust stock through allowed workflows',true),
  ('purchases:write','Create/manage purchase orders',true),
  ('attendance:manage','Adjust staff attendance',true),
  ('schedule:manage','Manage staff work schedules',true)
on conflict (permission_key) do nothing;

create table if not exists public.role_permission_defaults (
  role public.staff_role not null,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  primary key(role,permission_key)
);

insert into public.role_permission_defaults(role,permission_key,allowed) values
  ('owner','reports:view',true),
  ('owner','delivery:manage',true),
  ('owner','communication:send',true),
  ('owner','products:write',true),
  ('owner','inventory:write',true),
  ('owner','purchases:write',true),
  ('owner','attendance:manage',true),
  ('owner','schedule:manage',true),

  ('manager','reports:view',true),
  ('manager','delivery:manage',true),
  ('manager','communication:send',true),
  ('manager','products:write',true),
  ('manager','inventory:write',true),
  ('manager','purchases:write',true),
  ('manager','attendance:manage',true),
  ('manager','schedule:manage',true),

  ('cashier','reports:view',false),
  ('cashier','delivery:manage',true),
  ('cashier','communication:send',true),
  ('cashier','products:write',false),
  ('cashier','inventory:write',false),
  ('cashier','purchases:write',false),
  ('cashier','attendance:manage',false),
  ('cashier','schedule:manage',false),

  ('baker','reports:view',false),
  ('baker','delivery:manage',false),
  ('baker','communication:send',false),
  ('baker','products:write',false),
  ('baker','inventory:write',false),
  ('baker','purchases:write',false),
  ('baker','attendance:manage',false),
  ('baker','schedule:manage',false),

  ('storekeeper','reports:view',false),
  ('storekeeper','delivery:manage',false),
  ('storekeeper','communication:send',false),
  ('storekeeper','products:write',false),
  ('storekeeper','inventory:write',true),
  ('storekeeper','purchases:write',true),
  ('storekeeper','attendance:manage',false),
  ('storekeeper','schedule:manage',false)
on conflict (role,permission_key) do update set allowed=excluded.allowed;

create table if not exists public.staff_permission_overrides (
  staff_id uuid not null references public.profiles(id) on delete cascade,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  set_by uuid not null references public.profiles(id),
  set_at timestamptz not null default now(),
  reason text,
  primary key(staff_id,permission_key)
);

create or replace function public.effective_staff_permissions(p_staff_id uuid)
returns table(
  permission_key text,
  description text,
  critical boolean,
  role_default boolean,
  individual_override boolean,
  has_override boolean,
  effective_allowed boolean
)
language sql
security definer
set search_path=public
as $$
  select
    ap.permission_key,
    ap.description,
    ap.critical,
    coalesce(rpd.allowed,false) as role_default,
    spo.allowed as individual_override,
    (spo.staff_id is not null) as has_override,
    coalesce(spo.allowed,rpd.allowed,false) as effective_allowed
  from public.profiles p
  cross join public.app_permissions ap
  left join public.role_permission_defaults rpd
    on rpd.role=p.role and rpd.permission_key=ap.permission_key
  left join public.staff_permission_overrides spo
    on spo.staff_id=p.id and spo.permission_key=ap.permission_key
  where p.id=p_staff_id
$$;

create or replace function public.staff_has_permission(p_permission_key text)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((
    select e.effective_allowed
    from public.effective_staff_permissions(auth.uid()) e
    where e.permission_key=p_permission_key
  ),false)
$$;

create or replace function public.set_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text,
  p_allowed boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may set individual permission overrides';
  end if;

  if not exists(select 1 from public.profiles where id=p_staff_id and active=true) then
    raise exception 'Active staff profile not found';
  end if;

  if not exists(select 1 from public.app_permissions where permission_key=p_permission_key) then
    raise exception 'Unknown permission key';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.staff_permission_overrides(
    staff_id,permission_key,allowed,set_by,set_at
  )
  values(
    p_staff_id,p_permission_key,p_allowed,auth.uid(),now()
  )
  on conflict(staff_id,permission_key)
  do update set
    allowed=excluded.allowed,
    set_by=excluded.set_by,
    set_at=excluded.set_at;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_permission_override','profile',p_staff_id,
    case when v_old.staff_id is null then null
         else jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed) end,
    jsonb_build_object('permission_key',p_permission_key,'allowed',p_allowed)
  );
end;
$$;

create or replace function public.clear_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may clear individual permission overrides';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  if not found then return; end if;

  delete from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'clear_permission_override','profile',p_staff_id,
    jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed),
    jsonb_build_object('permission_key',p_permission_key,'override','cleared')
  );
end;
$$;

alter table public.attendance_settings enable row level security;
alter table public.staff_work_shifts enable row level security;
alter table public.attendance_records enable row level security;
alter table public.app_permissions enable row level security;
alter table public.role_permission_defaults enable row level security;
alter table public.staff_permission_overrides enable row level security;

create policy "staff read attendance settings" on public.attendance_settings
for select using (public.is_active_staff());

create policy "owner manage attendance settings" on public.attendance_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "staff read own or management schedules" on public.staff_work_shifts
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management schedules" on public.staff_work_shifts
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "staff read own or management attendance" on public.attendance_records
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management read permissions" on public.app_permissions
for select using (public.current_staff_role() in ('owner','manager'));

create policy "management read role defaults" on public.role_permission_defaults
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner read permission overrides" on public.staff_permission_overrides
for select using (public.current_staff_role()='owner');

grant execute on function public.clock_in_staff() to authenticated;
grant execute on function public.clock_out_staff() to authenticated;
grant execute on function public.adjust_attendance_record(uuid,timestamptz,timestamptz,public.attendance_status,text) to authenticated;
grant execute on function public.effective_staff_permissions(uuid) to authenticated;
grant execute on function public.staff_has_permission(text) to authenticated;
grant execute on function public.set_staff_permission_override(uuid,text,boolean) to authenticated;
grant execute on function public.clear_staff_permission_override(uuid,text) to authenticated;

create index if not exists staff_work_shifts_date_idx
  on public.staff_work_shifts(shift_date,staff_id,status);

create index if not exists attendance_staff_created_idx
  on public.attendance_records(staff_id,created_at desc);

create index if not exists permission_override_staff_idx
  on public.staff_permission_overrides(staff_id,permission_key);
