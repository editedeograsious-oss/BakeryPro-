

-- SOURCE FILE: 017_core_live_wiring.sql

-- DS Bakery v0.18 / Migration 017
-- Live data wiring for products, recipes, inventory, POS, cashier shifts and daily closing.
-- Also fixes cash-tender accounting, sale idempotency, refund cashflow, sale numbers and
-- owner/manager report RPC role checks.

create table if not exists public.business_settings (
  id integer primary key default 1 check (id=1),
  business_timezone text not null default 'Africa/Kampala',
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.business_settings(id,business_timezone)
values(1,'Africa/Kampala')
on conflict (id) do nothing;

create or replace function public.business_current_date()
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (now() at time zone coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  ))::date
$$;

create or replace function public.business_date(p_timestamp timestamptz)
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (p_timestamp at time zone coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  ))::date
$$;

-- Product/recipe costing views.
create or replace view public.product_cost_summary
with (security_invoker=true)
as
with costs as (
  select
    r.id as recipe_id,
    r.product_id,
    r.name as recipe_name,
    r.yield_qty,
    sum(
      ri.quantity_base_unit *
      case
        when rm.purchase_pack_base_qty > 0
          then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0
      end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id,r.product_id,r.name,r.yield_qty
)
select
  p.id,
  p.name,
  p.sku,
  pc.name as category_name,
  p.selling_price,
  p.status,
  c.recipe_id,
  c.recipe_name,
  c.yield_qty,
  c.batch_cost,
  case when c.yield_qty>0
    then round(c.batch_cost/c.yield_qty,2)
    else null end as unit_food_cost,
  case when c.yield_qty>0
    then round(p.selling_price-(c.batch_cost/c.yield_qty),2)
    else null end as gross_profit,
  case when p.selling_price>0 and c.yield_qty>0
    then round(((p.selling_price-(c.batch_cost/c.yield_qty))/p.selling_price)*100,2)
    else null end as gross_margin_pct
from public.products p
left join public.product_categories pc on pc.id=p.category_id
left join costs c on c.product_id=p.id;

create or replace view public.inventory_live_summary
with (security_invoker=true)
as
select
  rm.id,
  rm.name,
  rm.sku,
  rm.base_unit,
  rm.current_stock_qty,
  rm.low_stock_threshold,
  rm.current_purchase_cost,
  rm.purchase_pack_base_qty,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    rm.current_stock_qty *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as stock_value,
  (rm.current_stock_qty <= rm.low_stock_threshold) as low,
  rm.status
from public.raw_materials rm
where rm.status='active';

create or replace view public.recipe_cost_detail
with (security_invoker=true)
as
with rc as (
  select
    r.id as recipe_id,
    sum(
      ri.quantity_base_unit *
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id
)
select
  r.id as recipe_id,
  r.product_id,
  p.name as product_name,
  p.selling_price,
  r.name as recipe_name,
  r.yield_qty,
  ri.raw_material_id,
  rm.name as ingredient_name,
  rm.base_unit,
  ri.quantity_base_unit,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    ri.quantity_base_unit *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as line_cost,
  rc.batch_cost,
  round(rc.batch_cost/r.yield_qty,2)::numeric(14,2) as unit_food_cost,
  round(p.selling_price-(rc.batch_cost/r.yield_qty),2)::numeric(14,2) as gross_profit,
  case when p.selling_price>0
    then round(((p.selling_price-(rc.batch_cost/r.yield_qty))/p.selling_price)*100,2)
    else 0 end::numeric(8,2) as margin_pct
from public.recipes r
join public.products p on p.id=r.product_id
join public.recipe_items ri on ri.recipe_id=r.id
join public.raw_materials rm on rm.id=ri.raw_material_id
join rc on rc.recipe_id=r.id
where r.active=true;

-- Audited product save.
create or replace function public.save_product(
  p_product_id uuid,
  p_name text,
  p_category_id uuid,
  p_selling_price numeric,
  p_description text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := coalesce(p_product_id,gen_random_uuid());
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save products';
  end if;

  if coalesce(trim(p_name),'')='' then raise exception 'Product name is required'; end if;
  if p_selling_price<0 then raise exception 'Selling price cannot be negative'; end if;

  select to_jsonb(p) into v_before from public.products p where p.id=p_product_id;

  insert into public.products(
    id,category_id,name,description,selling_price,status,created_by
  )
  values(
    v_id,p_category_id,trim(p_name),p_description,p_selling_price,'active',auth.uid()
  )
  on conflict(id) do update set
    category_id=excluded.category_id,
    name=excluded.name,
    description=excluded.description,
    selling_price=excluded.selling_price,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_product_id is null then 'create_product' else 'update_product' end,
    'product',
    v_id,
    v_before,
    (select to_jsonb(p) from public.products p where p.id=v_id)
  );

  return v_id;
end;
$$;

-- Atomic active recipe replacement.
create or replace function public.save_active_recipe(
  p_product_id uuid,
  p_name text,
  p_yield_qty numeric,
  p_items jsonb
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_recipe_id uuid := gen_random_uuid();
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save recipes';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Recipe name is required'; end if;
  if p_yield_qty<=0 then raise exception 'Recipe yield must be greater than zero'; end if;
  if jsonb_array_length(p_items)=0 then raise exception 'Recipe needs at least one ingredient'; end if;

  -- Validate all ingredients before changing the active recipe.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id := (v_item->>'raw_material_id')::uuid;
    v_qty := (v_item->>'quantity_base_unit')::numeric;

    if v_qty<=0 then raise exception 'Ingredient quantity must be greater than zero'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid or inactive raw material';
    end if;
  end loop;

  update public.recipes
  set active=false,updated_at=now()
  where product_id=p_product_id and active=true;

  insert into public.recipes(id,product_id,name,yield_qty,active,created_by)
  values(v_recipe_id,p_product_id,trim(p_name),p_yield_qty,true,auth.uid());

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.recipe_items(recipe_id,raw_material_id,quantity_base_unit)
    values(
      v_recipe_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'quantity_base_unit')::numeric
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'replace_active_recipe','recipe',v_recipe_id,
    jsonb_build_object('product_id',p_product_id,'yield_qty',p_yield_qty,'items',p_items)
  );

  return v_recipe_id;
end;
$$;

-- Physical stock counts post a movement; they never directly overwrite stock.
create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid := gen_random_uuid();
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta := p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost := case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason
    )
  );

  return v_tx_id;
end;
$$;

-- Cashier shift RPCs. Cashiers may open/close only their own shift.
create or replace function public.start_cashier_shift(p_opening_float numeric default 0)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to start cashier shift';
  end if;
  if p_opening_float<0 then raise exception 'Opening float cannot be negative'; end if;

  if exists(
    select 1 from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
  ) then
    raise exception 'You already have an open cashier shift';
  end if;

  insert into public.cashier_shifts(
    id,cashier_id,opened_by,opening_float,status
  )
  values(v_id,auth.uid(),auth.uid(),p_opening_float,'open');

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'start_cashier_shift','cashier_shift',v_id,
    jsonb_build_object('opening_float',p_opening_float)
  );

  return v_id;
end;
$$;

create or replace function public.close_cashier_shift(
  p_shift_id uuid,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.cashier_shifts%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_shift
  from public.cashier_shifts
  where id=p_shift_id
  for update;

  if not found then raise exception 'Cashier shift not found'; end if;
  if v_shift.status='closed' then raise exception 'Cashier shift already closed'; end if;

  if v_role not in ('owner','manager')
     and not (v_role='cashier' and v_shift.cashier_id=auth.uid()) then
    raise exception 'Not authorized to close this shift';
  end if;

  update public.cashier_shifts
  set status='closed',closed_at=now(),closed_by=auth.uid(),closing_note=p_note
  where id=p_shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_cashier_shift','cashier_shift',p_shift_id,
    jsonb_build_object('note',p_note)
  );
end;
$$;

-- Safer sequential sale number.
create sequence if not exists public.sale_no_seq;

create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(
    now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),
      'UTC'
    ),
    'YYYYMMDD'
  ) || '-' || lpad(nextval('public.sale_no_seq')::text,7,'0')
$$;

alter table public.sales
  add column if not exists client_request_id uuid;

create unique index if not exists sales_client_request_unique
  on public.sales(client_request_id)
  where client_request_id is not null;

create unique index if not exists payments_mobile_reference_unique
  on public.payments(method,reference)
  where reference is not null
    and method in ('mtn_momo','airtel_money')
    and status='completed';

-- Replace old complete_sale signature with idempotent, shift-aware version.
drop function if exists public.complete_sale(jsonb,numeric,jsonb,text,boolean);

create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text;
  v_shift_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.sales
    where client_request_id=p_client_request_id;

    if v_existing is not null then return v_existing; end if;
  end if;

  select id into v_shift_id
  from public.cashier_shifts
  where cashier_id=auth.uid() and status='open'
  order by opened_at desc
  limit 1;

  if v_shift_id is null then
    raise exception 'Open cashier shift required';
  end if;

  if jsonb_array_length(p_items)=0 then
    raise exception 'Sale must contain at least one item';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then raise exception 'Invalid or inactive product'; end if;

    v_qty := (v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Quantity must be greater than zero'; end if;

    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount>v_subtotal then p_discount:=v_subtotal; end if;
  v_total := v_subtotal-p_discount;

  if not p_hold then
    if jsonb_array_length(p_payments)=0 then
      raise exception 'Payment is required';
    end if;

    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;

      if v_method in ('mtn_momo','airtel_money')
         and coalesce(trim(v_payment->>'reference'),'')='' then
        raise exception 'Mobile Money reference is required';
      end if;

      if (v_payment->>'amount')::numeric<=0 then
        raise exception 'Payment amount must be greater than zero';
      end if;

      v_paid := v_paid + (v_payment->>'amount')::numeric;
    end loop;

    -- Payment ledger records actual business receipt, not tender/change.
    if round(v_paid,2) <> round(v_total,2) then
      raise exception 'Payment ledger amount must equal sale total';
    end if;
  end if;

  v_sale_no:=public.next_sale_no();

  insert into public.sales(
    id,sale_no,status,held,subtotal,discount,total,cashier_id,shift_id,notes,client_request_id
  )
  values(
    v_sale_id,v_sale_no,
    case when p_hold then 'held' else 'completed' end,
    p_hold,v_subtotal,p_discount,v_total,auth.uid(),v_shift_id,p_notes,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select
      p.selling_price,
      coalesce((
        select sum(
          ri.quantity_base_unit *
          case when rm.purchase_pack_base_qty>0
            then rm.current_purchase_cost/rm.purchase_pack_base_qty
            else 0 end
        )/r.yield_qty
        from public.recipes r
        join public.recipe_items ri on ri.recipe_id=r.id
        join public.raw_materials rm on rm.id=ri.raw_material_id
        where r.product_id=p.id and r.active=true
        group by r.id,r.yield_qty
      ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(
        sale_id,method,amount,reference,status,created_by
      )
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(trim(v_payment->>'reference'),''),
        'completed',
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    case when p_hold then 'hold_sale' else 'complete_sale' end,
    'sale',
    v_sale_id,
    jsonb_build_object(
      'sale_no',v_sale_no,
      'subtotal',v_subtotal,
      'discount',p_discount,
      'total',v_total,
      'shift_id',v_shift_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_sale_id;
end;
$$;

-- Correct refund cashflow: no negative payment row, preserve original payment method.
create table if not exists public.sale_refunds (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount>0),
  reason text not null,
  approved_by uuid not null references public.profiles(id),
  refunded_at timestamptz not null default now()
);

alter table public.sale_refunds enable row level security;

drop policy if exists "sales staff read sale refunds" on public.sale_refunds;
create policy "sales staff read sale refunds" on public.sale_refunds
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sale_refunds_sale_idx on public.sale_refunds(sale_id,refunded_at desc);

create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
  v_method public.payment_method;
  v_method_count integer;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then raise exception 'Unsupported action'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  v_approver:=public.verify_approver_pin(p_approval_pin);

  select * into v_sale
  from public.sales
  where id=p_sale_id
  for update;

  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status<>'held' then
      raise exception 'Paid/completed sales must be refunded rather than cancelled';
    end if;

    update public.sales
    set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    if v_sale.status not in ('completed','partially_refunded') then
      raise exception 'Only completed sales may be refunded';
    end if;

    v_refund:=coalesce(p_refund_amount,v_sale.total-v_sale.refund_total);
    if v_refund<=0 or v_refund>(v_sale.total-v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    select count(distinct method)
    into v_method_count
    from public.payments
    where sale_id=p_sale_id and status='completed';

    if v_method_count<>1 then
      raise exception 'Mixed-payment refund needs explicit allocation and is not enabled yet';
    end if;

    select method
    into v_method
    from public.payments
    where sale_id=p_sale_id and status='completed'
    limit 1;

    update public.sales
    set
      refund_total=refund_total+v_refund,
      status=case
        when refund_total+v_refund>=total then 'refunded'
        else 'partially_refunded'
      end
    where id=p_sale_id;

    insert into public.sale_refunds(
      sale_id,method,amount,reason,approved_by
    )
    values(
      p_sale_id,v_method,v_refund,p_reason,v_approver
    );
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;


-- Reporting view uses a proportional allocation for partial refunds until item-level
-- refund allocation is implemented. Fully refunded sales contribute zero.
create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  (si.quantity * f.net_factor)::numeric(14,3) as quantity,
  (si.line_total * f.net_factor)::numeric(14,2) as sales_amount,
  ((coalesce(si.unit_cost_snapshot,0) * si.quantity) * f.net_factor)::numeric(14,2) as cogs_amount,
  (
    coalesce(
      si.gross_profit_snapshot,
      si.line_total-(coalesce(si.unit_cost_snapshot,0)*si.quantity)
    ) * f.net_factor
  )::numeric(14,2) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
cross join lateral (
  select case
    when s.total<=0 then 0::numeric
    else greatest(s.total-coalesce(s.refund_total,0),0)/s.total
  end as net_factor
) f
where s.status in ('completed','partially_refunded','refunded');

-- Cashier shift summary.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,
  cs.cashier_id,
  p.full_name as cashier_name,
  cs.opened_at,
  cs.opening_float,
  cs.status,
  cs.closed_at,
  count(distinct s.id)::bigint as transaction_count,
  coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as gross_sales,
  (
    coalesce(sum(pay.cash_amount),0) -
    coalesce(sum(ref.cash_refund),0)
  )::numeric(14,2) as cash_sales
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id
left join public.sales s
  on s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
left join lateral (
  select coalesce(sum(py.amount),0) as cash_amount
  from public.payments py
  where py.sale_id=s.id and py.status='completed' and py.method='cash'
) pay on true
left join lateral (
  select coalesce(sum(sr.amount),0) as cash_refund
  from public.sale_refunds sr
  where sr.sale_id=s.id and sr.method='cash'
) ref on true
group by cs.id,cs.cashier_id,p.full_name,cs.opened_at,cs.opening_float,cs.status,cs.closed_at;

-- Non-mutating closing preview.
create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_cash_receipts numeric(14,2);
  v_mtn_receipts numeric(14,2);
  v_airtel_receipts numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_total_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)
  into v_cash_receipts,v_mtn_receipts,v_airtel_receipts
  from public.payments p
  where p.status='completed'
    and public.business_date(p.created_at)=p_business_date;

  select
    coalesce(sum(case when sr.method='cash' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='mtn_momo' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='airtel_money' then sr.amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds sr
  where public.business_date(sr.refunded_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(
      case when status in ('completed','partially_refunded','refunded')
        then total-coalesce(refund_total,0) else 0 end
    ),0)
  into v_tx_count,v_total_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_cash_receipts-v_cash_refunds,
    'mtn_momo_sales',v_mtn_receipts-v_mtn_refunds,
    'airtel_money_sales',v_airtel_receipts-v_airtel_refunds,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_cash_receipts-v_cash_refunds)+v_cash_in-v_cash_out-v_cash_exp,
    'transaction_count',v_tx_count,
    'total_sales',v_total_sales
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- Fix two financial SECURITY DEFINER functions that previously lacked internal role checks.
create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  with bounds as (
    select public.period_start(p_period) as start_at
  ),
  sales_summary as (
    select
      coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
      count(*)::bigint as transaction_count
    from public.sales s,bounds b
    where s.created_at>=b.start_at
      and s.status in ('completed','partially_refunded','refunded')
  ),
  payment_summary as (
    select
      (
        coalesce(sum(case when p.method='cash' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='cash' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as cash_sales,
      (
        coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='mtn_momo' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as mtn_momo_sales,
      (
        coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='airtel_money' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as airtel_money_sales
    from public.payments p,bounds b
    where p.created_at>=b.start_at and p.status='completed'
  ),
  profit_summary as (
    select coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
    from public.sale_profit_lines spl,bounds b
    where spl.created_at>=b.start_at
  ),
  expense_summary as (
    select coalesce(sum(amount),0)::numeric(14,2) as expenses
    from public.expenses e,bounds b
    where e.created_at>=b.start_at
  )
  select
    b.start_at,
    ss.sales,
    ps.cash_sales,
    ps.mtn_momo_sales,
    ps.airtel_money_sales,
    prs.gross_profit,
    es.expenses,
    (prs.gross_profit-es.expenses)::numeric(14,2),
    ss.transaction_count,
    case when ss.transaction_count>0
      then round(ss.sales/ss.transaction_count,2)
      else 0 end::numeric(14,2)
  from bounds b
  cross join sales_summary ss
  cross join payment_summary ps
  cross join profit_summary prs
  cross join expense_summary es;
end;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'',''refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

-- Tighten sensitive RPC execution. SECURITY DEFINER functions still perform their own role checks.
revoke all on function public.save_product(uuid,text,uuid,numeric,text) from public;
revoke all on function public.save_active_recipe(uuid,text,numeric,jsonb) from public;
revoke all on function public.record_stock_count(uuid,numeric,text) from public;
revoke all on function public.start_cashier_shift(numeric) from public;
revoke all on function public.close_cashier_shift(uuid,text) from public;
revoke all on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) from public;
revoke all on function public.approve_sale_action(uuid,text,text,text,numeric) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;
revoke all on function public.close_business_day(date,numeric,text) from public;
revoke all on function public.owner_dashboard_summary(text) from public;
revoke all on function public.sales_trend(text) from public;

grant execute on function public.business_current_date() to authenticated;
grant execute on function public.save_product(uuid,text,uuid,numeric,text) to authenticated;
grant execute on function public.save_active_recipe(uuid,text,numeric,jsonb) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text) to authenticated;
grant execute on function public.start_cashier_shift(numeric) to authenticated;
grant execute on function public.close_cashier_shift(uuid,text) to authenticated;
grant execute on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) to authenticated;
grant execute on function public.approve_sale_action(uuid,text,text,text,numeric) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;
grant execute on function public.close_business_day(date,numeric,text) to authenticated;
grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;

-- Business settings are management-only.
alter table public.business_settings enable row level security;

drop policy if exists "management read business settings" on public.business_settings;
create policy "management read business settings" on public.business_settings
for select using (public.current_staff_role() in ('owner','manager'));

drop policy if exists "owner manage business settings" on public.business_settings;
create policy "owner manage business settings" on public.business_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');


-- SOURCE FILE: 018_operations_live_wiring.sql

-- DS Bakery v0.19 / Migration 018
-- Operations live wiring: production, baker tasks, waste, purchasing/payables,
-- expenses, cash movements, plus closing cashflow completeness.

-- =====================================================================
-- PRODUCTION + BAKER TASKS
-- =====================================================================

alter table public.production_plan_items
  add column if not exists client_request_id uuid;

create unique index if not exists production_plan_client_request_unique
  on public.production_plan_items(client_request_id)
  where client_request_id is not null;

alter table public.production_runs
  add column if not exists recipe_id uuid references public.recipes(id),
  add column if not exists client_request_id uuid;

create unique index if not exists production_runs_client_request_unique
  on public.production_runs(client_request_id)
  where client_request_id is not null;

create type public.baker_task_status as enum ('todo','complete','cancelled');

create table if not exists public.baker_tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  assigned_baker_id uuid not null references public.profiles(id),
  product_id uuid references public.products(id),
  plan_item_id uuid references public.production_plan_items(id) on delete set null,
  due_at timestamptz,
  status public.baker_task_status not null default 'todo',
  notes text,
  created_by uuid not null references public.profiles(id),
  completed_by uuid references public.profiles(id),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.create_production_plan_item(
  p_business_date date,
  p_product_id uuid,
  p_assigned_baker_id uuid,
  p_shift public.production_shift,
  p_planned_qty numeric,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_existing uuid;
  v_date date := coalesce(p_business_date,public.business_current_date());
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create production plans';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_plan_items
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_planned_qty<=0 then
    raise exception 'Planned quantity must be greater than zero';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;

  if p_assigned_baker_id is not null and not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not an active baker';
  end if;

  insert into public.production_plan_items(
    id,business_date,product_id,assigned_baker_id,shift,
    planned_qty,produced_qty,status,notes,created_by,client_request_id
  )
  values(
    v_id,v_date,p_product_id,p_assigned_baker_id,p_shift,
    p_planned_qty,0,'planned',p_notes,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_production_plan','production_plan_item',v_id,
    jsonb_build_object(
      'business_date',v_date,
      'product_id',p_product_id,
      'assigned_baker_id',p_assigned_baker_id,
      'shift',p_shift,
      'planned_qty',p_planned_qty,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.confirm_production_run(uuid,numeric);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_existing uuid;
  v_item record;
  v_required numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_runs
    where client_request_id=p_client_request_id;

    if v_existing is not null then
      return v_existing;
    end if;
  end if;

  if p_quantity_produced<=0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then raise exception 'Production plan item not found'; end if;
  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id is distinct from auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining:=v_plan.planned_qty-v_plan.produced_qty;
  if p_quantity_produced>v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id and active=true;

  if not found then raise exception 'Product has no active recipe'; end if;

  -- Lock and validate every ingredient before any movement is inserted.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;

    if v_item.current_stock_qty<v_required then
      raise exception 'Insufficient stock for raw material %',v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(
    id,plan_item_id,recipe_id,quantity_produced,confirmed_by,client_request_id
  )
  values(
    v_run_id,p_plan_item_id,v_recipe.id,p_quantity_produced,auth.uid(),p_client_request_id
  );

  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;
    v_unit_cost:=v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,'usage',-v_required,v_unit_cost,
      'production_run',v_run_id,auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced>=planned_qty then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'confirm_production','production_run',v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'recipe_id',v_recipe.id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty>0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=public.business_current_date();

create or replace view public.production_run_summary
with (security_invoker=true)
as
select
  pr.id,
  pr.plan_item_id,
  pr.recipe_id,
  ppi.product_id,
  p.name as product_name,
  pr.quantity_produced,
  pr.confirmed_by,
  prof.full_name as confirmed_by_name,
  pr.confirmed_at
from public.production_runs pr
join public.production_plan_items ppi on ppi.id=pr.plan_item_id
join public.products p on p.id=ppi.product_id
left join public.profiles prof on prof.id=pr.confirmed_by;

create or replace function public.create_baker_task(
  p_title text,
  p_assigned_baker_id uuid,
  p_product_id uuid default null,
  p_plan_item_id uuid default null,
  p_due_at timestamptz default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create baker tasks';
  end if;

  if coalesce(trim(p_title),'')='' then raise exception 'Task title is required'; end if;

  if not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not active';
  end if;

  insert into public.baker_tasks(
    id,title,assigned_baker_id,product_id,plan_item_id,due_at,notes,created_by
  )
  values(
    v_id,trim(p_title),p_assigned_baker_id,p_product_id,p_plan_item_id,p_due_at,p_notes,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_baker_task','baker_task',v_id,
    jsonb_build_object('title',p_title,'assigned_baker_id',p_assigned_baker_id,'due_at',p_due_at)
  );

  return v_id;
end;
$$;

create or replace function public.set_baker_task_status(
  p_task_id uuid,
  p_status public.baker_task_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_task public.baker_tasks%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_task
  from public.baker_tasks
  where id=p_task_id
  for update;

  if not found then raise exception 'Baker task not found'; end if;

  if v_role in ('owner','manager') then
    null;
  elsif v_role='baker' and v_task.assigned_baker_id=auth.uid() and p_status in ('todo','complete') then
    null;
  else
    raise exception 'Not authorized to update this task';
  end if;

  update public.baker_tasks
  set
    status=p_status,
    completed_by=case when p_status='complete' then auth.uid() else null end,
    completed_at=case when p_status='complete' then now() else null end,
    updated_at=now()
  where id=p_task_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_baker_task_status','baker_task',p_task_id,
    jsonb_build_object('status',v_task.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.baker_task_summary
with (security_invoker=true)
as
select
  bt.id,
  bt.title,
  bt.assigned_baker_id,
  bp.full_name as baker_name,
  bt.product_id,
  p.name as product_name,
  bt.plan_item_id,
  bt.due_at,
  bt.status,
  bt.notes,
  bt.completed_at,
  bt.created_at
from public.baker_tasks bt
left join public.profiles bp on bp.id=bt.assigned_baker_id
left join public.products p on p.id=bt.product_id;

alter table public.baker_tasks enable row level security;

create policy "staff read relevant baker tasks" on public.baker_tasks
for select using (
  public.current_staff_role() in ('owner','manager')
  or assigned_baker_id=auth.uid()
);

drop policy if exists "production staff read consumption" on public.production_consumptions;
create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper')
  or (
    public.current_staff_role()='baker'
    and exists(
      select 1
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=production_consumptions.production_run_id
        and (pr.confirmed_by=auth.uid() or ppi.assigned_baker_id=auth.uid())
    )
  )
);

-- =====================================================================
-- WASTE + PRODUCTION CONTROL
-- =====================================================================

alter table public.waste_events
  add column if not exists client_request_id uuid;

create unique index if not exists waste_events_client_request_unique
  on public.waste_events(client_request_id)
  where client_request_id is not null;

drop policy if exists "management read waste settings" on public.waste_settings;
create policy "relevant staff read waste settings" on public.waste_settings
for select using (public.current_staff_role() in ('owner','manager','baker','storekeeper'));

drop function if exists public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid);

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,
  p_quantity numeric,
  p_reason text,
  p_product_id uuid default null,
  p_raw_material_id uuid default null,
  p_production_run_id uuid default null,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_unit_cost numeric(14,6);
  v_total numeric(14,2);
  v_threshold numeric(14,2);
  v_status public.waste_approval_status;
  v_waste_id uuid:=gen_random_uuid();
  v_run_product uuid;
  v_run_qty numeric;
  v_existing_waste numeric;
  v_existing uuid;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing
    from public.waste_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','baker','storekeeper') then
    raise exception 'Not authorized to record waste';
  end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;

  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then
      raise exception 'Finished-product waste requires product only';
    end if;

    if p_production_run_id is not null then
      select ppi.product_id,pr.quantity_produced
      into v_run_product,v_run_qty
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=p_production_run_id;

      if v_run_product is null or v_run_product<>p_product_id then
        raise exception 'Production run does not match product';
      end if;

      select coalesce(sum(quantity),0)
      into v_existing_waste
      from public.waste_events
      where production_run_id=p_production_run_id
        and waste_type='finished_product'
        and approval_status<>'rejected';

      if v_existing_waste+p_quantity>v_run_qty then
        raise exception 'Waste quantity exceeds remaining output of linked production run';
      end if;

      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else
      v_unit_cost:=public.current_product_unit_cost(p_product_id);
    end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then
      raise exception 'Raw-material waste requires raw material only';
    end if;

    select case when purchase_pack_base_qty>0
      then current_purchase_cost/purchase_pack_base_qty else 0 end
    into v_unit_cost
    from public.raw_materials
    where id=p_raw_material_id;

    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;

  v_total:=round((p_quantity*v_unit_cost)::numeric,2);

  select approval_threshold into v_threshold
  from public.waste_settings
  where id=1;

  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then
    v_status:='approved';
  else
    v_status:='pending';
  end if;

  insert into public.waste_events(
    id,waste_type,product_id,raw_material_id,production_run_id,
    quantity,reason,notes,unit_cost_snapshot,total_cost,
    approval_status,recorded_by,approved_by,approved_at,client_request_id
  )
  values(
    v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,
    p_quantity,trim(p_reason),p_notes,v_unit_cost,v_total,
    v_status,auth.uid(),
    case when v_status='approved' then auth.uid() end,
    case when v_status='approved' then now() end,
    p_client_request_id
  );

  if v_status='approved' and p_waste_type='raw_material' then
    perform public.apply_approved_raw_waste(v_waste_id);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_waste','waste_event',v_waste_id,
    jsonb_build_object(
      'waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,
      'total_cost',v_total,'approval_status',v_status,'production_run_id',p_production_run_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_waste_id;
end;
$$;

create or replace view public.waste_event_summary
with (security_invoker=true)
as
select
  we.id,
  we.waste_type,
  we.product_id,
  we.raw_material_id,
  we.production_run_id,
  coalesce(p.name,rm.name) as item_name,
  case when we.waste_type='finished_product' then 'pcs' else rm.base_unit end as base_unit,
  we.quantity,
  we.reason,
  we.notes,
  we.unit_cost_snapshot,
  we.total_cost,
  we.approval_status,
  we.recorded_by,
  prof.full_name as recorded_by_name,
  we.recorded_at,
  we.approved_by,
  we.approved_at,
  we.decision_note
from public.waste_events we
left join public.products p on p.id=we.product_id
left join public.raw_materials rm on rm.id=we.raw_material_id
left join public.profiles prof on prof.id=we.recorded_by;

create or replace view public.production_control_today
with (security_invoker=true)
as
with plan as (
  select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty
  from public.production_plan_items
  where business_date=public.business_current_date()
    and status<>'cancelled'
  group by product_id
),
product_waste as (
  select
    product_id,
    coalesce(sum(quantity),0) approved_waste_qty,
    coalesce(sum(total_cost),0) approved_waste_cost
  from public.waste_events
  where waste_type='finished_product'
    and approval_status='approved'
    and public.business_date(recorded_at)=public.business_current_date()
  group by product_id
)
select
  p.id product_id,
  p.name product_name,
  pl.planned_qty,
  pl.produced_qty,
  coalesce(pw.approved_waste_qty,0) approved_waste_qty,
  greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,
  (pl.produced_qty-pl.planned_qty) production_variance,
  case when pl.produced_qty>0
    then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2)
    else 0 end waste_rate_pct,
  coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl
join public.products p on p.id=pl.product_id
left join product_waste pw on pw.product_id=pl.product_id;

-- =====================================================================
-- PURCHASE ORDERS / RECEIVING / SUPPLIER PAYABLES
-- =====================================================================

alter table public.purchases
  add column if not exists client_request_id uuid;

create unique index if not exists purchases_client_request_unique
  on public.purchases(client_request_id)
  where client_request_id is not null;

alter table public.purchase_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists purchase_payments_client_request_unique
  on public.purchase_payments(client_request_id)
  where client_request_id is not null;

create unique index if not exists purchase_payments_reference_unique
  on public.purchase_payments(lower(method),reference)
  where reference is not null and lower(method)<>'cash';

create table if not exists public.purchase_receipt_events (
  id uuid primary key default gen_random_uuid(),
  purchase_item_id uuid not null references public.purchase_items(id) on delete restrict,
  quantity_received numeric(18,6) not null check (quantity_received>0),
  client_request_id uuid,
  received_by uuid not null references public.profiles(id),
  received_at timestamptz not null default now()
);

create unique index if not exists purchase_receipt_request_unique
  on public.purchase_receipt_events(client_request_id)
  where client_request_id is not null;

create sequence if not exists public.purchase_no_seq;

create or replace function public.next_purchase_no()
returns text
language sql
volatile
as $$
  select 'PO-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.purchase_no_seq')::text,6,'0')
$$;

create or replace function public.create_purchase_order(
  p_supplier_id uuid,
  p_purchase_date date,
  p_supplier_invoice_no text,
  p_invoice_date date,
  p_credit_terms_days integer,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
  v_cost numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to create purchase orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchases
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.suppliers where id=p_supplier_id and active=true) then
    raise exception 'Active supplier not found';
  end if;

  if p_credit_terms_days<0 then raise exception 'Credit terms cannot be negative'; end if;
  if coalesce(p_discount,0)<0 then raise exception 'Discount cannot be negative'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Purchase order needs at least one item';
  end if;

  -- Validate all lines before creating the order.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id:=(v_item->>'raw_material_id')::uuid;
    v_qty:=(v_item->>'ordered_qty_base')::numeric;
    v_cost:=(v_item->>'unit_cost_base')::numeric;

    if v_qty<=0 then raise exception 'Ordered quantity must be greater than zero'; end if;
    if v_cost<0 then raise exception 'Unit cost cannot be negative'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid raw material';
    end if;
  end loop;

  insert into public.purchases(
    id,purchase_no,supplier_id,purchase_date,supplier_reference,
    status,payment_status,subtotal,discount,total_amount,amount_paid,notes,
    created_by,requested_by,approval_status,supplier_invoice_no,invoice_date,
    credit_terms_days,client_request_id
  )
  values(
    v_id,public.next_purchase_no(),p_supplier_id,coalesce(p_purchase_date,public.business_current_date()),null,
    'draft','unpaid',0,coalesce(p_discount,0),0,0,p_notes,
    auth.uid(),auth.uid(),'pending',nullif(trim(p_supplier_invoice_no),''),p_invoice_date,
    p_credit_terms_days,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.purchase_items(
      purchase_id,raw_material_id,ordered_qty_base,received_qty_base,
      unit_cost_base,line_total
    )
    values(
      v_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'ordered_qty_base')::numeric,
      0,
      (v_item->>'unit_cost_base')::numeric,
      ((v_item->>'ordered_qty_base')::numeric*(v_item->>'unit_cost_base')::numeric)
    );
  end loop;

  perform public.refresh_purchase_totals(v_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_purchase_order','purchase',v_id,
    jsonb_build_object(
      'supplier_id',p_supplier_id,
      'items',p_items,
      'discount',coalesce(p_discount,0),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then v_approval:='approved';
  elsif p_decision='reject' then v_approval:='rejected';
  else raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status<>'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  if v_approval='approved' then
    if not exists(select 1 from public.purchase_items where purchase_id=p_purchase_id) then
      raise exception 'Purchase order has no lines';
    end if;
    if v_before.total_amount<=0 then
      raise exception 'Purchase order total must be greater than zero';
    end if;
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

drop function if exists public.receive_purchase_item(uuid,numeric);

create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_purchase public.purchases%rowtype;
  v_remaining numeric;
  v_receipt_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to receive stock';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_receipt_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_receive_qty_base<=0 then raise exception 'Received quantity must be greater than zero'; end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then raise exception 'Purchase item not found'; end if;

  select * into v_purchase
  from public.purchases
  where id=v_item.purchase_id
  for update;

  if v_purchase.approval_status<>'approved' then
    raise exception 'Purchase order must be approved before receiving';
  end if;
  if v_purchase.status not in ('ordered','partially_received') then
    raise exception 'Purchase order is not open for receiving';
  end if;

  v_remaining:=v_item.ordered_qty_base-v_item.received_qty_base;
  if p_receive_qty_base>v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  insert into public.purchase_receipt_events(
    id,purchase_item_id,quantity_received,client_request_id,received_by
  )
  values(
    v_receipt_id,p_purchase_item_id,p_receive_qty_base,p_client_request_id,auth.uid()
  );

  update public.purchase_items
  set received_qty_base=received_qty_base+p_receive_qty_base
  where id=p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase_receipt',v_receipt_id,v_item.id,auth.uid(),'Approved purchase receipt'
  );

  update public.purchases p
  set
    status=case
      when not exists(
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base<pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'receive_stock','purchase_receipt',v_receipt_id,
    jsonb_build_object(
      'purchase_item_id',p_purchase_item_id,
      'quantity_received',p_receive_qty_base,
      'client_request_id',p_client_request_id
    )
  );

  return v_receipt_id;
end;
$$;

drop function if exists public.record_supplier_payment(uuid,numeric,text,text);

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid:=gen_random_uuid();
  v_remaining numeric(14,2);
  v_existing uuid;
  v_method text:=lower(trim(p_method));
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if v_method not in ('cash','bank','mtn_momo','airtel_money') then
    raise exception 'Unsupported supplier payment method';
  end if;
  if v_method<>'cash' and coalesce(trim(p_reference),'')='' then
    raise exception 'Reference is required for non-cash supplier payment';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status<>'approved' then raise exception 'Purchase order is not approved'; end if;

  perform public.refresh_purchase_totals(p_purchase_id);

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  v_remaining:=v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds amount outstanding on purchase'; end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by,shift_id,client_request_id
  )
  values(
    v_payment_id,p_purchase_id,p_amount,v_method,
    nullif(trim(p_reference),''),now(),auth.uid(),p_shift_id,p_client_request_id
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,'amount',p_amount,'method',v_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.trg_refresh_purchase_item_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_items_refresh_totals on public.purchase_items;
create trigger trg_purchase_items_refresh_totals
after insert or update or delete
on public.purchase_items
for each row execute function public.trg_refresh_purchase_item_totals();

create or replace function public.trg_refresh_purchase_payment_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_payments_refresh_totals on public.purchase_payments;
create trigger trg_purchase_payments_refresh_totals
after insert or update or delete
on public.purchase_payments
for each row execute function public.trg_refresh_purchase_payment_totals();

-- Recalculate historical purchase totals after enabling automatic refresh.
do $$
declare r record;
begin
  for r in select id from public.purchases loop
    perform public.refresh_purchase_totals(r.id);
  end loop;
end $$;

drop policy if exists "purchasing staff manage purchases" on public.purchases;
drop policy if exists "purchasing staff manage purchase items" on public.purchase_items;
drop policy if exists "owner manager create purchase payments" on public.purchase_payments;

alter table public.purchase_receipt_events enable row level security;
create policy "purchasing staff read receipts" on public.purchase_receipt_events
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create or replace view public.purchase_order_summary
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.supplier_invoice_no,
  p.invoice_date,
  p.credit_terms_days,
  p.due_date,
  p.status,
  p.payment_status,
  p.approval_status,
  p.subtotal,
  p.discount,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name,
  p.created_at
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by;

create or replace view public.purchase_receiving_lines
with (security_invoker=true)
as
select
  pi.id,
  pi.purchase_id,
  p.purchase_no,
  p.purchase_date,
  p.status,
  p.approval_status,
  p.supplier_id,
  s.name as supplier_name,
  pi.raw_material_id,
  rm.name as material_name,
  rm.base_unit,
  pi.ordered_qty_base,
  pi.received_qty_base,
  (pi.ordered_qty_base-pi.received_qty_base) as remaining_qty_base,
  pi.unit_cost_base,
  pi.line_total
from public.purchase_items pi
join public.purchases p on p.id=pi.purchase_id
join public.suppliers s on s.id=p.supplier_id
join public.raw_materials rm on rm.id=pi.raw_material_id
where p.approval_status='approved'
  and p.status in ('ordered','partially_received');

create or replace view public.supplier_open_payables
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.due_date,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.payment_status
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
where p.approval_status='approved'
  and p.status<>'cancelled'
  and p.total_amount>p.amount_paid;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date<public.business_current_date()
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled' and p.total_amount>p.amount_paid then p.due_date
  end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- =====================================================================
-- EXPENSES + MANUAL CASH MOVEMENTS
-- =====================================================================

alter table public.expenses
  add column if not exists client_request_id uuid;

create unique index if not exists expenses_client_request_unique
  on public.expenses(client_request_id)
  where client_request_id is not null;

alter table public.expenses enable row level security;

drop policy if exists "management read expenses" on public.expenses;
create policy "management read expenses" on public.expenses
for select using (public.current_staff_role() in ('owner','manager'));

create unique index if not exists expenses_mobile_reference_unique
  on public.expenses(payment_method,reference)
  where reference is not null and payment_method in ('mtn_momo','airtel_money');

create or replace function public.record_business_expense(
  p_category text,
  p_description text,
  p_amount numeric,
  p_payment_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record expenses';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.expenses where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_category),'')='' then raise exception 'Expense category is required'; end if;
  if coalesce(trim(p_description),'')='' then raise exception 'Expense description is required'; end if;
  if p_amount<=0 then raise exception 'Expense amount must be greater than zero'; end if;

  if p_payment_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money expense reference is required';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.expenses(
    id,category,description,amount,payment_method,reference,shift_id,created_by,client_request_id
  )
  values(
    v_id,trim(p_category),trim(p_description),p_amount,p_payment_method,
    nullif(trim(p_reference),''),p_shift_id,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_expense','expense',v_id,
    jsonb_build_object(
      'category',p_category,'amount',p_amount,'payment_method',p_payment_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.expense_live_summary
with (security_invoker=true)
as
select
  e.id,
  public.business_date(e.created_at) as business_date,
  e.category,
  e.description,
  e.amount,
  e.payment_method,
  e.reference,
  e.shift_id,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_label,
  e.created_by,
  rp.full_name as recorded_by_name,
  e.created_at
from public.expenses e
left join public.profiles rp on rp.id=e.created_by
left join public.cashier_shifts cs on cs.id=e.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

alter table public.cash_movements
  add column if not exists client_request_id uuid;

create unique index if not exists cash_movements_client_request_unique
  on public.cash_movements(client_request_id)
  where client_request_id is not null;

drop policy if exists "cashier create own cash movement" on public.cash_movements;

create or replace function public.record_cash_movement(
  p_movement_type public.cash_movement_type,
  p_amount numeric,
  p_reason text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing from public.cash_movements where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record cash movements';
  end if;
  if p_amount<=0 then raise exception 'Cash movement amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Cash movement reason is required'; end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc
    limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post movement to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.cash_movements(
    id,shift_id,movement_type,amount,reason,reference,created_by,client_request_id
  )
  values(
    v_id,v_shift_id,p_movement_type,p_amount,trim(p_reason),nullif(trim(p_reference),''),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_cash_movement','cash_movement',v_id,
    jsonb_build_object(
      'movement_type',p_movement_type,'amount',p_amount,'reason',p_reason,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.cash_movement_summary
with (security_invoker=true)
as
select
  cm.id,
  cm.shift_id,
  cm.movement_type,
  cm.amount,
  cm.reason,
  cm.reference,
  cm.created_by,
  rp.full_name as created_by_name,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_cashier_name,
  cm.created_at
from public.cash_movements cm
left join public.profiles rp on rp.id=cm.created_by
left join public.cashier_shifts cs on cs.id=cm.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

-- Stop authenticated staff from bypassing controlled inventory/purchase ledgers with direct inserts.
drop policy if exists "authorized staff create inventory tx" on public.inventory_transactions;


-- Stock-count corrections are also idempotent because a retry must not post the same adjustment twice.
alter table public.inventory_transactions
  add column if not exists client_request_id uuid;

create unique index if not exists inventory_tx_client_request_unique
  on public.inventory_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.record_stock_count(uuid,numeric,text);

create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.inventory_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta:=p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost:=case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by,client_request_id
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason,
      'client_request_id',p_client_request_id
    )
  );

  return v_tx_id;
end;
$$;


-- Direct table-write policies from the prototype are removed for core controlled ledgers.
-- The live pages use audited SECURITY DEFINER RPCs instead.
drop policy if exists "owner manager manage products" on public.products;
drop policy if exists "storekeeper manager owner manage materials" on public.raw_materials;
drop policy if exists "owner manager manage recipes" on public.recipes;
drop policy if exists "owner manager manage recipe items" on public.recipe_items;
drop policy if exists "owner manager manage plan items" on public.production_plan_items;

-- =====================================================================
-- DAILY CLOSING: INCLUDE CUSTOMER ORDER RECEIPTS + SUPPLIER PAYMENTS
-- =====================================================================

alter table public.daily_closings
  add column if not exists cash_order_receipts numeric(14,2) not null default 0,
  add column if not exists mtn_order_receipts numeric(14,2) not null default 0,
  add column if not exists airtel_order_receipts numeric(14,2) not null default 0,
  add column if not exists cash_supplier_payments numeric(14,2) not null default 0,
  add column if not exists mtn_supplier_payments numeric(14,2) not null default 0,
  add column if not exists airtel_supplier_payments numeric(14,2) not null default 0;

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_pos_cash numeric(14,2);
  v_pos_mtn numeric(14,2);
  v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2);
  v_order_mtn numeric(14,2);
  v_order_airtel numeric(14,2);
  v_supplier_cash numeric(14,2);
  v_supplier_mtn numeric(14,2);
  v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_pos_cash,v_pos_mtn,v_pos_airtel
  from public.payments
  where status='completed'
    and public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds
  where public.business_date(refunded_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_cash,v_order_mtn,v_order_airtel
  from public.customer_order_payments
  where payment_status='completed'
    and public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0)
  into v_supplier_cash,v_supplier_mtn,v_supplier_airtel
  from public.purchase_payments
  where public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(case when status in ('completed','partially_refunded','refunded')
      then total-coalesce(refund_total,0) else 0 end),0)
  into v_tx_count,v_pos_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_pos_cash-v_cash_refunds,
    'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,
    'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash,
    'mtn_order_receipts',v_order_mtn,
    'airtel_order_receipts',v_order_airtel,
    'cash_supplier_payments',v_supplier_cash,
    'mtn_supplier_payments',v_supplier_mtn,
    'airtel_supplier_payments',v_supplier_airtel,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',
      v_opening+(v_pos_cash-v_cash_refunds)+v_order_cash+v_cash_in
      -v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,
    'total_sales',v_pos_sales,
    'customer_order_receipts',v_order_cash+v_order_mtn+v_order_airtel
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_order_receipts,mtn_order_receipts,airtel_order_receipts,
    cash_supplier_payments,mtn_supplier_payments,airtel_supplier_payments,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_order_receipts')::numeric,
    (v_s->>'mtn_order_receipts')::numeric,
    (v_s->>'airtel_order_receipts')::numeric,
    (v_s->>'cash_supplier_payments')::numeric,
    (v_s->>'mtn_supplier_payments')::numeric,
    (v_s->>'airtel_supplier_payments')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_order_receipts=excluded.cash_order_receipts,
    mtn_order_receipts=excluded.mtn_order_receipts,
    airtel_order_receipts=excluded.airtel_order_receipts,
    cash_supplier_payments=excluded.cash_supplier_payments,
    mtn_supplier_payments=excluded.mtn_supplier_payments,
    airtel_supplier_payments=excluded.airtel_supplier_payments,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- =====================================================================
-- RLS / EXECUTE HARDENING
-- =====================================================================

revoke all on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) from public;
revoke all on function public.confirm_production_run(uuid,numeric,uuid) from public;
revoke all on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) from public;
revoke all on function public.set_baker_task_status(uuid,public.baker_task_status) from public;
revoke all on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) from public;
revoke all on function public.decide_waste_event(uuid,text,text) from public;
revoke all on function public.apply_approved_raw_waste(uuid) from public;
revoke all on function public.current_product_unit_cost(uuid) from public;
revoke all on function public.production_run_unit_cost(uuid) from public;
revoke all on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) from public;
revoke all on function public.decide_purchase_order(uuid,text,text) from public;
revoke all on function public.receive_purchase_item(uuid,numeric,uuid) from public;
revoke all on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) from public;
revoke all on function public.refresh_purchase_totals(uuid) from public;
revoke all on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) from public;
revoke all on function public.record_stock_count(uuid,numeric,text,uuid) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;

grant execute on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) to authenticated;
grant execute on function public.confirm_production_run(uuid,numeric,uuid) to authenticated;
grant execute on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) to authenticated;
grant execute on function public.set_baker_task_status(uuid,public.baker_task_status) to authenticated;
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
grant execute on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.receive_purchase_item(uuid,numeric,uuid) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text,uuid) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;

create index if not exists baker_tasks_assigned_due_idx
  on public.baker_tasks(assigned_baker_id,status,due_at);

create index if not exists production_runs_recipe_idx
  on public.production_runs(recipe_id,confirmed_at desc);

create index if not exists purchase_receipts_item_idx
  on public.purchase_receipt_events(purchase_item_id,received_at desc);

create index if not exists expenses_created_idx
  on public.expenses(created_at desc);


-- SOURCE FILE: 019_customer_service_live_wiring.sql

-- DS Bakery v0.20 / Migration 019
-- Customer & service live wiring:
-- customers, customer orders/deposits, custom cakes, delivery/riders,
-- loyalty/retention, WhatsApp click-to-chat and shared Mobile Money reference control.

-- =====================================================================
-- SHARED MOBILE MONEY REFERENCE REGISTRY
-- =====================================================================

create table if not exists public.mobile_money_reference_registry (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('mtn_momo','airtel_money')),
  direction text not null check (direction in ('inbound','outbound')),
  reference text not null,
  source_type text not null,
  source_id uuid not null,
  created_at timestamptz not null default now()
);

create unique index if not exists mobile_money_reference_global_unique
  on public.mobile_money_reference_registry(provider,direction,lower(reference));

create unique index if not exists mobile_money_reference_source_unique
  on public.mobile_money_reference_registry(source_type,source_id);

create or replace function public.trg_register_mobile_money_reference()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_provider text;
  v_direction text;
  v_reference text;
begin
  if tg_table_name='payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='customer_order_payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='expenses' then
    v_provider:=new.payment_method::text;
    v_direction:='outbound';
    v_reference:=new.reference;
  elsif tg_table_name='purchase_payments' then
    v_provider:=lower(new.method);
    v_direction:='outbound';
    v_reference:=new.reference;
  else
    return new;
  end if;

  if v_provider not in ('mtn_momo','airtel_money')
     or coalesce(trim(v_reference),'')='' then
    return new;
  end if;

  insert into public.mobile_money_reference_registry(
    provider,direction,reference,source_type,source_id
  )
  values(
    v_provider,v_direction,trim(v_reference),tg_table_name,new.id
  );

  return new;
end;
$$;

drop trigger if exists trg_payments_mobile_registry on public.payments;
create trigger trg_payments_mobile_registry
after insert on public.payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_customer_order_payments_mobile_registry on public.customer_order_payments;
create trigger trg_customer_order_payments_mobile_registry
after insert on public.customer_order_payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_expenses_mobile_registry on public.expenses;
create trigger trg_expenses_mobile_registry
after insert on public.expenses
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_purchase_payments_mobile_registry on public.purchase_payments;
create trigger trg_purchase_payments_mobile_registry
after insert on public.purchase_payments
for each row execute function public.trg_register_mobile_money_reference();

-- Backfill existing references. ON CONFLICT preserves migration progress while a conflict view
-- makes any historical duplicates visible for reconciliation.
insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'payments',id
from public.payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'customer_order_payments',id
from public.customer_order_payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select payment_method::text,'outbound',trim(reference),'expenses',id
from public.expenses
where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select lower(method),'outbound',trim(reference),'purchase_payments',id
from public.purchase_payments
where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

create or replace view public.mobile_money_reference_conflicts
with (security_invoker=true)
as
with refs as (
  select method::text provider,'inbound'::text direction,lower(trim(reference)) reference,'payments' source_table,id
  from public.payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select method::text,'inbound',lower(trim(reference)),'customer_order_payments',id
  from public.customer_order_payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select payment_method::text,'outbound',lower(trim(reference)),'expenses',id
  from public.expenses where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select lower(method),'outbound',lower(trim(reference)),'purchase_payments',id
  from public.purchase_payments where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
)
select provider,direction,reference,count(*)::bigint as occurrence_count,
       string_agg(source_table || ':' || id::text,', ' order by source_table) as sources
from refs
group by provider,direction,reference
having count(*)>1;

alter table public.mobile_money_reference_registry enable row level security;
create policy "management read mobile money registry"
on public.mobile_money_reference_registry
for select using (public.current_staff_role() in ('owner','manager'));


-- Private custom-cake reference bucket when this migration runs inside Supabase.
do $storage$
begin
  if to_regclass('storage.buckets') is not null and to_regclass('storage.objects') is not null then
    execute 'insert into storage.buckets(id,name,public) values (''custom-cake-references'',''custom-cake-references'',false)
             on conflict(id) do update set public=false';

    execute 'drop policy if exists "ds bakery custom cake read" on storage.objects';
    execute 'create policy "ds bakery custom cake read" on storage.objects
             for select using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'',''baker'')
             )';

    execute 'drop policy if exists "ds bakery custom cake upload" on storage.objects';
    execute 'create policy "ds bakery custom cake upload" on storage.objects
             for insert with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake update" on storage.objects';
    execute 'create policy "ds bakery custom cake update" on storage.objects
             for update using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             ) with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake delete" on storage.objects';
    execute 'create policy "ds bakery custom cake delete" on storage.objects
             for delete using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'')
             )';
  end if;
end
$storage$;

-- =====================================================================
-- CUSTOMERS
-- =====================================================================

alter table public.customers
  add column if not exists client_request_id uuid;

create unique index if not exists customers_client_request_unique
  on public.customers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_customer(
  p_customer_id uuid,
  p_full_name text,
  p_phone text,
  p_email text,
  p_address text,
  p_birthday date,
  p_notes text,
  p_whatsapp_opt_in boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_customer_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to save customers';
  end if;
  if coalesce(trim(p_full_name),'')='' then raise exception 'Customer name is required'; end if;

  if p_customer_id is null and p_client_request_id is not null then
    select id into v_existing from public.customers where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(c) into v_before from public.customers c where c.id=p_customer_id;

  insert into public.customers(
    id,full_name,phone,email,address,birthday,notes,active,created_by,
    whatsapp_opt_in,whatsapp_opt_in_at,whatsapp_opt_out_at,client_request_id
  )
  values(
    v_id,trim(p_full_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_address),''),p_birthday,p_notes,true,auth.uid(),
    coalesce(p_whatsapp_opt_in,false),
    case when p_whatsapp_opt_in then now() end,
    null,
    p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,
    phone=excluded.phone,
    email=excluded.email,
    address=excluded.address,
    birthday=excluded.birthday,
    notes=excluded.notes,
    whatsapp_opt_in=excluded.whatsapp_opt_in,
    whatsapp_opt_in_at=case
      when excluded.whatsapp_opt_in and not customers.whatsapp_opt_in then now()
      else customers.whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case
      when not excluded.whatsapp_opt_in and customers.whatsapp_opt_in then now()
      when excluded.whatsapp_opt_in then null
      else customers.whatsapp_opt_out_at end,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_customer_id is null then 'create_customer' else 'update_customer' end,
    'customer',v_id,v_before,
    (select to_jsonb(c) from public.customers c where c.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "sales staff manage customers" on public.customers;

create or replace view public.customer_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) total_order_value,
    coalesce(sum(
      case when co.status<>'cancelled' then
        co.total_amount-coalesce((
          select sum(cop.amount) from public.customer_order_payments cop
          where cop.order_id=co.id and cop.payment_status='completed'
        ),0)
      else 0 end
    ),0)::numeric(14,2) outstanding_balance,
    max(co.created_at) filter (where co.status<>'cancelled') last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  group by c.id
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  coalesce(os.order_count,0) order_count,
  coalesce(os.total_order_value,0)::numeric(14,2) total_order_value,
  coalesce(os.outstanding_balance,0)::numeric(14,2) outstanding_balance,
  os.last_order_at,
  c.address,
  c.birthday,
  c.notes,
  c.whatsapp_opt_in
from public.customers c
left join order_stats os on os.customer_id=c.id
where c.active=true;

-- =====================================================================
-- CUSTOMER ORDERS / DEPOSITS
-- =====================================================================

create sequence if not exists public.customer_order_no_seq;

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.customer_order_no_seq')::text,6,'0')
$$;

alter table public.customer_orders
  add column if not exists client_request_id uuid;

create unique index if not exists customer_orders_client_request_unique
  on public.customer_orders(client_request_id)
  where client_request_id is not null;

alter table public.customer_order_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists customer_order_payments_client_request_unique
  on public.customer_order_payments(client_request_id)
  where client_request_id is not null;

create or replace function public.create_customer_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty numeric;
  v_subtotal numeric(14,2):=0;
  v_discount numeric(14,2):=greatest(coalesce(p_discount,0),0);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create customer orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.customer_orders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Order needs at least one product';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty:=(v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Order quantity must be greater than zero'; end if;

    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if not found then raise exception 'Invalid or inactive product'; end if;
    v_subtotal:=v_subtotal+(v_product.selling_price*v_qty);
  end loop;

  if v_discount>v_subtotal then raise exception 'Discount cannot exceed subtotal'; end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    v_subtotal,v_discount,greatest(v_subtotal-v_discount,0),p_notes,auth.uid(),p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid;

    v_qty:=(v_item->>'quantity')::numeric;

    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(
      v_id,v_product.id,v_product.name,v_qty,v_product.selling_price,
      v_product.selling_price*v_qty,nullif(trim(v_item->>'customization_notes'),'')
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_customer_order','customer_order',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'fulfillment',p_fulfillment,
      'required_at',p_required_at,'subtotal',v_subtotal,'discount',v_discount,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.record_customer_order_payment(uuid,numeric,public.payment_method,text);

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.customer_order_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_method in ('mtn_momo','airtel_money') and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post payment to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_remaining:=v_order.total_amount-v_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds outstanding order balance'; end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,payment_status,recorded_by,paid_at,shift_id,client_request_id
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,nullif(trim(p_reference),''),
    'completed',auth.uid(),now(),v_shift_id,p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,'amount',p_amount,'method',p_method,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

drop function if exists public.update_customer_order_status(uuid,public.customer_order_status);

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
  v_paid numeric(14,2);
  v_valid boolean:=false;
  v_cake_status public.custom_cake_design_status;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;

  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_before.status in ('completed','cancelled') then raise exception 'Order is already closed'; end if;
  if p_status=v_before.status then return; end if;

  if p_status='cancelled' then
    if v_role not in ('owner','manager','cashier') then raise exception 'Baker cannot cancel customer orders'; end if;
    if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;
    select coalesce(sum(amount),0) into v_paid
    from public.customer_order_payments where order_id=p_order_id and payment_status='completed';
    if v_paid>0 then
      raise exception 'Paid orders cannot be cancelled until a customer-order refund workflow is completed';
    end if;
    v_valid:=true;
  elsif v_role='baker' then
    v_valid:=(v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready');
  elsif v_role='cashier' then
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  else
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  end if;

  if not v_valid then raise exception 'Invalid order status transition'; end if;

  if p_status='in_production' and exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    select design_status into v_cake_status from public.custom_cake_specs where order_id=p_order_id;
    if v_cake_status<>'approved' then raise exception 'Custom cake must be approved before production'; end if;
  end if;

  if p_status='completed' and v_before.fulfillment='delivery' then
    raise exception 'Delivery orders are completed through the delivery workflow';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    cancellation_reason=case when p_status='cancelled' then trim(p_reason) else cancellation_reason end,
    updated_at=now()
  where id=p_order_id;

  if exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    update public.custom_cake_specs
    set
      design_status=case
        when p_status='in_production' then 'in_production'::public.custom_cake_design_status
        when p_status='ready' then 'ready'::public.custom_cake_design_status
        when p_status='completed' then 'completed'::public.custom_cake_design_status
        when p_status='cancelled' then 'cancelled'::public.custom_cake_design_status
        else design_status end,
      updated_at=now()
    where order_id=p_order_id;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status,'reason',p_reason)
  );
end;
$$;

drop policy if exists "sales staff manage customer orders" on public.customer_orders;
drop policy if exists "sales staff manage customer order items" on public.customer_order_items;
drop policy if exists "sales staff create customer order payments" on public.customer_order_payments;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
with items as (
  select
    coi.order_id,
    count(*)::bigint item_count,
    string_agg(
      coi.description || ' × ' ||
      trim(to_char(coi.quantity,'FM999999990.###')),
      ', ' order by coi.created_at
    ) item_summary
  from public.customer_order_items coi
  group by coi.order_id
),
paid as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) amount_paid
  from public.customer_order_payments
  where payment_status='completed'
  group by order_id
)
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(pa.amount_paid,0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(pa.amount_paid,0))::numeric(14,2) balance_due,
  co.created_at,
  co.updated_at,
  co.delivery_charge,
  co.subtotal,
  co.discount,
  coalesce(i.item_count,0)::bigint item_count,
  coalesce(i.item_summary,'') item_summary,
  co.notes
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join items i on i.order_id=co.id
left join paid pa on pa.order_id=co.id;

-- Optional customer attachment at POS is performed atomically around the existing sale RPC.
create or replace function public.complete_sale_with_customer(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null,
  p_customer_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid;
  v_existing_customer uuid;
begin
  if p_customer_id is not null and not exists(
    select 1 from public.customers where id=p_customer_id and active=true
  ) then
    raise exception 'Active customer not found';
  end if;

  v_sale_id:=public.complete_sale(
    p_items,p_discount,p_payments,p_notes,p_hold,p_client_request_id
  );

  if p_customer_id is not null then
    select customer_id into v_existing_customer
    from public.sales where id=v_sale_id for update;

    if v_existing_customer is not null and v_existing_customer<>p_customer_id then
      raise exception 'Idempotent sale already belongs to another customer';
    end if;

    update public.sales
    set customer_id=p_customer_id
    where id=v_sale_id and customer_id is null;

    perform public.sync_sale_loyalty_points(v_sale_id);
  end if;

  return v_sale_id;
end;
$$;

-- Cashier-shift reconciliation now includes customer-order cash, expenses,
-- supplier payments and manual cash movements linked to the till.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,cs.cashier_id,p.full_name cashier_name,cs.opened_at,cs.opening_float,
  cs.status,cs.closed_at,

  (select count(*)::bigint
   from public.sales s
   where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ) transaction_count,

  coalesce((
    select sum(s.total-coalesce(s.refund_total,0))
    from public.sales s
    where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ),0)::numeric(14,2) gross_sales,

  (
    coalesce((
      select sum(py.amount)
      from public.payments py
      join public.sales s on s.id=py.sale_id
      where s.shift_id=cs.id and py.status='completed' and py.method='cash'
    ),0)
    -
    coalesce((
      select sum(sr.amount)
      from public.sale_refunds sr
      join public.sales s on s.id=sr.sale_id
      where s.shift_id=cs.id and sr.method='cash'
    ),0)
  )::numeric(14,2) cash_sales,

  coalesce((
    select sum(cop.amount)
    from public.customer_order_payments cop
    where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'
  ),0)::numeric(14,2) order_cash_receipts,

  coalesce((
    select sum(case when cm.movement_type='cash_in' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_in,

  coalesce((
    select sum(case when cm.movement_type='cash_out' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_out,

  coalesce((
    select sum(e.amount)
    from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'
  ),0)::numeric(14,2) cash_expenses,

  coalesce((
    select sum(pp.amount)
    from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'
  ),0)::numeric(14,2) supplier_cash_payments,

  (
    cs.opening_float
    + (
      coalesce((
        select sum(py.amount)
        from public.payments py
        join public.sales s on s.id=py.sale_id
        where s.shift_id=cs.id and py.status='completed' and py.method='cash'
      ),0)
      -
      coalesce((
        select sum(sr.amount)
        from public.sale_refunds sr
        join public.sales s on s.id=sr.sale_id
        where s.shift_id=cs.id and sr.method='cash'
      ),0)
    )
    + coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
    + coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_in'),0)
    - coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_out'),0)
    - coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)
    - coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)
  )::numeric(14,2) expected_cash
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id;

revoke all on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) from public;
grant execute on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) to authenticated;

-- =====================================================================
-- CUSTOM CAKES
-- =====================================================================

alter table public.custom_cake_specs
  add column if not exists order_item_id uuid references public.customer_order_items(id),
  add column if not exists client_request_id uuid;

create unique index if not exists custom_cake_client_request_unique
  on public.custom_cake_specs(client_request_id)
  where client_request_id is not null;

create table if not exists public.custom_cake_settings (
  id integer primary key default 1 check(id=1),
  deposit_percent numeric(5,2) not null default 50 check(deposit_percent>0 and deposit_percent<=100),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.custom_cake_settings(id,deposit_percent)
values(1,50)
on conflict(id) do nothing;

-- Backfill an order item for earlier custom-cake rows so refresh_customer_order_total remains authoritative.
do $$
declare
  r record;
  v_item_id uuid;
begin
  for r in
    select ccs.id,ccs.order_id,ccs.quote_amount
    from public.custom_cake_specs ccs
    where ccs.order_item_id is null
  loop
    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(r.order_id,null,'Custom Cake',1,r.quote_amount,r.quote_amount,'Custom cake specification')
    returning id into v_item_id;

    update public.custom_cake_specs set order_item_id=v_item_id where id=r.id;
    perform public.refresh_customer_order_total(r.order_id);
  end loop;
end $$;

create or replace function public.create_custom_cake_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_cake_size_label text,
  p_servings integer,
  p_tiers integer,
  p_flavour text,
  p_filling text,
  p_frosting text,
  p_theme text,
  p_primary_color text,
  p_secondary_color text,
  p_inscription text,
  p_special_instructions text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order_id uuid:=gen_random_uuid();
  v_spec_id uuid:=gen_random_uuid();
  v_item_id uuid;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create custom cake orders';
  end if;

  if p_client_request_id is not null then
    select order_id into v_existing
    from public.custom_cake_specs
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if coalesce(p_tiers,1)<=0 then raise exception 'Tiers must be greater than zero'; end if;
  if p_servings is not null and p_servings<=0 then raise exception 'Servings must be greater than zero'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_order_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    0,0,0,'Custom cake order',auth.uid(),p_client_request_id
  );

  insert into public.customer_order_items(
    order_id,product_id,description,quantity,unit_price,line_total,customization_notes
  )
  values(
    v_order_id,null,'Custom Cake',1,0,0,'Custom cake specification'
  )
  returning id into v_item_id;

  insert into public.custom_cake_specs(
    id,order_id,order_item_id,cake_size_label,servings,tiers,flavour,filling,frosting,
    theme,primary_color,secondary_color,inscription,special_instructions,quote_amount,
    design_status,created_by,client_request_id
  )
  values(
    v_spec_id,v_order_id,v_item_id,nullif(trim(p_cake_size_label),''),p_servings,coalesce(p_tiers,1),
    nullif(trim(p_flavour),''),nullif(trim(p_filling),''),nullif(trim(p_frosting),''),
    nullif(trim(p_theme),''),nullif(trim(p_primary_color),''),nullif(trim(p_secondary_color),''),
    nullif(trim(p_inscription),''),p_special_instructions,0,'draft',auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_custom_cake','custom_cake_spec',v_spec_id,
    jsonb_build_object('order_id',v_order_id,'customer_id',p_customer_id,'required_at',p_required_at)
  );

  return v_order_id;
end;
$$;

create or replace function public.save_custom_cake_reference_path(
  p_order_id uuid,
  p_reference_image_path text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_before text;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update custom cake reference image';
  end if;
  if coalesce(trim(p_reference_image_path),'')='' then raise exception 'Reference image path is required'; end if;

  select reference_image_path into v_before
  from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake not found'; end if;

  update public.custom_cake_specs
  set reference_image_path=trim(p_reference_image_path),updated_at=now()
  where order_id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_custom_cake_reference','customer_order',p_order_id,
    jsonb_build_object('reference_image_path',v_before),
    jsonb_build_object('reference_image_path',p_reference_image_path)
  );
end;
$$;

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;
  if p_quote_amount<=0 then raise exception 'Quote amount must be greater than zero'; end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(p_quote_amount-v_order.discount,0)+v_order.delivery_charge;
  if v_new_total<v_paid then raise exception 'Quote would reduce order total below payments already recorded'; end if;

  update public.customer_order_items
  set unit_price=p_quote_amount,line_total=p_quote_amount
  where id=v_spec.order_item_id;

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status end,
    updated_at=now()
  where order_id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
  v_pct numeric(5,2);
  v_required numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount<=0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  select deposit_percent into v_pct from public.custom_cake_settings where id=1;
  v_required:=round(v_spec.quote_amount*coalesce(v_pct,50)/100,2);

  if v_paid<v_required then
    raise exception 'Required deposit has not been reached';
  end if;

  update public.custom_cake_specs
  set design_status='approved',production_approved_by=auth.uid(),
      production_approved_at=now(),updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set status='confirmed',updated_at=now()
  where id=p_order_id and status='pending';

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid,'deposit_required',v_required
    )
  );
end;
$$;

drop policy if exists "sales staff create custom cakes" on public.custom_cake_specs;
drop policy if exists "sales staff update custom cakes" on public.custom_cake_specs;

alter table public.custom_cake_settings enable row level security;
create policy "relevant staff read custom cake settings"
on public.custom_cake_settings
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0))::numeric(14,2) balance_due,
  ccs.design_status,
  co.status order_status,
  round(ccs.quote_amount*cs.deposit_percent/100,2)::numeric(14,2) deposit_required
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
cross join public.custom_cake_settings cs
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,co.required_at,
  co.fulfillment,co.delivery_address,ccs.cake_size_label,ccs.servings,ccs.tiers,
  ccs.flavour,ccs.filling,ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,ccs.production_notes,
  ccs.quote_amount,cs.deposit_percent,ccs.design_status,co.status,co.total_amount;

-- =====================================================================
-- DELIVERY / RIDERS
-- =====================================================================

alter table public.delivery_riders
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_riders_client_request_unique
  on public.delivery_riders(client_request_id)
  where client_request_id is not null;

alter table public.delivery_jobs
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_jobs_client_request_unique
  on public.delivery_jobs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_delivery_rider(
  p_rider_id uuid,
  p_full_name text,
  p_phone text,
  p_vehicle_label text,
  p_active boolean,
  p_notes text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_rider_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage riders';
  end if;
  if coalesce(trim(p_full_name),'')='' or coalesce(trim(p_phone),'')='' then
    raise exception 'Rider name and phone are required';
  end if;

  if p_rider_id is null and p_client_request_id is not null then
    select id into v_existing from public.delivery_riders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(r) into v_before from public.delivery_riders r where r.id=p_rider_id;

  insert into public.delivery_riders(
    id,full_name,phone,vehicle_label,active,notes,created_by,client_request_id
  )
  values(
    v_id,trim(p_full_name),trim(p_phone),nullif(trim(p_vehicle_label),''),
    coalesce(p_active,true),p_notes,auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,phone=excluded.phone,vehicle_label=excluded.vehicle_label,
    active=excluded.active,notes=excluded.notes,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_rider_id is null then 'create_delivery_rider' else 'update_delivery_rider' end,
    'delivery_rider',v_id,v_before,
    (select to_jsonb(r) from public.delivery_riders r where r.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.create_delivery_job(uuid,numeric,text,timestamptz);

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.delivery_jobs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_delivery_charge<0 then raise exception 'Delivery charge cannot be negative'; end if;
  if coalesce(trim(p_address),'')='' then raise exception 'Delivery address is required'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment<>'delivery' then raise exception 'Order is not marked for delivery'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot create delivery for cancelled order'; end if;
  if exists(select 1 from public.delivery_jobs where order_id=p_order_id) then
    raise exception 'Delivery job already exists for this order';
  end if;

  select * into v_customer from public.customers where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;
  if v_new_total<v_paid then raise exception 'New order total would be less than payments already recorded'; end if;

  update public.customer_orders
  set delivery_charge=p_delivery_charge,delivery_address=trim(p_address),updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,delivery_address_snapshot,
    customer_name_snapshot,customer_phone_snapshot,delivery_charge,created_by,client_request_id
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    trim(p_address),v_customer.full_name,v_customer.phone,p_delivery_charge,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job from public.delivery_jobs where id=p_delivery_id for update;
  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order from public.customer_orders where id=v_job.order_id for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then raise exception 'Delivery must be assigned or failed before dispatch'; end if;
    if v_job.rider_id is null then raise exception 'Assign a rider before dispatch'; end if;
    if v_order.status<>'ready' then raise exception 'Customer order must be ready before dispatch'; end if;

    update public.delivery_jobs
    set status='out_for_delivery',dispatched_by=auth.uid(),dispatched_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may be completed'; end if;

    update public.delivery_jobs
    set status='delivered',delivered_by=auth.uid(),delivered_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set status='completed',completed_at=now(),updated_at=now()
    where id=v_job.order_id;

    update public.custom_cake_specs
    set design_status='completed',updated_at=now()
    where order_id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may fail'; end if;
    if coalesce(trim(p_note),'')='' then raise exception 'Failure reason is required'; end if;

    update public.delivery_jobs
    set status='failed',failed_at=now(),outcome_note=trim(p_note),updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then raise exception 'Delivered job cannot be cancelled'; end if;

    update public.delivery_jobs
    set status='cancelled',outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;
  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

drop policy if exists "owner manager manage riders" on public.delivery_riders;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id rider_id,dr.full_name,dr.phone,dr.vehicle_label,dr.active,
  count(dj.id) filter(where dj.status in ('assigned','out_for_delivery'))::bigint active_jobs,
  count(dj.id) filter(
    where dj.status='delivered' and public.business_date(dj.delivered_at)=public.business_current_date()
  )::bigint delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

-- =====================================================================
-- LOYALTY / RETENTION
-- =====================================================================

alter table public.loyalty_point_transactions
  add column if not exists value_amount numeric(14,2) not null default 0,
  add column if not exists client_request_id uuid;

create unique index if not exists loyalty_client_request_unique
  on public.loyalty_point_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.redeem_loyalty_on_order(uuid,integer);

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer,
  p_client_request_id uuid default null
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
  v_existing numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  if p_client_request_id is not null then
    select value_amount into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id and event_type='reward_redemption';
    if v_existing is not null then return v_existing; end if;
  end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then raise exception 'Cannot redeem on a closed order'; end if;

  perform 1 from public.customers where id=v_order.customer_id for update;

  select points_balance into v_balance
  from public.customer_loyalty_balances where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings where id=1;

  if p_points<=0 or mod(p_points,v_reward_points)<>0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points>v_balance then raise exception 'Insufficient loyalty points'; end if;

  v_units:=p_points/v_reward_points;
  v_discount:=v_units*v_reward_value;

  if v_discount>greatest(v_order.subtotal-v_order.discount,0) then
    raise exception 'Reward discount exceeds remaining merchandise value';
  end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0)<v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,value_amount,source_type,source_id,
    reason,created_by,client_request_id
  )
  values(
    v_order.customer_id,'reward_redemption',-p_points,v_discount,
    'customer_order',p_order_id,'Loyalty reward applied to customer order',
    auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount,'client_request_id',p_client_request_id)
  );

  return v_discount;
end;
$$;

drop function if exists public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type);

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment',
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  perform 1 from public.customers where id=p_customer_id for update;
  if not found then raise exception 'Customer not found'; end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if coalesce(v_balance,0)+p_points<0 then
    raise exception 'Adjustment would make points negative';
  end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,value_amount,source_type,
    reason,created_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,0,'manual',
    trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'points_delta',p_points,
      'reason',p_reason,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_loyalty_settings(
  p_earn_amount_per_point numeric,
  p_reward_points integer,
  p_reward_value numeric,
  p_birthday_reminder_days integer,
  p_vip_spend_threshold numeric,
  p_regular_spend_threshold numeric,
  p_regular_order_threshold integer
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update loyalty settings';
  end if;

  if p_earn_amount_per_point<=0 or p_reward_points<=0 or p_reward_value<0 then
    raise exception 'Invalid loyalty earning/reward settings';
  end if;
  if p_birthday_reminder_days<1 or p_birthday_reminder_days>90 then
    raise exception 'Birthday reminder days must be 1 to 90';
  end if;

  update public.loyalty_settings
  set
    earn_amount_per_point=p_earn_amount_per_point,
    reward_points=p_reward_points,
    reward_value=p_reward_value,
    birthday_reminder_days=p_birthday_reminder_days,
    vip_spend_threshold=p_vip_spend_threshold,
    regular_spend_threshold=p_regular_spend_threshold,
    regular_order_threshold=p_regular_order_threshold,
    updated_by=auth.uid(),updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'update_loyalty_settings','loyalty_settings',null,
    jsonb_build_object(
      'earn_amount_per_point',p_earn_amount_per_point,'reward_points',p_reward_points,
      'reward_value',p_reward_value,'birthday_reminder_days',p_birthday_reminder_days
    )
  );
end;
$$;

drop policy if exists "owner manage loyalty settings" on public.loyalty_settings;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id customer_id,c.full_name,c.phone,c.birthday,b.next_birthday,
  (b.next_birthday-public.business_current_date()) days_until_birthday,
  coalesce(lb.points_balance,0) points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date next_birthday
  from generate_series(
    public.business_current_date(),
    public.business_current_date()+interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d limit 1
) b
where c.active=true and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter(where co.status<>'cancelled')::bigint customer_order_count,
    coalesce(sum(co.total_amount) filter(where co.status<>'cancelled'),0)::numeric(14,2) customer_order_value,
    max(co.created_at) filter(where co.status<>'cancelled') last_customer_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
pos_stats as (
  select
    c.id customer_id,
    count(s.id) filter(where s.status in ('completed','partially_refunded','refunded'))::bigint pos_sale_count,
    coalesce(sum(
      case when s.status in ('completed','partially_refunded','refunded')
        then greatest(s.total-coalesce(s.refund_total,0),0) else 0 end
    ),0)::numeric(14,2) pos_sale_value,
    max(s.created_at) filter(where s.status in ('completed','partially_refunded','refunded')) last_pos_sale_at
  from public.customers c
  left join public.sales s on s.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (select * from public.loyalty_settings where id=1)
select
  c.id customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))::bigint order_count,
  (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))::numeric(14,2) lifetime_value,
  greatest(os.last_customer_order_at,ps.last_pos_sale_at) last_order_at,
  coalesce(lb.points_balance,0) points_balance,
  case
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.vip_spend_threshold then 'VIP'
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.regular_spend_threshold
      or (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=s.regular_order_threshold then 'Regular'
    when (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=2 then 'Returning'
    else 'New' end customer_segment,
  coalesce(os.customer_order_count,0)::bigint customer_order_count,
  coalesce(ps.pos_sale_count,0)::bigint pos_sale_count
from public.customers c
join order_stats os on os.customer_id=c.id
join pos_stats ps on ps.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

-- =====================================================================
-- WHATSAPP COMMUNICATION / TEMPLATES
-- =====================================================================

alter table public.communication_templates
  add column if not exists client_request_id uuid;

create unique index if not exists communication_templates_client_request_unique
  on public.communication_templates(client_request_id)
  where client_request_id is not null;

alter table public.communication_logs
  add column if not exists client_request_id uuid;

create unique index if not exists communication_logs_client_request_unique
  on public.communication_logs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_communication_template(
  p_template_id uuid,
  p_name text,
  p_template_type public.communication_template_type,
  p_body_template text,
  p_requires_marketing_opt_in boolean,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_template_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage communication templates';
  end if;
  if coalesce(trim(p_name),'')='' or coalesce(trim(p_body_template),'')='' then
    raise exception 'Template name and body are required';
  end if;

  if p_template_id is null and p_client_request_id is not null then
    select id into v_existing from public.communication_templates where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(t) into v_before from public.communication_templates t where t.id=p_template_id;

  insert into public.communication_templates(
    id,name,template_type,body_template,requires_marketing_opt_in,active,created_by,client_request_id
  )
  values(
    v_id,trim(p_name),p_template_type,trim(p_body_template),
    coalesce(p_requires_marketing_opt_in,false),coalesce(p_active,true),auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,template_type=excluded.template_type,body_template=excluded.body_template,
    requires_marketing_opt_in=excluded.requires_marketing_opt_in,active=excluded.active,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_template_id is null then 'create_communication_template' else 'update_communication_template' end,
    'communication_template',v_id,v_before,
    (select to_jsonb(t) from public.communication_templates t where t.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.log_whatsapp_open(uuid,uuid,uuid,text,text);

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.communication_logs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then raise exception 'Recipient phone is required'; end if;
  if coalesce(trim(p_message),'')='' then raise exception 'Message is required'; end if;

  select * into v_customer from public.customers where id=p_customer_id;
  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template from public.communication_templates
    where id=p_template_id and active=true;
    if not found then raise exception 'Active communication template not found'; end if;
    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,channel,status,
    recipient_phone_snapshot,message_snapshot,initiated_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'whatsapp','opened_whatsapp',
    trim(p_recipient_phone),p_message,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'order_id',p_order_id,
      'template_id',p_template_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager manage communication templates" on public.communication_templates;

create or replace view public.communication_log_summary
with (security_invoker=true)
as
select
  cl.id,cl.customer_id,c.full_name customer_name,cl.order_id,co.order_no,
  cl.template_id,ct.name template_name,ct.template_type,
  cl.status,cl.recipient_phone_snapshot,cl.message_snapshot,
  cl.initiated_by,p.full_name initiated_by_name,cl.initiated_at
from public.communication_logs cl
join public.customers c on c.id=cl.customer_id
left join public.customer_orders co on co.id=cl.order_id
left join public.communication_templates ct on ct.id=cl.template_id
left join public.profiles p on p.id=cl.initiated_by;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text queue_type,100 priority,co.customer_id,c.full_name customer_name,
  c.phone,c.whatsapp_opt_in,co.id order_id,co.order_no,co.required_at due_at,
  cos.balance_due,'Order is ready for pickup'::text reason,null::text rider_name
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready' and co.fulfillment='pickup'

union all
select
  'in_production',95,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,'Order is in production',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='in_production'

union all
select
  'out_for_delivery',90,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,dj.scheduled_for,cos.balance_due,'Order is out for delivery',dr.full_name
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
left join public.delivery_riders dr on dr.id=dj.rider_id
where dj.status='out_for_delivery'

union all
select
  'birthday',50,b.customer_id,b.full_name,b.phone,c.whatsapp_opt_in,
  null::uuid,null::text,b.next_birthday::timestamptz,0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days',null::text
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all
select
  'balance_reminder',40,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,
  'Customer order has outstanding balance',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0 and co.status<>'cancelled';

-- =====================================================================
-- EXECUTE / DIRECT-WRITE HARDENING
-- =====================================================================

revoke all on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) from public;
revoke all on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) from public;
revoke all on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.update_customer_order_status(uuid,public.customer_order_status,text) from public;
revoke all on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) from public;
revoke all on function public.save_custom_cake_reference_path(uuid,text) from public;
revoke all on function public.quote_custom_cake_order(uuid,numeric,text) from public;
revoke all on function public.approve_custom_cake_for_production(uuid) from public;
revoke all on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) from public;
revoke all on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) from public;
revoke all on function public.assign_delivery_rider(uuid,uuid) from public;
revoke all on function public.update_delivery_status(uuid,public.delivery_status,text) from public;
revoke all on function public.redeem_loyalty_on_order(uuid,integer,uuid) from public;
revoke all on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) from public;
revoke all on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) from public;
revoke all on function public.set_customer_whatsapp_preference(uuid,boolean) from public;
revoke all on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) from public;
revoke all on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) from public;

grant execute on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) to authenticated;
grant execute on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.update_customer_order_status(uuid,public.customer_order_status,text) to authenticated;
grant execute on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) to authenticated;
grant execute on function public.save_custom_cake_reference_path(uuid,text) to authenticated;
grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;
grant execute on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) to authenticated;
grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;
grant execute on function public.redeem_loyalty_on_order(uuid,integer,uuid) to authenticated;
grant execute on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) to authenticated;
grant execute on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) to authenticated;
grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) to authenticated;

create index if not exists customer_order_payments_shift_idx
  on public.customer_order_payments(shift_id,paid_at desc);

create index if not exists custom_cake_order_item_idx
  on public.custom_cake_specs(order_item_id);

create index if not exists communication_logs_customer_created_idx
  on public.communication_logs(customer_id,initiated_at desc);
