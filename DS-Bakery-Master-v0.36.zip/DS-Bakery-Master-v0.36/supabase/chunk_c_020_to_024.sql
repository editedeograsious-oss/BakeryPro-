

-- SOURCE FILE: 020_staff_admin_final_integration.sql

-- DS Bakery v0.21 / Migration 020
-- Staff/admin live wiring, customer-order refunds, route permission hardening,
-- live management reporting and business-timezone attendance corrections.

-- =====================================================================
-- CUSTOMER ORDER REFUNDS
-- =====================================================================

create table if not exists public.customer_order_refunds (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  payment_id uuid not null references public.customer_order_payments(id) on delete restrict,
  amount numeric(14,2) not null check(amount>0),
  method public.payment_method not null,
  reference text,
  reason text not null,
  refunded_by uuid not null references public.profiles(id),
  refunded_at timestamptz not null default now(),
  shift_id uuid references public.cashier_shifts(id),
  client_request_id uuid
);

create unique index if not exists customer_order_refunds_request_unique
  on public.customer_order_refunds(client_request_id,payment_id)
  where client_request_id is not null;

alter table public.customer_order_refunds enable row level security;

create policy "management read customer order refunds"
on public.customer_order_refunds
for select using (public.current_staff_role() in ('owner','manager'));

create or replace function public.refund_customer_order(
  p_order_id uuid,
  p_amount numeric,
  p_reason text,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_role public.staff_role;
  v_net_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment record;
  v_available numeric(14,2);
  v_alloc numeric(14,2);
  v_group_id uuid:=coalesce(p_client_request_id,gen_random_uuid());
  v_existing uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager') then
    raise exception 'Only owner or manager may refund customer orders';
  end if;
  if p_amount<=0 then raise exception 'Refund amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Refund reason is required'; end if;
  if p_shift_id is not null and not exists(select 1 from public.cashier_shifts where id=p_shift_id and status='open') then
    raise exception 'Selected cashier shift is not open';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.customer_order_refunds
    where client_request_id=p_client_request_id
    order by refunded_at
    limit 1;
    if v_existing is not null then return v_group_id; end if;
  end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Customer order not found'; end if;

  select
    coalesce((select sum(amount) from public.customer_order_payments where order_id=p_order_id and payment_status='completed'),0)
    -
    coalesce((select sum(amount) from public.customer_order_refunds where order_id=p_order_id),0)
  into v_net_paid;

  if p_amount>v_net_paid then raise exception 'Refund exceeds net customer payments'; end if;
  v_remaining:=p_amount;

  -- Reverse latest payments first while preserving each original payment method.
  for v_payment in
    select
      cop.id,cop.method,cop.reference,cop.paid_at,
      cop.amount-coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.payment_id=cop.id),0) as available
    from public.customer_order_payments cop
    where cop.order_id=p_order_id and cop.payment_status='completed'
    order by cop.paid_at desc,cop.id
    for update of cop
  loop
    exit when v_remaining<=0;
    v_available:=greatest(v_payment.available,0);
    if v_available<=0 then continue; end if;
    v_alloc:=least(v_remaining,v_available);

    insert into public.customer_order_refunds(
      order_id,payment_id,amount,method,reference,reason,refunded_by,shift_id,client_request_id
    )
    values(
      p_order_id,v_payment.id,v_alloc,v_payment.method,
      case when v_payment.method='cash' then null else v_payment.reference end,
      trim(p_reason),auth.uid(),
      case when v_payment.method='cash' then p_shift_id else null end,
      v_group_id
    );

    v_remaining:=v_remaining-v_alloc;
  end loop;

  if v_remaining>0 then raise exception 'Unable to allocate full refund'; end if;

  perform public.sync_order_loyalty_points(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'refund_customer_order','customer_order',p_order_id,
    jsonb_build_object('amount',p_amount,'reason',p_reason,'refund_group',v_group_id,'shift_id',p_shift_id)
  );

  return v_group_id;
end;
$$;

-- Net payment helper used by order/status/report logic.
create or replace function public.customer_order_net_paid(p_order_id uuid)
returns numeric
language sql
stable
security definer
set search_path=public
as $$
  select
    coalesce((select sum(amount) from public.customer_order_payments where order_id=p_order_id and payment_status='completed'),0)
    -
    coalesce((select sum(amount) from public.customer_order_refunds where order_id=p_order_id),0)
$$;

-- Customer-order loyalty now uses net payments after refunds.
create or replace function public.sync_order_loyalty_points(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_rate numeric(14,2);
  v_paid numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_order from public.customer_orders where id=p_order_id;
  if not found then return; end if;

  select earn_amount_per_point into v_rate from public.loyalty_settings where id=1;
  v_paid:=public.customer_order_net_paid(p_order_id);

  if v_order.status='completed' and v_paid>=v_order.total_amount then
    v_expected:=floor(v_order.total_amount/v_rate)::integer;
  else
    v_expected:=0;
  end if;

  select coalesce(sum(points_delta),0)::integer into v_current
  from public.loyalty_point_transactions
  where customer_id=v_order.customer_id
    and source_type='customer_order'
    and source_id=p_order_id
    and event_type in ('order_earn','refund_adjustment');

  v_delta:=v_expected-v_current;

  if v_delta<>0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_order.customer_id,
      case when v_delta>0 then 'order_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,'customer_order',p_order_id,
      case when v_delta>0 then 'Points earned from paid completed customer order'
           else 'Points adjusted after customer-order refund/status change' end,
      auth.uid()
    );
  end if;
end;
$$;

create or replace function public.trg_sync_order_refund_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.order_id);
  return new;
end;
$$;

drop trigger if exists trg_order_refunds_loyalty_sync on public.customer_order_refunds;
create trigger trg_order_refunds_loyalty_sync
after insert on public.customer_order_refunds
for each row execute function public.trg_sync_order_refund_loyalty();

-- Recreate customer order summary with net payments and refunded total.
create or replace view public.customer_order_summary
with (security_invoker=true)
as
with items as (
  select coi.order_id,count(*)::bigint item_count,
    string_agg(coi.description || ' × ' || trim(to_char(coi.quantity,'FM999999990.###')),', ' order by coi.created_at) item_summary
  from public.customer_order_items coi group by coi.order_id
),
paid as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) gross_paid
  from public.customer_order_payments where payment_status='completed' group by order_id
),
refunded as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) refunded_amount
  from public.customer_order_refunds group by order_id
)
select
  co.id,co.order_no,co.customer_id,c.full_name customer_name,c.phone,
  co.status,co.fulfillment,co.required_at,co.delivery_address,co.total_amount,
  (coalesce(pa.gross_paid,0)-coalesce(rf.refunded_amount,0))::numeric(14,2) amount_paid,
  (co.total_amount-(coalesce(pa.gross_paid,0)-coalesce(rf.refunded_amount,0)))::numeric(14,2) balance_due,
  co.created_at,co.updated_at,co.delivery_charge,co.subtotal,co.discount,
  coalesce(i.item_count,0)::bigint item_count,coalesce(i.item_summary,'') item_summary,co.notes,
  coalesce(rf.refunded_amount,0)::numeric(14,2) refunded_amount
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join items i on i.order_id=co.id
left join paid pa on pa.order_id=co.id
left join refunded rf on rf.order_id=co.id;


-- Customer profile outstanding balances use net customer-order payments after refunds.
create or replace view public.customer_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter(where co.status<>'cancelled')::bigint order_count,
    coalesce(sum(co.total_amount) filter(where co.status<>'cancelled'),0)::numeric(14,2) total_order_value,
    coalesce(sum(
      case when co.status<>'cancelled'
        then co.total_amount-public.customer_order_net_paid(co.id)
        else 0 end
    ),0)::numeric(14,2) outstanding_balance,
    max(co.created_at) filter(where co.status<>'cancelled') last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  group by c.id
)
select
  c.id customer_id,c.full_name,c.phone,c.email,
  coalesce(os.order_count,0) order_count,
  coalesce(os.total_order_value,0)::numeric(14,2) total_order_value,
  coalesce(os.outstanding_balance,0)::numeric(14,2) outstanding_balance,
  os.last_order_at,c.address,c.birthday,c.notes,c.whatsapp_opt_in
from public.customers c
left join order_stats os on os.customer_id=c.id
where c.active=true;

-- Recreate cake summary with net payments after refunds.
create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id custom_cake_id,ccs.order_id,co.order_no,co.customer_id,c.full_name customer_name,c.phone,
  co.required_at,co.fulfillment,co.delivery_address,ccs.cake_size_label,ccs.servings,ccs.tiers,
  ccs.flavour,ccs.filling,ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,ccs.production_notes,
  ccs.quote_amount,
  public.customer_order_net_paid(co.id)::numeric(14,2) amount_paid,
  (co.total_amount-public.customer_order_net_paid(co.id))::numeric(14,2) balance_due,
  ccs.design_status,co.status order_status,
  round(ccs.quote_amount*cs.deposit_percent/100,2)::numeric(14,2) deposit_required
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
cross join public.custom_cake_settings cs;

-- Cancellation is allowed only after net customer payments have been fully refunded.
create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
  v_paid numeric(14,2);
  v_valid boolean:=false;
  v_cake_status public.custom_cake_design_status;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;

  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_before.status in ('completed','cancelled') then raise exception 'Order is already closed'; end if;
  if p_status=v_before.status then return; end if;

  if p_status='cancelled' then
    if v_role not in ('owner','manager','cashier') then raise exception 'Baker cannot cancel customer orders'; end if;
    if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;
    v_paid:=public.customer_order_net_paid(p_order_id);
    if v_paid>0 then raise exception 'Refund all recorded customer payments before cancellation'; end if;
    v_valid:=true;
  elsif v_role='baker' then
    v_valid:=(v_before.status='confirmed' and p_status='in_production')
      or (v_before.status='in_production' and p_status='ready');
  elsif v_role='cashier' then
    v_valid:=(v_before.status='pending' and p_status='confirmed')
      or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  else
    v_valid:=(v_before.status='pending' and p_status='confirmed')
      or (v_before.status='confirmed' and p_status='in_production')
      or (v_before.status='in_production' and p_status='ready')
      or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  end if;

  if not v_valid then raise exception 'Invalid order status transition'; end if;

  if p_status='in_production' and exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    select design_status into v_cake_status from public.custom_cake_specs where order_id=p_order_id;
    if v_cake_status<>'approved' then raise exception 'Custom cake must be approved before production'; end if;
  end if;
  if p_status='completed' and v_before.fulfillment='delivery' then
    raise exception 'Delivery orders are completed through the delivery workflow';
  end if;

  update public.customer_orders
  set status=p_status,
      completed_at=case when p_status='completed' then now() else completed_at end,
      cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
      cancellation_reason=case when p_status='cancelled' then trim(p_reason) else cancellation_reason end,
      updated_at=now()
  where id=p_order_id;

  if exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    update public.custom_cake_specs
    set design_status=case
      when p_status='in_production' then 'in_production'::public.custom_cake_design_status
      when p_status='ready' then 'ready'::public.custom_cake_design_status
      when p_status='completed' then 'completed'::public.custom_cake_design_status
      when p_status='cancelled' then 'cancelled'::public.custom_cake_design_status
      else design_status end,
      updated_at=now()
    where order_id=p_order_id;
  end if;

  perform public.sync_order_loyalty_points(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status,'reason',p_reason));
end;
$$;



-- Delivery balances also use net order payments after refunds.
create or replace view public.delivery_job_summary
with (security_invoker=true)
as
select
  dj.id,dj.order_id,co.order_no,co.customer_id,
  dj.customer_name_snapshot customer_name,dj.customer_phone_snapshot customer_phone,
  dj.delivery_address_snapshot delivery_address,dj.scheduled_for,dj.delivery_charge,dj.status,
  dj.rider_id,dr.full_name rider_name,dr.phone rider_phone,co.total_amount,
  public.customer_order_net_paid(co.id)::numeric(14,2) amount_paid,
  (co.total_amount-public.customer_order_net_paid(co.id))::numeric(14,2) balance_due,
  dj.assigned_at,dj.dispatched_at,dj.delivered_at,dj.failed_at,dj.outcome_note
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
left join public.delivery_riders dr on dr.id=dj.rider_id;

-- Cashier till reconciliation subtracts customer-order cash refunds linked to that till.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,cs.cashier_id,p.full_name cashier_name,cs.opened_at,cs.opening_float,cs.status,cs.closed_at,
  (select count(*)::bigint from public.sales s where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')) transaction_count,
  coalesce((select sum(s.total-coalesce(s.refund_total,0)) from public.sales s where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')),0)::numeric(14,2) gross_sales,
  (
    coalesce((select sum(py.amount) from public.payments py join public.sales s on s.id=py.sale_id where s.shift_id=cs.id and py.status='completed' and py.method='cash'),0)
    -coalesce((select sum(sr.amount) from public.sale_refunds sr join public.sales s on s.id=sr.sale_id where s.shift_id=cs.id and sr.method='cash'),0)
  )::numeric(14,2) cash_sales,
  (
    coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
    -coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.shift_id=cs.id and cor.method='cash'),0)
  )::numeric(14,2) order_cash_receipts,
  coalesce((select sum(case when cm.movement_type='cash_in' then cm.amount else 0 end) from public.cash_movements cm where cm.shift_id=cs.id),0)::numeric(14,2) cash_in,
  coalesce((select sum(case when cm.movement_type='cash_out' then cm.amount else 0 end) from public.cash_movements cm where cm.shift_id=cs.id),0)::numeric(14,2) cash_out,
  coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)::numeric(14,2) cash_expenses,
  coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)::numeric(14,2) supplier_cash_payments,
  (
    cs.opening_float
    +(coalesce((select sum(py.amount) from public.payments py join public.sales s on s.id=py.sale_id where s.shift_id=cs.id and py.status='completed' and py.method='cash'),0)
      -coalesce((select sum(sr.amount) from public.sale_refunds sr join public.sales s on s.id=sr.sale_id where s.shift_id=cs.id and sr.method='cash'),0))
    +(coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
      -coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.shift_id=cs.id and cor.method='cash'),0))
    +coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_in'),0)
    -coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_out'),0)
    -coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)
    -coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)
  )::numeric(14,2) expected_cash
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id;


-- Custom-cake quote/deposit checks use net customer payments after refunds.
create or replace function public.quote_custom_cake_order(
  p_order_id uuid,p_quote_amount numeric,p_production_notes text default null
)
returns void language plpgsql security definer set search_path=public as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then raise exception 'Not authorized to quote custom cakes'; end if;
  if p_quote_amount<=0 then raise exception 'Quote amount must be greater than zero'; end if;
  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  select * into v_order from public.customer_orders where id=p_order_id for update;
  v_paid:=public.customer_order_net_paid(p_order_id);
  v_new_total:=greatest(p_quote_amount-v_order.discount,0)+v_order.delivery_charge;
  if v_new_total<v_paid then raise exception 'Quote would reduce order total below net payments already retained'; end if;

  update public.customer_order_items set unit_price=p_quote_amount,line_total=p_quote_amount where id=v_spec.order_item_id;
  update public.custom_cake_specs
  set quote_amount=p_quote_amount,production_notes=coalesce(p_production_notes,production_notes),
      design_status=case when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status else 'quoted'::public.custom_cake_design_status end,
      updated_at=now()
  where order_id=p_order_id;
  perform public.refresh_customer_order_total(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount,'net_paid',v_paid));
end;
$$;

create or replace function public.approve_custom_cake_for_production(p_order_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2); v_pct numeric(5,2); v_required numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve custom cake for production'; end if;
  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount<=0 then raise exception 'Custom cake has no valid quote'; end if;
  v_paid:=public.customer_order_net_paid(p_order_id);
  select deposit_percent into v_pct from public.custom_cake_settings where id=1;
  v_required:=round(v_spec.quote_amount*coalesce(v_pct,50)/100,2);
  if v_paid<v_required then raise exception 'Required net deposit has not been reached'; end if;

  update public.custom_cake_specs set design_status='approved',production_approved_by=auth.uid(),production_approved_at=now(),updated_at=now() where order_id=p_order_id;
  update public.customer_orders set status='confirmed',updated_at=now() where id=p_order_id and status='pending';

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',v_spec.quote_amount,'net_paid',v_paid,'deposit_required',v_required));
end;
$$;

-- =====================================================================
-- BUSINESS-TIMEZONE ATTENDANCE / SCHEDULING
-- =====================================================================

alter table public.staff_work_shifts
  add column if not exists client_request_id uuid;

create unique index if not exists staff_work_shift_request_unique
  on public.staff_work_shifts(client_request_id)
  where client_request_id is not null;

create or replace function public.business_local_time()
returns time
language sql
stable
security definer
set search_path=public
as $$
  select (now() at time zone coalesce((select business_timezone from public.business_settings where id=1),'UTC'))::time
$$;

create or replace function public.clock_in_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.staff_work_shifts%rowtype;
  v_id uuid;
  v_grace integer;
  v_scheduled timestamptz;
  v_now_local timestamp;
  v_late integer;
  v_tz text;
  v_date date:=public.business_current_date();
begin
  if not public.is_active_staff() then raise exception 'Active staff account required'; end if;

  select * into v_shift
  from public.staff_work_shifts
  where staff_id=auth.uid() and shift_date=v_date and status='scheduled'
  order by scheduled_start limit 1 for update;

  if not found then raise exception 'No scheduled work shift found for today'; end if;
  if exists(select 1 from public.attendance_records where shift_id=v_shift.id and clock_in_at is not null) then
    raise exception 'Already clocked in for this shift';
  end if;

  select late_grace_minutes into v_grace from public.attendance_settings where id=1;
  select business_timezone into v_tz from public.business_settings where id=1;
  v_tz:=coalesce(v_tz,'UTC');
  v_now_local:=now() at time zone v_tz;
  v_scheduled:=(v_shift.shift_date+v_shift.scheduled_start) at time zone v_tz;

  v_late:=greatest(0,floor(extract(epoch from (now()-v_scheduled))/60)::integer-coalesce(v_grace,0));

  insert into public.attendance_records(shift_id,staff_id,clock_in_at,status,late_minutes)
  values(v_shift.id,auth.uid(),now(),
    case when v_late>0 then 'late'::public.attendance_status else 'on_time'::public.attendance_status end,
    v_late)
  returning id into v_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'clock_in','attendance_record',v_id,jsonb_build_object('shift_id',v_shift.id,'late_minutes',v_late));

  return v_id;
end;
$$;

create or replace function public.clock_out_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare v_record public.attendance_records%rowtype;
begin
  select ar.* into v_record
  from public.attendance_records ar
  join public.staff_work_shifts sws on sws.id=ar.shift_id
  where ar.staff_id=auth.uid()
    and sws.shift_date=public.business_current_date()
    and ar.clock_in_at is not null and ar.clock_out_at is null
  order by ar.clock_in_at desc limit 1 for update of ar;

  if not found then raise exception 'No open attendance record found'; end if;

  update public.attendance_records set clock_out_at=now(),status='completed',updated_at=now() where id=v_record.id;
  update public.staff_work_shifts set status='completed',updated_at=now() where id=v_record.shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'clock_out','attendance_record',v_record.id,jsonb_build_object('clock_out_at',now()));

  return v_record.id;
end;
$$;

create or replace view public.attendance_today
with (security_invoker=true)
as
select
  sws.id shift_id,sws.staff_id,p.full_name,p.role,sws.shift_date,
  sws.scheduled_start,sws.scheduled_end,sws.work_station,
  ar.id attendance_id,ar.clock_in_at,ar.clock_out_at,ar.status attendance_status,
  coalesce(ar.late_minutes,0) late_minutes,
  case
    when ar.id is not null then ar.status::text
    when public.business_local_time()>sws.scheduled_end then 'absent'
    else 'scheduled'
  end display_status
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id
left join public.attendance_records ar on ar.shift_id=sws.id
where sws.shift_date=public.business_current_date()
  and sws.status<>'cancelled';

create or replace function public.my_attendance_status_today()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((
    select jsonb_build_object(
      'shift_id',sws.id,'scheduled_start',sws.scheduled_start,'scheduled_end',sws.scheduled_end,
      'clock_in_at',ar.clock_in_at,'clock_out_at',ar.clock_out_at,'status',ar.status
    )
    from public.staff_work_shifts sws
    left join public.attendance_records ar on ar.shift_id=sws.id
    where sws.staff_id=auth.uid() and sws.shift_date=public.business_current_date() and sws.status<>'cancelled'
    order by sws.scheduled_start limit 1
  ),'{}'::jsonb)
$$;

create or replace function public.create_staff_work_shift(
  p_staff_id uuid,
  p_shift_date date,
  p_scheduled_start time,
  p_scheduled_end time,
  p_work_station text default null,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare v_id uuid:=gen_random_uuid(); v_existing uuid;
begin
  if not public.staff_has_permission('schedule:manage') then raise exception 'Schedule management permission required'; end if;
  if p_shift_date is null or p_scheduled_start is null or p_scheduled_end is null then raise exception 'Date/start/end are required'; end if;
  if p_scheduled_end<=p_scheduled_start then raise exception 'Shift end must be later than start'; end if;
  if not exists(select 1 from public.profiles where id=p_staff_id and active=true) then raise exception 'Active staff member not found'; end if;

  if p_client_request_id is not null then
    select id into v_existing from public.staff_work_shifts where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  insert into public.staff_work_shifts(
    id,staff_id,shift_date,scheduled_start,scheduled_end,work_station,status,notes,created_by,client_request_id
  ) values(
    v_id,p_staff_id,p_shift_date,p_scheduled_start,p_scheduled_end,nullif(trim(p_work_station),''),'scheduled',p_notes,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'create_staff_shift','staff_work_shift',v_id,
    jsonb_build_object('staff_id',p_staff_id,'shift_date',p_shift_date,'start',p_scheduled_start,'end',p_scheduled_end,'station',p_work_station));

  return v_id;
end;
$$;

create or replace function public.cancel_staff_work_shift(p_shift_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_shift public.staff_work_shifts%rowtype;
begin
  if not public.staff_has_permission('schedule:manage') then raise exception 'Schedule management permission required'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;

  select * into v_shift from public.staff_work_shifts where id=p_shift_id for update;
  if not found then raise exception 'Shift not found'; end if;
  if v_shift.status<>'scheduled' then raise exception 'Only scheduled shifts may be cancelled'; end if;
  if exists(select 1 from public.attendance_records where shift_id=p_shift_id and clock_in_at is not null) then
    raise exception 'Cannot cancel a shift after clock-in';
  end if;

  update public.staff_work_shifts set status='cancelled',notes=concat_ws(' | ',notes,'Cancelled: '||trim(p_reason)),updated_at=now() where id=p_shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'cancel_staff_shift','staff_work_shift',p_shift_id,
    jsonb_build_object('status',v_shift.status),jsonb_build_object('status','cancelled','reason',p_reason));
end;
$$;

create or replace function public.update_attendance_settings(p_late_grace_minutes integer)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.staff_has_permission('attendance:manage') then raise exception 'Attendance management permission required'; end if;
  if p_late_grace_minutes<0 or p_late_grace_minutes>120 then raise exception 'Grace period must be between 0 and 120 minutes'; end if;

  update public.attendance_settings set late_grace_minutes=p_late_grace_minutes,updated_by=auth.uid(),updated_at=now() where id=1;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'update_attendance_settings','attendance_settings',null,jsonb_build_object('late_grace_minutes',p_late_grace_minutes));
end;
$$;

-- =====================================================================
-- INDIVIDUAL PERMISSION HARDENING
-- =====================================================================

drop function if exists public.set_staff_permission_override(uuid,text,boolean);

create or replace function public.set_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text,
  p_allowed boolean,
  p_reason text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role()<>'owner' then raise exception 'Only owner may set individual permission overrides'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Override reason is required'; end if;
  if not exists(select 1 from public.profiles where id=p_staff_id and active=true and role<>'owner') then
    raise exception 'Active non-owner staff profile not found';
  end if;
  if not exists(select 1 from public.app_permissions where permission_key=p_permission_key) then raise exception 'Unknown permission key'; end if;

  select * into v_old from public.staff_permission_overrides where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.staff_permission_overrides(staff_id,permission_key,allowed,set_by,set_at,reason)
  values(p_staff_id,p_permission_key,p_allowed,auth.uid(),now(),trim(p_reason))
  on conflict(staff_id,permission_key) do update set
    allowed=excluded.allowed,set_by=excluded.set_by,set_at=excluded.set_at,reason=excluded.reason;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'set_permission_override','profile',p_staff_id,
    case when v_old.staff_id is null then null else jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed,'reason',v_old.reason) end,
    jsonb_build_object('permission_key',p_permission_key,'allowed',p_allowed,'reason',p_reason));
end;
$$;

create or replace function public.effective_staff_permissions(p_staff_id uuid)
returns table(
  permission_key text,description text,critical boolean,role_default boolean,
  individual_override boolean,has_override boolean,effective_allowed boolean
)
language sql
security definer
set search_path=public
as $$
  select ap.permission_key,ap.description,ap.critical,coalesce(rpd.allowed,false),
    spo.allowed,(spo.staff_id is not null),coalesce(spo.allowed,rpd.allowed,false)
  from public.profiles p
  cross join public.app_permissions ap
  left join public.role_permission_defaults rpd on rpd.role=p.role and rpd.permission_key=ap.permission_key
  left join public.staff_permission_overrides spo on spo.staff_id=p.id and spo.permission_key=ap.permission_key
  where p.id=p_staff_id
    and (p.id=auth.uid() or public.current_staff_role()='owner')
$$;

-- =====================================================================
-- STAFF / AUDIT / LIVE MANAGEMENT REPORTING
-- =====================================================================

create or replace view public.audit_log_summary
with (security_invoker=true)
as
select
  al.id,al.created_at,al.actor_id,p.full_name actor_name,p.role actor_role,
  al.action,al.entity,al.entity_id,al.before_data,al.after_data
from public.audit_logs al
left join public.profiles p on p.id=al.actor_id;

create or replace function public.management_report_v2(p_period text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_end timestamptz:=now();
  v_days integer;
  v_summary jsonb;
  v_products jsonb;
  v_payments jsonb;
  v_expenses jsonb;
begin
  if not public.staff_has_permission('reports:view') then raise exception 'Reports permission required'; end if;
  if p_period='week' then v_days:=7;
  elsif p_period='month' then v_days:=30;
  else raise exception 'Period must be week or month'; end if;
  v_start:=now()-(v_days||' days')::interval;

  select jsonb_build_object(
    'sales',coalesce(sum(s.total-coalesce(s.refund_total,0)),0),
    'cogs',coalesce((select sum(cogs_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'gross_profit',coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'expenses',coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end),0),
    'operating_profit',
      coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0)
      -coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end),0),
    'purchases',coalesce((select sum(total_amount) from public.purchases p where p.created_at>=v_start and p.created_at<v_end and p.status<>'cancelled'),0),
    'waste_cost',coalesce((select sum(total_cost) from public.waste_events w where w.recorded_at>=v_start and w.recorded_at<v_end and w.approval_status='approved'),0),
    'transactions',count(*) filter(where s.status in ('completed','partially_refunded','refunded')),
    'customer_order_value',coalesce((select sum(total_amount) from public.customer_orders co where co.created_at>=v_start and co.created_at<v_end and co.status<>'cancelled'),0),
    'customer_order_outstanding',coalesce((select sum(balance_due) from public.customer_order_summary where status<>'cancelled'),0),
    'supplier_outstanding',coalesce((select sum(outstanding_balance) from public.supplier_account_summary),0),
    'supplier_overdue',coalesce((select sum(overdue_balance) from public.supplier_account_summary),0),
    'production_planned',coalesce((select sum(planned_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0),
    'production_produced',coalesce((select sum(produced_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0)
  ) into v_summary
  from public.sales s
  where s.created_at>=v_start and s.created_at<v_end;

  select coalesce(jsonb_agg(x order by x.sales_amount desc),'[]'::jsonb)
  into v_products
  from (
    select product_id,product_name,sum(quantity) units,sum(sales_amount) sales_amount,sum(gross_profit_amount) gross_profit
    from public.sale_profit_lines
    where created_at>=v_start and created_at<v_end
    group by product_id,product_name
    order by sales_amount desc limit 10
  ) x;

  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb)
  into v_payments
  from (
    select method::text method,sum(amount) amount
    from public.payments
    where created_at>=v_start and created_at<v_end and status='completed'
    group by method
  ) x;

  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb)
  into v_expenses
  from (
    select category,sum(amount) amount
    from public.expenses
    where created_at>=v_start and created_at<v_end
    group by category
  ) x;

  return jsonb_build_object('summary',v_summary,'products',v_products,'payments',v_payments,'expenses',v_expenses);
end;
$$;

-- =====================================================================
-- DAILY CLOSING: SUBTRACT CUSTOMER ORDER REFUNDS BY PAYMENT METHOD
-- =====================================================================

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2); v_pos_cash numeric(14,2); v_pos_mtn numeric(14,2); v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2); v_mtn_refunds numeric(14,2); v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2); v_order_mtn numeric(14,2); v_order_airtel numeric(14,2);
  v_order_refund_cash numeric(14,2); v_order_refund_mtn numeric(14,2); v_order_refund_airtel numeric(14,2);
  v_supplier_cash numeric(14,2); v_supplier_mtn numeric(14,2); v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2); v_cash_out numeric(14,2); v_cash_exp numeric(14,2); v_momo_exp numeric(14,2);
  v_tx_count integer; v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager can prepare daily closing'; end if;

  select coalesce(sum(opening_float),0) into v_opening from public.cashier_shifts where public.business_date(opened_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_pos_cash,v_pos_mtn,v_pos_airtel
  from public.payments where status='completed' and public.business_date(created_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds where public.business_date(refunded_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_cash,v_order_mtn,v_order_airtel
  from public.customer_order_payments where payment_status='completed' and public.business_date(paid_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_refund_cash,v_order_refund_mtn,v_order_refund_airtel
  from public.customer_order_refunds where public.business_date(refunded_at)=p_business_date;

  select coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),
         coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0)
  into v_supplier_cash,v_supplier_mtn,v_supplier_airtel
  from public.purchase_payments where public.business_date(paid_at)=p_business_date;

  select coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
         coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out from public.cash_movements where public.business_date(created_at)=p_business_date;

  select coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
         coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp from public.expenses where public.business_date(created_at)=p_business_date;

  select count(*) filter(where status in ('completed','partially_refunded','refunded')),
         coalesce(sum(case when status in ('completed','partially_refunded','refunded') then total-coalesce(refund_total,0) else 0 end),0)
  into v_tx_count,v_pos_sales from public.sales where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,'opening_float',v_opening,
    'cash_sales',v_pos_cash-v_cash_refunds,'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash-v_order_refund_cash,
    'mtn_order_receipts',v_order_mtn-v_order_refund_mtn,
    'airtel_order_receipts',v_order_airtel-v_order_refund_airtel,
    'cash_order_refunds',v_order_refund_cash,'mtn_order_refunds',v_order_refund_mtn,'airtel_order_refunds',v_order_refund_airtel,
    'cash_supplier_payments',v_supplier_cash,'mtn_supplier_payments',v_supplier_mtn,'airtel_supplier_payments',v_supplier_airtel,
    'cash_in',v_cash_in,'cash_out',v_cash_out,'cash_expenses',v_cash_exp,'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_pos_cash-v_cash_refunds)+(v_order_cash-v_order_refund_cash)+v_cash_in-v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,'total_sales',v_pos_sales,
    'customer_order_receipts',(v_order_cash+v_order_mtn+v_order_airtel)-(v_order_refund_cash+v_order_refund_mtn+v_order_refund_airtel)
  );
end;
$$;

-- =====================================================================
-- RPC EXECUTE HARDENING
-- =====================================================================

revoke all on function public.refund_customer_order(uuid,numeric,text,uuid,uuid) from public;
revoke all on function public.customer_order_net_paid(uuid) from public;
revoke all on function public.business_local_time() from public;
revoke all on function public.my_attendance_status_today() from public;
revoke all on function public.create_staff_work_shift(uuid,date,time,time,text,text,uuid) from public;
revoke all on function public.cancel_staff_work_shift(uuid,text) from public;
revoke all on function public.update_attendance_settings(integer) from public;
revoke all on function public.set_staff_permission_override(uuid,text,boolean,text) from public;
revoke all on function public.management_report_v2(text) from public;

grant execute on function public.refund_customer_order(uuid,numeric,text,uuid,uuid) to authenticated;
grant execute on function public.customer_order_net_paid(uuid) to authenticated;
grant execute on function public.business_local_time() to authenticated;
grant execute on function public.my_attendance_status_today() to authenticated;
grant execute on function public.create_staff_work_shift(uuid,date,time,time,text,text,uuid) to authenticated;
grant execute on function public.cancel_staff_work_shift(uuid,text) to authenticated;
grant execute on function public.update_attendance_settings(integer) to authenticated;
grant execute on function public.set_staff_permission_override(uuid,text,boolean,text) to authenticated;
grant execute on function public.management_report_v2(text) to authenticated;

create index if not exists customer_order_refunds_order_idx on public.customer_order_refunds(order_id,refunded_at desc);


-- SOURCE FILE: 021_production_validation.sql

-- DS Bakery v0.22 / Migration 021
-- Production validation and launch-readiness diagnostics.
-- This migration is intentionally read-mostly: it adds release metadata and
-- owner-visible integrity checks without changing normal business workflows.

create table if not exists public.system_release_state (
  id integer primary key default 1 check(id=1),
  app_version text not null,
  latest_migration integer not null,
  release_stage text not null,
  updated_at timestamptz not null default now()
);

insert into public.system_release_state(id,app_version,latest_migration,release_stage)
values(1,'0.22.0',21,'production_validation')
on conflict(id) do update set
  app_version=excluded.app_version,
  latest_migration=excluded.latest_migration,
  release_stage=excluded.release_stage,
  updated_at=now();

alter table public.system_release_state enable row level security;

drop policy if exists "active staff read release state" on public.system_release_state;
create policy "active staff read release state"
on public.system_release_state
for select using(public.is_active_staff());

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  -- Exactly one or more active owners must exist.
  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1
      then v_owner_count::text || ' active owner account(s)'
      else 'No active owner account exists' end;

  -- Business timezone must be set to a real IANA timezone.
  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  -- Each active product may have at most one active recipe.
  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  -- No negative raw-material stock.
  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  -- Purchase totals should match lines, discount and recorded payments.
  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  -- Customer-order net paid cannot be negative or materially over total.
  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  -- Waste linked to a production run should never exceed run output.
  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  -- Duplicate Mobile Money references from legacy history must be reviewed.
  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  -- Long-open till shifts are a warning, not an automatic failure.
  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  -- Scheduled work shifts left behind in the past are operational cleanup warnings.
  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  -- Storage bucket should exist and remain private when Supabase Storage is installed.
  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  -- Release metadata.
  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.22.0' and latest_migration=21
    ) then 'pass' else 'fail' end,
    'Expected app version 0.22.0 / migration 021';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.22.0',
    'latest_migration',21,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;



-- =====================================================================
-- FINAL STATIC-PAGE CLOSURE: SUPPLIERS + STOCK MOVEMENT LEDGER
-- =====================================================================

alter table public.suppliers
  add column if not exists client_request_id uuid;

create unique index if not exists suppliers_client_request_unique
  on public.suppliers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_supplier(
  p_supplier_id uuid,
  p_name text,
  p_phone text,
  p_email text,
  p_notes text,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_supplier_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to manage suppliers';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Supplier name is required'; end if;

  if p_supplier_id is null and p_client_request_id is not null then
    select id into v_existing
    from public.suppliers
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(s) into v_before
  from public.suppliers s
  where s.id=p_supplier_id;

  insert into public.suppliers(
    id,name,phone,email,notes,active,client_request_id
  )
  values(
    v_id,trim(p_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_notes),''),coalesce(p_active,true),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,
    phone=excluded.phone,
    email=excluded.email,
    notes=excluded.notes,
    active=excluded.active,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_supplier_id is null then 'create_supplier' else 'update_supplier' end,
    'supplier',v_id,v_before,
    (select to_jsonb(s) from public.suppliers s where s.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager storekeeper manage suppliers" on public.suppliers;

create or replace view public.inventory_movement_summary
with (security_invoker=true)
as
select
  it.id,it.created_at,it.raw_material_id,rm.name material_name,rm.base_unit,
  it.tx_type,it.quantity_delta,it.unit_cost,it.reference_type,it.reference_id,
  it.notes,it.created_by,p.full_name recorded_by_name,p.role recorded_by_role
from public.inventory_transactions it
join public.raw_materials rm on rm.id=it.raw_material_id
left join public.profiles p on p.id=it.created_by;

revoke all on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) from public;
grant execute on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) to authenticated;

revoke all on function public.launch_readiness_checks() from public;
revoke all on function public.launch_readiness_summary() from public;
grant execute on function public.launch_readiness_checks() to authenticated;
grant execute on function public.launch_readiness_summary() to authenticated;


-- SOURCE FILE: 022_public_website_live.sql

-- DS Bakery v0.23 / Migration 022
-- Public customer website live-data integration and public-site configuration.

create table if not exists public.public_site_settings (
  id integer primary key default 1 check(id=1),
  business_name text not null default 'DS Bakery',
  tagline text not null default 'Fresh bakery products for every occasion',
  hero_message text,
  phone text,
  whatsapp_phone text,
  email text,
  address_text text,
  opening_hours text,
  custom_cake_enabled boolean not null default true,
  delivery_enabled boolean not null default true,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.public_site_settings(id,business_name,tagline,custom_cake_enabled,delivery_enabled)
values(1,'DS Bakery','Fresh bakery products for every occasion',true,true)
on conflict(id) do nothing;

alter table public.public_site_settings enable row level security;

drop policy if exists "management read public site settings" on public.public_site_settings;
create policy "management read public site settings"
on public.public_site_settings
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.public_site_info()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'business_name',business_name,
    'tagline',tagline,
    'hero_message',hero_message,
    'phone',phone,
    'whatsapp_phone',whatsapp_phone,
    'email',email,
    'address_text',address_text,
    'opening_hours',opening_hours,
    'custom_cake_enabled',custom_cake_enabled,
    'delivery_enabled',delivery_enabled
  )
  from public.public_site_settings
  where id=1
$$;

create or replace function public.public_product_catalog()
returns table(
  id uuid,
  name text,
  description text,
  selling_price numeric,
  image_url text,
  category_name text,
  category_display_order integer,
  product_updated_at timestamptz
)
language sql
stable
security definer
set search_path=public
as $$
  select
    p.id,
    p.name,
    p.description,
    p.selling_price,
    p.image_url,
    pc.name,
    coalesce(pc.display_order,0),
    p.updated_at
  from public.products p
  left join public.product_categories pc on pc.id=p.category_id
  where p.status='active'
  order by coalesce(pc.display_order,0),pc.name nulls last,p.name
$$;

create or replace function public.update_public_site_settings(
  p_business_name text,
  p_tagline text,
  p_hero_message text,
  p_phone text,
  p_whatsapp_phone text,
  p_email text,
  p_address_text text,
  p_opening_hours text,
  p_custom_cake_enabled boolean,
  p_delivery_enabled boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may update public website settings';
  end if;

  if coalesce(trim(p_business_name),'')='' then
    raise exception 'Business name is required';
  end if;

  select to_jsonb(s) into v_before
  from public.public_site_settings s
  where id=1;

  update public.public_site_settings
  set
    business_name=trim(p_business_name),
    tagline=coalesce(nullif(trim(p_tagline),''),'Fresh bakery products for every occasion'),
    hero_message=nullif(trim(p_hero_message),''),
    phone=nullif(trim(p_phone),''),
    whatsapp_phone=nullif(trim(p_whatsapp_phone),''),
    email=nullif(trim(p_email),''),
    address_text=nullif(trim(p_address_text),''),
    opening_hours=nullif(trim(p_opening_hours),''),
    custom_cake_enabled=coalesce(p_custom_cake_enabled,true),
    delivery_enabled=coalesce(p_delivery_enabled,true),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_public_site_settings','public_site_settings',null,
    v_before,(select to_jsonb(s) from public.public_site_settings s where id=1)
  );
end;
$$;

revoke all on function public.public_site_info() from public;
revoke all on function public.public_product_catalog() from public;
revoke all on function public.update_public_site_settings(text,text,text,text,text,text,text,text,boolean,boolean) from public;

grant execute on function public.public_site_info() to anon, authenticated;
grant execute on function public.public_product_catalog() to anon, authenticated;
grant execute on function public.update_public_site_settings(text,text,text,text,text,text,text,text,boolean,boolean) to authenticated;

-- Release metadata moves to v0.23 / migration 022.
update public.system_release_state
set app_version='0.23.0',
    latest_migration=22,
    release_stage='public_website_live',
    updated_at=now()
where id=1;

-- Extend launch diagnostics with the public website settings row.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.23.0' and latest_migration=22
    ) then 'pass' else 'fail' end,
    'Expected app version 0.23.0 / migration 022';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.23.0',
    'latest_migration',22,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- SOURCE FILE: 023_public_contact_details.sql

-- DS Bakery v0.24 / Migration 023
-- Public contact/location and TikTok details.

alter table public.public_site_settings
  add column if not exists secondary_phone text,
  add column if not exists tiktok_handle text;

update public.public_site_settings
set
  phone='0708743663',
  secondary_phone='0760547003',
  whatsapp_phone='0760547003',
  email='dscakes3@gmail.com',
  address_text='Kiwafu Lugonjo',
  tiktok_handle='Ds bakery',
  updated_at=now()
where id=1;

create or replace function public.public_site_info()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'business_name',business_name,
    'tagline',tagline,
    'hero_message',hero_message,
    'phone',phone,
    'secondary_phone',secondary_phone,
    'whatsapp_phone',whatsapp_phone,
    'email',email,
    'address_text',address_text,
    'opening_hours',opening_hours,
    'tiktok_handle',tiktok_handle,
    'custom_cake_enabled',custom_cake_enabled,
    'delivery_enabled',delivery_enabled
  )
  from public.public_site_settings
  where id=1
$$;

drop function if exists public.update_public_site_settings(
  text,text,text,text,text,text,text,text,boolean,boolean
);

create or replace function public.update_public_site_settings(
  p_business_name text,
  p_tagline text,
  p_hero_message text,
  p_phone text,
  p_secondary_phone text,
  p_whatsapp_phone text,
  p_email text,
  p_address_text text,
  p_opening_hours text,
  p_tiktok_handle text,
  p_custom_cake_enabled boolean,
  p_delivery_enabled boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may update public website settings';
  end if;

  if coalesce(trim(p_business_name),'')='' then
    raise exception 'Business name is required';
  end if;

  select to_jsonb(s) into v_before
  from public.public_site_settings s
  where id=1;

  update public.public_site_settings
  set
    business_name=trim(p_business_name),
    tagline=coalesce(nullif(trim(p_tagline),''),'Fresh bakery products for every occasion'),
    hero_message=nullif(trim(p_hero_message),''),
    phone=nullif(trim(p_phone),''),
    secondary_phone=nullif(trim(p_secondary_phone),''),
    whatsapp_phone=nullif(trim(p_whatsapp_phone),''),
    email=nullif(trim(p_email),''),
    address_text=nullif(trim(p_address_text),''),
    opening_hours=nullif(trim(p_opening_hours),''),
    tiktok_handle=nullif(trim(p_tiktok_handle),''),
    custom_cake_enabled=coalesce(p_custom_cake_enabled,true),
    delivery_enabled=coalesce(p_delivery_enabled,true),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_public_site_settings','public_site_settings',null,
    v_before,(select to_jsonb(s) from public.public_site_settings s where id=1)
  );
end;
$$;

revoke all on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) from public;

grant execute on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) to authenticated;

update public.system_release_state
set app_version='0.24.0',
    latest_migration=23,
    release_stage='public_contact_details',
    updated_at=now()
where id=1;


-- Refresh launch-readiness release expectations for v0.24.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.24.0' and latest_migration=23
    ) then 'pass' else 'fail' end,
    'Expected app version 0.24.0 / migration 023';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.24.0',
    'latest_migration',23,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- SOURCE FILE: 024_staging_validation_harness.sql

-- DS Bakery v0.25 / Migration 024
-- Staging validation evidence, repeatable release checks and release-state update.

create table if not exists public.validation_runs (
  id uuid primary key default gen_random_uuid(),
  environment text not null check(environment in ('staging','production')),
  app_version text not null,
  latest_migration integer not null,
  started_by uuid not null references public.profiles(id),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  overall_status text not null default 'pending'
    check(overall_status in ('pending','pass','warn','fail')),
  notes text
);

create table if not exists public.validation_check_results (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.validation_runs(id) on delete cascade,
  check_key text not null,
  area text not null,
  status text not null check(status in ('pending','pass','warn','fail')),
  detail text,
  evidence text,
  checked_by uuid references public.profiles(id),
  checked_at timestamptz not null default now(),
  unique(run_id,check_key)
);

alter table public.validation_runs enable row level security;
alter table public.validation_check_results enable row level security;

drop policy if exists "management read validation runs" on public.validation_runs;
create policy "management read validation runs"
on public.validation_runs
for select using(public.current_staff_role() in ('owner','manager'));

drop policy if exists "management read validation results" on public.validation_check_results;
create policy "management read validation results"
on public.validation_check_results
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.begin_validation_run(
  p_environment text default 'staging',
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may start a validation run';
  end if;
  if p_environment not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  insert into public.validation_runs(
    id,environment,app_version,latest_migration,started_by,notes
  )
  values(
    v_id,p_environment,'0.25.0',24,auth.uid(),nullif(trim(p_notes),'')
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'begin_validation_run','validation_run',v_id,
    jsonb_build_object('environment',p_environment,'app_version','0.25.0','latest_migration',24)
  );

  return v_id;
end;
$$;

create or replace function public.record_validation_check(
  p_run_id uuid,
  p_check_key text,
  p_area text,
  p_status text,
  p_detail text default null,
  p_evidence text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid;
  v_run public.validation_runs%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record validation evidence';
  end if;
  if coalesce(trim(p_check_key),'')='' or coalesce(trim(p_area),'')='' then
    raise exception 'Check key and area are required';
  end if;
  if p_status not in ('pending','pass','warn','fail') then
    raise exception 'Invalid validation status';
  end if;

  select * into v_run
  from public.validation_runs
  where id=p_run_id
  for update;

  if not found then raise exception 'Validation run not found'; end if;
  if v_run.completed_at is not null then raise exception 'Validation run is already completed'; end if;

  insert into public.validation_check_results(
    run_id,check_key,area,status,detail,evidence,checked_by
  )
  values(
    p_run_id,trim(p_check_key),trim(p_area),p_status,
    nullif(trim(p_detail),''),nullif(trim(p_evidence),''),auth.uid()
  )
  on conflict(run_id,check_key) do update set
    area=excluded.area,
    status=excluded.status,
    detail=excluded.detail,
    evidence=excluded.evidence,
    checked_by=auth.uid(),
    checked_at=now()
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.complete_validation_run(
  p_run_id uuid,
  p_notes text default null
)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_fail bigint;
  v_warn bigint;
  v_pending bigint;
  v_total bigint;
  v_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may complete a validation run';
  end if;

  perform 1
  from public.validation_runs
  where id=p_run_id and completed_at is null
  for update;

  if not found then raise exception 'Open validation run not found'; end if;

  select
    count(*),
    count(*) filter(where status='fail'),
    count(*) filter(where status='warn'),
    count(*) filter(where status='pending')
  into v_total,v_fail,v_warn,v_pending
  from public.validation_check_results
  where run_id=p_run_id;

  if v_total=0 then raise exception 'Validation run has no recorded checks'; end if;
  if v_pending>0 then raise exception 'Validation run still contains pending checks'; end if;

  v_status:=case
    when v_fail>0 then 'fail'
    when v_warn>0 then 'warn'
    else 'pass'
  end;

  update public.validation_runs
  set completed_at=now(),
      overall_status=v_status,
      notes=coalesce(nullif(trim(p_notes),''),notes)
  where id=p_run_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'complete_validation_run','validation_run',p_run_id,
    jsonb_build_object(
      'overall_status',v_status,'check_count',v_total,
      'fail_count',v_fail,'warn_count',v_warn
    )
  );

  return v_status;
end;
$$;

create or replace view public.validation_run_summary
with (security_invoker=true)
as
select
  vr.id,vr.environment,vr.app_version,vr.latest_migration,
  vr.started_at,vr.completed_at,vr.overall_status,vr.notes,
  p.full_name started_by_name,
  count(vcr.id)::bigint check_count,
  count(vcr.id) filter(where vcr.status='pass')::bigint pass_count,
  count(vcr.id) filter(where vcr.status='warn')::bigint warn_count,
  count(vcr.id) filter(where vcr.status='fail')::bigint fail_count,
  count(vcr.id) filter(where vcr.status='pending')::bigint pending_count
from public.validation_runs vr
join public.profiles p on p.id=vr.started_by
left join public.validation_check_results vcr on vcr.run_id=vr.id
group by vr.id,p.full_name;

revoke all on function public.begin_validation_run(text,text) from public;
revoke all on function public.record_validation_check(uuid,text,text,text,text,text) from public;
revoke all on function public.complete_validation_run(uuid,text) from public;

grant execute on function public.begin_validation_run(text,text) to authenticated;
grant execute on function public.record_validation_check(uuid,text,text,text,text,text) to authenticated;
grant execute on function public.complete_validation_run(uuid,text) to authenticated;

update public.system_release_state
set app_version='0.25.0',
    latest_migration=24,
    release_stage='staging_validation_harness',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.25.0'
    and vr.latest_migration=24
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.25.0'
      else 'No completed passing staging validation run exists yet for v0.25.0' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.25.0' and latest_migration=24
    ) then 'pass' else 'fail' end,
    'Expected app version 0.25.0 / migration 024';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.25.0',
    'latest_migration',24,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;
