-- DS Bakery Master v0.1
create extension if not exists pgcrypto;

create type public.staff_role as enum ('owner','manager','cashier','baker','storekeeper');
create type public.record_status as enum ('active','inactive','archived');
create type public.inventory_tx_type as enum ('purchase','usage','adjustment','waste','return');
create type public.payment_method as enum ('cash','mtn_momo','airtel_money');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.staff_role not null default 'cashier',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  display_order int not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.product_categories(id),
  name text not null,
  sku text unique,
  description text,
  selling_price numeric(14,2) not null default 0 check (selling_price >= 0),
  track_recipe boolean not null default true,
  image_url text,
  notes text,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.raw_materials (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid,
  name text not null unique,
  sku text unique,
  base_unit text not null,
  purchase_pack_label text,
  purchase_pack_base_qty numeric(18,6) not null default 1 check (purchase_pack_base_qty > 0),
  current_purchase_cost numeric(14,2) not null default 0 check (current_purchase_cost >= 0),
  current_stock_qty numeric(18,6) not null default 0,
  low_stock_threshold numeric(18,6) not null default 0,
  status public.record_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  name text not null,
  yield_qty numeric(12,3) not null default 1 check (yield_qty > 0),
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index one_active_recipe_per_product on public.recipes(product_id) where active = true;

create table public.recipe_items (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_base_unit numeric(18,6) not null check (quantity_base_unit > 0),
  created_at timestamptz not null default now(),
  unique(recipe_id, raw_material_id)
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.raw_materials
  add constraint raw_material_supplier_fk
  foreign key (supplier_id) references public.suppliers(id);

create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  raw_material_id uuid not null references public.raw_materials(id),
  tx_type public.inventory_tx_type not null,
  quantity_delta numeric(18,6) not null,
  unit_cost numeric(14,6),
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'completed',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  cashier_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity numeric(12,3) not null,
  unit_price numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount >= 0),
  reference text,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  description text not null,
  amount numeric(14,2) not null check (amount >= 0),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity text not null,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_staff_role()
returns public.staff_role
language sql stable security definer set search_path=public
as $$ select role from public.profiles where id = auth.uid() $$;

alter table public.profiles enable row level security;
alter table public.product_categories enable row level security;
alter table public.products enable row level security;
alter table public.raw_materials enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_items enable row level security;
alter table public.suppliers enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.audit_logs enable row level security;

create policy "staff can read own profile" on public.profiles
for select using (id = auth.uid() or public.current_staff_role() in ('owner','manager'));

create policy "owner manages profiles" on public.profiles
for all using (public.current_staff_role() = 'owner')
with check (public.current_staff_role() = 'owner');

create policy "staff read active products" on public.products
for select using (status='active' or public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage products" on public.products
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "staff read categories" on public.product_categories
for select using (true);

create policy "owner manager manage categories" on public.product_categories
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "relevant staff read materials" on public.raw_materials
for select using (public.current_staff_role() in ('owner','manager','storekeeper','baker'));

create policy "storekeeper manager owner manage materials" on public.raw_materials
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "baker and managers read recipes" on public.recipes
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipes" on public.recipes
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "baker and managers read recipe items" on public.recipe_items
for select using (public.current_staff_role() in ('owner','manager','baker'));

create policy "owner manager manage recipe items" on public.recipe_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "owner manager storekeeper read suppliers" on public.suppliers
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager storekeeper manage suppliers" on public.suppliers
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff read inventory tx" on public.inventory_transactions
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "authorized staff create inventory tx" on public.inventory_transactions
for insert with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

create index products_category_idx on public.products(category_id);
create index recipe_items_recipe_idx on public.recipe_items(recipe_id);
create index inventory_tx_material_idx on public.inventory_transactions(raw_material_id, created_at desc);
create index audit_entity_idx on public.audit_logs(entity, entity_id, created_at desc);


-- ===== PHASE 1B MIGRATION =====
-- DS Bakery Phase 1B: stock & purchasing
-- Run after supabase/schema.sql from v0.1.

create type public.purchase_status as enum ('draft','ordered','partially_received','received','cancelled');
create type public.payment_status as enum ('unpaid','partial','paid');

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  purchase_no text not null unique,
  supplier_id uuid not null references public.suppliers(id),
  purchase_date date not null default current_date,
  supplier_reference text,
  status public.purchase_status not null default 'draft',
  payment_status public.payment_status not null default 'unpaid',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  amount_paid numeric(14,2) not null default 0 check (amount_paid >= 0),
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (amount_paid <= total_amount)
);

create table if not exists public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  ordered_qty_base numeric(18,6) not null check (ordered_qty_base > 0),
  received_qty_base numeric(18,6) not null default 0 check (received_qty_base >= 0),
  unit_cost_base numeric(14,6) not null check (unit_cost_base >= 0),
  line_total numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  unique(purchase_id, raw_material_id)
);

create table if not exists public.purchase_payments (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  amount numeric(14,2) not null check (amount > 0),
  method text not null,
  reference text,
  paid_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

-- Add purchase linkage to the stock ledger.
alter table public.inventory_transactions
  add column if not exists purchase_item_id uuid references public.purchase_items(id);

-- View current unit cost from the existing pack-cost fields.
create or replace view public.raw_material_costs as
select
  rm.*,
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_unit_cost,
  rm.current_stock_qty *
  case
    when rm.purchase_pack_base_qty > 0
      then rm.current_purchase_cost / rm.purchase_pack_base_qty
    else 0
  end as current_stock_value
from public.raw_materials rm;

create or replace view public.low_stock_materials as
select
  id,name,sku,base_unit,current_stock_qty,low_stock_threshold,
  case when low_stock_threshold > 0 then current_stock_qty / low_stock_threshold else null end as stock_ratio
from public.raw_materials
where status='active'
  and current_stock_qty <= low_stock_threshold;

create or replace view public.supplier_balances as
select
  s.id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(p.total_amount),0)::numeric(14,2) as total_purchases,
  coalesce(sum(p.amount_paid),0)::numeric(14,2) as total_paid,
  coalesce(sum(p.total_amount - p.amount_paid),0)::numeric(14,2) as outstanding_balance
from public.suppliers s
left join public.purchases p
  on p.supplier_id=s.id
 and p.status <> 'cancelled'
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- Central stock ledger trigger.
create or replace function public.apply_inventory_transaction()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  old_qty numeric(18,6);
  old_unit_cost numeric(14,6);
  incoming_cost numeric(14,6);
  new_unit_cost numeric(14,6);
begin
  select
    current_stock_qty,
    case when purchase_pack_base_qty > 0
      then current_purchase_cost / purchase_pack_base_qty
      else 0 end
  into old_qty, old_unit_cost
  from public.raw_materials
  where id = new.raw_material_id
  for update;

  -- For purchase receipts, update standard ingredient cost using weighted average.
  if new.tx_type = 'purchase' and new.quantity_delta > 0 and new.unit_cost is not null then
    incoming_cost := new.unit_cost;
    if old_qty <= 0 then
      new_unit_cost := incoming_cost;
    else
      new_unit_cost :=
        ((old_qty * old_unit_cost) + (new.quantity_delta * incoming_cost))
        / (old_qty + new.quantity_delta);
    end if;

    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      current_purchase_cost = new_unit_cost * purchase_pack_base_qty,
      updated_at = now()
    where id = new.raw_material_id;
  else
    update public.raw_materials
    set
      current_stock_qty = current_stock_qty + new.quantity_delta,
      updated_at = now()
    where id = new.raw_material_id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_apply_inventory_transaction on public.inventory_transactions;
create trigger trg_apply_inventory_transaction
after insert on public.inventory_transactions
for each row execute function public.apply_inventory_transaction();

-- Receive part or all of a purchase line and post the stock movement.
create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_remaining numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized';
  end if;

  if p_receive_qty_base <= 0 then
    raise exception 'Received quantity must be greater than zero';
  end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then
    raise exception 'Purchase item not found';
  end if;

  v_remaining := v_item.ordered_qty_base - v_item.received_qty_base;
  if p_receive_qty_base > v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  update public.purchase_items
  set received_qty_base = received_qty_base + p_receive_qty_base
  where id = p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase',v_item.purchase_id,v_item.id,auth.uid(),'Purchase receipt'
  );

  update public.purchases p
  set status =
    case
      when not exists (
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base < pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'receive_stock','purchase_item',p_purchase_item_id,
    jsonb_build_object('received_qty_base',p_receive_qty_base));
end;
$$;

create or replace function public.refresh_purchase_totals(p_purchase_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_total numeric(14,2);
  v_paid numeric(14,2);
begin
  select coalesce(sum(ordered_qty_base * unit_cost_base),0)::numeric(14,2)
    into v_total
  from public.purchase_items
  where purchase_id=p_purchase_id;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.purchase_payments
  where purchase_id=p_purchase_id;

  update public.purchases
  set
    subtotal=v_total,
    total_amount=greatest(v_total-discount,0),
    amount_paid=v_paid,
    payment_status=case
      when v_paid <= 0 then 'unpaid'::public.payment_status
      when v_paid >= greatest(v_total-discount,0) then 'paid'::public.payment_status
      else 'partial'::public.payment_status
    end,
    updated_at=now()
  where id=p_purchase_id;
end;
$$;

alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.purchase_payments enable row level security;

create policy "purchasing staff read purchases" on public.purchases
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchases" on public.purchases
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff read purchase items" on public.purchase_items
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "purchasing staff manage purchase items" on public.purchase_items
for all using (public.current_staff_role() in ('owner','manager','storekeeper'))
with check (public.current_staff_role() in ('owner','manager','storekeeper'));

create policy "owner manager read purchase payments" on public.purchase_payments
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager create purchase payments" on public.purchase_payments
for insert with check (public.current_staff_role() in ('owner','manager'));

create index if not exists purchases_supplier_idx on public.purchases(supplier_id,purchase_date desc);
create index if not exists purchase_items_purchase_idx on public.purchase_items(purchase_id);
create index if not exists purchase_payments_purchase_idx on public.purchase_payments(purchase_id);


-- ===== PHASE 1C MIGRATION =====
-- DS Bakery Phase 1C: cashier POS

-- Add fields to existing sales table.
alter table public.sales
  add column if not exists sale_no text unique,
  add column if not exists held boolean not null default false,
  add column if not exists notes text,
  add column if not exists voided_at timestamptz,
  add column if not exists voided_by uuid references public.profiles(id),
  add column if not exists void_reason text,
  add column if not exists refund_total numeric(14,2) not null default 0;

alter table public.sale_items
  add column if not exists unit_cost_snapshot numeric(14,6),
  add column if not exists gross_profit_snapshot numeric(14,2);

alter table public.payments
  add column if not exists status text not null default 'completed',
  add column if not exists created_by uuid references public.profiles(id);

-- Secure approval PIN hash for owner/manager.
alter table public.profiles
  add column if not exists approval_pin_hash text;

create or replace function public.set_my_approval_pin(p_pin text)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can set an approval PIN';
  end if;
  if length(p_pin) < 4 or length(p_pin) > 10 then
    raise exception 'Approval PIN must be 4 to 10 characters';
  end if;

  update public.profiles
  set approval_pin_hash = crypt(p_pin, gen_salt('bf')),
      updated_at = now()
  where id = auth.uid();

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'set_approval_pin','profile',auth.uid(),jsonb_build_object('changed',true));
end;
$$;

create or replace function public.verify_approver_pin(p_pin text)
returns uuid
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
begin
  select id into v_approver
  from public.profiles
  where active=true
    and role in ('owner','manager')
    and approval_pin_hash is not null
    and approval_pin_hash = crypt(p_pin, approval_pin_hash)
  limit 1;

  if v_approver is null then
    raise exception 'Invalid approval PIN';
  end if;

  return v_approver;
end;
$$;

-- Helper sale number
create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(now(),'YYYYMMDD') || '-' ||
         lpad((floor(random()*100000))::int::text,5,'0')
$$;

-- Atomic sale creation.
create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text := public.next_sale_no();
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if jsonb_array_length(p_items) = 0 then
    raise exception 'Sale must contain at least one item';
  end if;

  -- Calculate subtotal from authoritative current product prices.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then
      raise exception 'Invalid or inactive product';
    end if;

    v_qty := greatest((v_item->>'quantity')::numeric,0);
    if v_qty <= 0 then raise exception 'Quantity must be greater than zero'; end if;
    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount > v_subtotal then p_discount := v_subtotal; end if;
  v_total := v_subtotal - p_discount;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;
      if v_method in ('mtn_momo','airtel_money') and coalesce(v_payment->>'reference','')='' then
        raise exception 'Mobile Money reference is required';
      end if;
      v_paid := v_paid + greatest((v_payment->>'amount')::numeric,0);
    end loop;

    if v_paid < v_total then
      raise exception 'Payments are less than sale total';
    end if;
  end if;

  insert into public.sales(id,sale_no,status,held,subtotal,discount,total,cashier_id,notes)
  values(v_sale_id,v_sale_no,case when p_hold then 'held' else 'completed' end,p_hold,v_subtotal,p_discount,v_total,auth.uid(),p_notes);

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select p.selling_price,
           coalesce((
             select sum(ri.quantity_base_unit * (rm.current_purchase_cost/rm.purchase_pack_base_qty)) / r.yield_qty
             from public.recipes r
             join public.recipe_items ri on ri.recipe_id=r.id
             join public.raw_materials rm on rm.id=ri.raw_material_id
             where r.product_id=p.id and r.active=true
             group by r.id,r.yield_qty
           ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(sale_id,method,amount,reference,created_by)
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(v_payment->>'reference',''),
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),case when p_hold then 'hold_sale' else 'complete_sale' end,'sale',v_sale_id,
    jsonb_build_object('sale_no',v_sale_no,'subtotal',v_subtotal,'discount',p_discount,'total',v_total));

  return v_sale_id;
end;
$$;

-- Cancel or refund with manager/owner PIN approval.
create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then
    raise exception 'Unsupported action';
  end if;

  if coalesce(trim(p_reason),'')='' then
    raise exception 'Reason is required';
  end if;

  v_approver := public.verify_approver_pin(p_approval_pin);

  select * into v_sale from public.sales where id=p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status='refunded' then raise exception 'Refunded sale cannot be cancelled'; end if;
    update public.sales
      set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    v_refund := coalesce(p_refund_amount,v_sale.total);
    if v_refund <= 0 or v_refund > (v_sale.total - v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    update public.sales
      set refund_total=refund_total+v_refund,
          status=case when refund_total+v_refund >= total then 'refunded' else 'partially_refunded' end
    where id=p_sale_id;

    insert into public.payments(sale_id,method,amount,reference,status,created_by)
    values(p_sale_id,'cash',-v_refund,'REFUND','refunded',v_approver);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;

alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.payments enable row level security;

drop policy if exists "sales staff read sales" on public.sales;
create policy "sales staff read sales" on public.sales
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sales" on public.sales;
create policy "sales staff create sales" on public.sales
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read sale items" on public.sale_items;
create policy "sales staff read sale items" on public.sale_items
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create sale items" on public.sale_items;
create policy "sales staff create sale items" on public.sale_items
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff read payments" on public.payments;
create policy "sales staff read payments" on public.payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

drop policy if exists "sales staff create payments" on public.payments;
create policy "sales staff create payments" on public.payments
for insert with check (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sales_created_idx on public.sales(created_at desc);
create index if not exists sales_cashier_idx on public.sales(cashier_id,created_at desc);
create index if not exists sale_items_sale_idx on public.sale_items(sale_id);
create index if not exists payments_sale_idx on public.payments(sale_id);


-- ===== PHASE 1D MIGRATION =====
-- DS Bakery Phase 1D: expenses, cashier shifts and daily closing

create type public.cash_movement_type as enum ('cash_in','cash_out');
create type public.shift_status as enum ('open','closed');
create type public.closing_status as enum ('draft','closed');

alter table public.expenses
  add column if not exists payment_method public.payment_method not null default 'cash',
  add column if not exists reference text,
  add column if not exists shift_id uuid;

create table if not exists public.cashier_shifts (
  id uuid primary key default gen_random_uuid(),
  cashier_id uuid not null references public.profiles(id),
  opened_by uuid not null references public.profiles(id),
  opened_at timestamptz not null default now(),
  opening_float numeric(14,2) not null default 0 check (opening_float >= 0),
  status public.shift_status not null default 'open',
  closed_at timestamptz,
  closed_by uuid references public.profiles(id),
  closing_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.cash_movements (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid references public.cashier_shifts(id),
  movement_type public.cash_movement_type not null,
  amount numeric(14,2) not null check (amount > 0),
  reason text not null,
  reference text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.sales
  add column if not exists shift_id uuid references public.cashier_shifts(id);

alter table public.expenses
  add constraint expenses_shift_fk
  foreign key (shift_id) references public.cashier_shifts(id);

create table if not exists public.daily_closings (
  id uuid primary key default gen_random_uuid(),
  business_date date not null unique,
  status public.closing_status not null default 'draft',

  opening_float numeric(14,2) not null default 0,
  cash_sales numeric(14,2) not null default 0,
  mtn_momo_sales numeric(14,2) not null default 0,
  airtel_money_sales numeric(14,2) not null default 0,

  cash_in numeric(14,2) not null default 0,
  cash_out numeric(14,2) not null default 0,
  cash_expenses numeric(14,2) not null default 0,
  momo_expenses numeric(14,2) not null default 0,

  expected_cash numeric(14,2) not null default 0,
  counted_cash numeric(14,2),
  cash_variance numeric(14,2),

  transaction_count int not null default 0,
  notes text,

  prepared_by uuid references public.profiles(id),
  closed_by uuid references public.profiles(id),
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result public.daily_closings;
  v_opening numeric(14,2);
  v_cash_sales numeric(14,2);
  v_mtn numeric(14,2);
  v_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count int;
  v_expected numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where opened_at::date = p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0),
    count(distinct s.id)
  into v_cash_sales,v_mtn,v_airtel,v_tx_count
  from public.sales s
  left join public.payments p on p.sale_id=s.id and p.status='completed'
  where s.created_at::date=p_business_date
    and s.status in ('completed','partially_refunded');

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where created_at::date=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where created_at::date=p_business_date;

  v_expected := v_opening + v_cash_sales + v_cash_in - v_cash_out - v_cash_exp;

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,v_opening,v_cash_sales,v_mtn,v_airtel,
    v_cash_in,v_cash_out,v_cash_exp,v_momo_exp,v_expected,
    v_tx_count,auth.uid()
  )
  on conflict (business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

create or replace function public.close_business_day(
  p_business_date date,
  p_counted_cash numeric,
  p_notes text default null
)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_close public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can close the business day';
  end if;

  select * into v_close
  from public.calculate_daily_closing(p_business_date);

  if v_close.status='closed' then
    raise exception 'Business day already closed';
  end if;

  update public.daily_closings
  set
    counted_cash=p_counted_cash,
    cash_variance=p_counted_cash-expected_cash,
    notes=p_notes,
    status='closed',
    closed_by=auth.uid(),
    closed_at=now(),
    updated_at=now()
  where business_date=p_business_date
  returning * into v_close;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_business_day','daily_closing',v_close.id,
    jsonb_build_object(
      'business_date',p_business_date,
      'expected_cash',v_close.expected_cash,
      'counted_cash',v_close.counted_cash,
      'variance',v_close.cash_variance
    )
  );

  return v_close;
end;
$$;

alter table public.cashier_shifts enable row level security;
alter table public.cash_movements enable row level security;
alter table public.daily_closings enable row level security;

create policy "sales staff read own shifts" on public.cashier_shifts
for select using (
  cashier_id=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "manager owner manage shifts" on public.cashier_shifts
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "cashier create own cash movement" on public.cash_movements
for insert with check (
  created_by=auth.uid()
  and public.current_staff_role() in ('owner','manager','cashier')
);

create policy "staff read permitted cash movements" on public.cash_movements
for select using (
  created_by=auth.uid() or public.current_staff_role() in ('owner','manager')
);

create policy "owner manager read closings" on public.daily_closings
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner manager manage closings" on public.daily_closings
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create index if not exists cashier_shifts_cashier_idx on public.cashier_shifts(cashier_id,opened_at desc);
create index if not exists cash_movements_shift_idx on public.cash_movements(shift_id,created_at desc);
create index if not exists daily_closings_date_idx on public.daily_closings(business_date desc);


-- ===== PHASE 1E MIGRATION =====
-- DS Bakery Phase 1E: owner dashboard and reports

create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  si.quantity,
  si.line_total as sales_amount,
  coalesce(si.unit_cost_snapshot,0) * si.quantity as cogs_amount,
  coalesce(si.gross_profit_snapshot, si.line_total - (coalesce(si.unit_cost_snapshot,0) * si.quantity)) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
where s.status in ('completed','partially_refunded');

create or replace view public.best_selling_products_30d as
select
  product_id,
  product_name,
  sum(quantity)::numeric(14,3) as units_sold,
  sum(sales_amount)::numeric(14,2) as sales_amount,
  sum(gross_profit_amount)::numeric(14,2) as gross_profit_amount
from public.sale_profit_lines
where created_at >= now() - interval '30 days'
group by product_id,product_name
order by units_sold desc,sales_amount desc;

create or replace function public.period_start(p_period text)
returns timestamptz
language plpgsql
stable
as $$
begin
  case p_period
    when 'day' then return date_trunc('day',now());
    when 'week' then return date_trunc('week',now());
    when 'month' then return date_trunc('month',now());
    else raise exception 'Unsupported period';
  end case;
end;
$$;

create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language sql
security definer
set search_path=public
as $$
with bounds as (
  select public.period_start(p_period) as start_at
),
sales_summary as (
  select
    coalesce(sum(s.total - coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
    count(*)::bigint as transaction_count
  from public.sales s,bounds b
  where s.created_at >= b.start_at
    and s.status in ('completed','partially_refunded')
),
payment_summary as (
  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0)::numeric(14,2) as cash_sales,
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0)::numeric(14,2) as mtn_momo_sales,
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)::numeric(14,2) as airtel_money_sales
  from public.payments p
  join public.sales s on s.id=p.sale_id
  join bounds b on true
  where p.created_at >= b.start_at
    and p.status='completed'
    and s.status in ('completed','partially_refunded')
),
profit_summary as (
  select
    coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
  from public.sale_profit_lines spl,bounds b
  where spl.created_at >= b.start_at
),
expense_summary as (
  select
    coalesce(sum(amount),0)::numeric(14,2) as expenses
  from public.expenses e,bounds b
  where e.created_at >= b.start_at
)
select
  b.start_at,
  ss.sales,
  ps.cash_sales,
  ps.mtn_momo_sales,
  ps.airtel_money_sales,
  prs.gross_profit,
  es.expenses,
  (prs.gross_profit-es.expenses)::numeric(14,2) as estimated_operating_profit,
  ss.transaction_count,
  case when ss.transaction_count>0 then (ss.sales/ss.transaction_count)::numeric(14,2) else 0 end as average_sale
from bounds b,sales_summary ss,payment_summary ps,profit_summary prs,expense_summary es;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

create or replace function public.management_report(
  p_start_date date,
  p_end_date date
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sales numeric(14,2);
  v_cogs numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_purchases numeric(14,2);
  v_transactions bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_end_date < p_start_date then
    raise exception 'Invalid date range';
  end if;

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(cogs_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_cogs,v_gross
  from public.sale_profit_lines
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at >= p_start_date
    and created_at < (p_end_date + 1);

  select coalesce(sum(total_amount),0)
  into v_purchases
  from public.purchases
  where purchase_date between p_start_date and p_end_date
    and status <> 'cancelled';

  select count(*)
  into v_transactions
  from public.sales
  where created_at >= p_start_date
    and created_at < (p_end_date + 1)
    and status in ('completed','partially_refunded');

  return jsonb_build_object(
    'start_date',p_start_date,
    'end_date',p_end_date,
    'sales',v_sales,
    'cogs',v_cogs,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'purchases',v_purchases,
    'transactions',v_transactions
  );
end;
$$;

grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;
grant execute on function public.management_report(date,date) to authenticated;

-- Owner and manager may read profitability views.
alter view public.sale_profit_lines set (security_invoker = true);
alter view public.best_selling_products_30d set (security_invoker = true);


-- ===== PHASE 1F MIGRATION =====
-- DS Bakery Phase 1F: security and reliability

alter table public.profiles
  add column if not exists disabled_at timestamptz,
  add column if not exists disabled_by uuid references public.profiles(id),
  add column if not exists session_version integer not null default 1,
  add column if not exists require_password_reset boolean not null default false;

-- Active role helper: disabled/inactive users resolve to NULL.
create or replace function public.current_staff_role()
returns public.staff_role
language sql
stable
security definer
set search_path=public
as $$
  select role
  from public.profiles
  where id=auth.uid()
    and active=true
    and disabled_at is null
$$;

create or replace function public.is_active_staff()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles
    where id=auth.uid()
      and active=true
      and disabled_at is null
  )
$$;

-- Owner-only staff status control.
create or replace function public.set_staff_active(
  p_staff_id uuid,
  p_active boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.profiles%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may enable or disable staff';
  end if;

  if p_staff_id = auth.uid() and p_active=false then
    raise exception 'Owner cannot disable own currently authenticated account';
  end if;

  select * into v_before from public.profiles where id=p_staff_id for update;
  if not found then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set
    active=p_active,
    disabled_at=case when p_active then null else now() end,
    disabled_by=case when p_active then null else auth.uid() end,
    session_version=session_version+1,
    updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_active then 'enable_staff' else 'disable_staff' end,
    'profile',
    p_staff_id,
    jsonb_build_object('active',v_before.active,'role',v_before.role),
    jsonb_build_object('active',p_active,'session_version',v_before.session_version+1)
  );
end;
$$;

create or replace function public.change_staff_role(
  p_staff_id uuid,
  p_role public.staff_role
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old_role public.staff_role;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may change staff roles';
  end if;

  if p_staff_id=auth.uid() then
    raise exception 'Owner cannot change own role from the active session';
  end if;

  select role into v_old_role from public.profiles where id=p_staff_id for update;
  if v_old_role is null then raise exception 'Staff profile not found'; end if;

  update public.profiles
  set role=p_role,session_version=session_version+1,updated_at=now()
  where id=p_staff_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'change_staff_role','profile',p_staff_id,
    jsonb_build_object('role',v_old_role),
    jsonb_build_object('role',p_role)
  );
end;
$$;

-- View safe staff status metadata.
create or replace view public.staff_security_status
with (security_invoker=true)
as
select
  id,full_name,role,active,disabled_at,disabled_by,
  session_version,require_password_reset,created_at,updated_at
from public.profiles;

-- Owner/manager audit browsing. Inserts remain application/RPC controlled.
drop policy if exists "owner manager read audit logs" on public.audit_logs;
create policy "owner manager read audit logs" on public.audit_logs
for select using (public.current_staff_role() in ('owner','manager'));

-- Harden core financial tables: disabled users lose role through current_staff_role().
-- Existing policies continue to call current_staff_role(), so replacing that helper
-- applies disabled-profile enforcement across modules.

create index if not exists profiles_active_role_idx on public.profiles(active,role);
create index if not exists audit_actor_created_idx on public.audit_logs(actor_id,created_at desc);

grant execute on function public.set_staff_active(uuid,boolean) to authenticated;
grant execute on function public.change_staff_role(uuid,public.staff_role) to authenticated;


-- ===== PHASE 2A MIGRATION =====
-- DS Bakery Phase 2A: kitchen production and baker tasks

create type public.production_status as enum ('planned','in_progress','complete','cancelled');
create type public.production_shift as enum ('morning','afternoon','evening');

create table if not exists public.production_plan_items (
  id uuid primary key default gen_random_uuid(),
  business_date date not null default current_date,
  product_id uuid not null references public.products(id),
  assigned_baker_id uuid references public.profiles(id),
  shift public.production_shift not null default 'morning',
  planned_qty numeric(14,3) not null check (planned_qty > 0),
  produced_qty numeric(14,3) not null default 0 check (produced_qty >= 0),
  status public.production_status not null default 'planned',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (produced_qty <= planned_qty)
);

create table if not exists public.production_runs (
  id uuid primary key default gen_random_uuid(),
  plan_item_id uuid not null references public.production_plan_items(id) on delete restrict,
  quantity_produced numeric(14,3) not null check (quantity_produced > 0),
  confirmed_by uuid not null references public.profiles(id),
  confirmed_at timestamptz not null default now()
);

create table if not exists public.production_consumptions (
  id uuid primary key default gen_random_uuid(),
  production_run_id uuid not null references public.production_runs(id) on delete restrict,
  raw_material_id uuid not null references public.raw_materials(id),
  quantity_used_base numeric(18,6) not null check (quantity_used_base > 0),
  unit_cost_snapshot numeric(14,6) not null default 0,
  inventory_transaction_id uuid not null references public.inventory_transactions(id),
  created_at timestamptz not null default now()
);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_item record;
  v_required numeric(18,6);
  v_stock numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_quantity_produced <= 0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then
    raise exception 'Production plan item not found';
  end if;

  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id <> auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining := v_plan.planned_qty - v_plan.produced_qty;
  if p_quantity_produced > v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id
    and active=true
  limit 1;

  if not found then
    raise exception 'Product has no active recipe';
  end if;

  -- First pass: verify every required ingredient has enough stock.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;

    if v_item.current_stock_qty < v_required then
      raise exception 'Insufficient stock for raw material %', v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(id,plan_item_id,quantity_produced,confirmed_by)
  values(v_run_id,p_plan_item_id,p_quantity_produced,auth.uid());

  -- Second pass: post stock consumption ledger entries.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty > 0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required := (v_item.quantity_base_unit / v_recipe.yield_qty) * p_quantity_produced;
    v_unit_cost := v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,
      'usage',
      -v_required,
      v_unit_cost,
      'production_run',
      v_run_id,
      auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced >= planned_qty
        then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    'confirm_production',
    'production_run',
    v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty > 0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=current_date;

alter table public.production_plan_items enable row level security;
alter table public.production_runs enable row level security;
alter table public.production_consumptions enable row level security;

create policy "production staff read plan items" on public.production_plan_items
for select using (
  public.current_staff_role() in ('owner','manager')
  or (public.current_staff_role()='baker' and assigned_baker_id=auth.uid())
);

create policy "owner manager manage plan items" on public.production_plan_items
for all using (public.current_staff_role() in ('owner','manager'))
with check (public.current_staff_role() in ('owner','manager'));

create policy "production staff read runs" on public.production_runs
for select using (
  public.current_staff_role() in ('owner','manager')
  or confirmed_by=auth.uid()
);

create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper','baker')
);

grant execute on function public.confirm_production_run(uuid,numeric) to authenticated;

create index if not exists production_plan_date_idx
  on public.production_plan_items(business_date,status);

create index if not exists production_plan_baker_idx
  on public.production_plan_items(assigned_baker_id,business_date);

create index if not exists production_runs_plan_idx
  on public.production_runs(plan_item_id,confirmed_at desc);

create index if not exists production_consumption_run_idx
  on public.production_consumptions(production_run_id);


-- ===== PHASE 2B MIGRATION =====
-- DS Bakery Phase 2B: waste & production control
create type public.waste_type as enum ('finished_product','raw_material');
create type public.waste_approval_status as enum ('pending','approved','rejected');

create table public.waste_settings (
  id integer primary key default 1 check (id=1),
  approval_threshold numeric(14,2) not null default 50000 check (approval_threshold >= 0),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);
insert into public.waste_settings(id,approval_threshold) values(1,50000) on conflict (id) do nothing;

create table public.waste_events (
  id uuid primary key default gen_random_uuid(),
  waste_type public.waste_type not null,
  product_id uuid references public.products(id),
  raw_material_id uuid references public.raw_materials(id),
  production_run_id uuid references public.production_runs(id),
  quantity numeric(18,6) not null check (quantity > 0),
  reason text not null,
  notes text,
  unit_cost_snapshot numeric(14,6) not null default 0,
  total_cost numeric(14,2) not null default 0,
  approval_status public.waste_approval_status not null default 'pending',
  recorded_by uuid not null references public.profiles(id),
  recorded_at timestamptz not null default now(),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  decision_note text,
  inventory_transaction_id uuid references public.inventory_transactions(id),
  check ((waste_type='finished_product' and product_id is not null and raw_material_id is null) or (waste_type='raw_material' and raw_material_id is not null and product_id is null))
);

create or replace function public.current_product_unit_cost(p_product_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(ri.quantity_base_unit * case when rm.purchase_pack_base_qty>0 then rm.current_purchase_cost/rm.purchase_pack_base_qty else 0 end)/r.yield_qty
  from public.recipes r join public.recipe_items ri on ri.recipe_id=r.id join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.product_id=p_product_id and r.active=true group by r.id,r.yield_qty limit 1),0)
$$;

create or replace function public.production_run_unit_cost(p_run_id uuid)
returns numeric language sql stable security definer set search_path=public as $$
  select coalesce((select sum(pc.quantity_used_base*pc.unit_cost_snapshot)/pr.quantity_produced
  from public.production_runs pr join public.production_consumptions pc on pc.production_run_id=pr.id
  where pr.id=p_run_id group by pr.id,pr.quantity_produced),0)
$$;

create or replace function public.apply_approved_raw_waste(p_waste_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_waste public.waste_events%rowtype; v_stock numeric; v_tx_id uuid;
begin
  select * into v_waste from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_waste.waste_type<>'raw_material' or v_waste.inventory_transaction_id is not null or v_waste.approval_status<>'approved' then return; end if;
  select current_stock_qty into v_stock from public.raw_materials where id=v_waste.raw_material_id for update;
  if v_stock < v_waste.quantity then raise exception 'Insufficient raw-material stock for waste approval'; end if;
  insert into public.inventory_transactions(raw_material_id,tx_type,quantity_delta,unit_cost,reference_type,reference_id,created_by,notes)
  values(v_waste.raw_material_id,'waste',-v_waste.quantity,v_waste.unit_cost_snapshot,'waste_event',v_waste.id,coalesce(v_waste.approved_by,v_waste.recorded_by),'Approved raw-material waste: '||v_waste.reason)
  returning id into v_tx_id;
  update public.waste_events set inventory_transaction_id=v_tx_id where id=v_waste.id;
end; $$;

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,p_quantity numeric,p_reason text,p_product_id uuid default null,p_raw_material_id uuid default null,p_production_run_id uuid default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_role public.staff_role; v_unit_cost numeric(14,6); v_total numeric(14,2); v_threshold numeric(14,2); v_status public.waste_approval_status; v_waste_id uuid:=gen_random_uuid(); v_run_product uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','baker','storekeeper') then raise exception 'Not authorized to record waste'; end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;
  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then raise exception 'Finished-product waste requires product only'; end if;
    if p_production_run_id is not null then
      select ppi.product_id into v_run_product from public.production_runs pr join public.production_plan_items ppi on ppi.id=pr.plan_item_id where pr.id=p_production_run_id;
      if v_run_product is null or v_run_product<>p_product_id then raise exception 'Production run does not match product'; end if;
      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else v_unit_cost:=public.current_product_unit_cost(p_product_id); end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then raise exception 'Raw-material waste requires raw material only'; end if;
    select case when purchase_pack_base_qty>0 then current_purchase_cost/purchase_pack_base_qty else 0 end into v_unit_cost from public.raw_materials where id=p_raw_material_id;
    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;
  v_total:=round((p_quantity*v_unit_cost)::numeric,2);
  select approval_threshold into v_threshold from public.waste_settings where id=1;
  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then v_status:='approved'; else v_status:='pending'; end if;
  insert into public.waste_events(id,waste_type,product_id,raw_material_id,production_run_id,quantity,reason,notes,unit_cost_snapshot,total_cost,approval_status,recorded_by,approved_by,approved_at)
  values(v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,p_quantity,p_reason,p_notes,v_unit_cost,v_total,v_status,auth.uid(),case when v_status='approved' then auth.uid() end,case when v_status='approved' then now() end);
  if v_status='approved' and p_waste_type='raw_material' then perform public.apply_approved_raw_waste(v_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'record_waste','waste_event',v_waste_id,jsonb_build_object('waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,'total_cost',v_total,'approval_status',v_status));
  return v_waste_id;
end; $$;

create or replace function public.decide_waste_event(p_waste_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_before public.waste_events%rowtype; v_new public.waste_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve/reject waste'; end if;
  if p_decision='approve' then v_new:='approved'; elsif p_decision='reject' then v_new:='rejected'; else raise exception 'Decision must be approve or reject'; end if;
  select * into v_before from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_before.approval_status<>'pending' then raise exception 'Only pending waste can be decided'; end if;
  update public.waste_events set approval_status=v_new,approved_by=auth.uid(),approved_at=now(),decision_note=p_note where id=p_waste_id;
  if v_new='approved' and v_before.waste_type='raw_material' then perform public.apply_approved_raw_waste(p_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data) values(auth.uid(),case when v_new='approved' then 'approve_waste' else 'reject_waste' end,'waste_event',p_waste_id,jsonb_build_object('approval_status',v_before.approval_status),jsonb_build_object('approval_status',v_new,'decision_note',p_note));
end; $$;

create or replace view public.production_control_today with (security_invoker=true) as
with plan as (
 select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty from public.production_plan_items where business_date=current_date and status<>'cancelled' group by product_id
), product_waste as (
 select product_id,coalesce(sum(quantity),0) approved_waste_qty,coalesce(sum(total_cost),0) approved_waste_cost from public.waste_events
 where waste_type='finished_product' and approval_status='approved' and recorded_at::date=current_date group by product_id
)
select p.id product_id,p.name product_name,pl.planned_qty,pl.produced_qty,coalesce(pw.approved_waste_qty,0) approved_waste_qty,
 greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,(pl.produced_qty-pl.planned_qty) production_variance,
 case when pl.produced_qty>0 then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2) else 0 end waste_rate_pct,
 coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl join public.products p on p.id=pl.product_id left join product_waste pw on pw.product_id=pl.product_id;

create or replace view public.waste_summary_30d with (security_invoker=true) as
select waste_type,approval_status,count(*) event_count,coalesce(sum(total_cost),0)::numeric(14,2) total_cost from public.waste_events where recorded_at>=now()-interval '30 days' group by waste_type,approval_status;

alter table public.waste_settings enable row level security;
alter table public.waste_events enable row level security;
create policy "management read waste settings" on public.waste_settings for select using (public.current_staff_role() in ('owner','manager'));
create policy "owner manage waste settings" on public.waste_settings for all using (public.current_staff_role()='owner') with check (public.current_staff_role()='owner');
create policy "staff read relevant waste" on public.waste_events for select using (public.current_staff_role() in ('owner','manager') or recorded_by=auth.uid() or (public.current_staff_role()='storekeeper' and waste_type='raw_material'));
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
create index waste_events_recorded_idx on public.waste_events(recorded_at desc);
create index waste_events_pending_idx on public.waste_events(approval_status,recorded_at desc);
create index waste_events_product_idx on public.waste_events(product_id,recorded_at desc) where product_id is not null;
create index waste_events_material_idx on public.waste_events(raw_material_id,recorded_at desc) where raw_material_id is not null;


-- ===== PHASE 2C MIGRATION =====
-- DS Bakery Phase 2C: supplier accounts, payables and purchase-order approval

create type public.po_approval_status as enum ('pending','approved','rejected');

alter table public.purchases
  add column if not exists approval_status public.po_approval_status not null default 'pending',
  add column if not exists requested_by uuid references public.profiles(id),
  add column if not exists approved_by uuid references public.profiles(id),
  add column if not exists approved_at timestamptz,
  add column if not exists approval_note text,
  add column if not exists supplier_invoice_no text,
  add column if not exists invoice_date date,
  add column if not exists credit_terms_days integer not null default 0 check (credit_terms_days >= 0),
  add column if not exists due_date date;

update public.purchases
set requested_by=coalesce(requested_by,created_by),
    approval_status=case
      when status='draft' then 'pending'::public.po_approval_status
      else 'approved'::public.po_approval_status
    end
where requested_by is null
   or (approval_status='pending' and status<>'draft');

create or replace function public.set_purchase_due_date()
returns trigger
language plpgsql
set search_path=public
as $$
begin
  if new.due_date is null then
    new.due_date := coalesce(new.invoice_date,new.purchase_date) + new.credit_terms_days;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_set_purchase_due_date on public.purchases;
create trigger trg_set_purchase_due_date
before insert or update of invoice_date,purchase_date,credit_terms_days,due_date
on public.purchases
for each row execute function public.set_purchase_due_date();

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then
    v_approval := 'approved';
  elsif p_decision='reject' then
    v_approval := 'rejected';
  else
    raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status <> 'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',
    p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid := gen_random_uuid();
  v_remaining numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if coalesce(trim(p_method),'')='' then
    raise exception 'Payment method is required';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status <> 'approved' then raise exception 'Purchase order is not approved'; end if;

  v_remaining := v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount > v_remaining then
    raise exception 'Payment exceeds amount outstanding on purchase';
  end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by
  )
  values(
    v_payment_id,p_purchase_id,p_amount,p_method,nullif(trim(p_reference),''),now(),auth.uid()
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date < current_date
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled'
      and p.total_amount>p.amount_paid
    then p.due_date end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

create or replace view public.supplier_statement_lines
with (security_invoker=true)
as
with lines as (
  select
    p.supplier_id,
    p.purchase_date::timestamptz as occurred_at,
    'purchase'::text as line_type,
    p.id as source_id,
    p.purchase_no as reference,
    p.supplier_invoice_no,
    p.total_amount::numeric(14,2) as debit,
    0::numeric(14,2) as credit,
    p.total_amount::numeric(14,2) as balance_delta
  from public.purchases p
  where p.status<>'cancelled'
    and p.approval_status='approved'

  union all

  select
    p.supplier_id,
    pp.paid_at as occurred_at,
    'payment'::text as line_type,
    pp.id as source_id,
    coalesce(pp.reference,'Supplier payment') as reference,
    p.supplier_invoice_no,
    0::numeric(14,2) as debit,
    pp.amount::numeric(14,2) as credit,
    (-pp.amount)::numeric(14,2) as balance_delta
  from public.purchase_payments pp
  join public.purchases p on p.id=pp.purchase_id
)
select
  supplier_id,
  occurred_at,
  line_type,
  source_id,
  reference,
  supplier_invoice_no,
  debit,
  credit,
  sum(balance_delta) over(
    partition by supplier_id
    order by occurred_at,line_type,source_id
    rows between unbounded preceding and current row
  )::numeric(14,2) as running_balance
from lines;

create or replace view public.open_purchase_orders
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.total_amount,
  p.status,
  p.approval_status,
  p.due_date,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by
where p.status not in ('received','cancelled');

grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text) to authenticated;

create index if not exists purchases_due_idx
  on public.purchases(due_date,payment_status)
  where status<>'cancelled';

create index if not exists purchases_approval_idx
  on public.purchases(approval_status,status,created_at desc);

create index if not exists purchase_payments_paid_idx
  on public.purchase_payments(paid_at desc);


-- ===== PHASE 2D MIGRATION =====
-- DS Bakery Phase 2D: customers, customer orders, deposits and receipts

create type public.customer_order_status as enum (
  'pending','confirmed','in_production','ready','completed','cancelled'
);

create type public.fulfillment_type as enum ('pickup','delivery');

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text,
  email text,
  address text,
  birthday date,
  notes text,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists customers_phone_unique
  on public.customers(phone)
  where phone is not null;

create table if not exists public.customer_orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  customer_id uuid not null references public.customers(id),
  status public.customer_order_status not null default 'pending',
  fulfillment public.fulfillment_type not null default 'pickup',
  required_at timestamptz not null,
  delivery_address text,
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  discount numeric(14,2) not null default 0 check (discount >= 0),
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  cancelled_at timestamptz,
  cancellation_reason text
);

create table if not exists public.customer_order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  product_id uuid references public.products(id),
  description text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  line_total numeric(14,2) not null check (line_total >= 0),
  customization_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_order_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount > 0),
  reference text,
  payment_status text not null default 'completed',
  recorded_by uuid not null references public.profiles(id),
  paid_at timestamptz not null default now()
);

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' || to_char(now(),'YYMMDD') || '-' ||
         lpad((floor(random()*10000))::int::text,4,'0')
$$;

create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount into v_discount
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_amount <= 0 then
    raise exception 'Payment amount must be greater than zero';
  end if;

  if p_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
    into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_remaining := v_order.total_amount-v_paid;

  if p_amount > v_remaining then
    raise exception 'Payment exceeds outstanding order balance';
  end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,recorded_by
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,
    nullif(trim(p_reference),''),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'amount',p_amount,
      'method',p_method,
      'reference',p_reference
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
begin
  v_role := public.current_staff_role();

  if v_role not in ('owner','manager','cashier','baker') then
    raise exception 'Not authorized';
  end if;

  select * into v_before
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;

  if v_role='cashier' and p_status in ('in_production') then
    raise exception 'Cashier cannot move order into production';
  end if;

  if v_role='baker' and p_status not in ('in_production','ready') then
    raise exception 'Baker may only update production/ready status';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  co.created_at,
  co.updated_at
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  co.id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.status,co.fulfillment,co.required_at,co.delivery_address,
  co.total_amount,co.created_at,co.updated_at;

create or replace view public.customer_summary
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  count(distinct co.id)::bigint as order_count,
  coalesce(sum(co.total_amount),0)::numeric(14,2) as total_order_value,
  coalesce(sum((
    select co.total_amount -
      coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
    from public.customer_order_payments cop
    where cop.order_id=co.id
  )),0)::numeric(14,2) as outstanding_balance,
  max(co.created_at) as last_order_at
from public.customers c
left join public.customer_orders co
  on co.customer_id=c.id and co.status<>'cancelled'
where c.active=true
group by c.id,c.full_name,c.phone,c.email;

alter table public.customers enable row level security;
alter table public.customer_orders enable row level security;
alter table public.customer_order_items enable row level security;
alter table public.customer_order_payments enable row level security;

create policy "sales staff read customers" on public.customers
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff manage customers" on public.customers
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer orders" on public.customer_orders
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer orders" on public.customer_orders
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "relevant staff read customer order items" on public.customer_order_items
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create policy "sales staff manage customer order items" on public.customer_order_items
for all using (public.current_staff_role() in ('owner','manager','cashier'))
with check (public.current_staff_role() in ('owner','manager','cashier'));

create policy "sales staff read order payments" on public.customer_order_payments
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.record_customer_order_payment(
  uuid,numeric,public.payment_method,text
) to authenticated;

grant execute on function public.update_customer_order_status(
  uuid,public.customer_order_status
) to authenticated;

create index if not exists customer_orders_customer_idx
  on public.customer_orders(customer_id,created_at desc);

create index if not exists customer_orders_required_idx
  on public.customer_orders(status,required_at);

create index if not exists customer_order_items_order_idx
  on public.customer_order_items(order_id);

create index if not exists customer_order_payments_order_idx
  on public.customer_order_payments(order_id,paid_at desc);


-- ===== PHASE 2E MIGRATION =====
-- DS Bakery Phase 2E: weekly/monthly operational reporting

create or replace function public.operational_period_bounds(p_period text)
returns table(start_date date,end_date date)
language plpgsql
stable
as $$
begin
  if p_period='week' then
    start_date := date_trunc('week',current_date)::date;
    end_date := current_date;
  elsif p_period='month' then
    start_date := date_trunc('month',current_date)::date;
    end_date := current_date;
  else
    raise exception 'Unsupported period: %', p_period;
  end if;
  return next;
end;
$$;

create or replace function public.operational_report_summary(p_period text default 'week')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start date;
  v_end date;
  v_sales numeric(14,2);
  v_gross numeric(14,2);
  v_expenses numeric(14,2);
  v_planned numeric(18,3);
  v_produced numeric(18,3);
  v_waste_cost numeric(14,2);
  v_product_waste numeric(18,3);
  v_supplier_outstanding numeric(14,2);
  v_supplier_overdue numeric(14,2);
  v_customer_balance numeric(14,2);
  v_orders bigint;
  v_completed bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  select start_date,end_date into v_start,v_end
  from public.operational_period_bounds(p_period);

  select
    coalesce(sum(sales_amount),0),
    coalesce(sum(gross_profit_amount),0)
  into v_sales,v_gross
  from public.sale_profit_lines
  where created_at::date between v_start and v_end;

  select coalesce(sum(amount),0)
  into v_expenses
  from public.expenses
  where created_at::date between v_start and v_end;

  select
    coalesce(sum(planned_qty),0),
    coalesce(sum(produced_qty),0)
  into v_planned,v_produced
  from public.production_plan_items
  where business_date between v_start and v_end
    and status<>'cancelled';

  select
    coalesce(sum(total_cost),0),
    coalesce(sum(case when waste_type='finished_product' then quantity else 0 end),0)
  into v_waste_cost,v_product_waste
  from public.waste_events
  where approval_status='approved'
    and recorded_at::date between v_start and v_end;

  select
    coalesce(sum(outstanding_balance),0),
    coalesce(sum(overdue_balance),0)
  into v_supplier_outstanding,v_supplier_overdue
  from public.supplier_account_summary;

  select coalesce(sum(balance_due),0)
  into v_customer_balance
  from public.customer_order_summary
  where status not in ('completed','cancelled');

  select
    count(*),
    count(*) filter (where status='completed')
  into v_orders,v_completed
  from public.customer_orders
  where created_at::date between v_start and v_end;

  return jsonb_build_object(
    'period',p_period,
    'start_date',v_start,
    'end_date',v_end,
    'sales',v_sales,
    'gross_profit',v_gross,
    'expenses',v_expenses,
    'estimated_operating_profit',v_gross-v_expenses,
    'production_planned',v_planned,
    'production_produced',v_produced,
    'production_variance',v_produced-v_planned,
    'waste_cost',v_waste_cost,
    'finished_product_waste_qty',v_product_waste,
    'supplier_outstanding',v_supplier_outstanding,
    'supplier_overdue',v_supplier_overdue,
    'customer_order_balance',v_customer_balance,
    'orders_total',v_orders,
    'orders_completed',v_completed,
    'order_completion_rate',case when v_orders>0 then round((v_completed::numeric/v_orders)*100,2) else 0 end
  );
end;
$$;

create or replace view public.operational_production_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
),
waste as (
  select
    we.product_id,
    p.period_key,
    coalesce(sum(we.quantity),0) as waste_qty
  from public.waste_events we
  join periods p on we.recorded_at::date between p.start_date and p.end_date
  where we.waste_type='finished_product'
    and we.approval_status='approved'
  group by we.product_id,p.period_key
)
select
  per.period_key,
  ppi.product_id,
  pr.name as product_name,
  sum(ppi.planned_qty)::numeric(18,3) as planned_qty,
  sum(ppi.produced_qty)::numeric(18,3) as produced_qty,
  (sum(ppi.produced_qty)-sum(ppi.planned_qty))::numeric(18,3) as variance_qty,
  coalesce(w.waste_qty,0)::numeric(18,3) as approved_waste_qty,
  case when sum(ppi.produced_qty)>0
    then round((coalesce(w.waste_qty,0)/sum(ppi.produced_qty))*100,2)
    else 0 end as waste_rate_pct
from periods per
join public.production_plan_items ppi
  on ppi.business_date between per.start_date and per.end_date
join public.products pr on pr.id=ppi.product_id
left join waste w
  on w.product_id=ppi.product_id and w.period_key=per.period_key
where ppi.status<>'cancelled'
group by per.period_key,ppi.product_id,pr.name,w.waste_qty;

create or replace view public.operational_waste_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  we.waste_type,
  count(*)::bigint as event_count,
  coalesce(sum(we.quantity),0)::numeric(18,3) as quantity,
  coalesce(sum(we.total_cost),0)::numeric(14,2) as waste_cost
from periods per
join public.waste_events we
  on we.recorded_at::date between per.start_date and per.end_date
where we.approval_status='approved'
group by per.period_key,we.waste_type;

create or replace view public.customer_order_operational_summary
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  count(co.id)::bigint as orders_total,
  count(co.id) filter (where co.status='completed')::bigint as orders_completed,
  count(co.id) filter (where co.status='ready')::bigint as orders_ready,
  count(co.id) filter (where co.status='in_production')::bigint as orders_in_production,
  case when count(co.id)>0
    then round((count(co.id) filter (where co.status='completed')::numeric/count(co.id))*100,2)
    else 0 end as completion_rate
from periods per
left join public.customer_orders co
  on co.created_at::date between per.start_date and per.end_date
group by per.period_key;

create or replace view public.operational_product_performance
with (security_invoker=true)
as
with periods as (
  select 'week'::text as period_key,
         date_trunc('week',current_date)::date as start_date,
         current_date as end_date
  union all
  select 'month',
         date_trunc('month',current_date)::date,
         current_date
)
select
  per.period_key,
  spl.product_id,
  spl.product_name,
  sum(spl.quantity)::numeric(18,3) as units_sold,
  sum(spl.sales_amount)::numeric(14,2) as sales_amount,
  sum(spl.gross_profit_amount)::numeric(14,2) as gross_profit_amount
from periods per
join public.sale_profit_lines spl
  on spl.created_at::date between per.start_date and per.end_date
group by per.period_key,spl.product_id,spl.product_name
order by per.period_key,units_sold desc;

create or replace function public.management_alerts()
returns table(
  alert_type text,
  severity text,
  title text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  select
    'supplier'::text,
    'high'::text,
    'Overdue supplier balance'::text,
    s.supplier_name || ' overdue ' || to_char(s.overdue_balance,'FM999,999,999') || ' UGX'
  from public.supplier_account_summary s
  where s.overdue_balance>0

  union all

  select
    'stock',
    'high',
    'Low stock',
    l.name || ' at ' || l.current_stock_qty || ' ' || l.base_unit
  from public.low_stock_materials l

  union all

  select
    'production',
    'medium',
    'Production below plan',
    p.product_name || ' variance ' || p.variance_qty
  from public.operational_production_performance p
  where p.period_key='week'
    and p.variance_qty<0

  union all

  select
    'waste',
    'medium',
    'High waste rate',
    p.product_name || ' waste rate ' || p.waste_rate_pct || '%'
  from public.operational_production_performance p
  where p.period_key='week'
    and p.waste_rate_pct>=5;
end;
$$;

grant execute on function public.operational_report_summary(text) to authenticated;
grant execute on function public.management_alerts() to authenticated;


-- ===== PHASE 3A MIGRATION =====
-- DS Bakery Phase 3A: custom cake specification, quote, image reference and production handoff

create type public.custom_cake_design_status as enum (
  'draft','quoted','awaiting_deposit','approved','in_production','ready','completed','cancelled'
);

create table if not exists public.custom_cake_specs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  cake_size_label text,
  servings integer check (servings is null or servings > 0),
  tiers integer not null default 1 check (tiers > 0),
  flavour text,
  filling text,
  frosting text,
  theme text,
  primary_color text,
  secondary_color text,
  inscription text,
  reference_image_path text,
  special_instructions text,
  production_notes text,
  quote_amount numeric(14,2) not null default 0 check (quote_amount >= 0),
  design_status public.custom_cake_design_status not null default 'draft',
  customer_approved_at timestamptz,
  production_approved_by uuid references public.profiles(id),
  production_approved_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;

  if p_quote_amount <= 0 then
    raise exception 'Quote amount must be greater than zero';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status
    end,
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    subtotal=p_quote_amount,
    total_amount=p_quote_amount,
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(
  p_order_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec
  from public.custom_cake_specs
  where order_id=p_order_id
  for update;

  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount <= 0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_paid <= 0 then
    raise exception 'A deposit/payment is required before production approval';
  end if;

  update public.custom_cake_specs
  set
    design_status='approved',
    production_approved_by=auth.uid(),
    production_approved_at=now(),
    updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set
    status='confirmed',
    updated_at=now()
  where id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,
      'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid
    )
  );
end;
$$;

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id as custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (ccs.quote_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  ccs.design_status,
  co.status as order_status
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,
  co.required_at,co.fulfillment,co.delivery_address,
  ccs.cake_size_label,ccs.servings,ccs.tiers,ccs.flavour,ccs.filling,
  ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,
  ccs.production_notes,ccs.quote_amount,ccs.design_status,co.status;

alter table public.custom_cake_specs enable row level security;

create policy "relevant staff read custom cakes" on public.custom_cake_specs
for select using (
  public.current_staff_role() in ('owner','manager','cashier','baker')
);

create policy "sales staff create custom cakes" on public.custom_cake_specs
for insert with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "sales staff update custom cakes" on public.custom_cake_specs
for update using (
  public.current_staff_role() in ('owner','manager','cashier')
)
with check (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;

create index if not exists custom_cake_specs_status_idx
  on public.custom_cake_specs(design_status,updated_at desc);

-- Storage note:
-- Create a PRIVATE Supabase Storage bucket named `custom-cake-references`.
-- Store only the object path in reference_image_path.
-- Do not make customer reference images public by default.


-- ===== PHASE 3B MIGRATION =====
-- DS Bakery Phase 3B: delivery jobs and rider assignment

create type public.delivery_status as enum (
  'pending','assigned','out_for_delivery','delivered','failed','cancelled'
);

create table if not exists public.delivery_riders (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  vehicle_label text,
  profile_id uuid unique references public.profiles(id),
  active boolean not null default true,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.customer_orders
  add column if not exists delivery_charge numeric(14,2) not null default 0
    check (delivery_charge >= 0);

create table if not exists public.delivery_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.customer_orders(id) on delete restrict,
  rider_id uuid references public.delivery_riders(id),
  status public.delivery_status not null default 'pending',
  scheduled_for timestamptz,
  delivery_address_snapshot text not null,
  customer_name_snapshot text not null,
  customer_phone_snapshot text,
  delivery_charge numeric(14,2) not null default 0 check (delivery_charge >= 0),
  assigned_by uuid references public.profiles(id),
  assigned_at timestamptz,
  dispatched_by uuid references public.profiles(id),
  dispatched_at timestamptz,
  delivered_by uuid references public.profiles(id),
  delivered_at timestamptz,
  failed_at timestamptz,
  outcome_note text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Include delivery charge in order total calculation.
create or replace function public.refresh_customer_order_total(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_subtotal numeric(14,2);
  v_discount numeric(14,2);
  v_delivery numeric(14,2);
begin
  select coalesce(sum(line_total),0)::numeric(14,2)
    into v_subtotal
  from public.customer_order_items
  where order_id=p_order_id;

  select discount,delivery_charge
    into v_discount,v_delivery
  from public.customer_orders
  where id=p_order_id
  for update;

  update public.customer_orders
  set
    subtotal=v_subtotal,
    total_amount=greatest(v_subtotal-coalesce(v_discount,0),0)+coalesce(v_delivery,0),
    updated_at=now()
  where id=p_order_id;
end;
$$;

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_delivery_charge < 0 then
    raise exception 'Delivery charge cannot be negative';
  end if;

  if coalesce(trim(p_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment <> 'delivery' then
    raise exception 'Order is not marked for delivery';
  end if;
  if v_order.status='cancelled' then
    raise exception 'Cannot create delivery for cancelled order';
  end if;

  select * into v_customer
  from public.customers
  where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  v_new_total := greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;

  if v_new_total < v_paid then
    raise exception 'New order total would be less than payments already recorded';
  end if;

  update public.customer_orders
  set
    delivery_charge=p_delivery_charge,
    total_amount=v_new_total,
    delivery_address=p_address,
    updated_at=now()
  where id=p_order_id;

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,
    delivery_address_snapshot,customer_name_snapshot,customer_phone_snapshot,
    delivery_charge,created_by
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    p_address,v_customer.full_name,v_customer.phone,
    p_delivery_charge,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,
      'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at)
    )
  );

  return v_id;
end;
$$;

create or replace function public.assign_delivery_rider(
  p_delivery_id uuid,
  p_rider_id uuid
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_rider public.delivery_riders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to assign riders';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;
  if v_job.status in ('delivered','cancelled') then
    raise exception 'Delivery job is closed';
  end if;

  select * into v_rider
  from public.delivery_riders
  where id=p_rider_id and active=true;

  if not found then raise exception 'Active rider not found'; end if;

  update public.delivery_jobs
  set
    rider_id=p_rider_id,
    status='assigned',
    assigned_by=auth.uid(),
    assigned_at=now(),
    updated_at=now()
  where id=p_delivery_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'assign_delivery_rider','delivery_job',p_delivery_id,
    jsonb_build_object('rider_id',p_rider_id,'rider_name',v_rider.full_name)
  );
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job
  from public.delivery_jobs
  where id=p_delivery_id
  for update;

  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order
  from public.customer_orders
  where id=v_job.order_id
  for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then
      raise exception 'Delivery must be assigned or failed before dispatch';
    end if;
    if v_job.rider_id is null then
      raise exception 'Assign a rider before dispatch';
    end if;
    if v_order.status <> 'ready' then
      raise exception 'Customer order must be ready before dispatch';
    end if;

    update public.delivery_jobs
    set
      status='out_for_delivery',
      dispatched_by=auth.uid(),
      dispatched_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may be completed';
    end if;

    update public.delivery_jobs
    set
      status='delivered',
      delivered_by=auth.uid(),
      delivered_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set
      status='completed',
      completed_at=now(),
      updated_at=now()
    where id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status <> 'out_for_delivery' then
      raise exception 'Only out-for-delivery jobs may fail';
    end if;
    if coalesce(trim(p_note),'')='' then
      raise exception 'Failure reason is required';
    end if;

    update public.delivery_jobs
    set
      status='failed',
      failed_at=now(),
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then
      raise exception 'Delivered job cannot be cancelled';
    end if;

    update public.delivery_jobs
    set
      status='cancelled',
      outcome_note=p_note,
      updated_at=now()
    where id=p_delivery_id;

  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

create or replace view public.delivery_job_summary
with (security_invoker=true)
as
select
  dj.id,
  dj.order_id,
  co.order_no,
  co.customer_id,
  dj.customer_name_snapshot as customer_name,
  dj.customer_phone_snapshot as customer_phone,
  dj.delivery_address_snapshot as delivery_address,
  dj.scheduled_for,
  dj.delivery_charge,
  dj.status,
  dj.rider_id,
  dr.full_name as rider_name,
  dr.phone as rider_phone,
  co.total_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) as amount_paid,
  (co.total_amount -
    coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)
  )::numeric(14,2) as balance_due,
  dj.assigned_at,
  dj.dispatched_at,
  dj.delivered_at,
  dj.failed_at,
  dj.outcome_note
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
left join public.delivery_riders dr on dr.id=dj.rider_id
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  dj.id,dj.order_id,co.order_no,co.customer_id,
  dj.customer_name_snapshot,dj.customer_phone_snapshot,
  dj.delivery_address_snapshot,dj.scheduled_for,dj.delivery_charge,
  dj.status,dj.rider_id,dr.full_name,dr.phone,co.total_amount,
  dj.assigned_at,dj.dispatched_at,dj.delivered_at,dj.failed_at,dj.outcome_note;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id as rider_id,
  dr.full_name,
  dr.phone,
  dr.vehicle_label,
  dr.active,
  count(dj.id) filter (
    where dj.status in ('assigned','out_for_delivery')
  )::bigint as active_jobs,
  count(dj.id) filter (
    where dj.status='delivered'
      and dj.delivered_at::date=current_date
  )::bigint as delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

alter table public.delivery_riders enable row level security;
alter table public.delivery_jobs enable row level security;

create policy "delivery staff read riders" on public.delivery_riders
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage riders" on public.delivery_riders
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "delivery staff read delivery jobs" on public.delivery_jobs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;

create index if not exists delivery_jobs_status_schedule_idx
  on public.delivery_jobs(status,scheduled_for);

create index if not exists delivery_jobs_rider_idx
  on public.delivery_jobs(rider_id,status);

create index if not exists delivery_riders_active_idx
  on public.delivery_riders(active,full_name);


-- ===== PHASE 3C MIGRATION =====
-- DS Bakery Phase 3C: loyalty, birthdays and customer retention

create type public.loyalty_event_type as enum (
  'sale_earn',
  'order_earn',
  'refund_adjustment',
  'reward_redemption',
  'birthday_bonus',
  'manual_adjustment'
);

alter table public.sales
  add column if not exists customer_id uuid references public.customers(id);

create table if not exists public.loyalty_settings (
  id integer primary key default 1 check (id=1),
  earn_amount_per_point numeric(14,2) not null default 1000 check (earn_amount_per_point > 0),
  reward_points integer not null default 100 check (reward_points > 0),
  reward_value numeric(14,2) not null default 5000 check (reward_value >= 0),
  birthday_reminder_days integer not null default 30 check (birthday_reminder_days between 1 and 90),
  vip_spend_threshold numeric(14,2) not null default 1000000 check (vip_spend_threshold >= 0),
  regular_spend_threshold numeric(14,2) not null default 500000 check (regular_spend_threshold >= 0),
  regular_order_threshold integer not null default 5 check (regular_order_threshold >= 1),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.loyalty_settings(id)
values(1)
on conflict (id) do nothing;

create table if not exists public.loyalty_point_transactions (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  event_type public.loyalty_event_type not null,
  points_delta integer not null check (points_delta <> 0),
  source_type text,
  source_id uuid,
  reason text not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace view public.customer_loyalty_balances
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  coalesce(sum(lpt.points_delta),0)::bigint as points_balance,
  max(lpt.created_at) as last_loyalty_activity_at
from public.customers c
left join public.loyalty_point_transactions lpt on lpt.customer_id=c.id
where c.active=true
group by c.id,c.full_name,c.phone;

create or replace function public.sync_sale_loyalty_points(p_sale_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale public.sales%rowtype;
  v_rate numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_sale from public.sales where id=p_sale_id;
  if not found or v_sale.customer_id is null then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  if v_sale.status in ('completed','partially_refunded') then
    v_expected := floor(greatest(v_sale.total-coalesce(v_sale.refund_total,0),0)/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_sale.customer_id
    and source_type='sale'
    and source_id=p_sale_id
    and event_type in ('sale_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_sale.customer_id,
      case when v_delta>0 then 'sale_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'sale',
      p_sale_id,
      case when v_delta>0 then 'Points earned from completed sale'
           else 'Points adjusted after sale refund/cancellation' end,
      v_sale.cashier_id
    );
  end if;
end;
$$;

create or replace function public.trg_sync_sale_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_sale_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_sales_loyalty_sync on public.sales;
create trigger trg_sales_loyalty_sync
after insert or update of customer_id,total,refund_total,status
on public.sales
for each row execute function public.trg_sync_sale_loyalty();

create or replace function public.sync_order_loyalty_points(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_rate numeric(14,2);
  v_paid numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_order
  from public.customer_orders
  where id=p_order_id;

  if not found then return; end if;

  select earn_amount_per_point into v_rate
  from public.loyalty_settings where id=1;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if v_order.status='completed' and v_paid >= v_order.total_amount then
    v_expected := floor(v_order.total_amount/v_rate)::integer;
  else
    v_expected := 0;
  end if;

  select coalesce(sum(points_delta),0)::integer
  into v_current
  from public.loyalty_point_transactions
  where customer_id=v_order.customer_id
    and source_type='customer_order'
    and source_id=p_order_id
    and event_type in ('order_earn','refund_adjustment');

  v_delta := v_expected-v_current;

  if v_delta <> 0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_order.customer_id,
      case when v_delta>0 then 'order_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,
      'customer_order',
      p_order_id,
      case when v_delta>0 then 'Points earned from paid completed customer order'
           else 'Points adjusted after order status/payment change' end,
      v_order.created_by
    );
  end if;
end;
$$;

create or replace function public.trg_sync_order_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.id);
  return new;
end;
$$;

drop trigger if exists trg_customer_orders_loyalty_sync on public.customer_orders;
create trigger trg_customer_orders_loyalty_sync
after update of status,total_amount
on public.customer_orders
for each row execute function public.trg_sync_order_loyalty();

create or replace function public.trg_sync_order_payment_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.order_id);
  return new;
end;
$$;

drop trigger if exists trg_order_payments_loyalty_sync on public.customer_order_payments;
create trigger trg_order_payments_loyalty_sync
after insert or update of amount,payment_status
on public.customer_order_payments
for each row execute function public.trg_sync_order_payment_loyalty();

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment'
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if v_balance is null then raise exception 'Customer not found'; end if;
  if v_balance+p_points < 0 then raise exception 'Adjustment would make points negative'; end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,source_type,reason,created_by
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,'manual',p_reason,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object('customer_id',p_customer_id,'points_delta',p_points,'reason',p_reason)
  );

  return v_id;
end;
$$;

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then
    raise exception 'Cannot redeem on a closed order';
  end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings
  where id=1;

  if p_points <= 0 or mod(p_points,v_reward_points) <> 0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points > v_balance then
    raise exception 'Insufficient loyalty points';
  end if;

  v_units := p_points/v_reward_points;
  v_discount := v_units*v_reward_value;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id
    and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0) < v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,source_type,source_id,reason,created_by
  )
  values(
    v_order.customer_id,
    'reward_redemption',
    -p_points,
    'customer_order',
    p_order_id,
    'Loyalty reward applied to customer order',
    auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount)
  );

  return v_discount;
end;
$$;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.birthday,
  b.next_birthday,
  (b.next_birthday-current_date) as days_until_birthday,
  coalesce(lb.points_balance,0) as points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date as next_birthday
  from generate_series(
    current_date,
    current_date + interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d
  limit 1
) b
where c.active=true
  and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id as customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint as order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) as lifetime_value,
    max(co.created_at) filter (where co.status<>'cancelled') as last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (
  select * from public.loyalty_settings where id=1
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  os.order_count,
  os.lifetime_value,
  os.last_order_at,
  coalesce(lb.points_balance,0) as points_balance,
  case
    when os.lifetime_value >= s.vip_spend_threshold then 'VIP'
    when os.lifetime_value >= s.regular_spend_threshold
      or os.order_count >= s.regular_order_threshold then 'Regular'
    when os.order_count >= 2 then 'Returning'
    else 'New'
  end as customer_segment
from public.customers c
join order_stats os on os.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

alter table public.loyalty_settings enable row level security;
alter table public.loyalty_point_transactions enable row level security;

create policy "sales management read loyalty settings" on public.loyalty_settings
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create policy "owner manage loyalty settings" on public.loyalty_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "sales management read loyalty ledger" on public.loyalty_point_transactions
for select using (public.current_staff_role() in ('owner','manager','cashier'));

grant execute on function public.adjust_customer_loyalty_points(
  uuid,integer,text,public.loyalty_event_type
) to authenticated;

grant execute on function public.redeem_loyalty_on_order(uuid,integer) to authenticated;

create index if not exists loyalty_customer_created_idx
  on public.loyalty_point_transactions(customer_id,created_at desc);

create index if not exists loyalty_source_idx
  on public.loyalty_point_transactions(source_type,source_id)
  where source_id is not null;


-- ===== PHASE 3D MIGRATION =====
-- DS Bakery Phase 3D: WhatsApp customer communication

create type public.communication_template_type as enum (
  'ready_for_pickup',
  'in_production',
  'out_for_delivery',
  'birthday',
  'balance_reminder',
  'custom'
);

create type public.communication_event_status as enum (
  'prepared',
  'opened_whatsapp',
  'api_sent',
  'delivered',
  'failed'
);

alter table public.customers
  add column if not exists whatsapp_opt_in boolean not null default false,
  add column if not exists whatsapp_opt_in_at timestamptz,
  add column if not exists whatsapp_opt_out_at timestamptz;

create table if not exists public.communication_templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  template_type public.communication_template_type not null,
  body_template text not null,
  requires_marketing_opt_in boolean not null default false,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.communication_templates(
  name,template_type,body_template,requires_marketing_opt_in
)
select * from (values
  ('Ready for pickup','ready_for_pickup'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is ready for collection. Balance due: UGX {{balance}}. Thank you for choosing DS Bakery.',false),
  ('In production','in_production'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is now in production. We will update you when it is ready.',false),
  ('Out for delivery','out_for_delivery'::public.communication_template_type,
   'Hello {{customer_name}}, your DS Bakery order {{order_no}} is out for delivery. Please keep your phone available for the rider.',false),
  ('Birthday greeting','birthday'::public.communication_template_type,
   'Happy birthday {{customer_name}}! DS Bakery wishes you a wonderful day. We appreciate having you as our customer.',true),
  ('Balance reminder','balance_reminder'::public.communication_template_type,
   'Hello {{customer_name}}, a friendly reminder that order {{order_no}} has a remaining balance of UGX {{balance}}. Thank you.',false)
) v(name,template_type,body_template,requires_marketing_opt_in)
where not exists (
  select 1 from public.communication_templates ct
  where ct.template_type=v.template_type
);

create table if not exists public.communication_logs (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  order_id uuid references public.customer_orders(id),
  template_id uuid references public.communication_templates(id),
  channel text not null default 'whatsapp',
  status public.communication_event_status not null default 'prepared',
  recipient_phone_snapshot text not null,
  message_snapshot text not null,
  initiated_by uuid not null references public.profiles(id),
  initiated_at timestamptz not null default now(),
  external_message_id text,
  delivered_at timestamptz,
  failure_reason text
);

create or replace function public.set_customer_whatsapp_preference(
  p_customer_id uuid,
  p_opted_in boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before boolean;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update communication preference';
  end if;

  select whatsapp_opt_in into v_before
  from public.customers
  where id=p_customer_id
  for update;

  if not found then raise exception 'Customer not found'; end if;

  update public.customers
  set
    whatsapp_opt_in=p_opted_in,
    whatsapp_opt_in_at=case when p_opted_in then now() else whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case when not p_opted_in then now() else null end,
    updated_at=now()
  where id=p_customer_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_whatsapp_preference','customer',p_customer_id,
    jsonb_build_object('whatsapp_opt_in',v_before),
    jsonb_build_object('whatsapp_opt_in',p_opted_in)
  );
end;
$$;

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then
    raise exception 'Recipient phone is required';
  end if;
  if coalesce(trim(p_message),'')='' then
    raise exception 'Message is required';
  end if;

  select * into v_customer
  from public.customers
  where id=p_customer_id;

  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template
    from public.communication_templates
    where id=p_template_id and active=true;

    if not found then raise exception 'Active communication template not found'; end if;

    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders
    where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,status,
    recipient_phone_snapshot,message_snapshot,initiated_by
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'opened_whatsapp',
    p_recipient_phone,p_message,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,
      'order_id',p_order_id,
      'template_id',p_template_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text as queue_type,
  100 as priority,
  co.customer_id,
  c.full_name as customer_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id as order_id,
  co.order_no,
  co.required_at as due_at,
  cos.balance_due,
  'Order is ready for pickup'::text as reason
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready'

union all

select
  'out_for_delivery',
  90,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  dj.scheduled_for,
  cos.balance_due,
  'Order is out for delivery'
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where dj.status='out_for_delivery'

union all

select
  'birthday',
  50,
  b.customer_id,
  b.full_name,
  b.phone,
  c.whatsapp_opt_in,
  null::uuid,
  null::text,
  b.next_birthday::timestamptz,
  0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days'
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all

select
  'balance_reminder',
  40,
  co.customer_id,
  c.full_name,
  c.phone,
  c.whatsapp_opt_in,
  co.id,
  co.order_no,
  co.required_at,
  cos.balance_due,
  'Customer order has outstanding balance'
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0
  and co.status not in ('cancelled');

alter table public.communication_templates enable row level security;
alter table public.communication_logs enable row level security;

create policy "authorized staff read communication templates"
on public.communication_templates
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

create policy "owner manager manage communication templates"
on public.communication_templates
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "authorized staff read communication logs"
on public.communication_logs
for select using (
  public.current_staff_role() in ('owner','manager','cashier')
);

grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text) to authenticated;

create index if not exists communication_logs_customer_idx
  on public.communication_logs(customer_id,initiated_at desc);

create index if not exists communication_logs_order_idx
  on public.communication_logs(order_id,initiated_at desc)
  where order_id is not null;

create index if not exists communication_templates_type_idx
  on public.communication_templates(template_type,active);


-- ===== PHASE 3E MIGRATION =====
-- DS Bakery Phase 3E: attendance, staff scheduling and individual permissions

create type public.staff_shift_status as enum ('scheduled','completed','cancelled');
create type public.attendance_status as enum ('on_time','late','completed','absent','excused');

create table if not exists public.attendance_settings (
  id integer primary key default 1 check (id=1),
  late_grace_minutes integer not null default 5 check (late_grace_minutes between 0 and 120),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.attendance_settings(id,late_grace_minutes)
values(1,5)
on conflict (id) do nothing;

create table if not exists public.staff_work_shifts (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.profiles(id),
  shift_date date not null,
  scheduled_start time not null,
  scheduled_end time not null,
  work_station text,
  status public.staff_shift_status not null default 'scheduled',
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (scheduled_end > scheduled_start),
  unique(staff_id,shift_date,scheduled_start)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid not null unique references public.staff_work_shifts(id) on delete restrict,
  staff_id uuid not null references public.profiles(id),
  clock_in_at timestamptz,
  clock_out_at timestamptz,
  status public.attendance_status,
  late_minutes integer not null default 0 check (late_minutes >= 0),
  note text,
  adjusted_by uuid references public.profiles(id),
  adjusted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (clock_out_at is null or clock_in_at is null or clock_out_at >= clock_in_at)
);

create or replace function public.clock_in_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.staff_work_shifts%rowtype;
  v_id uuid;
  v_grace integer;
  v_scheduled timestamptz;
  v_late integer;
begin
  if not public.is_active_staff() then
    raise exception 'Active staff account required';
  end if;

  select * into v_shift
  from public.staff_work_shifts
  where staff_id=auth.uid()
    and shift_date=current_date
    and status='scheduled'
  order by scheduled_start
  limit 1
  for update;

  if not found then
    raise exception 'No scheduled work shift found for today';
  end if;

  if exists(
    select 1 from public.attendance_records
    where shift_id=v_shift.id and clock_in_at is not null
  ) then
    raise exception 'Already clocked in for this shift';
  end if;

  select late_grace_minutes into v_grace
  from public.attendance_settings
  where id=1;

  v_scheduled := current_date + v_shift.scheduled_start;
  v_late := greatest(
    0,
    floor(extract(epoch from (now()-v_scheduled))/60)::integer - coalesce(v_grace,0)
  );

  insert into public.attendance_records(
    shift_id,staff_id,clock_in_at,status,late_minutes
  )
  values(
    v_shift.id,
    auth.uid(),
    now(),
    case when v_late>0 then 'late'::public.attendance_status else 'on_time'::public.attendance_status end,
    v_late
  )
  returning id into v_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_in','attendance_record',v_id,
    jsonb_build_object('shift_id',v_shift.id,'late_minutes',v_late)
  );

  return v_id;
end;
$$;

create or replace function public.clock_out_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_record public.attendance_records%rowtype;
begin
  select ar.* into v_record
  from public.attendance_records ar
  join public.staff_work_shifts sws on sws.id=ar.shift_id
  where ar.staff_id=auth.uid()
    and sws.shift_date=current_date
    and ar.clock_in_at is not null
    and ar.clock_out_at is null
  order by ar.clock_in_at desc
  limit 1
  for update of ar;

  if not found then
    raise exception 'No open attendance record found';
  end if;

  update public.attendance_records
  set
    clock_out_at=now(),
    status='completed',
    updated_at=now()
  where id=v_record.id;

  update public.staff_work_shifts
  set status='completed',updated_at=now()
  where id=v_record.shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'clock_out','attendance_record',v_record.id,
    jsonb_build_object('clock_out_at',now())
  );

  return v_record.id;
end;
$$;

create or replace function public.adjust_attendance_record(
  p_attendance_id uuid,
  p_clock_in timestamptz,
  p_clock_out timestamptz,
  p_status public.attendance_status,
  p_note text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.attendance_records%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may adjust attendance';
  end if;

  if coalesce(trim(p_note),'')='' then
    raise exception 'Adjustment note is required';
  end if;

  select * into v_before
  from public.attendance_records
  where id=p_attendance_id
  for update;

  if not found then raise exception 'Attendance record not found'; end if;

  update public.attendance_records
  set
    clock_in_at=p_clock_in,
    clock_out_at=p_clock_out,
    status=p_status,
    note=p_note,
    adjusted_by=auth.uid(),
    adjusted_at=now(),
    updated_at=now()
  where id=p_attendance_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'adjust_attendance','attendance_record',p_attendance_id,
    jsonb_build_object(
      'clock_in_at',v_before.clock_in_at,
      'clock_out_at',v_before.clock_out_at,
      'status',v_before.status
    ),
    jsonb_build_object(
      'clock_in_at',p_clock_in,
      'clock_out_at',p_clock_out,
      'status',p_status,
      'note',p_note
    )
  );
end;
$$;

create or replace view public.staff_shift_schedule
with (security_invoker=true)
as
select
  sws.id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  sws.status,
  sws.notes
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id;

create or replace view public.attendance_today
with (security_invoker=true)
as
select
  sws.id as shift_id,
  sws.staff_id,
  p.full_name,
  p.role,
  sws.shift_date,
  sws.scheduled_start,
  sws.scheduled_end,
  sws.work_station,
  ar.id as attendance_id,
  ar.clock_in_at,
  ar.clock_out_at,
  ar.status as attendance_status,
  coalesce(ar.late_minutes,0) as late_minutes,
  case
    when ar.id is not null then ar.status::text
    when current_time > sws.scheduled_end then 'absent'
    else 'scheduled'
  end as display_status
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id
left join public.attendance_records ar on ar.shift_id=sws.id
where sws.shift_date=current_date
  and sws.status<>'cancelled';

-- Individual permission system
create table if not exists public.app_permissions (
  permission_key text primary key,
  description text not null,
  critical boolean not null default false
);

insert into public.app_permissions(permission_key,description,critical) values
  ('reports:view','View owner/manager reports',true),
  ('delivery:manage','Manage delivery jobs',false),
  ('communication:send','Open customer communication messages',false),
  ('products:write','Change product details/prices',true),
  ('inventory:write','Receive/adjust stock through allowed workflows',true),
  ('purchases:write','Create/manage purchase orders',true),
  ('attendance:manage','Adjust staff attendance',true),
  ('schedule:manage','Manage staff work schedules',true)
on conflict (permission_key) do nothing;

create table if not exists public.role_permission_defaults (
  role public.staff_role not null,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  primary key(role,permission_key)
);

insert into public.role_permission_defaults(role,permission_key,allowed) values
  ('owner','reports:view',true),
  ('owner','delivery:manage',true),
  ('owner','communication:send',true),
  ('owner','products:write',true),
  ('owner','inventory:write',true),
  ('owner','purchases:write',true),
  ('owner','attendance:manage',true),
  ('owner','schedule:manage',true),

  ('manager','reports:view',true),
  ('manager','delivery:manage',true),
  ('manager','communication:send',true),
  ('manager','products:write',true),
  ('manager','inventory:write',true),
  ('manager','purchases:write',true),
  ('manager','attendance:manage',true),
  ('manager','schedule:manage',true),

  ('cashier','reports:view',false),
  ('cashier','delivery:manage',true),
  ('cashier','communication:send',true),
  ('cashier','products:write',false),
  ('cashier','inventory:write',false),
  ('cashier','purchases:write',false),
  ('cashier','attendance:manage',false),
  ('cashier','schedule:manage',false),

  ('baker','reports:view',false),
  ('baker','delivery:manage',false),
  ('baker','communication:send',false),
  ('baker','products:write',false),
  ('baker','inventory:write',false),
  ('baker','purchases:write',false),
  ('baker','attendance:manage',false),
  ('baker','schedule:manage',false),

  ('storekeeper','reports:view',false),
  ('storekeeper','delivery:manage',false),
  ('storekeeper','communication:send',false),
  ('storekeeper','products:write',false),
  ('storekeeper','inventory:write',true),
  ('storekeeper','purchases:write',true),
  ('storekeeper','attendance:manage',false),
  ('storekeeper','schedule:manage',false)
on conflict (role,permission_key) do update set allowed=excluded.allowed;

create table if not exists public.staff_permission_overrides (
  staff_id uuid not null references public.profiles(id) on delete cascade,
  permission_key text not null references public.app_permissions(permission_key) on delete cascade,
  allowed boolean not null,
  set_by uuid not null references public.profiles(id),
  set_at timestamptz not null default now(),
  reason text,
  primary key(staff_id,permission_key)
);

create or replace function public.effective_staff_permissions(p_staff_id uuid)
returns table(
  permission_key text,
  description text,
  critical boolean,
  role_default boolean,
  individual_override boolean,
  has_override boolean,
  effective_allowed boolean
)
language sql
security definer
set search_path=public
as $$
  select
    ap.permission_key,
    ap.description,
    ap.critical,
    coalesce(rpd.allowed,false) as role_default,
    spo.allowed as individual_override,
    (spo.staff_id is not null) as has_override,
    coalesce(spo.allowed,rpd.allowed,false) as effective_allowed
  from public.profiles p
  cross join public.app_permissions ap
  left join public.role_permission_defaults rpd
    on rpd.role=p.role and rpd.permission_key=ap.permission_key
  left join public.staff_permission_overrides spo
    on spo.staff_id=p.id and spo.permission_key=ap.permission_key
  where p.id=p_staff_id
$$;

create or replace function public.staff_has_permission(p_permission_key text)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((
    select e.effective_allowed
    from public.effective_staff_permissions(auth.uid()) e
    where e.permission_key=p_permission_key
  ),false)
$$;

create or replace function public.set_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text,
  p_allowed boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may set individual permission overrides';
  end if;

  if not exists(select 1 from public.profiles where id=p_staff_id and active=true) then
    raise exception 'Active staff profile not found';
  end if;

  if not exists(select 1 from public.app_permissions where permission_key=p_permission_key) then
    raise exception 'Unknown permission key';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.staff_permission_overrides(
    staff_id,permission_key,allowed,set_by,set_at
  )
  values(
    p_staff_id,p_permission_key,p_allowed,auth.uid(),now()
  )
  on conflict(staff_id,permission_key)
  do update set
    allowed=excluded.allowed,
    set_by=excluded.set_by,
    set_at=excluded.set_at;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_permission_override','profile',p_staff_id,
    case when v_old.staff_id is null then null
         else jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed) end,
    jsonb_build_object('permission_key',p_permission_key,'allowed',p_allowed)
  );
end;
$$;

create or replace function public.clear_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role() <> 'owner' then
    raise exception 'Only owner may clear individual permission overrides';
  end if;

  select * into v_old
  from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  if not found then return; end if;

  delete from public.staff_permission_overrides
  where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'clear_permission_override','profile',p_staff_id,
    jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed),
    jsonb_build_object('permission_key',p_permission_key,'override','cleared')
  );
end;
$$;

alter table public.attendance_settings enable row level security;
alter table public.staff_work_shifts enable row level security;
alter table public.attendance_records enable row level security;
alter table public.app_permissions enable row level security;
alter table public.role_permission_defaults enable row level security;
alter table public.staff_permission_overrides enable row level security;

create policy "staff read attendance settings" on public.attendance_settings
for select using (public.is_active_staff());

create policy "owner manage attendance settings" on public.attendance_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');

create policy "staff read own or management schedules" on public.staff_work_shifts
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management schedules" on public.staff_work_shifts
for all using (
  public.current_staff_role() in ('owner','manager')
)
with check (
  public.current_staff_role() in ('owner','manager')
);

create policy "staff read own or management attendance" on public.attendance_records
for select using (
  staff_id=auth.uid()
  or public.current_staff_role() in ('owner','manager')
);

create policy "management read permissions" on public.app_permissions
for select using (public.current_staff_role() in ('owner','manager'));

create policy "management read role defaults" on public.role_permission_defaults
for select using (public.current_staff_role() in ('owner','manager'));

create policy "owner read permission overrides" on public.staff_permission_overrides
for select using (public.current_staff_role()='owner');

grant execute on function public.clock_in_staff() to authenticated;
grant execute on function public.clock_out_staff() to authenticated;
grant execute on function public.adjust_attendance_record(uuid,timestamptz,timestamptz,public.attendance_status,text) to authenticated;
grant execute on function public.effective_staff_permissions(uuid) to authenticated;
grant execute on function public.staff_has_permission(text) to authenticated;
grant execute on function public.set_staff_permission_override(uuid,text,boolean) to authenticated;
grant execute on function public.clear_staff_permission_override(uuid,text) to authenticated;

create index if not exists staff_work_shifts_date_idx
  on public.staff_work_shifts(shift_date,staff_id,status);

create index if not exists attendance_staff_created_idx
  on public.attendance_records(staff_id,created_at desc);

create index if not exists permission_override_staff_idx
  on public.staff_permission_overrides(staff_id,permission_key);


-- ===== INTEGRATION STAGE / MIGRATION 017 =====
-- DS Bakery v0.18 / Migration 017
-- Live data wiring for products, recipes, inventory, POS, cashier shifts and daily closing.
-- Also fixes cash-tender accounting, sale idempotency, refund cashflow, sale numbers and
-- owner/manager report RPC role checks.

create table if not exists public.business_settings (
  id integer primary key default 1 check (id=1),
  business_timezone text not null default 'Africa/Kampala',
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.business_settings(id,business_timezone)
values(1,'Africa/Kampala')
on conflict (id) do nothing;

create or replace function public.business_current_date()
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (now() at time zone (coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  )))::date
$$;

create or replace function public.business_date(p_timestamp timestamptz)
returns date
language sql
stable
security definer
set search_path=public
as $$
  select (p_timestamp at time zone (coalesce(
    (select business_timezone from public.business_settings where id=1),
    'UTC'
  )))::date
$$;

-- Product/recipe costing views.
create or replace view public.product_cost_summary
with (security_invoker=true)
as
with costs as (
  select
    r.id as recipe_id,
    r.product_id,
    r.name as recipe_name,
    r.yield_qty,
    sum(
      ri.quantity_base_unit *
      case
        when rm.purchase_pack_base_qty > 0
          then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0
      end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id,r.product_id,r.name,r.yield_qty
)
select
  p.id,
  p.name,
  p.sku,
  pc.name as category_name,
  p.selling_price,
  p.status,
  c.recipe_id,
  c.recipe_name,
  c.yield_qty,
  c.batch_cost,
  case when c.yield_qty>0
    then round(c.batch_cost/c.yield_qty,2)
    else null end as unit_food_cost,
  case when c.yield_qty>0
    then round(p.selling_price-(c.batch_cost/c.yield_qty),2)
    else null end as gross_profit,
  case when p.selling_price>0 and c.yield_qty>0
    then round(((p.selling_price-(c.batch_cost/c.yield_qty))/p.selling_price)*100,2)
    else null end as gross_margin_pct
from public.products p
left join public.product_categories pc on pc.id=p.category_id
left join costs c on c.product_id=p.id;

create or replace view public.inventory_live_summary
with (security_invoker=true)
as
select
  rm.id,
  rm.name,
  rm.sku,
  rm.base_unit,
  rm.current_stock_qty,
  rm.low_stock_threshold,
  rm.current_purchase_cost,
  rm.purchase_pack_base_qty,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    rm.current_stock_qty *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as stock_value,
  (rm.current_stock_qty <= rm.low_stock_threshold) as low,
  rm.status
from public.raw_materials rm
where rm.status='active';

create or replace view public.recipe_cost_detail
with (security_invoker=true)
as
with rc as (
  select
    r.id as recipe_id,
    sum(
      ri.quantity_base_unit *
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end
    )::numeric(14,2) as batch_cost
  from public.recipes r
  join public.recipe_items ri on ri.recipe_id=r.id
  join public.raw_materials rm on rm.id=ri.raw_material_id
  where r.active=true
  group by r.id
)
select
  r.id as recipe_id,
  r.product_id,
  p.name as product_name,
  p.selling_price,
  r.name as recipe_name,
  r.yield_qty,
  ri.raw_material_id,
  rm.name as ingredient_name,
  rm.base_unit,
  ri.quantity_base_unit,
  case when rm.purchase_pack_base_qty>0
    then rm.current_purchase_cost/rm.purchase_pack_base_qty
    else 0 end::numeric(14,6) as unit_cost,
  (
    ri.quantity_base_unit *
    case when rm.purchase_pack_base_qty>0
      then rm.current_purchase_cost/rm.purchase_pack_base_qty
      else 0 end
  )::numeric(14,2) as line_cost,
  rc.batch_cost,
  round(rc.batch_cost/r.yield_qty,2)::numeric(14,2) as unit_food_cost,
  round(p.selling_price-(rc.batch_cost/r.yield_qty),2)::numeric(14,2) as gross_profit,
  case when p.selling_price>0
    then round(((p.selling_price-(rc.batch_cost/r.yield_qty))/p.selling_price)*100,2)
    else 0 end::numeric(8,2) as margin_pct
from public.recipes r
join public.products p on p.id=r.product_id
join public.recipe_items ri on ri.recipe_id=r.id
join public.raw_materials rm on rm.id=ri.raw_material_id
join rc on rc.recipe_id=r.id
where r.active=true;

-- Audited product save.
create or replace function public.save_product(
  p_product_id uuid,
  p_name text,
  p_category_id uuid,
  p_selling_price numeric,
  p_description text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := coalesce(p_product_id,gen_random_uuid());
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save products';
  end if;

  if coalesce(trim(p_name),'')='' then raise exception 'Product name is required'; end if;
  if p_selling_price<0 then raise exception 'Selling price cannot be negative'; end if;

  select to_jsonb(p) into v_before from public.products p where p.id=p_product_id;

  insert into public.products(
    id,category_id,name,description,selling_price,status,created_by
  )
  values(
    v_id,p_category_id,trim(p_name),p_description,p_selling_price,'active',auth.uid()
  )
  on conflict(id) do update set
    category_id=excluded.category_id,
    name=excluded.name,
    description=excluded.description,
    selling_price=excluded.selling_price,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_product_id is null then 'create_product' else 'update_product' end,
    'product',
    v_id,
    v_before,
    (select to_jsonb(p) from public.products p where p.id=v_id)
  );

  return v_id;
end;
$$;

-- Atomic active recipe replacement.
create or replace function public.save_active_recipe(
  p_product_id uuid,
  p_name text,
  p_yield_qty numeric,
  p_items jsonb
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_recipe_id uuid := gen_random_uuid();
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may save recipes';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Recipe name is required'; end if;
  if p_yield_qty<=0 then raise exception 'Recipe yield must be greater than zero'; end if;
  if jsonb_array_length(p_items)=0 then raise exception 'Recipe needs at least one ingredient'; end if;

  -- Validate all ingredients before changing the active recipe.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id := (v_item->>'raw_material_id')::uuid;
    v_qty := (v_item->>'quantity_base_unit')::numeric;

    if v_qty<=0 then raise exception 'Ingredient quantity must be greater than zero'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid or inactive raw material';
    end if;
  end loop;

  update public.recipes
  set active=false,updated_at=now()
  where product_id=p_product_id and active=true;

  insert into public.recipes(id,product_id,name,yield_qty,active,created_by)
  values(v_recipe_id,p_product_id,trim(p_name),p_yield_qty,true,auth.uid());

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.recipe_items(recipe_id,raw_material_id,quantity_base_unit)
    values(
      v_recipe_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'quantity_base_unit')::numeric
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'replace_active_recipe','recipe',v_recipe_id,
    jsonb_build_object('product_id',p_product_id,'yield_qty',p_yield_qty,'items',p_items)
  );

  return v_recipe_id;
end;
$$;

-- Physical stock counts post a movement; they never directly overwrite stock.
create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid := gen_random_uuid();
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta := p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost := case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason
    )
  );

  return v_tx_id;
end;
$$;

-- Cashier shift RPCs. Cashiers may open/close only their own shift.
create or replace function public.start_cashier_shift(p_opening_float numeric default 0)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to start cashier shift';
  end if;
  if p_opening_float<0 then raise exception 'Opening float cannot be negative'; end if;

  if exists(
    select 1 from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
  ) then
    raise exception 'You already have an open cashier shift';
  end if;

  insert into public.cashier_shifts(
    id,cashier_id,opened_by,opening_float,status
  )
  values(v_id,auth.uid(),auth.uid(),p_opening_float,'open');

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'start_cashier_shift','cashier_shift',v_id,
    jsonb_build_object('opening_float',p_opening_float)
  );

  return v_id;
end;
$$;

create or replace function public.close_cashier_shift(
  p_shift_id uuid,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.cashier_shifts%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_shift
  from public.cashier_shifts
  where id=p_shift_id
  for update;

  if not found then raise exception 'Cashier shift not found'; end if;
  if v_shift.status='closed' then raise exception 'Cashier shift already closed'; end if;

  if v_role not in ('owner','manager')
     and not (v_role='cashier' and v_shift.cashier_id=auth.uid()) then
    raise exception 'Not authorized to close this shift';
  end if;

  update public.cashier_shifts
  set status='closed',closed_at=now(),closed_by=auth.uid(),closing_note=p_note
  where id=p_shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'close_cashier_shift','cashier_shift',p_shift_id,
    jsonb_build_object('note',p_note)
  );
end;
$$;

-- Safer sequential sale number.
create sequence if not exists public.sale_no_seq;

create or replace function public.next_sale_no()
returns text
language sql
volatile
as $$
  select 'DS-' || to_char(
    now() at time zone (coalesce(
      (select business_timezone from public.business_settings where id=1),
      'UTC'
    )),
    'YYYYMMDD'
  ) || '-' || lpad(nextval('public.sale_no_seq')::text,7,'0')
$$;

alter table public.sales
  add column if not exists client_request_id uuid;

create unique index if not exists sales_client_request_unique
  on public.sales(client_request_id)
  where client_request_id is not null;

create unique index if not exists payments_mobile_reference_unique
  on public.payments(method,reference)
  where reference is not null
    and method in ('mtn_momo','airtel_money')
    and status='completed';

-- Replace old complete_sale signature with idempotent, shift-aware version.
drop function if exists public.complete_sale(jsonb,numeric,jsonb,text,boolean);

create or replace function public.complete_sale(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_sale_no text;
  v_shift_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_payment jsonb;
  v_price numeric(14,2);
  v_qty numeric(12,3);
  v_line numeric(14,2);
  v_recipe_cost numeric(14,6);
  v_paid numeric(14,2) := 0;
  v_method public.payment_method;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create sales';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.sales
    where client_request_id=p_client_request_id;

    if v_existing is not null then return v_existing; end if;
  end if;

  select id into v_shift_id
  from public.cashier_shifts
  where cashier_id=auth.uid() and status='open'
  order by opened_at desc
  limit 1;

  if v_shift_id is null then
    raise exception 'Open cashier shift required';
  end if;

  if jsonb_array_length(p_items)=0 then
    raise exception 'Sale must contain at least one item';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select selling_price into v_price
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if v_price is null then raise exception 'Invalid or inactive product'; end if;

    v_qty := (v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Quantity must be greater than zero'; end if;

    v_subtotal := v_subtotal + (v_price*v_qty);
  end loop;

  p_discount := greatest(coalesce(p_discount,0),0);
  if p_discount>v_subtotal then p_discount:=v_subtotal; end if;
  v_total := v_subtotal-p_discount;

  if not p_hold then
    if jsonb_array_length(p_payments)=0 then
      raise exception 'Payment is required';
    end if;

    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      v_method := (v_payment->>'method')::public.payment_method;

      if v_method in ('mtn_momo','airtel_money')
         and coalesce(trim(v_payment->>'reference'),'')='' then
        raise exception 'Mobile Money reference is required';
      end if;

      if (v_payment->>'amount')::numeric<=0 then
        raise exception 'Payment amount must be greater than zero';
      end if;

      v_paid := v_paid + (v_payment->>'amount')::numeric;
    end loop;

    -- Payment ledger records actual business receipt, not tender/change.
    if round(v_paid,2) <> round(v_total,2) then
      raise exception 'Payment ledger amount must equal sale total';
    end if;
  end if;

  v_sale_no:=public.next_sale_no();

  insert into public.sales(
    id,sale_no,status,held,subtotal,discount,total,cashier_id,shift_id,notes,client_request_id
  )
  values(
    v_sale_id,v_sale_no,
    case when p_hold then 'held' else 'completed' end,
    p_hold,v_subtotal,p_discount,v_total,auth.uid(),v_shift_id,p_notes,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select
      p.selling_price,
      coalesce((
        select sum(
          ri.quantity_base_unit *
          case when rm.purchase_pack_base_qty>0
            then rm.current_purchase_cost/rm.purchase_pack_base_qty
            else 0 end
        )/r.yield_qty
        from public.recipes r
        join public.recipe_items ri on ri.recipe_id=r.id
        join public.raw_materials rm on rm.id=ri.raw_material_id
        where r.product_id=p.id and r.active=true
        group by r.id,r.yield_qty
      ),0)
    into v_price,v_recipe_cost
    from public.products p
    where p.id=(v_item->>'product_id')::uuid;

    v_qty := (v_item->>'quantity')::numeric;
    v_line := v_price*v_qty;

    insert into public.sale_items(
      sale_id,product_id,quantity,unit_price,line_total,
      unit_cost_snapshot,gross_profit_snapshot
    )
    values(
      v_sale_id,(v_item->>'product_id')::uuid,v_qty,v_price,v_line,
      v_recipe_cost,(v_price-v_recipe_cost)*v_qty
    );
  end loop;

  if not p_hold then
    for v_payment in select * from jsonb_array_elements(p_payments)
    loop
      insert into public.payments(
        sale_id,method,amount,reference,status,created_by
      )
      values(
        v_sale_id,
        (v_payment->>'method')::public.payment_method,
        (v_payment->>'amount')::numeric,
        nullif(trim(v_payment->>'reference'),''),
        'completed',
        auth.uid()
      );
    end loop;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),
    case when p_hold then 'hold_sale' else 'complete_sale' end,
    'sale',
    v_sale_id,
    jsonb_build_object(
      'sale_no',v_sale_no,
      'subtotal',v_subtotal,
      'discount',p_discount,
      'total',v_total,
      'shift_id',v_shift_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_sale_id;
end;
$$;

-- Correct refund cashflow: no negative payment row, preserve original payment method.
create table if not exists public.sale_refunds (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount>0),
  reason text not null,
  approved_by uuid not null references public.profiles(id),
  refunded_at timestamptz not null default now()
);

alter table public.sale_refunds enable row level security;

drop policy if exists "sales staff read sale refunds" on public.sale_refunds;
create policy "sales staff read sale refunds" on public.sale_refunds
for select using (public.current_staff_role() in ('owner','manager','cashier'));

create index if not exists sale_refunds_sale_idx on public.sale_refunds(sale_id,refunded_at desc);

create or replace function public.approve_sale_action(
  p_sale_id uuid,
  p_action text,
  p_reason text,
  p_approval_pin text,
  p_refund_amount numeric default null
)
returns void
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_approver uuid;
  v_sale public.sales%rowtype;
  v_refund numeric(14,2);
  v_method public.payment_method;
  v_method_count integer;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized';
  end if;

  if p_action not in ('cancel','refund') then raise exception 'Unsupported action'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  v_approver:=public.verify_approver_pin(p_approval_pin);

  select * into v_sale
  from public.sales
  where id=p_sale_id
  for update;

  if not found then raise exception 'Sale not found'; end if;

  if p_action='cancel' then
    if v_sale.status<>'held' then
      raise exception 'Paid/completed sales must be refunded rather than cancelled';
    end if;

    update public.sales
    set status='cancelled',voided_at=now(),voided_by=v_approver,void_reason=p_reason
    where id=p_sale_id;
  else
    if v_sale.status not in ('completed','partially_refunded') then
      raise exception 'Only completed sales may be refunded';
    end if;

    v_refund:=coalesce(p_refund_amount,v_sale.total-v_sale.refund_total);
    if v_refund<=0 or v_refund>(v_sale.total-v_sale.refund_total) then
      raise exception 'Invalid refund amount';
    end if;

    select count(distinct method)
    into v_method_count
    from public.payments
    where sale_id=p_sale_id and status='completed';

    if v_method_count<>1 then
      raise exception 'Mixed-payment refund needs explicit allocation and is not enabled yet';
    end if;

    select method
    into v_method
    from public.payments
    where sale_id=p_sale_id and status='completed'
    limit 1;

    update public.sales
    set
      refund_total=refund_total+v_refund,
      status=case
        when refund_total+v_refund>=total then 'refunded'
        else 'partially_refunded'
      end
    where id=p_sale_id;

    insert into public.sale_refunds(
      sale_id,method,amount,reason,approved_by
    )
    values(
      p_sale_id,v_method,v_refund,p_reason,v_approver
    );
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    v_approver,
    p_action || '_sale',
    'sale',
    p_sale_id,
    jsonb_build_object('status',v_sale.status,'refund_total',v_sale.refund_total),
    jsonb_build_object('reason',p_reason,'refund_amount',p_refund_amount,'approved_by',v_approver)
  );
end;
$$;


-- Reporting view uses a proportional allocation for partial refunds until item-level
-- refund allocation is implemented. Fully refunded sales contribute zero.
create or replace view public.sale_profit_lines as
select
  si.id,
  si.sale_id,
  si.product_id,
  p.name as product_name,
  (si.quantity * f.net_factor)::numeric(12,3) as quantity,
  (si.line_total * f.net_factor)::numeric(14,2) as sales_amount,
  ((coalesce(si.unit_cost_snapshot,0) * si.quantity) * f.net_factor) as cogs_amount,
  (
    coalesce(
      si.gross_profit_snapshot,
      si.line_total-(coalesce(si.unit_cost_snapshot,0)*si.quantity)
    ) * f.net_factor
  ) as gross_profit_amount,
  s.created_at,
  s.status
from public.sale_items si
join public.sales s on s.id=si.sale_id
join public.products p on p.id=si.product_id
cross join lateral (
  select case
    when s.total<=0 then 0::numeric
    else greatest(s.total-coalesce(s.refund_total,0),0)/s.total
  end as net_factor
) f
where s.status in ('completed','partially_refunded','refunded');

-- Cashier shift summary.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,
  cs.cashier_id,
  p.full_name as cashier_name,
  cs.opened_at,
  cs.opening_float,
  cs.status,
  cs.closed_at,
  count(distinct s.id)::bigint as transaction_count,
  coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as gross_sales,
  (
    coalesce(sum(pay.cash_amount),0) -
    coalesce(sum(ref.cash_refund),0)
  )::numeric(14,2) as cash_sales
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id
left join public.sales s
  on s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
left join lateral (
  select coalesce(sum(py.amount),0) as cash_amount
  from public.payments py
  where py.sale_id=s.id and py.status='completed' and py.method='cash'
) pay on true
left join lateral (
  select coalesce(sum(sr.amount),0) as cash_refund
  from public.sale_refunds sr
  where sr.sale_id=s.id and sr.method='cash'
) ref on true
group by cs.id,cs.cashier_id,p.full_name,cs.opened_at,cs.opening_float,cs.status,cs.closed_at;

-- Non-mutating closing preview.
create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_cash_receipts numeric(14,2);
  v_mtn_receipts numeric(14,2);
  v_airtel_receipts numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_total_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when p.method='cash' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0),
    coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)
  into v_cash_receipts,v_mtn_receipts,v_airtel_receipts
  from public.payments p
  where p.status='completed'
    and public.business_date(p.created_at)=p_business_date;

  select
    coalesce(sum(case when sr.method='cash' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='mtn_momo' then sr.amount else 0 end),0),
    coalesce(sum(case when sr.method='airtel_money' then sr.amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds sr
  where public.business_date(sr.refunded_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(
      case when status in ('completed','partially_refunded','refunded')
        then total-coalesce(refund_total,0) else 0 end
    ),0)
  into v_tx_count,v_total_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_cash_receipts-v_cash_refunds,
    'mtn_momo_sales',v_mtn_receipts-v_mtn_refunds,
    'airtel_money_sales',v_airtel_receipts-v_airtel_refunds,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_cash_receipts-v_cash_refunds)+v_cash_in-v_cash_out-v_cash_exp,
    'transaction_count',v_tx_count,
    'total_sales',v_total_sales
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- Fix two financial SECURITY DEFINER functions that previously lacked internal role checks.
create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(
  period_start timestamptz,
  sales numeric,
  cash_sales numeric,
  mtn_momo_sales numeric,
  airtel_money_sales numeric,
  gross_profit numeric,
  expenses numeric,
  estimated_operating_profit numeric,
  transaction_count bigint,
  average_sale numeric
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  return query
  with bounds as (
    select public.period_start(p_period) as start_at
  ),
  sales_summary as (
    select
      coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) as sales,
      count(*)::bigint as transaction_count
    from public.sales s,bounds b
    where s.created_at>=b.start_at
      and s.status in ('completed','partially_refunded','refunded')
  ),
  payment_summary as (
    select
      (
        coalesce(sum(case when p.method='cash' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='cash' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as cash_sales,
      (
        coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='mtn_momo' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as mtn_momo_sales,
      (
        coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0) -
        coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='airtel_money' and sr.refunded_at>=b.start_at),0)
      )::numeric(14,2) as airtel_money_sales
    from public.payments p,bounds b
    where p.created_at>=b.start_at and p.status='completed'
  ),
  profit_summary as (
    select coalesce(sum(gross_profit_amount),0)::numeric(14,2) as gross_profit
    from public.sale_profit_lines spl,bounds b
    where spl.created_at>=b.start_at
  ),
  expense_summary as (
    select coalesce(sum(amount),0)::numeric(14,2) as expenses
    from public.expenses e,bounds b
    where e.created_at>=b.start_at
  )
  select
    b.start_at,
    ss.sales,
    ps.cash_sales,
    ps.mtn_momo_sales,
    ps.airtel_money_sales,
    prs.gross_profit,
    es.expenses,
    (prs.gross_profit-es.expenses)::numeric(14,2),
    ss.transaction_count,
    case when ss.transaction_count>0
      then round(ss.sales/ss.transaction_count,2)
      else 0 end::numeric(14,2)
  from bounds b
  cross join sales_summary ss
  cross join payment_summary ps
  cross join profit_summary prs
  cross join expense_summary es;
end;
$$;

create or replace function public.sales_trend(p_period text default 'week')
returns table(
  bucket timestamptz,
  sales numeric,
  transactions bigint
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_grain text;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Not authorized';
  end if;

  if p_period='day' then
    v_start:=date_trunc('day',now());
    v_grain:='hour';
  elsif p_period='week' then
    v_start:=date_trunc('week',now());
    v_grain:='day';
  elsif p_period='month' then
    v_start:=date_trunc('month',now());
    v_grain:='day';
  else
    raise exception 'Unsupported period';
  end if;

  return query execute format(
    'select date_trunc(%L,created_at) as bucket,
            coalesce(sum(total-coalesce(refund_total,0)),0)::numeric(14,2) as sales,
            count(*)::bigint
     from public.sales
     where created_at >= $1
       and status in (''completed'',''partially_refunded'',''refunded'')
     group by 1
     order by 1',
    v_grain
  ) using v_start;
end;
$$;

-- Tighten sensitive RPC execution. SECURITY DEFINER functions still perform their own role checks.
revoke all on function public.save_product(uuid,text,uuid,numeric,text) from public;
revoke all on function public.save_active_recipe(uuid,text,numeric,jsonb) from public;
revoke all on function public.record_stock_count(uuid,numeric,text) from public;
revoke all on function public.start_cashier_shift(numeric) from public;
revoke all on function public.close_cashier_shift(uuid,text) from public;
revoke all on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) from public;
revoke all on function public.approve_sale_action(uuid,text,text,text,numeric) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;
revoke all on function public.close_business_day(date,numeric,text) from public;
revoke all on function public.owner_dashboard_summary(text) from public;
revoke all on function public.sales_trend(text) from public;

grant execute on function public.business_current_date() to authenticated;
grant execute on function public.save_product(uuid,text,uuid,numeric,text) to authenticated;
grant execute on function public.save_active_recipe(uuid,text,numeric,jsonb) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text) to authenticated;
grant execute on function public.start_cashier_shift(numeric) to authenticated;
grant execute on function public.close_cashier_shift(uuid,text) to authenticated;
grant execute on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) to authenticated;
grant execute on function public.approve_sale_action(uuid,text,text,text,numeric) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;
grant execute on function public.close_business_day(date,numeric,text) to authenticated;
grant execute on function public.owner_dashboard_summary(text) to authenticated;
grant execute on function public.sales_trend(text) to authenticated;

-- Business settings are management-only.
alter table public.business_settings enable row level security;

drop policy if exists "management read business settings" on public.business_settings;
create policy "management read business settings" on public.business_settings
for select using (public.current_staff_role() in ('owner','manager'));

drop policy if exists "owner manage business settings" on public.business_settings;
create policy "owner manage business settings" on public.business_settings
for all using (public.current_staff_role()='owner')
with check (public.current_staff_role()='owner');


-- ===== INTEGRATION STAGE / MIGRATION 018 =====
-- DS Bakery v0.19 / Migration 018
-- Operations live wiring: production, baker tasks, waste, purchasing/payables,
-- expenses, cash movements, plus closing cashflow completeness.

-- =====================================================================
-- PRODUCTION + BAKER TASKS
-- =====================================================================

alter table public.production_plan_items
  add column if not exists client_request_id uuid;

create unique index if not exists production_plan_client_request_unique
  on public.production_plan_items(client_request_id)
  where client_request_id is not null;

alter table public.production_runs
  add column if not exists recipe_id uuid references public.recipes(id),
  add column if not exists client_request_id uuid;

create unique index if not exists production_runs_client_request_unique
  on public.production_runs(client_request_id)
  where client_request_id is not null;

create type public.baker_task_status as enum ('todo','complete','cancelled');

create table if not exists public.baker_tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  assigned_baker_id uuid not null references public.profiles(id),
  product_id uuid references public.products(id),
  plan_item_id uuid references public.production_plan_items(id) on delete set null,
  due_at timestamptz,
  status public.baker_task_status not null default 'todo',
  notes text,
  created_by uuid not null references public.profiles(id),
  completed_by uuid references public.profiles(id),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.create_production_plan_item(
  p_business_date date,
  p_product_id uuid,
  p_assigned_baker_id uuid,
  p_shift public.production_shift,
  p_planned_qty numeric,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid := gen_random_uuid();
  v_existing uuid;
  v_date date := coalesce(p_business_date,public.business_current_date());
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create production plans';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_plan_items
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_planned_qty<=0 then
    raise exception 'Planned quantity must be greater than zero';
  end if;

  if not exists(select 1 from public.products where id=p_product_id and status='active') then
    raise exception 'Active product not found';
  end if;

  if p_assigned_baker_id is not null and not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not an active baker';
  end if;

  insert into public.production_plan_items(
    id,business_date,product_id,assigned_baker_id,shift,
    planned_qty,produced_qty,status,notes,created_by,client_request_id
  )
  values(
    v_id,v_date,p_product_id,p_assigned_baker_id,p_shift,
    p_planned_qty,0,'planned',p_notes,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_production_plan','production_plan_item',v_id,
    jsonb_build_object(
      'business_date',v_date,
      'product_id',p_product_id,
      'assigned_baker_id',p_assigned_baker_id,
      'shift',p_shift,
      'planned_qty',p_planned_qty,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.confirm_production_run(uuid,numeric);

create or replace function public.confirm_production_run(
  p_plan_item_id uuid,
  p_quantity_produced numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_plan public.production_plan_items%rowtype;
  v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);
  v_run_id uuid := gen_random_uuid();
  v_existing uuid;
  v_item record;
  v_required numeric(18,6);
  v_unit_cost numeric(14,6);
  v_tx_id uuid;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','baker') then
    raise exception 'Not authorized to confirm production';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.production_runs
    where client_request_id=p_client_request_id;

    if v_existing is not null then
      return v_existing;
    end if;
  end if;

  if p_quantity_produced<=0 then
    raise exception 'Quantity produced must be greater than zero';
  end if;

  select * into v_plan
  from public.production_plan_items
  where id=p_plan_item_id
  for update;

  if not found then raise exception 'Production plan item not found'; end if;
  if v_plan.status in ('complete','cancelled') then
    raise exception 'Production plan item is not open';
  end if;

  if v_role='baker' and v_plan.assigned_baker_id is distinct from auth.uid() then
    raise exception 'Baker may confirm only assigned production items';
  end if;

  v_remaining:=v_plan.planned_qty-v_plan.produced_qty;
  if p_quantity_produced>v_remaining then
    raise exception 'Cannot confirm more than remaining planned quantity';
  end if;

  select * into v_recipe
  from public.recipes
  where product_id=v_plan.product_id and active=true;

  if not found then raise exception 'Product has no active recipe'; end if;

  -- Lock and validate every ingredient before any movement is inserted.
  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      rm.current_stock_qty,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
    for update of rm
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;

    if v_item.current_stock_qty<v_required then
      raise exception 'Insufficient stock for raw material %',v_item.raw_material_id;
    end if;
  end loop;

  insert into public.production_runs(
    id,plan_item_id,recipe_id,quantity_produced,confirmed_by,client_request_id
  )
  values(
    v_run_id,p_plan_item_id,v_recipe.id,p_quantity_produced,auth.uid(),p_client_request_id
  );

  for v_item in
    select
      ri.raw_material_id,
      ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty>0
        then rm.current_purchase_cost/rm.purchase_pack_base_qty
        else 0 end as current_unit_cost
    from public.recipe_items ri
    join public.raw_materials rm on rm.id=ri.raw_material_id
    where ri.recipe_id=v_recipe.id
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;
    v_unit_cost:=v_item.current_unit_cost;

    insert into public.inventory_transactions(
      raw_material_id,tx_type,quantity_delta,unit_cost,
      reference_type,reference_id,created_by,notes
    )
    values(
      v_item.raw_material_id,'usage',-v_required,v_unit_cost,
      'production_run',v_run_id,auth.uid(),
      'Recipe consumption for confirmed production'
    )
    returning id into v_tx_id;

    insert into public.production_consumptions(
      production_run_id,raw_material_id,quantity_used_base,
      unit_cost_snapshot,inventory_transaction_id
    )
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;

  update public.production_plan_items
  set
    produced_qty=produced_qty+p_quantity_produced,
    status=case
      when produced_qty+p_quantity_produced>=planned_qty then 'complete'::public.production_status
      else 'in_progress'::public.production_status
    end,
    updated_at=now()
  where id=p_plan_item_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'confirm_production','production_run',v_run_id,
    jsonb_build_object(
      'plan_item_id',p_plan_item_id,
      'recipe_id',v_recipe.id,
      'quantity_produced',p_quantity_produced,
      'product_id',v_plan.product_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_run_id;
end;
$$;

create or replace view public.production_progress_today
with (security_invoker=true)
as
select
  ppi.id,
  ppi.business_date,
  ppi.product_id,
  p.name as product_name,
  ppi.planned_qty,
  ppi.produced_qty,
  (ppi.planned_qty-ppi.produced_qty) as remaining_qty,
  case when ppi.planned_qty>0
    then round((ppi.produced_qty/ppi.planned_qty)*100,1)
    else 0 end as completion_pct,
  ppi.shift,
  ppi.status,
  ppi.assigned_baker_id,
  pr.full_name as baker_name
from public.production_plan_items ppi
join public.products p on p.id=ppi.product_id
left join public.profiles pr on pr.id=ppi.assigned_baker_id
where ppi.business_date=public.business_current_date();

create or replace view public.production_run_summary
with (security_invoker=true)
as
select
  pr.id,
  pr.plan_item_id,
  pr.recipe_id,
  ppi.product_id,
  p.name as product_name,
  pr.quantity_produced,
  pr.confirmed_by,
  prof.full_name as confirmed_by_name,
  pr.confirmed_at
from public.production_runs pr
join public.production_plan_items ppi on ppi.id=pr.plan_item_id
join public.products p on p.id=ppi.product_id
left join public.profiles prof on prof.id=pr.confirmed_by;

create or replace function public.create_baker_task(
  p_title text,
  p_assigned_baker_id uuid,
  p_product_id uuid default null,
  p_plan_item_id uuid default null,
  p_due_at timestamptz default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may create baker tasks';
  end if;

  if coalesce(trim(p_title),'')='' then raise exception 'Task title is required'; end if;

  if not exists(
    select 1 from public.profiles
    where id=p_assigned_baker_id and active=true and role='baker'
  ) then
    raise exception 'Assigned baker is not active';
  end if;

  insert into public.baker_tasks(
    id,title,assigned_baker_id,product_id,plan_item_id,due_at,notes,created_by
  )
  values(
    v_id,trim(p_title),p_assigned_baker_id,p_product_id,p_plan_item_id,p_due_at,p_notes,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_baker_task','baker_task',v_id,
    jsonb_build_object('title',p_title,'assigned_baker_id',p_assigned_baker_id,'due_at',p_due_at)
  );

  return v_id;
end;
$$;

create or replace function public.set_baker_task_status(
  p_task_id uuid,
  p_status public.baker_task_status
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_task public.baker_tasks%rowtype;
  v_role public.staff_role;
begin
  v_role:=public.current_staff_role();

  select * into v_task
  from public.baker_tasks
  where id=p_task_id
  for update;

  if not found then raise exception 'Baker task not found'; end if;

  if v_role in ('owner','manager') then
    null;
  elsif v_role='baker' and v_task.assigned_baker_id=auth.uid() and p_status in ('todo','complete') then
    null;
  else
    raise exception 'Not authorized to update this task';
  end if;

  update public.baker_tasks
  set
    status=p_status,
    completed_by=case when p_status='complete' then auth.uid() else null end,
    completed_at=case when p_status='complete' then now() else null end,
    updated_at=now()
  where id=p_task_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'set_baker_task_status','baker_task',p_task_id,
    jsonb_build_object('status',v_task.status),
    jsonb_build_object('status',p_status)
  );
end;
$$;

create or replace view public.baker_task_summary
with (security_invoker=true)
as
select
  bt.id,
  bt.title,
  bt.assigned_baker_id,
  bp.full_name as baker_name,
  bt.product_id,
  p.name as product_name,
  bt.plan_item_id,
  bt.due_at,
  bt.status,
  bt.notes,
  bt.completed_at,
  bt.created_at
from public.baker_tasks bt
left join public.profiles bp on bp.id=bt.assigned_baker_id
left join public.products p on p.id=bt.product_id;

alter table public.baker_tasks enable row level security;

create policy "staff read relevant baker tasks" on public.baker_tasks
for select using (
  public.current_staff_role() in ('owner','manager')
  or assigned_baker_id=auth.uid()
);

drop policy if exists "production staff read consumption" on public.production_consumptions;
create policy "production staff read consumption" on public.production_consumptions
for select using (
  public.current_staff_role() in ('owner','manager','storekeeper')
  or (
    public.current_staff_role()='baker'
    and exists(
      select 1
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=production_consumptions.production_run_id
        and (pr.confirmed_by=auth.uid() or ppi.assigned_baker_id=auth.uid())
    )
  )
);

-- =====================================================================
-- WASTE + PRODUCTION CONTROL
-- =====================================================================

alter table public.waste_events
  add column if not exists client_request_id uuid;

create unique index if not exists waste_events_client_request_unique
  on public.waste_events(client_request_id)
  where client_request_id is not null;

drop policy if exists "management read waste settings" on public.waste_settings;
create policy "relevant staff read waste settings" on public.waste_settings
for select using (public.current_staff_role() in ('owner','manager','baker','storekeeper'));

drop function if exists public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid);

create or replace function public.record_waste_event(
  p_waste_type public.waste_type,
  p_quantity numeric,
  p_reason text,
  p_product_id uuid default null,
  p_raw_material_id uuid default null,
  p_production_run_id uuid default null,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_role public.staff_role;
  v_unit_cost numeric(14,6);
  v_total numeric(14,2);
  v_threshold numeric(14,2);
  v_status public.waste_approval_status;
  v_waste_id uuid:=gen_random_uuid();
  v_run_product uuid;
  v_run_qty numeric;
  v_existing_waste numeric;
  v_existing uuid;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing
    from public.waste_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','baker','storekeeper') then
    raise exception 'Not authorized to record waste';
  end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;

  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then
      raise exception 'Finished-product waste requires product only';
    end if;

    if p_production_run_id is not null then
      select ppi.product_id,pr.quantity_produced
      into v_run_product,v_run_qty
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=p_production_run_id;

      if v_run_product is null or v_run_product<>p_product_id then
        raise exception 'Production run does not match product';
      end if;

      select coalesce(sum(quantity),0)
      into v_existing_waste
      from public.waste_events
      where production_run_id=p_production_run_id
        and waste_type='finished_product'
        and approval_status<>'rejected';

      if v_existing_waste+p_quantity>v_run_qty then
        raise exception 'Waste quantity exceeds remaining output of linked production run';
      end if;

      v_unit_cost:=public.production_run_unit_cost(p_production_run_id);
    else
      v_unit_cost:=public.current_product_unit_cost(p_product_id);
    end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then
      raise exception 'Raw-material waste requires raw material only';
    end if;

    select case when purchase_pack_base_qty>0
      then current_purchase_cost/purchase_pack_base_qty else 0 end
    into v_unit_cost
    from public.raw_materials
    where id=p_raw_material_id;

    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;

  v_total:=round((p_quantity*v_unit_cost)::numeric,2);

  select approval_threshold into v_threshold
  from public.waste_settings
  where id=1;

  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then
    v_status:='approved';
  else
    v_status:='pending';
  end if;

  insert into public.waste_events(
    id,waste_type,product_id,raw_material_id,production_run_id,
    quantity,reason,notes,unit_cost_snapshot,total_cost,
    approval_status,recorded_by,approved_by,approved_at,client_request_id
  )
  values(
    v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,
    p_quantity,trim(p_reason),p_notes,v_unit_cost,v_total,
    v_status,auth.uid(),
    case when v_status='approved' then auth.uid() end,
    case when v_status='approved' then now() end,
    p_client_request_id
  );

  if v_status='approved' and p_waste_type='raw_material' then
    perform public.apply_approved_raw_waste(v_waste_id);
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_waste','waste_event',v_waste_id,
    jsonb_build_object(
      'waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,
      'total_cost',v_total,'approval_status',v_status,'production_run_id',p_production_run_id,
      'client_request_id',p_client_request_id
    )
  );

  return v_waste_id;
end;
$$;

create or replace view public.waste_event_summary
with (security_invoker=true)
as
select
  we.id,
  we.waste_type,
  we.product_id,
  we.raw_material_id,
  we.production_run_id,
  coalesce(p.name,rm.name) as item_name,
  case when we.waste_type='finished_product' then 'pcs' else rm.base_unit end as base_unit,
  we.quantity,
  we.reason,
  we.notes,
  we.unit_cost_snapshot,
  we.total_cost,
  we.approval_status,
  we.recorded_by,
  prof.full_name as recorded_by_name,
  we.recorded_at,
  we.approved_by,
  we.approved_at,
  we.decision_note
from public.waste_events we
left join public.products p on p.id=we.product_id
left join public.raw_materials rm on rm.id=we.raw_material_id
left join public.profiles prof on prof.id=we.recorded_by;

create or replace view public.production_control_today
with (security_invoker=true)
as
with plan as (
  select product_id,sum(planned_qty) planned_qty,sum(produced_qty) produced_qty
  from public.production_plan_items
  where business_date=public.business_current_date()
    and status<>'cancelled'
  group by product_id
),
product_waste as (
  select
    product_id,
    coalesce(sum(quantity),0) approved_waste_qty,
    coalesce(sum(total_cost),0) approved_waste_cost
  from public.waste_events
  where waste_type='finished_product'
    and approval_status='approved'
    and public.business_date(recorded_at)=public.business_current_date()
  group by product_id
)
select
  p.id product_id,
  p.name product_name,
  pl.planned_qty,
  pl.produced_qty,
  coalesce(pw.approved_waste_qty,0) approved_waste_qty,
  greatest(pl.produced_qty-coalesce(pw.approved_waste_qty,0),0) estimated_sellable_output,
  (pl.produced_qty-pl.planned_qty) production_variance,
  case when pl.produced_qty>0
    then round((coalesce(pw.approved_waste_qty,0)/pl.produced_qty)*100,2)
    else 0 end waste_rate_pct,
  coalesce(pw.approved_waste_cost,0)::numeric(14,2) approved_waste_cost
from plan pl
join public.products p on p.id=pl.product_id
left join product_waste pw on pw.product_id=pl.product_id;

-- =====================================================================
-- PURCHASE ORDERS / RECEIVING / SUPPLIER PAYABLES
-- =====================================================================

alter table public.purchases
  add column if not exists client_request_id uuid;

create unique index if not exists purchases_client_request_unique
  on public.purchases(client_request_id)
  where client_request_id is not null;

alter table public.purchase_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists purchase_payments_client_request_unique
  on public.purchase_payments(client_request_id)
  where client_request_id is not null;

create unique index if not exists purchase_payments_reference_unique
  on public.purchase_payments(lower(method),reference)
  where reference is not null and lower(method)<>'cash';

create table if not exists public.purchase_receipt_events (
  id uuid primary key default gen_random_uuid(),
  purchase_item_id uuid not null references public.purchase_items(id) on delete restrict,
  quantity_received numeric(18,6) not null check (quantity_received>0),
  client_request_id uuid,
  received_by uuid not null references public.profiles(id),
  received_at timestamptz not null default now()
);

create unique index if not exists purchase_receipt_request_unique
  on public.purchase_receipt_events(client_request_id)
  where client_request_id is not null;

create sequence if not exists public.purchase_no_seq;

create or replace function public.next_purchase_no()
returns text
language sql
volatile
as $$
  select 'PO-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.purchase_no_seq')::text,6,'0')
$$;

create or replace function public.create_purchase_order(
  p_supplier_id uuid,
  p_purchase_date date,
  p_supplier_invoice_no text,
  p_invoice_date date,
  p_credit_terms_days integer,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_material_id uuid;
  v_qty numeric;
  v_cost numeric;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to create purchase orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchases
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.suppliers where id=p_supplier_id and active=true) then
    raise exception 'Active supplier not found';
  end if;

  if p_credit_terms_days<0 then raise exception 'Credit terms cannot be negative'; end if;
  if coalesce(p_discount,0)<0 then raise exception 'Discount cannot be negative'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Purchase order needs at least one item';
  end if;

  -- Validate all lines before creating the order.
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_material_id:=(v_item->>'raw_material_id')::uuid;
    v_qty:=(v_item->>'ordered_qty_base')::numeric;
    v_cost:=(v_item->>'unit_cost_base')::numeric;

    if v_qty<=0 then raise exception 'Ordered quantity must be greater than zero'; end if;
    if v_cost<0 then raise exception 'Unit cost cannot be negative'; end if;
    if not exists(select 1 from public.raw_materials where id=v_material_id and status='active') then
      raise exception 'Invalid raw material';
    end if;
  end loop;

  insert into public.purchases(
    id,purchase_no,supplier_id,purchase_date,supplier_reference,
    status,payment_status,subtotal,discount,total_amount,amount_paid,notes,
    created_by,requested_by,approval_status,supplier_invoice_no,invoice_date,
    credit_terms_days,client_request_id
  )
  values(
    v_id,public.next_purchase_no(),p_supplier_id,coalesce(p_purchase_date,public.business_current_date()),null,
    'draft','unpaid',0,coalesce(p_discount,0),0,0,p_notes,
    auth.uid(),auth.uid(),'pending',nullif(trim(p_supplier_invoice_no),''),p_invoice_date,
    p_credit_terms_days,p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    insert into public.purchase_items(
      purchase_id,raw_material_id,ordered_qty_base,received_qty_base,
      unit_cost_base,line_total
    )
    values(
      v_id,
      (v_item->>'raw_material_id')::uuid,
      (v_item->>'ordered_qty_base')::numeric,
      0,
      (v_item->>'unit_cost_base')::numeric,
      ((v_item->>'ordered_qty_base')::numeric*(v_item->>'unit_cost_base')::numeric)
    );
  end loop;

  perform public.refresh_purchase_totals(v_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_purchase_order','purchase',v_id,
    jsonb_build_object(
      'supplier_id',p_supplier_id,
      'items',p_items,
      'discount',coalesce(p_discount,0),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.decide_purchase_order(
  p_purchase_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.purchases%rowtype;
  v_approval public.po_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve purchase orders';
  end if;

  if p_decision='approve' then v_approval:='approved';
  elsif p_decision='reject' then v_approval:='rejected';
  else raise exception 'Decision must be approve or reject';
  end if;

  select * into v_before
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase order not found'; end if;
  if v_before.approval_status<>'pending' then
    raise exception 'Only pending purchase orders may be decided';
  end if;

  if v_approval='approved' then
    if not exists(select 1 from public.purchase_items where purchase_id=p_purchase_id) then
      raise exception 'Purchase order has no lines';
    end if;
    if v_before.total_amount<=0 then
      raise exception 'Purchase order total must be greater than zero';
    end if;
  end if;

  update public.purchases
  set
    approval_status=v_approval,
    approved_by=auth.uid(),
    approved_at=now(),
    approval_note=p_note,
    status=case
      when v_approval='approved' then 'ordered'::public.purchase_status
      else 'cancelled'::public.purchase_status
    end,
    updated_at=now()
  where id=p_purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when v_approval='approved' then 'approve_purchase_order' else 'reject_purchase_order' end,
    'purchase',p_purchase_id,
    jsonb_build_object('approval_status',v_before.approval_status,'status',v_before.status),
    jsonb_build_object('approval_status',v_approval,'note',p_note)
  );
end;
$$;

drop function if exists public.receive_purchase_item(uuid,numeric);

create or replace function public.receive_purchase_item(
  p_purchase_item_id uuid,
  p_receive_qty_base numeric,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.purchase_items%rowtype;
  v_purchase public.purchases%rowtype;
  v_remaining numeric;
  v_receipt_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to receive stock';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_receipt_events
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_receive_qty_base<=0 then raise exception 'Received quantity must be greater than zero'; end if;

  select * into v_item
  from public.purchase_items
  where id=p_purchase_item_id
  for update;

  if not found then raise exception 'Purchase item not found'; end if;

  select * into v_purchase
  from public.purchases
  where id=v_item.purchase_id
  for update;

  if v_purchase.approval_status<>'approved' then
    raise exception 'Purchase order must be approved before receiving';
  end if;
  if v_purchase.status not in ('ordered','partially_received') then
    raise exception 'Purchase order is not open for receiving';
  end if;

  v_remaining:=v_item.ordered_qty_base-v_item.received_qty_base;
  if p_receive_qty_base>v_remaining then
    raise exception 'Cannot receive more than remaining ordered quantity';
  end if;

  insert into public.purchase_receipt_events(
    id,purchase_item_id,quantity_received,client_request_id,received_by
  )
  values(
    v_receipt_id,p_purchase_item_id,p_receive_qty_base,p_client_request_id,auth.uid()
  );

  update public.purchase_items
  set received_qty_base=received_qty_base+p_receive_qty_base
  where id=p_purchase_item_id;

  insert into public.inventory_transactions(
    raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,purchase_item_id,created_by,notes
  )
  values(
    v_item.raw_material_id,'purchase',p_receive_qty_base,v_item.unit_cost_base,
    'purchase_receipt',v_receipt_id,v_item.id,auth.uid(),'Approved purchase receipt'
  );

  update public.purchases p
  set
    status=case
      when not exists(
        select 1 from public.purchase_items pi
        where pi.purchase_id=p.id and pi.received_qty_base<pi.ordered_qty_base
      ) then 'received'::public.purchase_status
      else 'partially_received'::public.purchase_status
    end,
    updated_at=now()
  where p.id=v_item.purchase_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'receive_stock','purchase_receipt',v_receipt_id,
    jsonb_build_object(
      'purchase_item_id',p_purchase_item_id,
      'quantity_received',p_receive_qty_base,
      'client_request_id',p_client_request_id
    )
  );

  return v_receipt_id;
end;
$$;

drop function if exists public.record_supplier_payment(uuid,numeric,text,text);

create or replace function public.record_supplier_payment(
  p_purchase_id uuid,
  p_amount numeric,
  p_method text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_purchase public.purchases%rowtype;
  v_payment_id uuid:=gen_random_uuid();
  v_remaining numeric(14,2);
  v_existing uuid;
  v_method text:=lower(trim(p_method));
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record supplier payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.purchase_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if v_method not in ('cash','bank','mtn_momo','airtel_money') then
    raise exception 'Unsupported supplier payment method';
  end if;
  if v_method<>'cash' and coalesce(trim(p_reference),'')='' then
    raise exception 'Reference is required for non-cash supplier payment';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  if not found then raise exception 'Purchase not found'; end if;
  if v_purchase.status='cancelled' then raise exception 'Cannot pay cancelled purchase'; end if;
  if v_purchase.approval_status<>'approved' then raise exception 'Purchase order is not approved'; end if;

  perform public.refresh_purchase_totals(p_purchase_id);

  select * into v_purchase
  from public.purchases
  where id=p_purchase_id
  for update;

  v_remaining:=v_purchase.total_amount-v_purchase.amount_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds amount outstanding on purchase'; end if;

  insert into public.purchase_payments(
    id,purchase_id,amount,method,reference,paid_at,created_by,shift_id,client_request_id
  )
  values(
    v_payment_id,p_purchase_id,p_amount,v_method,
    nullif(trim(p_reference),''),now(),auth.uid(),p_shift_id,p_client_request_id
  );

  perform public.refresh_purchase_totals(p_purchase_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_supplier_payment','purchase_payment',v_payment_id,
    jsonb_build_object(
      'purchase_id',p_purchase_id,'amount',p_amount,'method',v_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

create or replace function public.trg_refresh_purchase_item_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_items_refresh_totals on public.purchase_items;
create trigger trg_purchase_items_refresh_totals
after insert or update or delete
on public.purchase_items
for each row execute function public.trg_refresh_purchase_item_totals();

create or replace function public.trg_refresh_purchase_payment_totals()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='DELETE' then
    perform public.refresh_purchase_totals(old.purchase_id);
    return old;
  else
    perform public.refresh_purchase_totals(new.purchase_id);
    return new;
  end if;
end;
$$;

drop trigger if exists trg_purchase_payments_refresh_totals on public.purchase_payments;
create trigger trg_purchase_payments_refresh_totals
after insert or update or delete
on public.purchase_payments
for each row execute function public.trg_refresh_purchase_payment_totals();

-- Recalculate historical purchase totals after enabling automatic refresh.
do $$
declare r record;
begin
  for r in select id from public.purchases loop
    perform public.refresh_purchase_totals(r.id);
  end loop;
end $$;

drop policy if exists "purchasing staff manage purchases" on public.purchases;
drop policy if exists "purchasing staff manage purchase items" on public.purchase_items;
drop policy if exists "owner manager create purchase payments" on public.purchase_payments;

alter table public.purchase_receipt_events enable row level security;
create policy "purchasing staff read receipts" on public.purchase_receipt_events
for select using (public.current_staff_role() in ('owner','manager','storekeeper'));

create or replace view public.purchase_order_summary
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.purchase_date,
  p.supplier_invoice_no,
  p.invoice_date,
  p.credit_terms_days,
  p.due_date,
  p.status,
  p.payment_status,
  p.approval_status,
  p.subtotal,
  p.discount,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.requested_by,
  req.full_name as requested_by_name,
  p.approved_by,
  appr.full_name as approved_by_name,
  p.created_at
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
left join public.profiles req on req.id=p.requested_by
left join public.profiles appr on appr.id=p.approved_by;

create or replace view public.purchase_receiving_lines
with (security_invoker=true)
as
select
  pi.id,
  pi.purchase_id,
  p.purchase_no,
  p.purchase_date,
  p.status,
  p.approval_status,
  p.supplier_id,
  s.name as supplier_name,
  pi.raw_material_id,
  rm.name as material_name,
  rm.base_unit,
  pi.ordered_qty_base,
  pi.received_qty_base,
  (pi.ordered_qty_base-pi.received_qty_base) as remaining_qty_base,
  pi.unit_cost_base,
  pi.line_total
from public.purchase_items pi
join public.purchases p on p.id=pi.purchase_id
join public.suppliers s on s.id=p.supplier_id
join public.raw_materials rm on rm.id=pi.raw_material_id
where p.approval_status='approved'
  and p.status in ('ordered','partially_received');

create or replace view public.supplier_open_payables
with (security_invoker=true)
as
select
  p.id,
  p.purchase_no,
  p.supplier_id,
  s.name as supplier_name,
  p.due_date,
  p.total_amount,
  p.amount_paid,
  (p.total_amount-p.amount_paid)::numeric(14,2) as outstanding_amount,
  p.payment_status
from public.purchases p
join public.suppliers s on s.id=p.supplier_id
where p.approval_status='approved'
  and p.status<>'cancelled'
  and p.total_amount>p.amount_paid;

create or replace view public.supplier_account_summary
with (security_invoker=true)
as
select
  s.id as supplier_id,
  s.name as supplier_name,
  s.phone,
  s.email,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount else 0 end),0)::numeric(14,2) as total_purchases,
  coalesce(sum(case when p.status<>'cancelled' then p.amount_paid else 0 end),0)::numeric(14,2) as total_paid,
  coalesce(sum(case when p.status<>'cancelled' then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as outstanding_balance,
  coalesce(sum(case
    when p.status<>'cancelled'
      and p.due_date<public.business_current_date()
      and p.total_amount>p.amount_paid
    then p.total_amount-p.amount_paid else 0 end),0)::numeric(14,2) as overdue_balance,
  min(case
    when p.status<>'cancelled' and p.total_amount>p.amount_paid then p.due_date
  end) as next_due_date
from public.suppliers s
left join public.purchases p on p.supplier_id=s.id
where s.active=true
group by s.id,s.name,s.phone,s.email;

-- =====================================================================
-- EXPENSES + MANUAL CASH MOVEMENTS
-- =====================================================================

alter table public.expenses
  add column if not exists client_request_id uuid;

create unique index if not exists expenses_client_request_unique
  on public.expenses(client_request_id)
  where client_request_id is not null;

alter table public.expenses enable row level security;

drop policy if exists "management read expenses" on public.expenses;
create policy "management read expenses" on public.expenses
for select using (public.current_staff_role() in ('owner','manager'));

create unique index if not exists expenses_mobile_reference_unique
  on public.expenses(payment_method,reference)
  where reference is not null and payment_method in ('mtn_momo','airtel_money');

create or replace function public.record_business_expense(
  p_category text,
  p_description text,
  p_amount numeric,
  p_payment_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may record expenses';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.expenses where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_category),'')='' then raise exception 'Expense category is required'; end if;
  if coalesce(trim(p_description),'')='' then raise exception 'Expense description is required'; end if;
  if p_amount<=0 then raise exception 'Expense amount must be greater than zero'; end if;

  if p_payment_method in ('mtn_momo','airtel_money')
     and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money expense reference is required';
  end if;

  if p_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=p_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.expenses(
    id,category,description,amount,payment_method,reference,shift_id,created_by,client_request_id
  )
  values(
    v_id,trim(p_category),trim(p_description),p_amount,p_payment_method,
    nullif(trim(p_reference),''),p_shift_id,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_expense','expense',v_id,
    jsonb_build_object(
      'category',p_category,'amount',p_amount,'payment_method',p_payment_method,
      'reference',p_reference,'shift_id',p_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.expense_live_summary
with (security_invoker=true)
as
select
  e.id,
  public.business_date(e.created_at) as business_date,
  e.category,
  e.description,
  e.amount,
  e.payment_method,
  e.reference,
  e.shift_id,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_label,
  e.created_by,
  rp.full_name as recorded_by_name,
  e.created_at
from public.expenses e
left join public.profiles rp on rp.id=e.created_by
left join public.cashier_shifts cs on cs.id=e.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

alter table public.cash_movements
  add column if not exists client_request_id uuid;

create unique index if not exists cash_movements_client_request_unique
  on public.cash_movements(client_request_id)
  where client_request_id is not null;

drop policy if exists "cashier create own cash movement" on public.cash_movements;

create or replace function public.record_cash_movement(
  p_movement_type public.cash_movement_type,
  p_amount numeric,
  p_reason text,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if p_client_request_id is not null then
    select id into v_existing from public.cash_movements where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record cash movements';
  end if;
  if p_amount<=0 then raise exception 'Cash movement amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Cash movement reason is required'; end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc
    limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post movement to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  insert into public.cash_movements(
    id,shift_id,movement_type,amount,reason,reference,created_by,client_request_id
  )
  values(
    v_id,v_shift_id,p_movement_type,p_amount,trim(p_reason),nullif(trim(p_reference),''),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_cash_movement','cash_movement',v_id,
    jsonb_build_object(
      'movement_type',p_movement_type,'amount',p_amount,'reason',p_reason,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace view public.cash_movement_summary
with (security_invoker=true)
as
select
  cm.id,
  cm.shift_id,
  cm.movement_type,
  cm.amount,
  cm.reason,
  cm.reference,
  cm.created_by,
  rp.full_name as created_by_name,
  cs.cashier_id as shift_cashier_id,
  cp.full_name as shift_cashier_name,
  cm.created_at
from public.cash_movements cm
left join public.profiles rp on rp.id=cm.created_by
left join public.cashier_shifts cs on cs.id=cm.shift_id
left join public.profiles cp on cp.id=cs.cashier_id;

-- Stop authenticated staff from bypassing controlled inventory/purchase ledgers with direct inserts.
drop policy if exists "authorized staff create inventory tx" on public.inventory_transactions;


-- Stock-count corrections are also idempotent because a retry must not post the same adjustment twice.
alter table public.inventory_transactions
  add column if not exists client_request_id uuid;

create unique index if not exists inventory_tx_client_request_unique
  on public.inventory_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.record_stock_count(uuid,numeric,text);

create or replace function public.record_stock_count(
  p_raw_material_id uuid,
  p_counted_qty numeric,
  p_reason text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_material public.raw_materials%rowtype;
  v_delta numeric;
  v_tx_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_unit_cost numeric(14,6);
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to post stock counts';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.inventory_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_counted_qty<0 then raise exception 'Counted stock cannot be negative'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;

  select * into v_material
  from public.raw_materials
  where id=p_raw_material_id
  for update;

  if not found then raise exception 'Raw material not found'; end if;

  v_delta:=p_counted_qty-v_material.current_stock_qty;
  if v_delta=0 then return null; end if;

  v_unit_cost:=case when v_material.purchase_pack_base_qty>0
    then v_material.current_purchase_cost/v_material.purchase_pack_base_qty
    else 0 end;

  insert into public.inventory_transactions(
    id,raw_material_id,tx_type,quantity_delta,unit_cost,
    reference_type,reference_id,notes,created_by,client_request_id
  )
  values(
    v_tx_id,p_raw_material_id,'adjustment',v_delta,v_unit_cost,
    'stock_count',v_tx_id,trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'stock_count_adjustment','inventory_transaction',v_tx_id,
    jsonb_build_object(
      'raw_material_id',p_raw_material_id,
      'previous_qty',v_material.current_stock_qty,
      'counted_qty',p_counted_qty,
      'delta',v_delta,
      'reason',p_reason,
      'client_request_id',p_client_request_id
    )
  );

  return v_tx_id;
end;
$$;


-- Direct table-write policies from the prototype are removed for core controlled ledgers.
-- The live pages use audited SECURITY DEFINER RPCs instead.
drop policy if exists "owner manager manage products" on public.products;
drop policy if exists "storekeeper manager owner manage materials" on public.raw_materials;
drop policy if exists "owner manager manage recipes" on public.recipes;
drop policy if exists "owner manager manage recipe items" on public.recipe_items;
drop policy if exists "owner manager manage plan items" on public.production_plan_items;

-- =====================================================================
-- DAILY CLOSING: INCLUDE CUSTOMER ORDER RECEIPTS + SUPPLIER PAYMENTS
-- =====================================================================

alter table public.daily_closings
  add column if not exists cash_order_receipts numeric(14,2) not null default 0,
  add column if not exists mtn_order_receipts numeric(14,2) not null default 0,
  add column if not exists airtel_order_receipts numeric(14,2) not null default 0,
  add column if not exists cash_supplier_payments numeric(14,2) not null default 0,
  add column if not exists mtn_supplier_payments numeric(14,2) not null default 0,
  add column if not exists airtel_supplier_payments numeric(14,2) not null default 0;

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2);
  v_pos_cash numeric(14,2);
  v_pos_mtn numeric(14,2);
  v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2);
  v_mtn_refunds numeric(14,2);
  v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2);
  v_order_mtn numeric(14,2);
  v_order_airtel numeric(14,2);
  v_supplier_cash numeric(14,2);
  v_supplier_mtn numeric(14,2);
  v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2);
  v_cash_out numeric(14,2);
  v_cash_exp numeric(14,2);
  v_momo_exp numeric(14,2);
  v_tx_count integer;
  v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  select coalesce(sum(opening_float),0)
  into v_opening
  from public.cashier_shifts
  where public.business_date(opened_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_pos_cash,v_pos_mtn,v_pos_airtel
  from public.payments
  where status='completed'
    and public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds
  where public.business_date(refunded_at)=p_business_date;

  select
    coalesce(sum(case when method='cash' then amount else 0 end),0),
    coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_cash,v_order_mtn,v_order_airtel
  from public.customer_order_payments
  where payment_status='completed'
    and public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),
    coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0)
  into v_supplier_cash,v_supplier_mtn,v_supplier_airtel
  from public.purchase_payments
  where public.business_date(paid_at)=p_business_date;

  select
    coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
    coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out
  from public.cash_movements
  where public.business_date(created_at)=p_business_date;

  select
    coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
    coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp
  from public.expenses
  where public.business_date(created_at)=p_business_date;

  select
    count(*) filter (where status in ('completed','partially_refunded','refunded')),
    coalesce(sum(case when status in ('completed','partially_refunded','refunded')
      then total-coalesce(refund_total,0) else 0 end),0)
  into v_tx_count,v_pos_sales
  from public.sales
  where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,
    'opening_float',v_opening,
    'cash_sales',v_pos_cash-v_cash_refunds,
    'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,
    'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash,
    'mtn_order_receipts',v_order_mtn,
    'airtel_order_receipts',v_order_airtel,
    'cash_supplier_payments',v_supplier_cash,
    'mtn_supplier_payments',v_supplier_mtn,
    'airtel_supplier_payments',v_supplier_airtel,
    'cash_in',v_cash_in,
    'cash_out',v_cash_out,
    'cash_expenses',v_cash_exp,
    'momo_expenses',v_momo_exp,
    'expected_cash',
      v_opening+(v_pos_cash-v_cash_refunds)+v_order_cash+v_cash_in
      -v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,
    'total_sales',v_pos_sales,
    'customer_order_receipts',v_order_cash+v_order_mtn+v_order_airtel
  );
end;
$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s jsonb;
  v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager can prepare daily closing';
  end if;

  v_s:=public.daily_closing_snapshot(p_business_date);

  insert into public.daily_closings(
    business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,
    cash_order_receipts,mtn_order_receipts,airtel_order_receipts,
    cash_supplier_payments,mtn_supplier_payments,airtel_supplier_payments,
    cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,
    transaction_count,prepared_by
  )
  values(
    p_business_date,
    (v_s->>'opening_float')::numeric,
    (v_s->>'cash_sales')::numeric,
    (v_s->>'mtn_momo_sales')::numeric,
    (v_s->>'airtel_money_sales')::numeric,
    (v_s->>'cash_order_receipts')::numeric,
    (v_s->>'mtn_order_receipts')::numeric,
    (v_s->>'airtel_order_receipts')::numeric,
    (v_s->>'cash_supplier_payments')::numeric,
    (v_s->>'mtn_supplier_payments')::numeric,
    (v_s->>'airtel_supplier_payments')::numeric,
    (v_s->>'cash_in')::numeric,
    (v_s->>'cash_out')::numeric,
    (v_s->>'cash_expenses')::numeric,
    (v_s->>'momo_expenses')::numeric,
    (v_s->>'expected_cash')::numeric,
    (v_s->>'transaction_count')::integer,
    auth.uid()
  )
  on conflict(business_date) do update set
    opening_float=excluded.opening_float,
    cash_sales=excluded.cash_sales,
    mtn_momo_sales=excluded.mtn_momo_sales,
    airtel_money_sales=excluded.airtel_money_sales,
    cash_order_receipts=excluded.cash_order_receipts,
    mtn_order_receipts=excluded.mtn_order_receipts,
    airtel_order_receipts=excluded.airtel_order_receipts,
    cash_supplier_payments=excluded.cash_supplier_payments,
    mtn_supplier_payments=excluded.mtn_supplier_payments,
    airtel_supplier_payments=excluded.airtel_supplier_payments,
    cash_in=excluded.cash_in,
    cash_out=excluded.cash_out,
    cash_expenses=excluded.cash_expenses,
    momo_expenses=excluded.momo_expenses,
    expected_cash=excluded.expected_cash,
    transaction_count=excluded.transaction_count,
    prepared_by=excluded.prepared_by,
    updated_at=now()
  returning * into v_result;

  return v_result;
end;
$$;

-- =====================================================================
-- RLS / EXECUTE HARDENING
-- =====================================================================

revoke all on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) from public;
revoke all on function public.confirm_production_run(uuid,numeric,uuid) from public;
revoke all on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) from public;
revoke all on function public.set_baker_task_status(uuid,public.baker_task_status) from public;
revoke all on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) from public;
revoke all on function public.decide_waste_event(uuid,text,text) from public;
revoke all on function public.apply_approved_raw_waste(uuid) from public;
revoke all on function public.current_product_unit_cost(uuid) from public;
revoke all on function public.production_run_unit_cost(uuid) from public;
revoke all on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) from public;
revoke all on function public.decide_purchase_order(uuid,text,text) from public;
revoke all on function public.receive_purchase_item(uuid,numeric,uuid) from public;
revoke all on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) from public;
revoke all on function public.refresh_purchase_totals(uuid) from public;
revoke all on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) from public;
revoke all on function public.record_stock_count(uuid,numeric,text,uuid) from public;
revoke all on function public.daily_closing_snapshot(date) from public;
revoke all on function public.calculate_daily_closing(date) from public;

grant execute on function public.create_production_plan_item(date,uuid,uuid,public.production_shift,numeric,text,uuid) to authenticated;
grant execute on function public.confirm_production_run(uuid,numeric,uuid) to authenticated;
grant execute on function public.create_baker_task(text,uuid,uuid,uuid,timestamptz,text) to authenticated;
grant execute on function public.set_baker_task_status(uuid,public.baker_task_status) to authenticated;
grant execute on function public.record_waste_event(public.waste_type,numeric,text,uuid,uuid,uuid,text,uuid) to authenticated;
grant execute on function public.decide_waste_event(uuid,text,text) to authenticated;
grant execute on function public.create_purchase_order(uuid,date,text,date,integer,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.decide_purchase_order(uuid,text,text) to authenticated;
grant execute on function public.receive_purchase_item(uuid,numeric,uuid) to authenticated;
grant execute on function public.record_supplier_payment(uuid,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_business_expense(text,text,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.record_cash_movement(public.cash_movement_type,numeric,text,text,uuid,uuid) to authenticated;
grant execute on function public.record_stock_count(uuid,numeric,text,uuid) to authenticated;
grant execute on function public.daily_closing_snapshot(date) to authenticated;
grant execute on function public.calculate_daily_closing(date) to authenticated;

create index if not exists baker_tasks_assigned_due_idx
  on public.baker_tasks(assigned_baker_id,status,due_at);

create index if not exists production_runs_recipe_idx
  on public.production_runs(recipe_id,confirmed_at desc);

create index if not exists purchase_receipts_item_idx
  on public.purchase_receipt_events(purchase_item_id,received_at desc);

create index if not exists expenses_created_idx
  on public.expenses(created_at desc);


-- ===== INTEGRATION STAGE / MIGRATION 019 =====
-- DS Bakery v0.20 / Migration 019
-- Customer & service live wiring:
-- customers, customer orders/deposits, custom cakes, delivery/riders,
-- loyalty/retention, WhatsApp click-to-chat and shared Mobile Money reference control.

-- =====================================================================
-- SHARED MOBILE MONEY REFERENCE REGISTRY
-- =====================================================================

create table if not exists public.mobile_money_reference_registry (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('mtn_momo','airtel_money')),
  direction text not null check (direction in ('inbound','outbound')),
  reference text not null,
  source_type text not null,
  source_id uuid not null,
  created_at timestamptz not null default now()
);

create unique index if not exists mobile_money_reference_global_unique
  on public.mobile_money_reference_registry(provider,direction,lower(reference));

create unique index if not exists mobile_money_reference_source_unique
  on public.mobile_money_reference_registry(source_type,source_id);

create or replace function public.trg_register_mobile_money_reference()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_provider text;
  v_direction text;
  v_reference text;
begin
  if tg_table_name='payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='customer_order_payments' then
    v_provider:=new.method::text;
    v_direction:='inbound';
    v_reference:=new.reference;
  elsif tg_table_name='expenses' then
    v_provider:=new.payment_method::text;
    v_direction:='outbound';
    v_reference:=new.reference;
  elsif tg_table_name='purchase_payments' then
    v_provider:=lower(new.method);
    v_direction:='outbound';
    v_reference:=new.reference;
  else
    return new;
  end if;

  if v_provider not in ('mtn_momo','airtel_money')
     or coalesce(trim(v_reference),'')='' then
    return new;
  end if;

  insert into public.mobile_money_reference_registry(
    provider,direction,reference,source_type,source_id
  )
  values(
    v_provider,v_direction,trim(v_reference),tg_table_name,new.id
  );

  return new;
end;
$$;

drop trigger if exists trg_payments_mobile_registry on public.payments;
create trigger trg_payments_mobile_registry
after insert on public.payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_customer_order_payments_mobile_registry on public.customer_order_payments;
create trigger trg_customer_order_payments_mobile_registry
after insert on public.customer_order_payments
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_expenses_mobile_registry on public.expenses;
create trigger trg_expenses_mobile_registry
after insert on public.expenses
for each row execute function public.trg_register_mobile_money_reference();

drop trigger if exists trg_purchase_payments_mobile_registry on public.purchase_payments;
create trigger trg_purchase_payments_mobile_registry
after insert on public.purchase_payments
for each row execute function public.trg_register_mobile_money_reference();

-- Backfill existing references. ON CONFLICT preserves migration progress while a conflict view
-- makes any historical duplicates visible for reconciliation.
insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'payments',id
from public.payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select method::text,'inbound',trim(reference),'customer_order_payments',id
from public.customer_order_payments
where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select payment_method::text,'outbound',trim(reference),'expenses',id
from public.expenses
where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

insert into public.mobile_money_reference_registry(provider,direction,reference,source_type,source_id)
select lower(method),'outbound',trim(reference),'purchase_payments',id
from public.purchase_payments
where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
on conflict do nothing;

create or replace view public.mobile_money_reference_conflicts
with (security_invoker=true)
as
with refs as (
  select method::text provider,'inbound'::text direction,lower(trim(reference)) reference,'payments' source_table,id
  from public.payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select method::text,'inbound',lower(trim(reference)),'customer_order_payments',id
  from public.customer_order_payments where method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select payment_method::text,'outbound',lower(trim(reference)),'expenses',id
  from public.expenses where payment_method in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
  union all
  select lower(method),'outbound',lower(trim(reference)),'purchase_payments',id
  from public.purchase_payments where lower(method) in ('mtn_momo','airtel_money') and nullif(trim(reference),'') is not null
)
select provider,direction,reference,count(*)::bigint as occurrence_count,
       string_agg(source_table || ':' || id::text,', ' order by source_table) as sources
from refs
group by provider,direction,reference
having count(*)>1;

alter table public.mobile_money_reference_registry enable row level security;
create policy "management read mobile money registry"
on public.mobile_money_reference_registry
for select using (public.current_staff_role() in ('owner','manager'));


-- Private custom-cake reference bucket when this migration runs inside Supabase.
do $storage$
begin
  if to_regclass('storage.buckets') is not null and to_regclass('storage.objects') is not null then
    execute 'insert into storage.buckets(id,name,public) values (''custom-cake-references'',''custom-cake-references'',false)
             on conflict(id) do update set public=false';

    execute 'drop policy if exists "ds bakery custom cake read" on storage.objects';
    execute 'create policy "ds bakery custom cake read" on storage.objects
             for select using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'',''baker'')
             )';

    execute 'drop policy if exists "ds bakery custom cake upload" on storage.objects';
    execute 'create policy "ds bakery custom cake upload" on storage.objects
             for insert with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake update" on storage.objects';
    execute 'create policy "ds bakery custom cake update" on storage.objects
             for update using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             ) with check (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'',''cashier'')
             )';

    execute 'drop policy if exists "ds bakery custom cake delete" on storage.objects';
    execute 'create policy "ds bakery custom cake delete" on storage.objects
             for delete using (
               bucket_id=''custom-cake-references''
               and public.current_staff_role() in (''owner'',''manager'')
             )';
  end if;
end
$storage$;

-- =====================================================================
-- CUSTOMERS
-- =====================================================================

alter table public.customers
  add column if not exists client_request_id uuid;

create unique index if not exists customers_client_request_unique
  on public.customers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_customer(
  p_customer_id uuid,
  p_full_name text,
  p_phone text,
  p_email text,
  p_address text,
  p_birthday date,
  p_notes text,
  p_whatsapp_opt_in boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_customer_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to save customers';
  end if;
  if coalesce(trim(p_full_name),'')='' then raise exception 'Customer name is required'; end if;

  if p_customer_id is null and p_client_request_id is not null then
    select id into v_existing from public.customers where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(c) into v_before from public.customers c where c.id=p_customer_id;

  insert into public.customers(
    id,full_name,phone,email,address,birthday,notes,active,created_by,
    whatsapp_opt_in,whatsapp_opt_in_at,whatsapp_opt_out_at,client_request_id
  )
  values(
    v_id,trim(p_full_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_address),''),p_birthday,p_notes,true,auth.uid(),
    coalesce(p_whatsapp_opt_in,false),
    case when p_whatsapp_opt_in then now() end,
    null,
    p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,
    phone=excluded.phone,
    email=excluded.email,
    address=excluded.address,
    birthday=excluded.birthday,
    notes=excluded.notes,
    whatsapp_opt_in=excluded.whatsapp_opt_in,
    whatsapp_opt_in_at=case
      when excluded.whatsapp_opt_in and not customers.whatsapp_opt_in then now()
      else customers.whatsapp_opt_in_at end,
    whatsapp_opt_out_at=case
      when not excluded.whatsapp_opt_in and customers.whatsapp_opt_in then now()
      when excluded.whatsapp_opt_in then null
      else customers.whatsapp_opt_out_at end,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_customer_id is null then 'create_customer' else 'update_customer' end,
    'customer',v_id,v_before,
    (select to_jsonb(c) from public.customers c where c.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "sales staff manage customers" on public.customers;

create or replace view public.customer_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter (where co.status<>'cancelled')::bigint order_count,
    coalesce(sum(co.total_amount) filter (where co.status<>'cancelled'),0)::numeric(14,2) total_order_value,
    coalesce(sum(
      case when co.status<>'cancelled' then
        co.total_amount-coalesce((
          select sum(cop.amount) from public.customer_order_payments cop
          where cop.order_id=co.id and cop.payment_status='completed'
        ),0)
      else 0 end
    ),0)::numeric(14,2) outstanding_balance,
    max(co.created_at) filter (where co.status<>'cancelled') last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  group by c.id
)
select
  c.id as customer_id,
  c.full_name,
  c.phone,
  c.email,
  coalesce(os.order_count,0) order_count,
  coalesce(os.total_order_value,0)::numeric(14,2) total_order_value,
  coalesce(os.outstanding_balance,0)::numeric(14,2) outstanding_balance,
  os.last_order_at,
  c.address,
  c.birthday,
  c.notes,
  c.whatsapp_opt_in
from public.customers c
left join order_stats os on os.customer_id=c.id
where c.active=true;

-- =====================================================================
-- CUSTOMER ORDERS / DEPOSITS
-- =====================================================================

create sequence if not exists public.customer_order_no_seq;

create or replace function public.next_customer_order_no()
returns text
language sql
volatile
as $$
  select 'ORD-' ||
    to_char(now() at time zone coalesce(
      (select business_timezone from public.business_settings where id=1),'UTC'
    ),'YYYYMMDD') ||
    '-' || lpad(nextval('public.customer_order_no_seq')::text,6,'0')
$$;

alter table public.customer_orders
  add column if not exists client_request_id uuid;

create unique index if not exists customer_orders_client_request_unique
  on public.customer_orders(client_request_id)
  where client_request_id is not null;

alter table public.customer_order_payments
  add column if not exists shift_id uuid references public.cashier_shifts(id),
  add column if not exists client_request_id uuid;

create unique index if not exists customer_order_payments_client_request_unique
  on public.customer_order_payments(client_request_id)
  where client_request_id is not null;

create or replace function public.create_customer_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_discount numeric,
  p_notes text,
  p_items jsonb,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty numeric;
  v_subtotal numeric(14,2):=0;
  v_discount numeric(14,2):=greatest(coalesce(p_discount,0),0);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create customer orders';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.customer_orders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Order needs at least one product';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty:=(v_item->>'quantity')::numeric;
    if v_qty<=0 then raise exception 'Order quantity must be greater than zero'; end if;

    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid and status='active';

    if not found then raise exception 'Invalid or inactive product'; end if;
    v_subtotal:=v_subtotal+(v_product.selling_price*v_qty);
  end loop;

  if v_discount>v_subtotal then raise exception 'Discount cannot exceed subtotal'; end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    v_subtotal,v_discount,greatest(v_subtotal-v_discount,0),p_notes,auth.uid(),p_client_request_id
  );

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product
    from public.products
    where id=(v_item->>'product_id')::uuid;

    v_qty:=(v_item->>'quantity')::numeric;

    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(
      v_id,v_product.id,v_product.name,v_qty,v_product.selling_price,
      v_product.selling_price*v_qty,nullif(trim(v_item->>'customization_notes'),'')
    );
  end loop;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_customer_order','customer_order',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'fulfillment',p_fulfillment,
      'required_at',p_required_at,'subtotal',v_subtotal,'discount',v_discount,
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop function if exists public.record_customer_order_payment(uuid,numeric,public.payment_method,text);

create or replace function public.record_customer_order_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method public.payment_method,
  p_reference text default null,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_role public.staff_role;
  v_shift_id uuid:=p_shift_id;
begin
  v_role:=public.current_staff_role();

  if v_role not in ('owner','manager','cashier') then
    raise exception 'Not authorized to record customer-order payments';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.customer_order_payments
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_method in ('mtn_momo','airtel_money') and coalesce(trim(p_reference),'')='' then
    raise exception 'Mobile Money reference is required';
  end if;

  if v_role='cashier' then
    select id into v_shift_id
    from public.cashier_shifts
    where cashier_id=auth.uid() and status='open'
    order by opened_at desc limit 1;

    if v_shift_id is null then raise exception 'Cashier needs an open cashier shift'; end if;
    if p_shift_id is not null and p_shift_id<>v_shift_id then
      raise exception 'Cashier cannot post payment to another cashier shift';
    end if;
  elsif v_shift_id is not null and not exists(
    select 1 from public.cashier_shifts where id=v_shift_id and status='open'
  ) then
    raise exception 'Selected cashier shift is not open';
  end if;

  select * into v_order
  from public.customer_orders
  where id=p_order_id
  for update;

  if not found then raise exception 'Order not found'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot pay a cancelled order'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_remaining:=v_order.total_amount-v_paid;
  if p_amount>v_remaining then raise exception 'Payment exceeds outstanding order balance'; end if;

  insert into public.customer_order_payments(
    id,order_id,method,amount,reference,payment_status,recorded_by,paid_at,shift_id,client_request_id
  )
  values(
    v_payment_id,p_order_id,p_method,p_amount,nullif(trim(p_reference),''),
    'completed',auth.uid(),now(),v_shift_id,p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_customer_order_payment','customer_order_payment',v_payment_id,
    jsonb_build_object(
      'order_id',p_order_id,'amount',p_amount,'method',p_method,
      'reference',p_reference,'shift_id',v_shift_id,'client_request_id',p_client_request_id
    )
  );

  return v_payment_id;
end;
$$;

drop function if exists public.update_customer_order_status(uuid,public.customer_order_status);

create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
  v_paid numeric(14,2);
  v_valid boolean:=false;
  v_cake_status public.custom_cake_design_status;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;

  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_before.status in ('completed','cancelled') then raise exception 'Order is already closed'; end if;
  if p_status=v_before.status then return; end if;

  if p_status='cancelled' then
    if v_role not in ('owner','manager','cashier') then raise exception 'Baker cannot cancel customer orders'; end if;
    if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;
    select coalesce(sum(amount),0) into v_paid
    from public.customer_order_payments where order_id=p_order_id and payment_status='completed';
    if v_paid>0 then
      raise exception 'Paid orders cannot be cancelled until a customer-order refund workflow is completed';
    end if;
    v_valid:=true;
  elsif v_role='baker' then
    v_valid:=(v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready');
  elsif v_role='cashier' then
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  else
    v_valid:=(v_before.status='pending' and p_status='confirmed')
          or (v_before.status='confirmed' and p_status='in_production')
          or (v_before.status='in_production' and p_status='ready')
          or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  end if;

  if not v_valid then raise exception 'Invalid order status transition'; end if;

  if p_status='in_production' and exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    select design_status into v_cake_status from public.custom_cake_specs where order_id=p_order_id;
    if v_cake_status<>'approved' then raise exception 'Custom cake must be approved before production'; end if;
  end if;

  if p_status='completed' and v_before.fulfillment='delivery' then
    raise exception 'Delivery orders are completed through the delivery workflow';
  end if;

  update public.customer_orders
  set
    status=p_status,
    completed_at=case when p_status='completed' then now() else completed_at end,
    cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
    cancellation_reason=case when p_status='cancelled' then trim(p_reason) else cancellation_reason end,
    updated_at=now()
  where id=p_order_id;

  if exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    update public.custom_cake_specs
    set
      design_status=case
        when p_status='in_production' then 'in_production'::public.custom_cake_design_status
        when p_status='ready' then 'ready'::public.custom_cake_design_status
        when p_status='completed' then 'completed'::public.custom_cake_design_status
        when p_status='cancelled' then 'cancelled'::public.custom_cake_design_status
        else design_status end,
      updated_at=now()
    where order_id=p_order_id;
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status,'reason',p_reason)
  );
end;
$$;

drop policy if exists "sales staff manage customer orders" on public.customer_orders;
drop policy if exists "sales staff manage customer order items" on public.customer_order_items;
drop policy if exists "sales staff create customer order payments" on public.customer_order_payments;

create or replace view public.customer_order_summary
with (security_invoker=true)
as
with items as (
  select
    coi.order_id,
    count(*)::bigint item_count,
    string_agg(
      coi.description || ' × ' ||
      trim(to_char(coi.quantity,'FM999999990.###')),
      ', ' order by coi.created_at
    ) item_summary
  from public.customer_order_items coi
  group by coi.order_id
),
paid as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) amount_paid
  from public.customer_order_payments
  where payment_status='completed'
  group by order_id
)
select
  co.id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.status,
  co.fulfillment,
  co.required_at,
  co.delivery_address,
  co.total_amount,
  coalesce(pa.amount_paid,0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(pa.amount_paid,0))::numeric(14,2) balance_due,
  co.created_at,
  co.updated_at,
  co.delivery_charge,
  co.subtotal,
  co.discount,
  coalesce(i.item_count,0)::bigint item_count,
  coalesce(i.item_summary,'') item_summary,
  co.notes
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join items i on i.order_id=co.id
left join paid pa on pa.order_id=co.id;

-- Optional customer attachment at POS is performed atomically around the existing sale RPC.
create or replace function public.complete_sale_with_customer(
  p_items jsonb,
  p_discount numeric,
  p_payments jsonb,
  p_notes text default null,
  p_hold boolean default false,
  p_client_request_id uuid default null,
  p_customer_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sale_id uuid;
  v_existing_customer uuid;
begin
  if p_customer_id is not null and not exists(
    select 1 from public.customers where id=p_customer_id and active=true
  ) then
    raise exception 'Active customer not found';
  end if;

  v_sale_id:=public.complete_sale(
    p_items,p_discount,p_payments,p_notes,p_hold,p_client_request_id
  );

  if p_customer_id is not null then
    select customer_id into v_existing_customer
    from public.sales where id=v_sale_id for update;

    if v_existing_customer is not null and v_existing_customer<>p_customer_id then
      raise exception 'Idempotent sale already belongs to another customer';
    end if;

    update public.sales
    set customer_id=p_customer_id
    where id=v_sale_id and customer_id is null;

    perform public.sync_sale_loyalty_points(v_sale_id);
  end if;

  return v_sale_id;
end;
$$;

-- Cashier-shift reconciliation now includes customer-order cash, expenses,
-- supplier payments and manual cash movements linked to the till.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,cs.cashier_id,p.full_name cashier_name,cs.opened_at,cs.opening_float,
  cs.status,cs.closed_at,

  (select count(*)::bigint
   from public.sales s
   where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ) transaction_count,

  coalesce((
    select sum(s.total-coalesce(s.refund_total,0))
    from public.sales s
    where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')
  ),0)::numeric(14,2) gross_sales,

  (
    coalesce((
      select sum(py.amount)
      from public.payments py
      join public.sales s on s.id=py.sale_id
      where s.shift_id=cs.id and py.status='completed' and py.method='cash'
    ),0)
    -
    coalesce((
      select sum(sr.amount)
      from public.sale_refunds sr
      join public.sales s on s.id=sr.sale_id
      where s.shift_id=cs.id and sr.method='cash'
    ),0)
  )::numeric(14,2) cash_sales,

  coalesce((
    select sum(cop.amount)
    from public.customer_order_payments cop
    where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'
  ),0)::numeric(14,2) order_cash_receipts,

  coalesce((
    select sum(case when cm.movement_type='cash_in' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_in,

  coalesce((
    select sum(case when cm.movement_type='cash_out' then cm.amount else 0 end)
    from public.cash_movements cm where cm.shift_id=cs.id
  ),0)::numeric(14,2) cash_out,

  coalesce((
    select sum(e.amount)
    from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'
  ),0)::numeric(14,2) cash_expenses,

  coalesce((
    select sum(pp.amount)
    from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'
  ),0)::numeric(14,2) supplier_cash_payments,

  (
    cs.opening_float
    + (
      coalesce((
        select sum(py.amount)
        from public.payments py
        join public.sales s on s.id=py.sale_id
        where s.shift_id=cs.id and py.status='completed' and py.method='cash'
      ),0)
      -
      coalesce((
        select sum(sr.amount)
        from public.sale_refunds sr
        join public.sales s on s.id=sr.sale_id
        where s.shift_id=cs.id and sr.method='cash'
      ),0)
    )
    + coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
    + coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_in'),0)
    - coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_out'),0)
    - coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)
    - coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)
  )::numeric(14,2) expected_cash
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id;

revoke all on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) from public;
grant execute on function public.complete_sale_with_customer(jsonb,numeric,jsonb,text,boolean,uuid,uuid) to authenticated;

-- =====================================================================
-- CUSTOM CAKES
-- =====================================================================

alter table public.custom_cake_specs
  add column if not exists order_item_id uuid references public.customer_order_items(id),
  add column if not exists client_request_id uuid;

create unique index if not exists custom_cake_client_request_unique
  on public.custom_cake_specs(client_request_id)
  where client_request_id is not null;

create table if not exists public.custom_cake_settings (
  id integer primary key default 1 check(id=1),
  deposit_percent numeric(5,2) not null default 50 check(deposit_percent>0 and deposit_percent<=100),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.custom_cake_settings(id,deposit_percent)
values(1,50)
on conflict(id) do nothing;

-- Backfill an order item for earlier custom-cake rows so refresh_customer_order_total remains authoritative.
do $$
declare
  r record;
  v_item_id uuid;
begin
  for r in
    select ccs.id,ccs.order_id,ccs.quote_amount
    from public.custom_cake_specs ccs
    where ccs.order_item_id is null
  loop
    insert into public.customer_order_items(
      order_id,product_id,description,quantity,unit_price,line_total,customization_notes
    )
    values(r.order_id,null,'Custom Cake',1,r.quote_amount,r.quote_amount,'Custom cake specification')
    returning id into v_item_id;

    update public.custom_cake_specs set order_item_id=v_item_id where id=r.id;
    perform public.refresh_customer_order_total(r.order_id);
  end loop;
end $$;

create or replace function public.create_custom_cake_order(
  p_customer_id uuid,
  p_required_at timestamptz,
  p_fulfillment public.fulfillment_type,
  p_delivery_address text,
  p_cake_size_label text,
  p_servings integer,
  p_tiers integer,
  p_flavour text,
  p_filling text,
  p_frosting text,
  p_theme text,
  p_primary_color text,
  p_secondary_color text,
  p_inscription text,
  p_special_instructions text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order_id uuid:=gen_random_uuid();
  v_spec_id uuid:=gen_random_uuid();
  v_item_id uuid;
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create custom cake orders';
  end if;

  if p_client_request_id is not null then
    select order_id into v_existing
    from public.custom_cake_specs
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then
    raise exception 'Active customer not found';
  end if;
  if p_required_at is null then raise exception 'Required date/time is required'; end if;
  if coalesce(p_tiers,1)<=0 then raise exception 'Tiers must be greater than zero'; end if;
  if p_servings is not null and p_servings<=0 then raise exception 'Servings must be greater than zero'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then
    raise exception 'Delivery address is required';
  end if;

  insert into public.customer_orders(
    id,order_no,customer_id,status,fulfillment,required_at,delivery_address,
    subtotal,discount,total_amount,notes,created_by,client_request_id
  )
  values(
    v_order_id,public.next_customer_order_no(),p_customer_id,'pending',p_fulfillment,p_required_at,
    case when p_fulfillment='delivery' then trim(p_delivery_address) else null end,
    0,0,0,'Custom cake order',auth.uid(),p_client_request_id
  );

  insert into public.customer_order_items(
    order_id,product_id,description,quantity,unit_price,line_total,customization_notes
  )
  values(
    v_order_id,null,'Custom Cake',1,0,0,'Custom cake specification'
  )
  returning id into v_item_id;

  insert into public.custom_cake_specs(
    id,order_id,order_item_id,cake_size_label,servings,tiers,flavour,filling,frosting,
    theme,primary_color,secondary_color,inscription,special_instructions,quote_amount,
    design_status,created_by,client_request_id
  )
  values(
    v_spec_id,v_order_id,v_item_id,nullif(trim(p_cake_size_label),''),p_servings,coalesce(p_tiers,1),
    nullif(trim(p_flavour),''),nullif(trim(p_filling),''),nullif(trim(p_frosting),''),
    nullif(trim(p_theme),''),nullif(trim(p_primary_color),''),nullif(trim(p_secondary_color),''),
    nullif(trim(p_inscription),''),p_special_instructions,0,'draft',auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_custom_cake','custom_cake_spec',v_spec_id,
    jsonb_build_object('order_id',v_order_id,'customer_id',p_customer_id,'required_at',p_required_at)
  );

  return v_order_id;
end;
$$;

create or replace function public.save_custom_cake_reference_path(
  p_order_id uuid,
  p_reference_image_path text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_before text;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update custom cake reference image';
  end if;
  if coalesce(trim(p_reference_image_path),'')='' then raise exception 'Reference image path is required'; end if;

  select reference_image_path into v_before
  from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake not found'; end if;

  update public.custom_cake_specs
  set reference_image_path=trim(p_reference_image_path),updated_at=now()
  where order_id=p_order_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_custom_cake_reference','customer_order',p_order_id,
    jsonb_build_object('reference_image_path',v_before),
    jsonb_build_object('reference_image_path',p_reference_image_path)
  );
end;
$$;

create or replace function public.quote_custom_cake_order(
  p_order_id uuid,
  p_quote_amount numeric,
  p_production_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to quote custom cakes';
  end if;
  if p_quote_amount<=0 then raise exception 'Quote amount must be greater than zero'; end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(p_quote_amount-v_order.discount,0)+v_order.delivery_charge;
  if v_new_total<v_paid then raise exception 'Quote would reduce order total below payments already recorded'; end if;

  update public.customer_order_items
  set unit_price=p_quote_amount,line_total=p_quote_amount
  where id=v_spec.order_item_id;

  update public.custom_cake_specs
  set
    quote_amount=p_quote_amount,
    production_notes=coalesce(p_production_notes,production_notes),
    design_status=case
      when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status
      else 'quoted'::public.custom_cake_design_status end,
    updated_at=now()
  where order_id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount)
  );
end;
$$;

create or replace function public.approve_custom_cake_for_production(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2);
  v_pct numeric(5,2);
  v_required numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may approve custom cake for production';
  end if;

  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount<=0 then raise exception 'Custom cake has no valid quote'; end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  select deposit_percent into v_pct from public.custom_cake_settings where id=1;
  v_required:=round(v_spec.quote_amount*coalesce(v_pct,50)/100,2);

  if v_paid<v_required then
    raise exception 'Required deposit has not been reached';
  end if;

  update public.custom_cake_specs
  set design_status='approved',production_approved_by=auth.uid(),
      production_approved_at=now(),updated_at=now()
  where order_id=p_order_id;

  update public.customer_orders
  set status='confirmed',updated_at=now()
  where id=p_order_id and status='pending';

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object(
      'order_id',p_order_id,'quote_amount',v_spec.quote_amount,
      'amount_paid',v_paid,'deposit_required',v_required
    )
  );
end;
$$;

drop policy if exists "sales staff create custom cakes" on public.custom_cake_specs;
drop policy if exists "sales staff update custom cakes" on public.custom_cake_specs;

alter table public.custom_cake_settings enable row level security;
create policy "relevant staff read custom cake settings"
on public.custom_cake_settings
for select using (public.current_staff_role() in ('owner','manager','cashier','baker'));

create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id custom_cake_id,
  ccs.order_id,
  co.order_no,
  co.customer_id,
  c.full_name customer_name,
  c.phone,
  co.required_at,
  co.fulfillment,
  co.delivery_address,
  ccs.cake_size_label,
  ccs.servings,
  ccs.tiers,
  ccs.flavour,
  ccs.filling,
  ccs.frosting,
  ccs.theme,
  ccs.primary_color,
  ccs.secondary_color,
  ccs.inscription,
  ccs.reference_image_path,
  ccs.special_instructions,
  ccs.production_notes,
  ccs.quote_amount,
  coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0)::numeric(14,2) amount_paid,
  (co.total_amount-coalesce(sum(case when cop.payment_status='completed' then cop.amount else 0 end),0))::numeric(14,2) balance_due,
  ccs.design_status,
  co.status order_status,
  round(ccs.quote_amount*cs.deposit_percent/100,2)::numeric(14,2) deposit_required
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
cross join public.custom_cake_settings cs
left join public.customer_order_payments cop on cop.order_id=co.id
group by
  ccs.id,ccs.order_id,co.order_no,co.customer_id,c.full_name,c.phone,co.required_at,
  co.fulfillment,co.delivery_address,ccs.cake_size_label,ccs.servings,ccs.tiers,
  ccs.flavour,ccs.filling,ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,ccs.production_notes,
  ccs.quote_amount,cs.deposit_percent,ccs.design_status,co.status,co.total_amount;

-- =====================================================================
-- DELIVERY / RIDERS
-- =====================================================================

alter table public.delivery_riders
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_riders_client_request_unique
  on public.delivery_riders(client_request_id)
  where client_request_id is not null;

alter table public.delivery_jobs
  add column if not exists client_request_id uuid;

create unique index if not exists delivery_jobs_client_request_unique
  on public.delivery_jobs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_delivery_rider(
  p_rider_id uuid,
  p_full_name text,
  p_phone text,
  p_vehicle_label text,
  p_active boolean,
  p_notes text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_rider_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage riders';
  end if;
  if coalesce(trim(p_full_name),'')='' or coalesce(trim(p_phone),'')='' then
    raise exception 'Rider name and phone are required';
  end if;

  if p_rider_id is null and p_client_request_id is not null then
    select id into v_existing from public.delivery_riders where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(r) into v_before from public.delivery_riders r where r.id=p_rider_id;

  insert into public.delivery_riders(
    id,full_name,phone,vehicle_label,active,notes,created_by,client_request_id
  )
  values(
    v_id,trim(p_full_name),trim(p_phone),nullif(trim(p_vehicle_label),''),
    coalesce(p_active,true),p_notes,auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    full_name=excluded.full_name,phone=excluded.phone,vehicle_label=excluded.vehicle_label,
    active=excluded.active,notes=excluded.notes,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_rider_id is null then 'create_delivery_rider' else 'update_delivery_rider' end,
    'delivery_rider',v_id,v_before,
    (select to_jsonb(r) from public.delivery_riders r where r.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.create_delivery_job(uuid,numeric,text,timestamptz);

create or replace function public.create_delivery_job(
  p_order_id uuid,
  p_delivery_charge numeric,
  p_address text,
  p_scheduled_for timestamptz default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_customer public.customers%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to create delivery jobs';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.delivery_jobs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_delivery_charge<0 then raise exception 'Delivery charge cannot be negative'; end if;
  if coalesce(trim(p_address),'')='' then raise exception 'Delivery address is required'; end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Customer order not found'; end if;
  if v_order.fulfillment<>'delivery' then raise exception 'Order is not marked for delivery'; end if;
  if v_order.status='cancelled' then raise exception 'Cannot create delivery for cancelled order'; end if;
  if exists(select 1 from public.delivery_jobs where order_id=p_order_id) then
    raise exception 'Delivery job already exists for this order';
  end if;

  select * into v_customer from public.customers where id=v_order.customer_id;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  v_new_total:=greatest(v_order.subtotal-v_order.discount,0)+p_delivery_charge;
  if v_new_total<v_paid then raise exception 'New order total would be less than payments already recorded'; end if;

  update public.customer_orders
  set delivery_charge=p_delivery_charge,delivery_address=trim(p_address),updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.delivery_jobs(
    id,order_id,status,scheduled_for,delivery_address_snapshot,
    customer_name_snapshot,customer_phone_snapshot,delivery_charge,created_by,client_request_id
  )
  values(
    v_id,p_order_id,'pending',coalesce(p_scheduled_for,v_order.required_at),
    trim(p_address),v_customer.full_name,v_customer.phone,p_delivery_charge,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'create_delivery_job','delivery_job',v_id,
    jsonb_build_object(
      'order_id',p_order_id,'delivery_charge',p_delivery_charge,
      'scheduled_for',coalesce(p_scheduled_for,v_order.required_at),
      'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_delivery_status(
  p_delivery_id uuid,
  p_status public.delivery_status,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_job public.delivery_jobs%rowtype;
  v_order public.customer_orders%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to update delivery status';
  end if;

  select * into v_job from public.delivery_jobs where id=p_delivery_id for update;
  if not found then raise exception 'Delivery job not found'; end if;

  select * into v_order from public.customer_orders where id=v_job.order_id for update;

  if p_status='out_for_delivery' then
    if v_job.status not in ('assigned','failed') then raise exception 'Delivery must be assigned or failed before dispatch'; end if;
    if v_job.rider_id is null then raise exception 'Assign a rider before dispatch'; end if;
    if v_order.status<>'ready' then raise exception 'Customer order must be ready before dispatch'; end if;

    update public.delivery_jobs
    set status='out_for_delivery',dispatched_by=auth.uid(),dispatched_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

  elsif p_status='delivered' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may be completed'; end if;

    update public.delivery_jobs
    set status='delivered',delivered_by=auth.uid(),delivered_at=now(),
        outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;

    update public.customer_orders
    set status='completed',completed_at=now(),updated_at=now()
    where id=v_job.order_id;

    update public.custom_cake_specs
    set design_status='completed',updated_at=now()
    where order_id=v_job.order_id;

  elsif p_status='failed' then
    if v_job.status<>'out_for_delivery' then raise exception 'Only out-for-delivery jobs may fail'; end if;
    if coalesce(trim(p_note),'')='' then raise exception 'Failure reason is required'; end if;

    update public.delivery_jobs
    set status='failed',failed_at=now(),outcome_note=trim(p_note),updated_at=now()
    where id=p_delivery_id;

  elsif p_status='cancelled' then
    if public.current_staff_role() not in ('owner','manager') then
      raise exception 'Only owner/manager may cancel a delivery job';
    end if;
    if v_job.status='delivered' then raise exception 'Delivered job cannot be cancelled'; end if;

    update public.delivery_jobs
    set status='cancelled',outcome_note=p_note,updated_at=now()
    where id=p_delivery_id;
  else
    raise exception 'Unsupported delivery status transition';
  end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_delivery_status','delivery_job',p_delivery_id,
    jsonb_build_object('status',v_job.status),
    jsonb_build_object('status',p_status,'note',p_note)
  );
end;
$$;

drop policy if exists "owner manager manage riders" on public.delivery_riders;

create or replace view public.delivery_rider_summary
with (security_invoker=true)
as
select
  dr.id rider_id,dr.full_name,dr.phone,dr.vehicle_label,dr.active,
  count(dj.id) filter(where dj.status in ('assigned','out_for_delivery'))::bigint active_jobs,
  count(dj.id) filter(
    where dj.status='delivered' and public.business_date(dj.delivered_at)=public.business_current_date()
  )::bigint delivered_today
from public.delivery_riders dr
left join public.delivery_jobs dj on dj.rider_id=dr.id
group by dr.id,dr.full_name,dr.phone,dr.vehicle_label,dr.active;

-- =====================================================================
-- LOYALTY / RETENTION
-- =====================================================================

alter table public.loyalty_point_transactions
  add column if not exists value_amount numeric(14,2) not null default 0,
  add column if not exists client_request_id uuid;

create unique index if not exists loyalty_client_request_unique
  on public.loyalty_point_transactions(client_request_id)
  where client_request_id is not null;

drop function if exists public.redeem_loyalty_on_order(uuid,integer);

create or replace function public.redeem_loyalty_on_order(
  p_order_id uuid,
  p_points integer,
  p_client_request_id uuid default null
)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_balance bigint;
  v_reward_points integer;
  v_reward_value numeric(14,2);
  v_units integer;
  v_discount numeric(14,2);
  v_paid numeric(14,2);
  v_existing numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to redeem loyalty rewards';
  end if;

  if p_client_request_id is not null then
    select value_amount into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id and event_type='reward_redemption';
    if v_existing is not null then return v_existing; end if;
  end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_order.status in ('completed','cancelled') then raise exception 'Cannot redeem on a closed order'; end if;

  perform 1 from public.customers where id=v_order.customer_id for update;

  select points_balance into v_balance
  from public.customer_loyalty_balances where customer_id=v_order.customer_id;

  select reward_points,reward_value
  into v_reward_points,v_reward_value
  from public.loyalty_settings where id=1;

  if p_points<=0 or mod(p_points,v_reward_points)<>0 then
    raise exception 'Points must be a positive multiple of the reward-points setting';
  end if;
  if p_points>v_balance then raise exception 'Insufficient loyalty points'; end if;

  v_units:=p_points/v_reward_points;
  v_discount:=v_units*v_reward_value;

  if v_discount>greatest(v_order.subtotal-v_order.discount,0) then
    raise exception 'Reward discount exceeds remaining merchandise value';
  end if;

  select coalesce(sum(amount),0)::numeric(14,2)
  into v_paid
  from public.customer_order_payments
  where order_id=p_order_id and payment_status='completed';

  if greatest(v_order.subtotal-(v_order.discount+v_discount),0)+coalesce(v_order.delivery_charge,0)<v_paid then
    raise exception 'Reward would reduce order total below payments already recorded';
  end if;

  update public.customer_orders
  set discount=discount+v_discount,updated_at=now()
  where id=p_order_id;

  perform public.refresh_customer_order_total(p_order_id);

  insert into public.loyalty_point_transactions(
    customer_id,event_type,points_delta,value_amount,source_type,source_id,
    reason,created_by,client_request_id
  )
  values(
    v_order.customer_id,'reward_redemption',-p_points,v_discount,
    'customer_order',p_order_id,'Loyalty reward applied to customer order',
    auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'redeem_loyalty_reward','customer_order',p_order_id,
    jsonb_build_object('points',p_points,'discount_value',v_discount,'client_request_id',p_client_request_id)
  );

  return v_discount;
end;
$$;

drop function if exists public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type);

create or replace function public.adjust_customer_loyalty_points(
  p_customer_id uuid,
  p_points integer,
  p_reason text,
  p_event_type public.loyalty_event_type default 'manual_adjustment',
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
  v_balance bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manually adjust loyalty points';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.loyalty_point_transactions
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if p_points=0 then raise exception 'Point adjustment cannot be zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Reason is required'; end if;
  if p_event_type not in ('manual_adjustment','birthday_bonus') then
    raise exception 'Unsupported manual event type';
  end if;

  perform 1 from public.customers where id=p_customer_id for update;
  if not found then raise exception 'Customer not found'; end if;

  select points_balance into v_balance
  from public.customer_loyalty_balances
  where customer_id=p_customer_id;

  if coalesce(v_balance,0)+p_points<0 then
    raise exception 'Adjustment would make points negative';
  end if;

  insert into public.loyalty_point_transactions(
    id,customer_id,event_type,points_delta,value_amount,source_type,
    reason,created_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_event_type,p_points,0,'manual',
    trim(p_reason),auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'adjust_loyalty_points','loyalty_transaction',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'points_delta',p_points,
      'reason',p_reason,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

create or replace function public.update_loyalty_settings(
  p_earn_amount_per_point numeric,
  p_reward_points integer,
  p_reward_value numeric,
  p_birthday_reminder_days integer,
  p_vip_spend_threshold numeric,
  p_regular_spend_threshold numeric,
  p_regular_order_threshold integer
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update loyalty settings';
  end if;

  if p_earn_amount_per_point<=0 or p_reward_points<=0 or p_reward_value<0 then
    raise exception 'Invalid loyalty earning/reward settings';
  end if;
  if p_birthday_reminder_days<1 or p_birthday_reminder_days>90 then
    raise exception 'Birthday reminder days must be 1 to 90';
  end if;

  update public.loyalty_settings
  set
    earn_amount_per_point=p_earn_amount_per_point,
    reward_points=p_reward_points,
    reward_value=p_reward_value,
    birthday_reminder_days=p_birthday_reminder_days,
    vip_spend_threshold=p_vip_spend_threshold,
    regular_spend_threshold=p_regular_spend_threshold,
    regular_order_threshold=p_regular_order_threshold,
    updated_by=auth.uid(),updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'update_loyalty_settings','loyalty_settings',null,
    jsonb_build_object(
      'earn_amount_per_point',p_earn_amount_per_point,'reward_points',p_reward_points,
      'reward_value',p_reward_value,'birthday_reminder_days',p_birthday_reminder_days
    )
  );
end;
$$;

drop policy if exists "owner manage loyalty settings" on public.loyalty_settings;

create or replace view public.upcoming_customer_birthdays
with (security_invoker=true)
as
select
  c.id customer_id,c.full_name,c.phone,c.birthday,b.next_birthday,
  (b.next_birthday-public.business_current_date()) days_until_birthday,
  coalesce(lb.points_balance,0) points_balance
from public.customers c
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
cross join lateral (
  select d::date next_birthday
  from generate_series(
    public.business_current_date(),
    public.business_current_date()+interval '1461 days',
    interval '1 day'
  ) d
  where extract(month from d)=extract(month from c.birthday)
    and extract(day from d)=extract(day from c.birthday)
  order by d limit 1
) b
where c.active=true and c.birthday is not null;

create or replace view public.customer_retention_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter(where co.status<>'cancelled')::bigint customer_order_count,
    coalesce(sum(co.total_amount) filter(where co.status<>'cancelled'),0)::numeric(14,2) customer_order_value,
    max(co.created_at) filter(where co.status<>'cancelled') last_customer_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  where c.active=true
  group by c.id
),
pos_stats as (
  select
    c.id customer_id,
    count(s.id) filter(where s.status in ('completed','partially_refunded','refunded'))::bigint pos_sale_count,
    coalesce(sum(
      case when s.status in ('completed','partially_refunded','refunded')
        then greatest(s.total-coalesce(s.refund_total,0),0) else 0 end
    ),0)::numeric(14,2) pos_sale_value,
    max(s.created_at) filter(where s.status in ('completed','partially_refunded','refunded')) last_pos_sale_at
  from public.customers c
  left join public.sales s on s.customer_id=c.id
  where c.active=true
  group by c.id
),
settings as (select * from public.loyalty_settings where id=1)
select
  c.id customer_id,
  c.full_name,
  c.phone,
  c.email,
  c.birthday,
  (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))::bigint order_count,
  (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))::numeric(14,2) lifetime_value,
  greatest(os.last_customer_order_at,ps.last_pos_sale_at) last_order_at,
  coalesce(lb.points_balance,0) points_balance,
  case
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.vip_spend_threshold then 'VIP'
    when (coalesce(os.customer_order_value,0)+coalesce(ps.pos_sale_value,0))>=s.regular_spend_threshold
      or (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=s.regular_order_threshold then 'Regular'
    when (coalesce(os.customer_order_count,0)+coalesce(ps.pos_sale_count,0))>=2 then 'Returning'
    else 'New' end customer_segment,
  coalesce(os.customer_order_count,0)::bigint customer_order_count,
  coalesce(ps.pos_sale_count,0)::bigint pos_sale_count
from public.customers c
join order_stats os on os.customer_id=c.id
join pos_stats ps on ps.customer_id=c.id
cross join settings s
left join public.customer_loyalty_balances lb on lb.customer_id=c.id
where c.active=true;

-- =====================================================================
-- WHATSAPP COMMUNICATION / TEMPLATES
-- =====================================================================

alter table public.communication_templates
  add column if not exists client_request_id uuid;

create unique index if not exists communication_templates_client_request_unique
  on public.communication_templates(client_request_id)
  where client_request_id is not null;

alter table public.communication_logs
  add column if not exists client_request_id uuid;

create unique index if not exists communication_logs_client_request_unique
  on public.communication_logs(client_request_id)
  where client_request_id is not null;

create or replace function public.save_communication_template(
  p_template_id uuid,
  p_name text,
  p_template_type public.communication_template_type,
  p_body_template text,
  p_requires_marketing_opt_in boolean,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_template_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may manage communication templates';
  end if;
  if coalesce(trim(p_name),'')='' or coalesce(trim(p_body_template),'')='' then
    raise exception 'Template name and body are required';
  end if;

  if p_template_id is null and p_client_request_id is not null then
    select id into v_existing from public.communication_templates where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(t) into v_before from public.communication_templates t where t.id=p_template_id;

  insert into public.communication_templates(
    id,name,template_type,body_template,requires_marketing_opt_in,active,created_by,client_request_id
  )
  values(
    v_id,trim(p_name),p_template_type,trim(p_body_template),
    coalesce(p_requires_marketing_opt_in,false),coalesce(p_active,true),auth.uid(),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,template_type=excluded.template_type,body_template=excluded.body_template,
    requires_marketing_opt_in=excluded.requires_marketing_opt_in,active=excluded.active,updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),case when p_template_id is null then 'create_communication_template' else 'update_communication_template' end,
    'communication_template',v_id,v_before,
    (select to_jsonb(t) from public.communication_templates t where t.id=v_id)
  );

  return v_id;
end;
$$;

drop function if exists public.log_whatsapp_open(uuid,uuid,uuid,text,text);

create or replace function public.log_whatsapp_open(
  p_customer_id uuid,
  p_order_id uuid,
  p_template_id uuid,
  p_recipient_phone text,
  p_message text,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_template public.communication_templates%rowtype;
  v_customer public.customers%rowtype;
  v_id uuid:=gen_random_uuid();
  v_existing uuid;
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then
    raise exception 'Not authorized to communicate with customers';
  end if;

  if p_client_request_id is not null then
    select id into v_existing from public.communication_logs where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  if coalesce(trim(p_recipient_phone),'')='' then raise exception 'Recipient phone is required'; end if;
  if coalesce(trim(p_message),'')='' then raise exception 'Message is required'; end if;

  select * into v_customer from public.customers where id=p_customer_id;
  if not found then raise exception 'Customer not found'; end if;

  if p_template_id is not null then
    select * into v_template from public.communication_templates
    where id=p_template_id and active=true;
    if not found then raise exception 'Active communication template not found'; end if;
    if v_template.requires_marketing_opt_in and not v_customer.whatsapp_opt_in then
      raise exception 'Customer has not opted in to marketing WhatsApp contact';
    end if;
  end if;

  if p_order_id is not null and not exists(
    select 1 from public.customer_orders where id=p_order_id and customer_id=p_customer_id
  ) then
    raise exception 'Order does not belong to customer';
  end if;

  insert into public.communication_logs(
    id,customer_id,order_id,template_id,channel,status,
    recipient_phone_snapshot,message_snapshot,initiated_by,client_request_id
  )
  values(
    v_id,p_customer_id,p_order_id,p_template_id,'whatsapp','opened_whatsapp',
    trim(p_recipient_phone),p_message,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'open_whatsapp_message','communication_log',v_id,
    jsonb_build_object(
      'customer_id',p_customer_id,'order_id',p_order_id,
      'template_id',p_template_id,'client_request_id',p_client_request_id
    )
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager manage communication templates" on public.communication_templates;

create or replace view public.communication_log_summary
with (security_invoker=true)
as
select
  cl.id,cl.customer_id,c.full_name customer_name,cl.order_id,co.order_no,
  cl.template_id,ct.name template_name,ct.template_type,
  cl.status,cl.recipient_phone_snapshot,cl.message_snapshot,
  cl.initiated_by,p.full_name initiated_by_name,cl.initiated_at
from public.communication_logs cl
join public.customers c on c.id=cl.customer_id
left join public.customer_orders co on co.id=cl.order_id
left join public.communication_templates ct on ct.id=cl.template_id
left join public.profiles p on p.id=cl.initiated_by;

create or replace view public.customer_communication_queue
with (security_invoker=true)
as
select
  'ready_for_pickup'::text queue_type,100 priority,co.customer_id,c.full_name customer_name,
  c.phone,c.whatsapp_opt_in,co.id order_id,co.order_no,co.required_at due_at,
  cos.balance_due,'Order is ready for pickup'::text reason,null::text rider_name
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='ready' and co.fulfillment='pickup'

union all
select
  'in_production',95,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,'Order is in production',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where co.status='in_production'

union all
select
  'out_for_delivery',90,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,dj.scheduled_for,cos.balance_due,'Order is out for delivery',dr.full_name
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
left join public.delivery_riders dr on dr.id=dj.rider_id
where dj.status='out_for_delivery'

union all
select
  'birthday',50,b.customer_id,b.full_name,b.phone,c.whatsapp_opt_in,
  null::uuid,null::text,b.next_birthday::timestamptz,0::numeric,
  'Birthday in ' || b.days_until_birthday || ' days',null::text
from public.upcoming_customer_birthdays b
join public.customers c on c.id=b.customer_id
join public.loyalty_settings ls on ls.id=1
where b.days_until_birthday between 0 and ls.birthday_reminder_days
  and c.whatsapp_opt_in=true

union all
select
  'balance_reminder',40,co.customer_id,c.full_name,c.phone,c.whatsapp_opt_in,
  co.id,co.order_no,co.required_at,cos.balance_due,
  'Customer order has outstanding balance',null::text
from public.customer_orders co
join public.customers c on c.id=co.customer_id
join public.customer_order_summary cos on cos.id=co.id
where cos.balance_due>0 and co.status<>'cancelled';

-- =====================================================================
-- EXECUTE / DIRECT-WRITE HARDENING
-- =====================================================================

revoke all on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) from public;
revoke all on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) from public;
revoke all on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) from public;
revoke all on function public.update_customer_order_status(uuid,public.customer_order_status,text) from public;
revoke all on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) from public;
revoke all on function public.save_custom_cake_reference_path(uuid,text) from public;
revoke all on function public.quote_custom_cake_order(uuid,numeric,text) from public;
revoke all on function public.approve_custom_cake_for_production(uuid) from public;
revoke all on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) from public;
revoke all on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) from public;
revoke all on function public.assign_delivery_rider(uuid,uuid) from public;
revoke all on function public.update_delivery_status(uuid,public.delivery_status,text) from public;
revoke all on function public.redeem_loyalty_on_order(uuid,integer,uuid) from public;
revoke all on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) from public;
revoke all on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) from public;
revoke all on function public.set_customer_whatsapp_preference(uuid,boolean) from public;
revoke all on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) from public;
revoke all on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) from public;

grant execute on function public.save_customer(uuid,text,text,text,text,date,text,boolean,uuid) to authenticated;
grant execute on function public.create_customer_order(uuid,timestamptz,public.fulfillment_type,text,numeric,text,jsonb,uuid) to authenticated;
grant execute on function public.record_customer_order_payment(uuid,numeric,public.payment_method,text,uuid,uuid) to authenticated;
grant execute on function public.update_customer_order_status(uuid,public.customer_order_status,text) to authenticated;
grant execute on function public.create_custom_cake_order(uuid,timestamptz,public.fulfillment_type,text,text,integer,integer,text,text,text,text,text,text,text,text,uuid) to authenticated;
grant execute on function public.save_custom_cake_reference_path(uuid,text) to authenticated;
grant execute on function public.quote_custom_cake_order(uuid,numeric,text) to authenticated;
grant execute on function public.approve_custom_cake_for_production(uuid) to authenticated;
grant execute on function public.save_delivery_rider(uuid,text,text,text,boolean,text,uuid) to authenticated;
grant execute on function public.create_delivery_job(uuid,numeric,text,timestamptz,uuid) to authenticated;
grant execute on function public.assign_delivery_rider(uuid,uuid) to authenticated;
grant execute on function public.update_delivery_status(uuid,public.delivery_status,text) to authenticated;
grant execute on function public.redeem_loyalty_on_order(uuid,integer,uuid) to authenticated;
grant execute on function public.adjust_customer_loyalty_points(uuid,integer,text,public.loyalty_event_type,uuid) to authenticated;
grant execute on function public.update_loyalty_settings(numeric,integer,numeric,integer,numeric,numeric,integer) to authenticated;
grant execute on function public.set_customer_whatsapp_preference(uuid,boolean) to authenticated;
grant execute on function public.save_communication_template(uuid,text,public.communication_template_type,text,boolean,boolean,uuid) to authenticated;
grant execute on function public.log_whatsapp_open(uuid,uuid,uuid,text,text,uuid) to authenticated;

create index if not exists customer_order_payments_shift_idx
  on public.customer_order_payments(shift_id,paid_at desc);

create index if not exists custom_cake_order_item_idx
  on public.custom_cake_specs(order_item_id);

create index if not exists communication_logs_customer_created_idx
  on public.communication_logs(customer_id,initiated_at desc);


-- ===== INTEGRATION STAGE / MIGRATION 020 =====
-- DS Bakery v0.21 / Migration 020
-- Staff/admin live wiring, customer-order refunds, route permission hardening,
-- live management reporting and business-timezone attendance corrections.

-- =====================================================================
-- CUSTOMER ORDER REFUNDS
-- =====================================================================

create table if not exists public.customer_order_refunds (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  payment_id uuid not null references public.customer_order_payments(id) on delete restrict,
  amount numeric(14,2) not null check(amount>0),
  method public.payment_method not null,
  reference text,
  reason text not null,
  refunded_by uuid not null references public.profiles(id),
  refunded_at timestamptz not null default now(),
  shift_id uuid references public.cashier_shifts(id),
  client_request_id uuid
);

create unique index if not exists customer_order_refunds_request_unique
  on public.customer_order_refunds(client_request_id,payment_id)
  where client_request_id is not null;

alter table public.customer_order_refunds enable row level security;

create policy "management read customer order refunds"
on public.customer_order_refunds
for select using (public.current_staff_role() in ('owner','manager'));

create or replace function public.refund_customer_order(
  p_order_id uuid,
  p_amount numeric,
  p_reason text,
  p_shift_id uuid default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_role public.staff_role;
  v_net_paid numeric(14,2);
  v_remaining numeric(14,2);
  v_payment record;
  v_available numeric(14,2);
  v_alloc numeric(14,2);
  v_group_id uuid:=coalesce(p_client_request_id,gen_random_uuid());
  v_existing uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager') then
    raise exception 'Only owner or manager may refund customer orders';
  end if;
  if p_amount<=0 then raise exception 'Refund amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Refund reason is required'; end if;
  if p_shift_id is not null and not exists(select 1 from public.cashier_shifts where id=p_shift_id and status='open') then
    raise exception 'Selected cashier shift is not open';
  end if;

  if p_client_request_id is not null then
    select id into v_existing
    from public.customer_order_refunds
    where client_request_id=p_client_request_id
    order by refunded_at
    limit 1;
    if v_existing is not null then return v_group_id; end if;
  end if;

  select * into v_order from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Customer order not found'; end if;

  select
    coalesce((select sum(amount) from public.customer_order_payments where order_id=p_order_id and payment_status='completed'),0)
    -
    coalesce((select sum(amount) from public.customer_order_refunds where order_id=p_order_id),0)
  into v_net_paid;

  if p_amount>v_net_paid then raise exception 'Refund exceeds net customer payments'; end if;
  v_remaining:=p_amount;

  -- Reverse latest payments first while preserving each original payment method.
  for v_payment in
    select
      cop.id,cop.method,cop.reference,cop.paid_at,
      cop.amount-coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.payment_id=cop.id),0) as available
    from public.customer_order_payments cop
    where cop.order_id=p_order_id and cop.payment_status='completed'
    order by cop.paid_at desc,cop.id
    for update of cop
  loop
    exit when v_remaining<=0;
    v_available:=greatest(v_payment.available,0);
    if v_available<=0 then continue; end if;
    v_alloc:=least(v_remaining,v_available);

    insert into public.customer_order_refunds(
      order_id,payment_id,amount,method,reference,reason,refunded_by,shift_id,client_request_id
    )
    values(
      p_order_id,v_payment.id,v_alloc,v_payment.method,
      case when v_payment.method='cash' then null else v_payment.reference end,
      trim(p_reason),auth.uid(),
      case when v_payment.method='cash' then p_shift_id else null end,
      v_group_id
    );

    v_remaining:=v_remaining-v_alloc;
  end loop;

  if v_remaining>0 then raise exception 'Unable to allocate full refund'; end if;

  perform public.sync_order_loyalty_points(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'refund_customer_order','customer_order',p_order_id,
    jsonb_build_object('amount',p_amount,'reason',p_reason,'refund_group',v_group_id,'shift_id',p_shift_id)
  );

  return v_group_id;
end;
$$;

-- Net payment helper used by order/status/report logic.
create or replace function public.customer_order_net_paid(p_order_id uuid)
returns numeric
language sql
stable
security definer
set search_path=public
as $$
  select
    coalesce((select sum(amount) from public.customer_order_payments where order_id=p_order_id and payment_status='completed'),0)
    -
    coalesce((select sum(amount) from public.customer_order_refunds where order_id=p_order_id),0)
$$;

-- Customer-order loyalty now uses net payments after refunds.
create or replace function public.sync_order_loyalty_points(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.customer_orders%rowtype;
  v_rate numeric(14,2);
  v_paid numeric(14,2);
  v_expected integer;
  v_current integer;
  v_delta integer;
begin
  select * into v_order from public.customer_orders where id=p_order_id;
  if not found then return; end if;

  select earn_amount_per_point into v_rate from public.loyalty_settings where id=1;
  v_paid:=public.customer_order_net_paid(p_order_id);

  if v_order.status='completed' and v_paid>=v_order.total_amount then
    v_expected:=floor(v_order.total_amount/v_rate)::integer;
  else
    v_expected:=0;
  end if;

  select coalesce(sum(points_delta),0)::integer into v_current
  from public.loyalty_point_transactions
  where customer_id=v_order.customer_id
    and source_type='customer_order'
    and source_id=p_order_id
    and event_type in ('order_earn','refund_adjustment');

  v_delta:=v_expected-v_current;

  if v_delta<>0 then
    insert into public.loyalty_point_transactions(
      customer_id,event_type,points_delta,source_type,source_id,reason,created_by
    )
    values(
      v_order.customer_id,
      case when v_delta>0 then 'order_earn'::public.loyalty_event_type
           else 'refund_adjustment'::public.loyalty_event_type end,
      v_delta,'customer_order',p_order_id,
      case when v_delta>0 then 'Points earned from paid completed customer order'
           else 'Points adjusted after customer-order refund/status change' end,
      auth.uid()
    );
  end if;
end;
$$;

create or replace function public.trg_sync_order_refund_loyalty()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.sync_order_loyalty_points(new.order_id);
  return new;
end;
$$;

drop trigger if exists trg_order_refunds_loyalty_sync on public.customer_order_refunds;
create trigger trg_order_refunds_loyalty_sync
after insert on public.customer_order_refunds
for each row execute function public.trg_sync_order_refund_loyalty();

-- Recreate customer order summary with net payments and refunded total.
create or replace view public.customer_order_summary
with (security_invoker=true)
as
with items as (
  select coi.order_id,count(*)::bigint item_count,
    string_agg(coi.description || ' × ' || trim(to_char(coi.quantity,'FM999999990.###')),', ' order by coi.created_at) item_summary
  from public.customer_order_items coi group by coi.order_id
),
paid as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) gross_paid
  from public.customer_order_payments where payment_status='completed' group by order_id
),
refunded as (
  select order_id,coalesce(sum(amount),0)::numeric(14,2) refunded_amount
  from public.customer_order_refunds group by order_id
)
select
  co.id,co.order_no,co.customer_id,c.full_name customer_name,c.phone,
  co.status,co.fulfillment,co.required_at,co.delivery_address,co.total_amount,
  (coalesce(pa.gross_paid,0)-coalesce(rf.refunded_amount,0))::numeric(14,2) amount_paid,
  (co.total_amount-(coalesce(pa.gross_paid,0)-coalesce(rf.refunded_amount,0)))::numeric(14,2) balance_due,
  co.created_at,co.updated_at,co.delivery_charge,co.subtotal,co.discount,
  coalesce(i.item_count,0)::bigint item_count,coalesce(i.item_summary,'') item_summary,co.notes,
  coalesce(rf.refunded_amount,0)::numeric(14,2) refunded_amount
from public.customer_orders co
join public.customers c on c.id=co.customer_id
left join items i on i.order_id=co.id
left join paid pa on pa.order_id=co.id
left join refunded rf on rf.order_id=co.id;


-- Customer profile outstanding balances use net customer-order payments after refunds.
create or replace view public.customer_summary
with (security_invoker=true)
as
with order_stats as (
  select
    c.id customer_id,
    count(co.id) filter(where co.status<>'cancelled')::bigint order_count,
    coalesce(sum(co.total_amount) filter(where co.status<>'cancelled'),0)::numeric(14,2) total_order_value,
    coalesce(sum(
      case when co.status<>'cancelled'
        then co.total_amount-public.customer_order_net_paid(co.id)
        else 0 end
    ),0)::numeric(14,2) outstanding_balance,
    max(co.created_at) filter(where co.status<>'cancelled') last_order_at
  from public.customers c
  left join public.customer_orders co on co.customer_id=c.id
  group by c.id
)
select
  c.id customer_id,c.full_name,c.phone,c.email,
  coalesce(os.order_count,0) order_count,
  coalesce(os.total_order_value,0)::numeric(14,2) total_order_value,
  coalesce(os.outstanding_balance,0)::numeric(14,2) outstanding_balance,
  os.last_order_at,c.address,c.birthday,c.notes,c.whatsapp_opt_in
from public.customers c
left join order_stats os on os.customer_id=c.id
where c.active=true;

-- Recreate cake summary with net payments after refunds.
create or replace view public.custom_cake_order_summary
with (security_invoker=true)
as
select
  ccs.id custom_cake_id,ccs.order_id,co.order_no,co.customer_id,c.full_name customer_name,c.phone,
  co.required_at,co.fulfillment,co.delivery_address,ccs.cake_size_label,ccs.servings,ccs.tiers,
  ccs.flavour,ccs.filling,ccs.frosting,ccs.theme,ccs.primary_color,ccs.secondary_color,
  ccs.inscription,ccs.reference_image_path,ccs.special_instructions,ccs.production_notes,
  ccs.quote_amount,
  public.customer_order_net_paid(co.id)::numeric(14,2) amount_paid,
  (co.total_amount-public.customer_order_net_paid(co.id))::numeric(14,2) balance_due,
  ccs.design_status,co.status order_status,
  round(ccs.quote_amount*cs.deposit_percent/100,2)::numeric(14,2) deposit_required
from public.custom_cake_specs ccs
join public.customer_orders co on co.id=ccs.order_id
join public.customers c on c.id=co.customer_id
cross join public.custom_cake_settings cs;

-- Cancellation is allowed only after net customer payments have been fully refunded.
create or replace function public.update_customer_order_status(
  p_order_id uuid,
  p_status public.customer_order_status,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.customer_orders%rowtype;
  v_role public.staff_role;
  v_paid numeric(14,2);
  v_valid boolean:=false;
  v_cake_status public.custom_cake_design_status;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;

  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_before.status in ('completed','cancelled') then raise exception 'Order is already closed'; end if;
  if p_status=v_before.status then return; end if;

  if p_status='cancelled' then
    if v_role not in ('owner','manager','cashier') then raise exception 'Baker cannot cancel customer orders'; end if;
    if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;
    v_paid:=public.customer_order_net_paid(p_order_id);
    if v_paid>0 then raise exception 'Refund all recorded customer payments before cancellation'; end if;
    v_valid:=true;
  elsif v_role='baker' then
    v_valid:=(v_before.status='confirmed' and p_status='in_production')
      or (v_before.status='in_production' and p_status='ready');
  elsif v_role='cashier' then
    v_valid:=(v_before.status='pending' and p_status='confirmed')
      or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  else
    v_valid:=(v_before.status='pending' and p_status='confirmed')
      or (v_before.status='confirmed' and p_status='in_production')
      or (v_before.status='in_production' and p_status='ready')
      or (v_before.status='ready' and p_status='completed' and v_before.fulfillment='pickup');
  end if;

  if not v_valid then raise exception 'Invalid order status transition'; end if;

  if p_status='in_production' and exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    select design_status into v_cake_status from public.custom_cake_specs where order_id=p_order_id;
    if v_cake_status<>'approved' then raise exception 'Custom cake must be approved before production'; end if;
  end if;
  if p_status='completed' and v_before.fulfillment='delivery' then
    raise exception 'Delivery orders are completed through the delivery workflow';
  end if;

  update public.customer_orders
  set status=p_status,
      completed_at=case when p_status='completed' then now() else completed_at end,
      cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
      cancellation_reason=case when p_status='cancelled' then trim(p_reason) else cancellation_reason end,
      updated_at=now()
  where id=p_order_id;

  if exists(select 1 from public.custom_cake_specs where order_id=p_order_id) then
    update public.custom_cake_specs
    set design_status=case
      when p_status='in_production' then 'in_production'::public.custom_cake_design_status
      when p_status='ready' then 'ready'::public.custom_cake_design_status
      when p_status='completed' then 'completed'::public.custom_cake_design_status
      when p_status='cancelled' then 'cancelled'::public.custom_cake_design_status
      else design_status end,
      updated_at=now()
    where order_id=p_order_id;
  end if;

  perform public.sync_order_loyalty_points(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'update_customer_order_status','customer_order',p_order_id,
    jsonb_build_object('status',v_before.status),
    jsonb_build_object('status',p_status,'reason',p_reason));
end;
$$;



-- Delivery balances also use net order payments after refunds.
create or replace view public.delivery_job_summary
with (security_invoker=true)
as
select
  dj.id,dj.order_id,co.order_no,co.customer_id,
  dj.customer_name_snapshot customer_name,dj.customer_phone_snapshot customer_phone,
  dj.delivery_address_snapshot delivery_address,dj.scheduled_for,dj.delivery_charge,dj.status,
  dj.rider_id,dr.full_name rider_name,dr.phone rider_phone,co.total_amount,
  public.customer_order_net_paid(co.id)::numeric(14,2) amount_paid,
  (co.total_amount-public.customer_order_net_paid(co.id))::numeric(14,2) balance_due,
  dj.assigned_at,dj.dispatched_at,dj.delivered_at,dj.failed_at,dj.outcome_note
from public.delivery_jobs dj
join public.customer_orders co on co.id=dj.order_id
left join public.delivery_riders dr on dr.id=dj.rider_id;

-- Cashier till reconciliation subtracts customer-order cash refunds linked to that till.
create or replace view public.cashier_shift_summary
with (security_invoker=true)
as
select
  cs.id,cs.cashier_id,p.full_name cashier_name,cs.opened_at,cs.opening_float,cs.status,cs.closed_at,
  (select count(*)::bigint from public.sales s where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')) transaction_count,
  coalesce((select sum(s.total-coalesce(s.refund_total,0)) from public.sales s where s.shift_id=cs.id and s.status in ('completed','partially_refunded','refunded')),0)::numeric(14,2) gross_sales,
  (
    coalesce((select sum(py.amount) from public.payments py join public.sales s on s.id=py.sale_id where s.shift_id=cs.id and py.status='completed' and py.method='cash'),0)
    -coalesce((select sum(sr.amount) from public.sale_refunds sr join public.sales s on s.id=sr.sale_id where s.shift_id=cs.id and sr.method='cash'),0)
  )::numeric(14,2) cash_sales,
  (
    coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
    -coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.shift_id=cs.id and cor.method='cash'),0)
  )::numeric(14,2) order_cash_receipts,
  coalesce((select sum(case when cm.movement_type='cash_in' then cm.amount else 0 end) from public.cash_movements cm where cm.shift_id=cs.id),0)::numeric(14,2) cash_in,
  coalesce((select sum(case when cm.movement_type='cash_out' then cm.amount else 0 end) from public.cash_movements cm where cm.shift_id=cs.id),0)::numeric(14,2) cash_out,
  coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)::numeric(14,2) cash_expenses,
  coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)::numeric(14,2) supplier_cash_payments,
  (
    cs.opening_float
    +(coalesce((select sum(py.amount) from public.payments py join public.sales s on s.id=py.sale_id where s.shift_id=cs.id and py.status='completed' and py.method='cash'),0)
      -coalesce((select sum(sr.amount) from public.sale_refunds sr join public.sales s on s.id=sr.sale_id where s.shift_id=cs.id and sr.method='cash'),0))
    +(coalesce((select sum(cop.amount) from public.customer_order_payments cop where cop.shift_id=cs.id and cop.payment_status='completed' and cop.method='cash'),0)
      -coalesce((select sum(cor.amount) from public.customer_order_refunds cor where cor.shift_id=cs.id and cor.method='cash'),0))
    +coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_in'),0)
    -coalesce((select sum(cm.amount) from public.cash_movements cm where cm.shift_id=cs.id and cm.movement_type='cash_out'),0)
    -coalesce((select sum(e.amount) from public.expenses e where e.shift_id=cs.id and e.payment_method='cash'),0)
    -coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.shift_id=cs.id and lower(pp.method)='cash'),0)
  )::numeric(14,2) expected_cash
from public.cashier_shifts cs
join public.profiles p on p.id=cs.cashier_id;


-- Custom-cake quote/deposit checks use net customer payments after refunds.
create or replace function public.quote_custom_cake_order(
  p_order_id uuid,p_quote_amount numeric,p_production_notes text default null
)
returns void language plpgsql security definer set search_path=public as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_order public.customer_orders%rowtype;
  v_paid numeric(14,2);
  v_new_total numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager','cashier') then raise exception 'Not authorized to quote custom cakes'; end if;
  if p_quote_amount<=0 then raise exception 'Quote amount must be greater than zero'; end if;
  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  select * into v_order from public.customer_orders where id=p_order_id for update;
  v_paid:=public.customer_order_net_paid(p_order_id);
  v_new_total:=greatest(p_quote_amount-v_order.discount,0)+v_order.delivery_charge;
  if v_new_total<v_paid then raise exception 'Quote would reduce order total below net payments already retained'; end if;

  update public.customer_order_items set unit_price=p_quote_amount,line_total=p_quote_amount where id=v_spec.order_item_id;
  update public.custom_cake_specs
  set quote_amount=p_quote_amount,production_notes=coalesce(p_production_notes,production_notes),
      design_status=case when v_paid>0 then 'awaiting_deposit'::public.custom_cake_design_status else 'quoted'::public.custom_cake_design_status end,
      updated_at=now()
  where order_id=p_order_id;
  perform public.refresh_customer_order_total(p_order_id);

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'quote_custom_cake','custom_cake_spec',v_spec.id,jsonb_build_object('order_id',p_order_id,'quote_amount',p_quote_amount,'net_paid',v_paid));
end;
$$;

create or replace function public.approve_custom_cake_for_production(p_order_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare
  v_spec public.custom_cake_specs%rowtype;
  v_paid numeric(14,2); v_pct numeric(5,2); v_required numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve custom cake for production'; end if;
  select * into v_spec from public.custom_cake_specs where order_id=p_order_id for update;
  if not found then raise exception 'Custom cake specification not found'; end if;
  if v_spec.quote_amount<=0 then raise exception 'Custom cake has no valid quote'; end if;
  v_paid:=public.customer_order_net_paid(p_order_id);
  select deposit_percent into v_pct from public.custom_cake_settings where id=1;
  v_required:=round(v_spec.quote_amount*coalesce(v_pct,50)/100,2);
  if v_paid<v_required then raise exception 'Required net deposit has not been reached'; end if;

  update public.custom_cake_specs set design_status='approved',production_approved_by=auth.uid(),production_approved_at=now(),updated_at=now() where order_id=p_order_id;
  update public.customer_orders set status='confirmed',updated_at=now() where id=p_order_id and status='pending';

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'approve_custom_cake_for_production','custom_cake_spec',v_spec.id,
    jsonb_build_object('order_id',p_order_id,'quote_amount',v_spec.quote_amount,'net_paid',v_paid,'deposit_required',v_required));
end;
$$;

-- =====================================================================
-- BUSINESS-TIMEZONE ATTENDANCE / SCHEDULING
-- =====================================================================

alter table public.staff_work_shifts
  add column if not exists client_request_id uuid;

create unique index if not exists staff_work_shift_request_unique
  on public.staff_work_shifts(client_request_id)
  where client_request_id is not null;

create or replace function public.business_local_time()
returns time
language sql
stable
security definer
set search_path=public
as $$
  select (now() at time zone coalesce((select business_timezone from public.business_settings where id=1),'UTC'))::time
$$;

create or replace function public.clock_in_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_shift public.staff_work_shifts%rowtype;
  v_id uuid;
  v_grace integer;
  v_scheduled timestamptz;
  v_now_local timestamp;
  v_late integer;
  v_tz text;
  v_date date:=public.business_current_date();
begin
  if not public.is_active_staff() then raise exception 'Active staff account required'; end if;

  select * into v_shift
  from public.staff_work_shifts
  where staff_id=auth.uid() and shift_date=v_date and status='scheduled'
  order by scheduled_start limit 1 for update;

  if not found then raise exception 'No scheduled work shift found for today'; end if;
  if exists(select 1 from public.attendance_records where shift_id=v_shift.id and clock_in_at is not null) then
    raise exception 'Already clocked in for this shift';
  end if;

  select late_grace_minutes into v_grace from public.attendance_settings where id=1;
  select business_timezone into v_tz from public.business_settings where id=1;
  v_tz:=coalesce(v_tz,'UTC');
  v_now_local:=now() at time zone v_tz;
  v_scheduled:=(v_shift.shift_date+v_shift.scheduled_start) at time zone v_tz;

  v_late:=greatest(0,floor(extract(epoch from (now()-v_scheduled))/60)::integer-coalesce(v_grace,0));

  insert into public.attendance_records(shift_id,staff_id,clock_in_at,status,late_minutes)
  values(v_shift.id,auth.uid(),now(),
    case when v_late>0 then 'late'::public.attendance_status else 'on_time'::public.attendance_status end,
    v_late)
  returning id into v_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'clock_in','attendance_record',v_id,jsonb_build_object('shift_id',v_shift.id,'late_minutes',v_late));

  return v_id;
end;
$$;

create or replace function public.clock_out_staff()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare v_record public.attendance_records%rowtype;
begin
  select ar.* into v_record
  from public.attendance_records ar
  join public.staff_work_shifts sws on sws.id=ar.shift_id
  where ar.staff_id=auth.uid()
    and sws.shift_date=public.business_current_date()
    and ar.clock_in_at is not null and ar.clock_out_at is null
  order by ar.clock_in_at desc limit 1 for update of ar;

  if not found then raise exception 'No open attendance record found'; end if;

  update public.attendance_records set clock_out_at=now(),status='completed',updated_at=now() where id=v_record.id;
  update public.staff_work_shifts set status='completed',updated_at=now() where id=v_record.shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'clock_out','attendance_record',v_record.id,jsonb_build_object('clock_out_at',now()));

  return v_record.id;
end;
$$;

create or replace view public.attendance_today
with (security_invoker=true)
as
select
  sws.id shift_id,sws.staff_id,p.full_name,p.role,sws.shift_date,
  sws.scheduled_start,sws.scheduled_end,sws.work_station,
  ar.id attendance_id,ar.clock_in_at,ar.clock_out_at,ar.status attendance_status,
  coalesce(ar.late_minutes,0) late_minutes,
  case
    when ar.id is not null then ar.status::text
    when public.business_local_time()>sws.scheduled_end then 'absent'
    else 'scheduled'
  end display_status
from public.staff_work_shifts sws
join public.profiles p on p.id=sws.staff_id
left join public.attendance_records ar on ar.shift_id=sws.id
where sws.shift_date=public.business_current_date()
  and sws.status<>'cancelled';

create or replace function public.my_attendance_status_today()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select coalesce((
    select jsonb_build_object(
      'shift_id',sws.id,'scheduled_start',sws.scheduled_start,'scheduled_end',sws.scheduled_end,
      'clock_in_at',ar.clock_in_at,'clock_out_at',ar.clock_out_at,'status',ar.status
    )
    from public.staff_work_shifts sws
    left join public.attendance_records ar on ar.shift_id=sws.id
    where sws.staff_id=auth.uid() and sws.shift_date=public.business_current_date() and sws.status<>'cancelled'
    order by sws.scheduled_start limit 1
  ),'{}'::jsonb)
$$;

create or replace function public.create_staff_work_shift(
  p_staff_id uuid,
  p_shift_date date,
  p_scheduled_start time,
  p_scheduled_end time,
  p_work_station text default null,
  p_notes text default null,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare v_id uuid:=gen_random_uuid(); v_existing uuid;
begin
  if not public.staff_has_permission('schedule:manage') then raise exception 'Schedule management permission required'; end if;
  if p_shift_date is null or p_scheduled_start is null or p_scheduled_end is null then raise exception 'Date/start/end are required'; end if;
  if p_scheduled_end<=p_scheduled_start then raise exception 'Shift end must be later than start'; end if;
  if not exists(select 1 from public.profiles where id=p_staff_id and active=true) then raise exception 'Active staff member not found'; end if;

  if p_client_request_id is not null then
    select id into v_existing from public.staff_work_shifts where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  insert into public.staff_work_shifts(
    id,staff_id,shift_date,scheduled_start,scheduled_end,work_station,status,notes,created_by,client_request_id
  ) values(
    v_id,p_staff_id,p_shift_date,p_scheduled_start,p_scheduled_end,nullif(trim(p_work_station),''),'scheduled',p_notes,auth.uid(),p_client_request_id
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'create_staff_shift','staff_work_shift',v_id,
    jsonb_build_object('staff_id',p_staff_id,'shift_date',p_shift_date,'start',p_scheduled_start,'end',p_scheduled_end,'station',p_work_station));

  return v_id;
end;
$$;

create or replace function public.cancel_staff_work_shift(p_shift_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_shift public.staff_work_shifts%rowtype;
begin
  if not public.staff_has_permission('schedule:manage') then raise exception 'Schedule management permission required'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Cancellation reason is required'; end if;

  select * into v_shift from public.staff_work_shifts where id=p_shift_id for update;
  if not found then raise exception 'Shift not found'; end if;
  if v_shift.status<>'scheduled' then raise exception 'Only scheduled shifts may be cancelled'; end if;
  if exists(select 1 from public.attendance_records where shift_id=p_shift_id and clock_in_at is not null) then
    raise exception 'Cannot cancel a shift after clock-in';
  end if;

  update public.staff_work_shifts set status='cancelled',notes=concat_ws(' | ',notes,'Cancelled: '||trim(p_reason)),updated_at=now() where id=p_shift_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'cancel_staff_shift','staff_work_shift',p_shift_id,
    jsonb_build_object('status',v_shift.status),jsonb_build_object('status','cancelled','reason',p_reason));
end;
$$;

create or replace function public.update_attendance_settings(p_late_grace_minutes integer)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.staff_has_permission('attendance:manage') then raise exception 'Attendance management permission required'; end if;
  if p_late_grace_minutes<0 or p_late_grace_minutes>120 then raise exception 'Grace period must be between 0 and 120 minutes'; end if;

  update public.attendance_settings set late_grace_minutes=p_late_grace_minutes,updated_by=auth.uid(),updated_at=now() where id=1;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'update_attendance_settings','attendance_settings',null,jsonb_build_object('late_grace_minutes',p_late_grace_minutes));
end;
$$;

-- =====================================================================
-- INDIVIDUAL PERMISSION HARDENING
-- =====================================================================

drop function if exists public.set_staff_permission_override(uuid,text,boolean);

create or replace function public.set_staff_permission_override(
  p_staff_id uuid,
  p_permission_key text,
  p_allowed boolean,
  p_reason text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_old public.staff_permission_overrides%rowtype;
begin
  if public.current_staff_role()<>'owner' then raise exception 'Only owner may set individual permission overrides'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Override reason is required'; end if;
  if not exists(select 1 from public.profiles where id=p_staff_id and active=true and role<>'owner') then
    raise exception 'Active non-owner staff profile not found';
  end if;
  if not exists(select 1 from public.app_permissions where permission_key=p_permission_key) then raise exception 'Unknown permission key'; end if;

  select * into v_old from public.staff_permission_overrides where staff_id=p_staff_id and permission_key=p_permission_key;

  insert into public.staff_permission_overrides(staff_id,permission_key,allowed,set_by,set_at,reason)
  values(p_staff_id,p_permission_key,p_allowed,auth.uid(),now(),trim(p_reason))
  on conflict(staff_id,permission_key) do update set
    allowed=excluded.allowed,set_by=excluded.set_by,set_at=excluded.set_at,reason=excluded.reason;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'set_permission_override','profile',p_staff_id,
    case when v_old.staff_id is null then null else jsonb_build_object('permission_key',p_permission_key,'allowed',v_old.allowed,'reason',v_old.reason) end,
    jsonb_build_object('permission_key',p_permission_key,'allowed',p_allowed,'reason',p_reason));
end;
$$;

create or replace function public.effective_staff_permissions(p_staff_id uuid)
returns table(
  permission_key text,description text,critical boolean,role_default boolean,
  individual_override boolean,has_override boolean,effective_allowed boolean
)
language sql
security definer
set search_path=public
as $$
  select ap.permission_key,ap.description,ap.critical,coalesce(rpd.allowed,false),
    spo.allowed,(spo.staff_id is not null),coalesce(spo.allowed,rpd.allowed,false)
  from public.profiles p
  cross join public.app_permissions ap
  left join public.role_permission_defaults rpd on rpd.role=p.role and rpd.permission_key=ap.permission_key
  left join public.staff_permission_overrides spo on spo.staff_id=p.id and spo.permission_key=ap.permission_key
  where p.id=p_staff_id
    and (p.id=auth.uid() or public.current_staff_role()='owner')
$$;

-- =====================================================================
-- STAFF / AUDIT / LIVE MANAGEMENT REPORTING
-- =====================================================================

create or replace view public.audit_log_summary
with (security_invoker=true)
as
select
  al.id,al.created_at,al.actor_id,p.full_name actor_name,p.role actor_role,
  al.action,al.entity,al.entity_id,al.before_data,al.after_data
from public.audit_logs al
left join public.profiles p on p.id=al.actor_id;

create or replace function public.management_report_v2(p_period text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_start timestamptz;
  v_end timestamptz:=now();
  v_days integer;
  v_summary jsonb;
  v_products jsonb;
  v_payments jsonb;
  v_expenses jsonb;
begin
  if not public.staff_has_permission('reports:view') then raise exception 'Reports permission required'; end if;
  if p_period='week' then v_days:=7;
  elsif p_period='month' then v_days:=30;
  else raise exception 'Period must be week or month'; end if;
  v_start:=now()-(v_days||' days')::interval;

  select jsonb_build_object(
    'sales',coalesce(sum(s.total-coalesce(s.refund_total,0)),0),
    'cogs',coalesce((select sum(cogs_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'gross_profit',coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'expenses',coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end),0),
    'operating_profit',
      coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0)
      -coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end),0),
    'purchases',coalesce((select sum(total_amount) from public.purchases p where p.created_at>=v_start and p.created_at<v_end and p.status<>'cancelled'),0),
    'waste_cost',coalesce((select sum(total_cost) from public.waste_events w where w.recorded_at>=v_start and w.recorded_at<v_end and w.approval_status='approved'),0),
    'transactions',count(*) filter(where s.status in ('completed','partially_refunded','refunded')),
    'customer_order_value',coalesce((select sum(total_amount) from public.customer_orders co where co.created_at>=v_start and co.created_at<v_end and co.status<>'cancelled'),0),
    'customer_order_outstanding',coalesce((select sum(balance_due) from public.customer_order_summary where status<>'cancelled'),0),
    'supplier_outstanding',coalesce((select sum(outstanding_balance) from public.supplier_account_summary),0),
    'supplier_overdue',coalesce((select sum(overdue_balance) from public.supplier_account_summary),0),
    'production_planned',coalesce((select sum(planned_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0),
    'production_produced',coalesce((select sum(produced_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0)
  ) into v_summary
  from public.sales s
  where s.created_at>=v_start and s.created_at<v_end;

  select coalesce(jsonb_agg(x order by x.sales_amount desc),'[]'::jsonb)
  into v_products
  from (
    select product_id,product_name,sum(quantity) units,sum(sales_amount) sales_amount,sum(gross_profit_amount) gross_profit
    from public.sale_profit_lines
    where created_at>=v_start and created_at<v_end
    group by product_id,product_name
    order by sales_amount desc limit 10
  ) x;

  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb)
  into v_payments
  from (
    select method::text method,sum(amount) amount
    from public.payments
    where created_at>=v_start and created_at<v_end and status='completed'
    group by method
  ) x;

  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb)
  into v_expenses
  from (
    select category,sum(amount) amount
    from public.expenses
    where created_at>=v_start and created_at<v_end
    group by category
  ) x;

  return jsonb_build_object('summary',v_summary,'products',v_products,'payments',v_payments,'expenses',v_expenses);
end;
$$;

-- =====================================================================
-- DAILY CLOSING: SUBTRACT CUSTOMER ORDER REFUNDS BY PAYMENT METHOD
-- =====================================================================

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_opening numeric(14,2); v_pos_cash numeric(14,2); v_pos_mtn numeric(14,2); v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2); v_mtn_refunds numeric(14,2); v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2); v_order_mtn numeric(14,2); v_order_airtel numeric(14,2);
  v_order_refund_cash numeric(14,2); v_order_refund_mtn numeric(14,2); v_order_refund_airtel numeric(14,2);
  v_supplier_cash numeric(14,2); v_supplier_mtn numeric(14,2); v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2); v_cash_out numeric(14,2); v_cash_exp numeric(14,2); v_momo_exp numeric(14,2);
  v_tx_count integer; v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager can prepare daily closing'; end if;

  select coalesce(sum(opening_float),0) into v_opening from public.cashier_shifts where public.business_date(opened_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_pos_cash,v_pos_mtn,v_pos_airtel
  from public.payments where status='completed' and public.business_date(created_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_cash_refunds,v_mtn_refunds,v_airtel_refunds
  from public.sale_refunds where public.business_date(refunded_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_cash,v_order_mtn,v_order_airtel
  from public.customer_order_payments where payment_status='completed' and public.business_date(paid_at)=p_business_date;

  select coalesce(sum(case when method='cash' then amount else 0 end),0),
         coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when method='airtel_money' then amount else 0 end),0)
  into v_order_refund_cash,v_order_refund_mtn,v_order_refund_airtel
  from public.customer_order_refunds where public.business_date(refunded_at)=p_business_date;

  select coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),
         coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),
         coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0)
  into v_supplier_cash,v_supplier_mtn,v_supplier_airtel
  from public.purchase_payments where public.business_date(paid_at)=p_business_date;

  select coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),
         coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0)
  into v_cash_in,v_cash_out from public.cash_movements where public.business_date(created_at)=p_business_date;

  select coalesce(sum(case when payment_method='cash' then amount else 0 end),0),
         coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0)
  into v_cash_exp,v_momo_exp from public.expenses where public.business_date(created_at)=p_business_date;

  select count(*) filter(where status in ('completed','partially_refunded','refunded')),
         coalesce(sum(case when status in ('completed','partially_refunded','refunded') then total-coalesce(refund_total,0) else 0 end),0)
  into v_tx_count,v_pos_sales from public.sales where public.business_date(created_at)=p_business_date;

  return jsonb_build_object(
    'business_date',p_business_date,'opening_float',v_opening,
    'cash_sales',v_pos_cash-v_cash_refunds,'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash-v_order_refund_cash,
    'mtn_order_receipts',v_order_mtn-v_order_refund_mtn,
    'airtel_order_receipts',v_order_airtel-v_order_refund_airtel,
    'cash_order_refunds',v_order_refund_cash,'mtn_order_refunds',v_order_refund_mtn,'airtel_order_refunds',v_order_refund_airtel,
    'cash_supplier_payments',v_supplier_cash,'mtn_supplier_payments',v_supplier_mtn,'airtel_supplier_payments',v_supplier_airtel,
    'cash_in',v_cash_in,'cash_out',v_cash_out,'cash_expenses',v_cash_exp,'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_pos_cash-v_cash_refunds)+(v_order_cash-v_order_refund_cash)+v_cash_in-v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,'total_sales',v_pos_sales,
    'customer_order_receipts',(v_order_cash+v_order_mtn+v_order_airtel)-(v_order_refund_cash+v_order_refund_mtn+v_order_refund_airtel)
  );
end;
$$;

-- =====================================================================
-- RPC EXECUTE HARDENING
-- =====================================================================

revoke all on function public.refund_customer_order(uuid,numeric,text,uuid,uuid) from public;
revoke all on function public.customer_order_net_paid(uuid) from public;
revoke all on function public.business_local_time() from public;
revoke all on function public.my_attendance_status_today() from public;
revoke all on function public.create_staff_work_shift(uuid,date,time,time,text,text,uuid) from public;
revoke all on function public.cancel_staff_work_shift(uuid,text) from public;
revoke all on function public.update_attendance_settings(integer) from public;
revoke all on function public.set_staff_permission_override(uuid,text,boolean,text) from public;
revoke all on function public.management_report_v2(text) from public;

grant execute on function public.refund_customer_order(uuid,numeric,text,uuid,uuid) to authenticated;
grant execute on function public.customer_order_net_paid(uuid) to authenticated;
grant execute on function public.business_local_time() to authenticated;
grant execute on function public.my_attendance_status_today() to authenticated;
grant execute on function public.create_staff_work_shift(uuid,date,time,time,text,text,uuid) to authenticated;
grant execute on function public.cancel_staff_work_shift(uuid,text) to authenticated;
grant execute on function public.update_attendance_settings(integer) to authenticated;
grant execute on function public.set_staff_permission_override(uuid,text,boolean,text) to authenticated;
grant execute on function public.management_report_v2(text) to authenticated;

create index if not exists customer_order_refunds_order_idx on public.customer_order_refunds(order_id,refunded_at desc);


-- ===== INTEGRATION STAGE / MIGRATION 021 =====
-- DS Bakery v0.22 / Migration 021
-- Production validation and launch-readiness diagnostics.
-- This migration is intentionally read-mostly: it adds release metadata and
-- owner-visible integrity checks without changing normal business workflows.

create table if not exists public.system_release_state (
  id integer primary key default 1 check(id=1),
  app_version text not null,
  latest_migration integer not null,
  release_stage text not null,
  updated_at timestamptz not null default now()
);

insert into public.system_release_state(id,app_version,latest_migration,release_stage)
values(1,'0.22.0',21,'production_validation')
on conflict(id) do update set
  app_version=excluded.app_version,
  latest_migration=excluded.latest_migration,
  release_stage=excluded.release_stage,
  updated_at=now();

alter table public.system_release_state enable row level security;

drop policy if exists "active staff read release state" on public.system_release_state;
create policy "active staff read release state"
on public.system_release_state
for select using(public.is_active_staff());

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  -- Exactly one or more active owners must exist.
  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1
      then v_owner_count::text || ' active owner account(s)'
      else 'No active owner account exists' end;

  -- Business timezone must be set to a real IANA timezone.
  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  -- Each active product may have at most one active recipe.
  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  -- No negative raw-material stock.
  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  -- Purchase totals should match lines, discount and recorded payments.
  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  -- Customer-order net paid cannot be negative or materially over total.
  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  -- Waste linked to a production run should never exceed run output.
  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  -- Duplicate Mobile Money references from legacy history must be reviewed.
  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  -- Long-open till shifts are a warning, not an automatic failure.
  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  -- Scheduled work shifts left behind in the past are operational cleanup warnings.
  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  -- Storage bucket should exist and remain private when Supabase Storage is installed.
  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  -- Release metadata.
  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.22.0' and latest_migration=21
    ) then 'pass' else 'fail' end,
    'Expected app version 0.22.0 / migration 021';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.22.0',
    'latest_migration',21,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;



-- =====================================================================
-- FINAL STATIC-PAGE CLOSURE: SUPPLIERS + STOCK MOVEMENT LEDGER
-- =====================================================================

alter table public.suppliers
  add column if not exists client_request_id uuid;

create unique index if not exists suppliers_client_request_unique
  on public.suppliers(client_request_id)
  where client_request_id is not null;

create or replace function public.save_supplier(
  p_supplier_id uuid,
  p_name text,
  p_phone text,
  p_email text,
  p_notes text,
  p_active boolean,
  p_client_request_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_supplier_id,gen_random_uuid());
  v_existing uuid;
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager','storekeeper') then
    raise exception 'Not authorized to manage suppliers';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Supplier name is required'; end if;

  if p_supplier_id is null and p_client_request_id is not null then
    select id into v_existing
    from public.suppliers
    where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;

  select to_jsonb(s) into v_before
  from public.suppliers s
  where s.id=p_supplier_id;

  insert into public.suppliers(
    id,name,phone,email,notes,active,client_request_id
  )
  values(
    v_id,trim(p_name),nullif(trim(p_phone),''),nullif(trim(p_email),''),
    nullif(trim(p_notes),''),coalesce(p_active,true),p_client_request_id
  )
  on conflict(id) do update set
    name=excluded.name,
    phone=excluded.phone,
    email=excluded.email,
    notes=excluded.notes,
    active=excluded.active,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_supplier_id is null then 'create_supplier' else 'update_supplier' end,
    'supplier',v_id,v_before,
    (select to_jsonb(s) from public.suppliers s where s.id=v_id)
  );

  return v_id;
end;
$$;

drop policy if exists "owner manager storekeeper manage suppliers" on public.suppliers;

create or replace view public.inventory_movement_summary
with (security_invoker=true)
as
select
  it.id,it.created_at,it.raw_material_id,rm.name material_name,rm.base_unit,
  it.tx_type,it.quantity_delta,it.unit_cost,it.reference_type,it.reference_id,
  it.notes,it.created_by,p.full_name recorded_by_name,p.role recorded_by_role
from public.inventory_transactions it
join public.raw_materials rm on rm.id=it.raw_material_id
left join public.profiles p on p.id=it.created_by;

revoke all on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) from public;
grant execute on function public.save_supplier(uuid,text,text,text,text,boolean,uuid) to authenticated;

revoke all on function public.launch_readiness_checks() from public;
revoke all on function public.launch_readiness_summary() from public;
grant execute on function public.launch_readiness_checks() to authenticated;
grant execute on function public.launch_readiness_summary() to authenticated;


-- ===== INTEGRATION STAGE / MIGRATION 022 =====
-- DS Bakery v0.23 / Migration 022
-- Public customer website live-data integration and public-site configuration.

create table if not exists public.public_site_settings (
  id integer primary key default 1 check(id=1),
  business_name text not null default 'DS Bakery',
  tagline text not null default 'Fresh bakery products for every occasion',
  hero_message text,
  phone text,
  whatsapp_phone text,
  email text,
  address_text text,
  opening_hours text,
  custom_cake_enabled boolean not null default true,
  delivery_enabled boolean not null default true,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.public_site_settings(id,business_name,tagline,custom_cake_enabled,delivery_enabled)
values(1,'DS Bakery','Fresh bakery products for every occasion',true,true)
on conflict(id) do nothing;

alter table public.public_site_settings enable row level security;

drop policy if exists "management read public site settings" on public.public_site_settings;
create policy "management read public site settings"
on public.public_site_settings
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.public_site_info()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'business_name',business_name,
    'tagline',tagline,
    'hero_message',hero_message,
    'phone',phone,
    'whatsapp_phone',whatsapp_phone,
    'email',email,
    'address_text',address_text,
    'opening_hours',opening_hours,
    'custom_cake_enabled',custom_cake_enabled,
    'delivery_enabled',delivery_enabled
  )
  from public.public_site_settings
  where id=1
$$;

create or replace function public.public_product_catalog()
returns table(
  id uuid,
  name text,
  description text,
  selling_price numeric,
  image_url text,
  category_name text,
  category_display_order integer,
  product_updated_at timestamptz
)
language sql
stable
security definer
set search_path=public
as $$
  select
    p.id,
    p.name,
    p.description,
    p.selling_price,
    p.image_url,
    pc.name,
    coalesce(pc.display_order,0),
    p.updated_at
  from public.products p
  left join public.product_categories pc on pc.id=p.category_id
  where p.status='active'
  order by coalesce(pc.display_order,0),pc.name nulls last,p.name
$$;

create or replace function public.update_public_site_settings(
  p_business_name text,
  p_tagline text,
  p_hero_message text,
  p_phone text,
  p_whatsapp_phone text,
  p_email text,
  p_address_text text,
  p_opening_hours text,
  p_custom_cake_enabled boolean,
  p_delivery_enabled boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may update public website settings';
  end if;

  if coalesce(trim(p_business_name),'')='' then
    raise exception 'Business name is required';
  end if;

  select to_jsonb(s) into v_before
  from public.public_site_settings s
  where id=1;

  update public.public_site_settings
  set
    business_name=trim(p_business_name),
    tagline=coalesce(nullif(trim(p_tagline),''),'Fresh bakery products for every occasion'),
    hero_message=nullif(trim(p_hero_message),''),
    phone=nullif(trim(p_phone),''),
    whatsapp_phone=nullif(trim(p_whatsapp_phone),''),
    email=nullif(trim(p_email),''),
    address_text=nullif(trim(p_address_text),''),
    opening_hours=nullif(trim(p_opening_hours),''),
    custom_cake_enabled=coalesce(p_custom_cake_enabled,true),
    delivery_enabled=coalesce(p_delivery_enabled,true),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_public_site_settings','public_site_settings',null,
    v_before,(select to_jsonb(s) from public.public_site_settings s where id=1)
  );
end;
$$;

revoke all on function public.public_site_info() from public;
revoke all on function public.public_product_catalog() from public;
revoke all on function public.update_public_site_settings(text,text,text,text,text,text,text,text,boolean,boolean) from public;

grant execute on function public.public_site_info() to anon, authenticated;
grant execute on function public.public_product_catalog() to anon, authenticated;
grant execute on function public.update_public_site_settings(text,text,text,text,text,text,text,text,boolean,boolean) to authenticated;

-- Release metadata moves to v0.23 / migration 022.
update public.system_release_state
set app_version='0.23.0',
    latest_migration=22,
    release_stage='public_website_live',
    updated_at=now()
where id=1;

-- Extend launch diagnostics with the public website settings row.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.23.0' and latest_migration=22
    ) then 'pass' else 'fail' end,
    'Expected app version 0.23.0 / migration 022';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.23.0',
    'latest_migration',22,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 023 =====
-- DS Bakery v0.24 / Migration 023
-- Public contact/location and TikTok details.

alter table public.public_site_settings
  add column if not exists secondary_phone text,
  add column if not exists tiktok_handle text;

update public.public_site_settings
set
  phone='0708743663',
  secondary_phone='0760547003',
  whatsapp_phone='0760547003',
  email='dscakes3@gmail.com',
  address_text='Kiwafu Lugonjo',
  tiktok_handle='Ds bakery',
  updated_at=now()
where id=1;

create or replace function public.public_site_info()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'business_name',business_name,
    'tagline',tagline,
    'hero_message',hero_message,
    'phone',phone,
    'secondary_phone',secondary_phone,
    'whatsapp_phone',whatsapp_phone,
    'email',email,
    'address_text',address_text,
    'opening_hours',opening_hours,
    'tiktok_handle',tiktok_handle,
    'custom_cake_enabled',custom_cake_enabled,
    'delivery_enabled',delivery_enabled
  )
  from public.public_site_settings
  where id=1
$$;

drop function if exists public.update_public_site_settings(
  text,text,text,text,text,text,text,text,boolean,boolean
);

create or replace function public.update_public_site_settings(
  p_business_name text,
  p_tagline text,
  p_hero_message text,
  p_phone text,
  p_secondary_phone text,
  p_whatsapp_phone text,
  p_email text,
  p_address_text text,
  p_opening_hours text,
  p_tiktok_handle text,
  p_custom_cake_enabled boolean,
  p_delivery_enabled boolean
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before jsonb;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Only owner or manager may update public website settings';
  end if;

  if coalesce(trim(p_business_name),'')='' then
    raise exception 'Business name is required';
  end if;

  select to_jsonb(s) into v_before
  from public.public_site_settings s
  where id=1;

  update public.public_site_settings
  set
    business_name=trim(p_business_name),
    tagline=coalesce(nullif(trim(p_tagline),''),'Fresh bakery products for every occasion'),
    hero_message=nullif(trim(p_hero_message),''),
    phone=nullif(trim(p_phone),''),
    secondary_phone=nullif(trim(p_secondary_phone),''),
    whatsapp_phone=nullif(trim(p_whatsapp_phone),''),
    email=nullif(trim(p_email),''),
    address_text=nullif(trim(p_address_text),''),
    opening_hours=nullif(trim(p_opening_hours),''),
    tiktok_handle=nullif(trim(p_tiktok_handle),''),
    custom_cake_enabled=coalesce(p_custom_cake_enabled,true),
    delivery_enabled=coalesce(p_delivery_enabled,true),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_public_site_settings','public_site_settings',null,
    v_before,(select to_jsonb(s) from public.public_site_settings s where id=1)
  );
end;
$$;

revoke all on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) from public;

grant execute on function public.update_public_site_settings(
  text,text,text,text,text,text,text,text,text,text,boolean,boolean
) to authenticated;

update public.system_release_state
set app_version='0.24.0',
    latest_migration=23,
    release_stage='public_contact_details',
    updated_at=now()
where id=1;


-- Refresh launch-readiness release expectations for v0.24.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.24.0' and latest_migration=23
    ) then 'pass' else 'fail' end,
    'Expected app version 0.24.0 / migration 023';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.24.0',
    'latest_migration',23,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 024 =====
-- DS Bakery v0.25 / Migration 024
-- Staging validation evidence, repeatable release checks and release-state update.

create table if not exists public.validation_runs (
  id uuid primary key default gen_random_uuid(),
  environment text not null check(environment in ('staging','production')),
  app_version text not null,
  latest_migration integer not null,
  started_by uuid not null references public.profiles(id),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  overall_status text not null default 'pending'
    check(overall_status in ('pending','pass','warn','fail')),
  notes text
);

create table if not exists public.validation_check_results (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.validation_runs(id) on delete cascade,
  check_key text not null,
  area text not null,
  status text not null check(status in ('pending','pass','warn','fail')),
  detail text,
  evidence text,
  checked_by uuid references public.profiles(id),
  checked_at timestamptz not null default now(),
  unique(run_id,check_key)
);

alter table public.validation_runs enable row level security;
alter table public.validation_check_results enable row level security;

drop policy if exists "management read validation runs" on public.validation_runs;
create policy "management read validation runs"
on public.validation_runs
for select using(public.current_staff_role() in ('owner','manager'));

drop policy if exists "management read validation results" on public.validation_check_results;
create policy "management read validation results"
on public.validation_check_results
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.begin_validation_run(
  p_environment text default 'staging',
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may start a validation run';
  end if;
  if p_environment not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  insert into public.validation_runs(
    id,environment,app_version,latest_migration,started_by,notes
  )
  values(
    v_id,p_environment,'0.25.0',24,auth.uid(),nullif(trim(p_notes),'')
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'begin_validation_run','validation_run',v_id,
    jsonb_build_object('environment',p_environment,'app_version','0.25.0','latest_migration',24)
  );

  return v_id;
end;
$$;

create or replace function public.record_validation_check(
  p_run_id uuid,
  p_check_key text,
  p_area text,
  p_status text,
  p_detail text default null,
  p_evidence text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid;
  v_run public.validation_runs%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record validation evidence';
  end if;
  if coalesce(trim(p_check_key),'')='' or coalesce(trim(p_area),'')='' then
    raise exception 'Check key and area are required';
  end if;
  if p_status not in ('pending','pass','warn','fail') then
    raise exception 'Invalid validation status';
  end if;

  select * into v_run
  from public.validation_runs
  where id=p_run_id
  for update;

  if not found then raise exception 'Validation run not found'; end if;
  if v_run.completed_at is not null then raise exception 'Validation run is already completed'; end if;

  insert into public.validation_check_results(
    run_id,check_key,area,status,detail,evidence,checked_by
  )
  values(
    p_run_id,trim(p_check_key),trim(p_area),p_status,
    nullif(trim(p_detail),''),nullif(trim(p_evidence),''),auth.uid()
  )
  on conflict(run_id,check_key) do update set
    area=excluded.area,
    status=excluded.status,
    detail=excluded.detail,
    evidence=excluded.evidence,
    checked_by=auth.uid(),
    checked_at=now()
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.complete_validation_run(
  p_run_id uuid,
  p_notes text default null
)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_fail bigint;
  v_warn bigint;
  v_pending bigint;
  v_total bigint;
  v_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may complete a validation run';
  end if;

  perform 1
  from public.validation_runs
  where id=p_run_id and completed_at is null
  for update;

  if not found then raise exception 'Open validation run not found'; end if;

  select
    count(*),
    count(*) filter(where status='fail'),
    count(*) filter(where status='warn'),
    count(*) filter(where status='pending')
  into v_total,v_fail,v_warn,v_pending
  from public.validation_check_results
  where run_id=p_run_id;

  if v_total=0 then raise exception 'Validation run has no recorded checks'; end if;
  if v_pending>0 then raise exception 'Validation run still contains pending checks'; end if;

  v_status:=case
    when v_fail>0 then 'fail'
    when v_warn>0 then 'warn'
    else 'pass'
  end;

  update public.validation_runs
  set completed_at=now(),
      overall_status=v_status,
      notes=coalesce(nullif(trim(p_notes),''),notes)
  where id=p_run_id;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'complete_validation_run','validation_run',p_run_id,
    jsonb_build_object(
      'overall_status',v_status,'check_count',v_total,
      'fail_count',v_fail,'warn_count',v_warn
    )
  );

  return v_status;
end;
$$;

create or replace view public.validation_run_summary
with (security_invoker=true)
as
select
  vr.id,vr.environment,vr.app_version,vr.latest_migration,
  vr.started_at,vr.completed_at,vr.overall_status,vr.notes,
  p.full_name started_by_name,
  count(vcr.id)::bigint check_count,
  count(vcr.id) filter(where vcr.status='pass')::bigint pass_count,
  count(vcr.id) filter(where vcr.status='warn')::bigint warn_count,
  count(vcr.id) filter(where vcr.status='fail')::bigint fail_count,
  count(vcr.id) filter(where vcr.status='pending')::bigint pending_count
from public.validation_runs vr
join public.profiles p on p.id=vr.started_by
left join public.validation_check_results vcr on vcr.run_id=vr.id
group by vr.id,p.full_name;

revoke all on function public.begin_validation_run(text,text) from public;
revoke all on function public.record_validation_check(uuid,text,text,text,text,text) from public;
revoke all on function public.complete_validation_run(uuid,text) from public;

grant execute on function public.begin_validation_run(text,text) to authenticated;
grant execute on function public.record_validation_check(uuid,text,text,text,text,text) to authenticated;
grant execute on function public.complete_validation_run(uuid,text) to authenticated;

update public.system_release_state
set app_version='0.25.0',
    latest_migration=24,
    release_stage='staging_validation_harness',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.25.0'
    and vr.latest_migration=24
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.25.0'
      else 'No completed passing staging validation run exists yet for v0.25.0' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.25.0' and latest_migration=24
    ) then 'pass' else 'fail' end,
    'Expected app version 0.25.0 / migration 024';
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from public.launch_readiness_checks() x;

  return jsonb_build_object(
    'app_version','0.25.0',
    'latest_migration',24,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 025 =====
-- DS Bakery v0.26 / Migration 025
-- Environment guardrails for staging bootstrap and production cutover.

create table if not exists public.system_environment_config (
  id integer primary key default 1 check(id=1),
  environment_mode text not null default 'unconfigured'
    check(environment_mode in ('unconfigured','staging','production')),
  allow_staging_test_accounts boolean not null default false,
  production_lock boolean not null default false,
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.system_environment_config(
  id,environment_mode,allow_staging_test_accounts,production_lock
)
values(1,'unconfigured',false,false)
on conflict(id) do nothing;

alter table public.system_environment_config enable row level security;

drop policy if exists "owner manager read environment config" on public.system_environment_config;
create policy "owner manager read environment config"
on public.system_environment_config
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.configure_system_environment(
  p_environment_mode text,
  p_allow_staging_test_accounts boolean,
  p_notes text,
  p_confirmation text
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.system_environment_config%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may configure the deployment environment';
  end if;

  if p_environment_mode not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  if p_environment_mode='staging' and p_confirmation<>'CONFIRM STAGING' then
    raise exception 'Type CONFIRM STAGING to configure staging mode';
  end if;

  if p_environment_mode='production' and p_confirmation<>'CONFIRM PRODUCTION' then
    raise exception 'Type CONFIRM PRODUCTION to configure production mode';
  end if;

  select * into v_before
  from public.system_environment_config
  where id=1
  for update;

  if v_before.production_lock and p_environment_mode<>'production' then
    raise exception 'Production lock is enabled; environment cannot be moved back to staging';
  end if;

  if p_environment_mode='production' and p_allow_staging_test_accounts then
    raise exception 'Staging test accounts cannot be enabled in production mode';
  end if;

  update public.system_environment_config
  set
    environment_mode=p_environment_mode,
    allow_staging_test_accounts=case when p_environment_mode='production' then false else coalesce(p_allow_staging_test_accounts,false) end,
    notes=nullif(trim(p_notes),''),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'configure_system_environment','system_environment_config',null,
    to_jsonb(v_before),
    (select to_jsonb(c) from public.system_environment_config c where c.id=1)
  );
end;
$$;

create or replace function public.enable_production_lock(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may enable production lock';
  end if;

  if p_confirmation<>'LOCK PRODUCTION' then
    raise exception 'Type LOCK PRODUCTION to enable production lock';
  end if;

  if not exists(
    select 1 from public.system_environment_config
    where id=1 and environment_mode='production'
  ) then
    raise exception 'Environment must already be production before locking';
  end if;

  update public.system_environment_config
  set production_lock=true,
      allow_staging_test_accounts=false,
      updated_by=auth.uid(),
      updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'enable_production_lock','system_environment_config',null,
    jsonb_build_object('environment_mode','production','production_lock',true)
  );
end;
$$;

create or replace function public.environment_state()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'environment_mode',environment_mode,
    'allow_staging_test_accounts',allow_staging_test_accounts,
    'production_lock',production_lock,
    'notes',notes,
    'updated_at',updated_at
  )
  from public.system_environment_config
  where id=1
$$;

revoke all on function public.configure_system_environment(text,boolean,text,text) from public;
revoke all on function public.enable_production_lock(text) from public;
revoke all on function public.environment_state() from public;

grant execute on function public.configure_system_environment(text,boolean,text,text) to authenticated;
grant execute on function public.enable_production_lock(text) to authenticated;
grant execute on function public.environment_state() to authenticated;

update public.system_release_state
set app_version='0.26.0',
    latest_migration=25,
    release_stage='environment_guardrails',
    updated_at=now()
where id=1;

-- Refresh launch readiness to require explicit environment configuration.
create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.26.0'
    and vr.latest_migration=25
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0'
      else 'No completed passing staging validation run exists yet for v0.26.0' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.26.0' and latest_migration=25
    ) then 'pass' else 'fail' end,
    'Expected app version 0.26.0 / migration 025';
end;
$$;


create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.26.0',
    'latest_migration',25,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 026 =====
-- DS Bakery v0.27 / Migration 026
-- Go-live setup checklist and readiness sign-off.

create table if not exists public.go_live_setup_state (
  id integer primary key default 1 check(id=1),
  catalog_verified boolean not null default false,
  opening_stock_verified boolean not null default false,
  payment_methods_verified boolean not null default false,
  public_site_verified boolean not null default false,
  staff_accounts_verified boolean not null default false,
  backup_plan_verified boolean not null default false,
  notes text,
  verified_by uuid references public.profiles(id),
  verified_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz not null default now()
);

insert into public.go_live_setup_state(id)
values(1)
on conflict(id) do nothing;

alter table public.go_live_setup_state enable row level security;

drop policy if exists "owner manager read go live setup" on public.go_live_setup_state;
create policy "owner manager read go live setup"
on public.go_live_setup_state
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.go_live_setup_readiness()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_state public.go_live_setup_state%rowtype;
  v_env public.system_environment_config%rowtype;
  v_owner_count bigint;
  v_product_count bigint;
  v_material_count bigint;
  v_recipe_gap bigint;
  v_supplier_count bigint;
  v_staff_count bigint;
  v_negative_stock bigint;
  v_public_ok boolean;
  v_validation_pass boolean;
  v_auto_pass boolean;
  v_manual_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_state from public.go_live_setup_state where id=1;
  select * into v_env from public.system_environment_config where id=1;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  select count(*) into v_staff_count
  from public.profiles
  where active=true and disabled_at is null;

  select count(*) into v_product_count
  from public.products
  where status='active' and selling_price>0;

  select count(*) into v_material_count
  from public.raw_materials
  where status='active';

  select count(*) into v_supplier_count
  from public.suppliers
  where active=true;

  select count(*) into v_negative_stock
  from public.raw_materials
  where current_stock_qty<0;

  select count(*) into v_recipe_gap
  from public.products p
  where p.status='active'
    and p.track_recipe=true
    and not exists(
      select 1 from public.recipes r
      where r.product_id=p.id and r.active=true
    );

  select exists(
    select 1
    from public.public_site_settings
    where id=1
      and coalesce(trim(business_name),'')<>''
      and coalesce(trim(phone),'')<>''
      and coalesce(trim(whatsapp_phone),'')<>''
      and coalesce(trim(address_text),'')<>''
  ) into v_public_ok;

  select exists(
    select 1
    from public.validation_runs
    where environment='staging'
      and overall_status='pass'
      and completed_at is not null
      and app_version in ('0.26.0','0.27.0')
      and latest_migration>=25
  ) into v_validation_pass;

  v_auto_pass :=
    v_owner_count>=1
    and v_staff_count>=1
    and v_product_count>=1
    and v_material_count>=1
    and v_supplier_count>=1
    and v_negative_stock=0
    and v_recipe_gap=0
    and v_public_ok
    and v_env.environment_mode<>'unconfigured';

  v_manual_pass :=
    v_state.catalog_verified
    and v_state.opening_stock_verified
    and v_state.payment_methods_verified
    and v_state.public_site_verified
    and v_state.staff_accounts_verified
    and v_state.backup_plan_verified;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'automatic',jsonb_build_object(
      'active_owner',v_owner_count>=1,
      'active_staff_count',v_staff_count,
      'active_products',v_product_count,
      'active_raw_materials',v_material_count,
      'active_suppliers',v_supplier_count,
      'negative_stock_count',v_negative_stock,
      'recipe_gap_count',v_recipe_gap,
      'public_site_contact_ready',v_public_ok,
      'passing_staging_validation',v_validation_pass
    ),
    'manual',jsonb_build_object(
      'catalog_verified',v_state.catalog_verified,
      'opening_stock_verified',v_state.opening_stock_verified,
      'payment_methods_verified',v_state.payment_methods_verified,
      'public_site_verified',v_state.public_site_verified,
      'staff_accounts_verified',v_state.staff_accounts_verified,
      'backup_plan_verified',v_state.backup_plan_verified
    ),
    'automatic_gate',case when v_auto_pass then 'pass' else 'fail' end,
    'manual_gate',case when v_manual_pass then 'pass' else 'fail' end,
    'staging_validation_gate',case when v_validation_pass then 'pass' else 'warn' end,
    'setup_completed',v_state.completed_at is not null,
    'completed_at',v_state.completed_at,
    'notes',v_state.notes
  );
end;
$$;

create or replace function public.update_go_live_setup_checklist(
  p_catalog_verified boolean,
  p_opening_stock_verified boolean,
  p_payment_methods_verified boolean,
  p_public_site_verified boolean,
  p_staff_accounts_verified boolean,
  p_backup_plan_verified boolean,
  p_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_before public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update the go-live checklist';
  end if;

  select * into v_before
  from public.go_live_setup_state
  where id=1
  for update;

  update public.go_live_setup_state
  set
    catalog_verified=coalesce(p_catalog_verified,false),
    opening_stock_verified=coalesce(p_opening_stock_verified,false),
    payment_methods_verified=coalesce(p_payment_methods_verified,false),
    public_site_verified=coalesce(p_public_site_verified,false),
    staff_accounts_verified=coalesce(p_staff_accounts_verified,false),
    backup_plan_verified=coalesce(p_backup_plan_verified,false),
    notes=nullif(trim(p_notes),''),
    verified_by=auth.uid(),
    verified_at=now(),
    completed_at=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'update_go_live_checklist','go_live_setup_state',null,
    to_jsonb(v_before),
    (select to_jsonb(s) from public.go_live_setup_state s where s.id=1)
  );
end;
$$;

create or replace function public.complete_go_live_setup(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_ready jsonb;
  v_state public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may complete go-live setup';
  end if;

  if p_confirmation<>'COMPLETE GO LIVE SETUP' then
    raise exception 'Type COMPLETE GO LIVE SETUP exactly';
  end if;

  select * into v_state
  from public.go_live_setup_state
  where id=1
  for update;

  v_ready:=public.go_live_setup_readiness();

  if coalesce(v_ready->>'automatic_gate','fail')<>'pass' then
    raise exception 'Automatic go-live checks are not complete';
  end if;

  if coalesce(v_ready->>'manual_gate','fail')<>'pass' then
    raise exception 'Manual go-live checklist is incomplete';
  end if;

  if coalesce(v_ready->>'staging_validation_gate','warn')<>'pass' then
    raise exception 'A passing staging validation run is required';
  end if;

  update public.go_live_setup_state
  set completed_at=now(),
      verified_by=auth.uid(),
      verified_at=now(),
      updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'complete_go_live_setup','go_live_setup_state',null,
    jsonb_build_object('completed_at',now(),'readiness',v_ready)
  );
end;
$$;

revoke all on function public.go_live_setup_readiness() from public;
revoke all on function public.update_go_live_setup_checklist(boolean,boolean,boolean,boolean,boolean,boolean,text) from public;
revoke all on function public.complete_go_live_setup(text) from public;

grant execute on function public.go_live_setup_readiness() to authenticated;
grant execute on function public.update_go_live_setup_checklist(boolean,boolean,boolean,boolean,boolean,boolean,text) to authenticated;
grant execute on function public.complete_go_live_setup(text) to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.27.0'
    and vr.latest_migration=26
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.27.0' and latest_migration=26
    ) then 'pass' else 'fail' end,
    'Expected app version 0.27.0 / migration 026';
end;
$$;



update public.system_release_state
set app_version='0.27.0',
    latest_migration=26,
    release_stage='go_live_setup',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.27.0',
    'latest_migration',26,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 027 =====
-- DS Bakery v0.28 / Migration 027
-- Production cutover authorization and transactional safety gate.

create table if not exists public.production_cutover_state (
  id integer primary key default 1 check(id=1),
  operations_enabled boolean not null default false,
  authorized_by uuid references public.profiles(id),
  authorized_at timestamptz,
  suspended_by uuid references public.profiles(id),
  suspended_at timestamptz,
  suspension_reason text,
  updated_at timestamptz not null default now()
);

insert into public.production_cutover_state(id)
values(1)
on conflict(id) do nothing;

alter table public.production_cutover_state enable row level security;

drop policy if exists "owner manager read production cutover" on public.production_cutover_state;
create policy "owner manager read production cutover"
on public.production_cutover_state
for select using(public.current_staff_role() in ('owner','manager'));

create or replace function public.production_cutover_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup_completed',v_setup.completed_at is not null,
    'go_live_setup_completed_at',v_setup.completed_at,
    'operations_enabled',v_cut.operations_enabled,
    'authorized_at',v_cut.authorized_at,
    'suspended_at',v_cut.suspended_at,
    'suspension_reason',v_cut.suspension_reason,
    'ready_to_authorize',
      v_env.environment_mode='production'
      and v_env.production_lock
      and v_setup.completed_at is not null
  );
end;
$$;

create or replace function public.authorize_production_operations(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_cut public.production_cutover_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may authorize production operations';
  end if;

  if p_confirmation<>'AUTHORIZE LIVE OPERATIONS' then
    raise exception 'Type AUTHORIZE LIVE OPERATIONS exactly';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1
  for update;

  select * into v_setup
  from public.go_live_setup_state
  where id=1
  for update;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  if v_env.environment_mode<>'production' then
    raise exception 'Environment must be Production';
  end if;

  if not v_env.production_lock then
    raise exception 'Production Lock must be enabled before live operations';
  end if;

  if v_setup.completed_at is null then
    raise exception 'Go-Live Setup must be completed first';
  end if;

  update public.production_cutover_state
  set
    operations_enabled=true,
    authorized_by=auth.uid(),
    authorized_at=now(),
    suspended_by=null,
    suspended_at=null,
    suspension_reason=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'authorize_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.suspend_production_operations(p_reason text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_cut public.production_cutover_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager required';
  end if;

  if coalesce(trim(p_reason),'')='' then
    raise exception 'Suspension reason is required';
  end if;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  update public.production_cutover_state
  set
    operations_enabled=false,
    suspended_by=auth.uid(),
    suspended_at=now(),
    suspension_reason=trim(p_reason),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'suspend_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.assert_business_operation_allowed()
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
begin
  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  if v_env.environment_mode='staging' then
    return;
  end if;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Business operations are blocked until the environment is configured';
  end if;

  if v_env.environment_mode='production' then
    if not v_env.production_lock then
      raise exception 'Business operations are blocked until Production Lock is enabled';
    end if;

    if v_setup.completed_at is null then
      raise exception 'Business operations are blocked until Go-Live Setup is completed';
    end if;

    if not v_cut.operations_enabled then
      raise exception 'Live business operations are currently disabled';
    end if;

    return;
  end if;

  raise exception 'Unknown system environment state';
end;
$$;

create or replace function public.trg_business_operation_gate()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.assert_business_operation_allowed();
  if tg_op='DELETE' then
    return old;
  end if;
  return new;
end;
$$;

-- Critical transactional tables. Staging stays usable; production requires final authorization.
do $$
declare
  v_table text;
  v_trigger text;
begin
  foreach v_table in array ARRAY[
    'sales',
    'payments',
    'sale_refunds',
    'customer_orders',
    'customer_order_payments',
    'customer_order_refunds',
    'purchases',
    'purchase_items',
    'purchase_payments',
    'inventory_transactions',
    'production_runs',
    'waste_events',
    'expenses',
    'cash_movements'
  ]
  loop
    if to_regclass('public.'||v_table) is not null then
      v_trigger:='trg_business_operation_gate_'||v_table;
      execute format('drop trigger if exists %I on public.%I',v_trigger,v_table);
      execute format(
        'create trigger %I before insert or update or delete on public.%I for each row execute function public.trg_business_operation_gate()',
        v_trigger,v_table
      );
    end if;
  end loop;
end $$;

revoke all on function public.production_cutover_status() from public;
revoke all on function public.authorize_production_operations(text) from public;
revoke all on function public.suspend_production_operations(text) from public;
revoke all on function public.assert_business_operation_allowed() from public;

grant execute on function public.production_cutover_status() to authenticated;
grant execute on function public.authorize_production_operations(text) to authenticated;
grant execute on function public.suspend_production_operations(text) to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.28.0'
    and vr.latest_migration=27
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.28.0' and latest_migration=27
    ) then 'pass' else 'fail' end,
    'Expected app version 0.28.0 / migration 027';
end;
$$;





update public.system_release_state
set app_version='0.28.0',
    latest_migration=27,
    release_stage='production_cutover',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  select * into v_cut
  from public.production_cutover_state
  where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case
        when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
        else 'Environment mode: '||v_env.environment_mode
      end
    union all
    select
      'staging_test_accounts'::text,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'fail'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'warn'
        else 'pass'
      end,
      case
        when v_env.environment_mode='production' and v_env.allow_staging_test_accounts then 'Staging test accounts are enabled in production'
        when v_env.environment_mode='staging' and not v_env.allow_staging_test_accounts then 'Staging test accounts are disabled'
        when v_env.environment_mode='staging' then 'Staging test accounts are enabled'
        else 'Staging test accounts are disabled in production'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select
      'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select
      'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.28.0',
    'latest_migration',27,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 028 =====
-- DS Bakery v0.29 / Migration 028
-- Supabase staging-connection evidence and environment handoff.

create table if not exists public.environment_connection_checks (
  id uuid primary key default gen_random_uuid(),
  environment_mode text not null check(environment_mode in ('staging','production')),
  check_type text not null,
  status text not null check(status in ('pass','warn','fail')),
  detail text,
  metadata jsonb,
  app_version text not null,
  latest_migration integer not null,
  recorded_by uuid references public.profiles(id),
  recorded_at timestamptz not null default now()
);

alter table public.environment_connection_checks enable row level security;

drop policy if exists "owner manager read environment connection checks" on public.environment_connection_checks;
create policy "owner manager read environment connection checks"
on public.environment_connection_checks
for select using(public.current_staff_role() in ('owner','manager'));

create index if not exists environment_connection_checks_lookup_idx
on public.environment_connection_checks(environment_mode,check_type,recorded_at desc);

create or replace function public.record_environment_connection_check(
  p_check_type text,
  p_status text,
  p_detail text default null,
  p_metadata jsonb default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record environment connection evidence';
  end if;

  if coalesce(trim(p_check_type),'')='' then
    raise exception 'Check type is required';
  end if;

  if p_status not in ('pass','warn','fail') then
    raise exception 'Invalid connection-check status';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Configure the environment before recording connection evidence';
  end if;

  insert into public.environment_connection_checks(
    id,environment_mode,check_type,status,detail,metadata,
    app_version,latest_migration,recorded_by
  )
  values(
    v_id,v_env.environment_mode,trim(p_check_type),p_status,
    nullif(trim(p_detail),''),p_metadata,
    '0.29.0',28,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_environment_connection_check','environment_connection_check',v_id,
    jsonb_build_object(
      'environment_mode',v_env.environment_mode,
      'check_type',p_check_type,
      'status',p_status,
      'app_version','0.29.0',
      'latest_migration',28
    )
  );

  return v_id;
end;
$$;

create or replace function public.environment_connection_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_latest jsonb;
  v_pass_count bigint;
  v_fail_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select coalesce(jsonb_agg(to_jsonb(x) order by x.recorded_at desc),'[]'::jsonb)
  into v_latest
  from (
    select distinct on (ecc.check_type)
      ecc.id,ecc.environment_mode,ecc.check_type,ecc.status,ecc.detail,
      ecc.metadata,ecc.app_version,ecc.latest_migration,ecc.recorded_at
    from public.environment_connection_checks ecc
    order by ecc.check_type,ecc.recorded_at desc
  ) x;

  select
    count(*) filter(where status='pass'),
    count(*) filter(where status='fail')
  into v_pass_count,v_fail_count
  from public.environment_connection_checks
  where environment_mode=v_env.environment_mode
    and app_version='0.29.0'
    and latest_migration=28;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'allow_staging_test_accounts',v_env.allow_staging_test_accounts,
    'production_lock',v_env.production_lock,
    'release',jsonb_build_object(
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration,
      'release_stage',v_release.release_stage
    ),
    'latest_checks',v_latest,
    'pass_count',v_pass_count,
    'fail_count',v_fail_count,
    'checked_at',now()
  );
end;
$$;

revoke all on function public.record_environment_connection_check(text,text,text,jsonb) from public;
revoke all on function public.environment_connection_summary() from public;

grant execute on function public.record_environment_connection_check(text,text,text,jsonb) to authenticated;
grant execute on function public.environment_connection_summary() to authenticated;

create or replace function public.launch_readiness_checks()
returns table(
  check_key text,
  status text,
  detail text
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select
    'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz
  from public.business_settings where id=1;

  return query select
    'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (
    select product_id
    from public.recipes
    where active=true
    group by product_id
    having count(*)>1
  ) x;

  return query select
    'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count
  from public.raw_materials
  where current_stock_qty<0;

  return query select
    'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(
    p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)
  )>0.01
  or abs(
    p.total_amount-greatest(
      coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0
    )
  )>0.01
  or abs(
    p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0)
  )>0.01;

  return query select
    'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;

  return query select
    'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((
    select sum(we.quantity)
    from public.waste_events we
    where we.production_run_id=pr.id
      and we.waste_type='finished_product'
      and we.approval_status<>'rejected'
  ),0)>pr.quantity_produced;

  return query select
    'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count
  from public.mobile_money_reference_conflicts;

  return query select
    'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts
  where status='open' and opened_at<now()-interval '18 hours';

  return query select
    'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts
  where status='scheduled' and shift_date<public.business_current_date();

  return query select
    'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references'''
    into v_storage_public;

    return query select
      'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case
        when v_storage_public is false then 'custom-cake-references bucket is private'
        when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
        else 'custom-cake-references bucket is missing'
      end;
  else
    return query select
      'custom_cake_storage',
      'warn',
      'Supabase Storage schema is unavailable in this database session';
  end if;

  return query select
    'public_site_settings',
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings where id=1 and coalesce(trim(business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.app_version='0.29.0'
    and vr.latest_migration=28
    and vr.completed_at is not null;

  return query select
    'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1
      then 'A completed passing staging validation run exists for v0.26.0 or later'
      else 'No completed passing staging validation run exists yet for v0.26.0 or later' end;

  return query select
    'release_state',
    case when exists(
      select 1 from public.system_release_state
      where id=1 and app_version='0.29.0' and latest_migration=28
    ) then 'pass' else 'fail' end,
    'Expected app version 0.29.0 / migration 028';
end;
$$;







update public.system_release_state
set app_version='0.29.0',
    latest_migration=28,
    release_stage='supabase_staging_handoff',
    updated_at=now()
where id=1;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
  v_connection_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;

  v_setup:=public.go_live_setup_readiness();

  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_connection_status:=case
    when v_env.environment_mode='production' then 'pass'
    when exists(
      select 1 from public.environment_connection_checks
      where environment_mode='staging'
        and check_type='supabase_connectivity'
        and status='pass'
        and app_version='0.29.0'
        and latest_migration=28
    ) then 'pass'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select
      'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
           else 'Environment mode: '||v_env.environment_mode end
    union all
    select
      'staging_connection_evidence'::text,
      v_connection_status,
      case
        when v_env.environment_mode='production' then 'Staging connection evidence was a pre-production gate'
        when v_connection_status='pass' then 'Passing Supabase staging connectivity evidence exists'
        else 'Run the real Supabase staging connectivity check'
      end
    union all
    select
      'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select
      'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select
      'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version','0.29.0',
    'latest_migration',28,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;


-- ===== INTEGRATION STAGE / MIGRATION 029 =====
-- DS Bakery v0.30 / Migration 029
-- Security hardening after real Supabase staging advisor review.

alter view if exists public.raw_material_costs set (security_invoker=true);
alter view if exists public.low_stock_materials set (security_invoker=true);
alter view if exists public.supplier_balances set (security_invoker=true);
alter view if exists public.sale_profit_lines set (security_invoker=true);

alter function public.next_sale_no() set search_path=public;
alter function public.period_start(text) set search_path=public;
alter function public.next_customer_order_no() set search_path=public;
alter function public.operational_period_bounds(text) set search_path=public;
alter function public.next_purchase_no() set search_path=public;

do $$
declare
  r record;
begin
  for r in
    select
      p.oid::regprocedure as signature,
      pg_get_function_result(p.oid) as result_type
    from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public'
      and p.prosecdef=true
  loop
    execute format('revoke all on function %s from public',r.signature);
    execute format('revoke all on function %s from anon',r.signature);
    execute format('revoke all on function %s from authenticated',r.signature);

    if r.result_type <> 'trigger' then
      execute format('grant execute on function %s to authenticated',r.signature);
    end if;
  end loop;
end
$$;

grant execute on function public.public_site_info() to anon,authenticated;
grant execute on function public.public_product_catalog() to anon,authenticated;

update public.system_release_state
set app_version='0.30.0',
    latest_migration=29,
    release_stage='security_hardening',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 030 =====
-- DS Bakery v0.31 / Migration 030
-- Real staging workflow hardening.

create or replace function public.save_raw_material(
  p_raw_material_id uuid,
  p_supplier_id uuid,
  p_name text,
  p_sku text,
  p_base_unit text,
  p_purchase_pack_label text,
  p_purchase_pack_base_qty numeric,
  p_low_stock_threshold numeric
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=coalesce(p_raw_material_id,gen_random_uuid());
  v_before jsonb;
begin
  if not public.staff_has_permission('inventory:write') then
    raise exception 'Not authorized to manage raw materials';
  end if;
  if coalesce(trim(p_name),'')='' then raise exception 'Raw material name is required'; end if;
  if coalesce(trim(p_base_unit),'')='' then raise exception 'Base unit is required'; end if;
  if coalesce(p_purchase_pack_base_qty,0)<=0 then raise exception 'Purchase pack quantity must be greater than zero'; end if;
  if coalesce(p_low_stock_threshold,0)<0 then raise exception 'Low stock threshold cannot be negative'; end if;
  if p_supplier_id is not null and not exists(select 1 from public.suppliers where id=p_supplier_id and active=true) then
    raise exception 'Active supplier not found';
  end if;

  select to_jsonb(rm) into v_before
  from public.raw_materials rm
  where rm.id=p_raw_material_id;

  insert into public.raw_materials(
    id,supplier_id,name,sku,base_unit,purchase_pack_label,purchase_pack_base_qty,
    current_purchase_cost,current_stock_qty,low_stock_threshold,status,created_by
  )
  values(
    v_id,p_supplier_id,trim(p_name),nullif(trim(p_sku),''),
    trim(p_base_unit),nullif(trim(p_purchase_pack_label),''),
    p_purchase_pack_base_qty,0,0,p_low_stock_threshold,'active',auth.uid()
  )
  on conflict(id) do update set
    supplier_id=excluded.supplier_id,
    name=excluded.name,
    sku=excluded.sku,
    base_unit=excluded.base_unit,
    purchase_pack_label=excluded.purchase_pack_label,
    purchase_pack_base_qty=excluded.purchase_pack_base_qty,
    low_stock_threshold=excluded.low_stock_threshold,
    updated_at=now();

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),
    case when p_raw_material_id is null then 'create_raw_material' else 'update_raw_material' end,
    'raw_material',v_id,v_before,
    (select to_jsonb(rm) from public.raw_materials rm where rm.id=v_id)
  );

  return v_id;
end;
$$;

revoke all on function public.save_raw_material(uuid,uuid,text,text,text,text,numeric,numeric) from public,anon;
grant execute on function public.save_raw_material(uuid,uuid,text,text,text,text,numeric,numeric) to authenticated;


create or replace function public.launch_readiness_checks()
returns table(check_key text, status text, detail text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_count bigint;
  v_owner_count bigint;
  v_tz text;
  v_storage_public boolean;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness checks';
  end if;

  select count(*) into v_owner_count
  from public.profiles
  where active=true and disabled_at is null and role='owner';

  return query select 'active_owner',
    case when v_owner_count>=1 then 'pass' else 'fail' end,
    case when v_owner_count>=1 then v_owner_count::text || ' active owner account(s)'
         else 'No active owner account exists' end;

  select business_timezone into v_tz from public.business_settings where id=1;

  return query select 'business_timezone',
    case when exists(select 1 from pg_timezone_names where name=v_tz) then 'pass' else 'fail' end,
    coalesce(v_tz,'NULL');

  select count(*) into v_count
  from (select product_id from public.recipes where active=true group by product_id having count(*)>1) x;
  return query select 'active_recipe_uniqueness',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No products have multiple active recipes'
         else v_count::text || ' product(s) have multiple active recipes' end;

  select count(*) into v_count from public.raw_materials rm where rm.current_stock_qty<0;
  return query select 'negative_inventory',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'No negative raw-material balances'
         else v_count::text || ' raw material(s) have negative stock' end;

  select count(*) into v_count
  from public.purchases p
  where abs(p.subtotal-coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0))>0.01
     or abs(p.total_amount-greatest(coalesce((select sum(pi.line_total) from public.purchase_items pi where pi.purchase_id=p.id),0)-p.discount,0))>0.01
     or abs(p.amount_paid-coalesce((select sum(pp.amount) from public.purchase_payments pp where pp.purchase_id=p.id),0))>0.01;
  return query select 'purchase_totals',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Purchase totals and payment totals reconcile'
         else v_count::text || ' purchase(s) have total mismatches' end;

  select count(*) into v_count
  from public.customer_orders co
  where public.customer_order_net_paid(co.id)<-0.01
     or public.customer_order_net_paid(co.id)>co.total_amount+0.01;
  return query select 'customer_order_payments',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Customer-order net payments are within order totals'
         else v_count::text || ' order(s) have invalid net payment balances' end;

  select count(*) into v_count
  from public.production_runs pr
  where coalesce((select sum(we.quantity) from public.waste_events we
                  where we.production_run_id=pr.id
                    and we.waste_type='finished_product'
                    and we.approval_status<>'rejected'),0)>pr.quantity_produced;
  return query select 'production_waste_limits',
    case when v_count=0 then 'pass' else 'fail' end,
    case when v_count=0 then 'Linked finished-product waste does not exceed production output'
         else v_count::text || ' production run(s) have excessive linked waste' end;

  select count(*) into v_count from public.mobile_money_reference_conflicts;
  return query select 'mobile_money_conflicts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No historical Mobile Money reference conflicts'
         else v_count::text || ' historical reference conflict(s) require review' end;

  select count(*) into v_count
  from public.cashier_shifts cs
  where cs.status='open' and cs.opened_at<now()-interval '18 hours';
  return query select 'stale_cashier_shifts',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No cashier shifts have been open longer than 18 hours'
         else v_count::text || ' cashier shift(s) have been open longer than 18 hours' end;

  select count(*) into v_count
  from public.staff_work_shifts sws
  where sws.status='scheduled' and sws.shift_date<public.business_current_date();
  return query select 'stale_staff_schedule',
    case when v_count=0 then 'pass' else 'warn' end,
    case when v_count=0 then 'No past staff shifts remain scheduled'
         else v_count::text || ' past staff shift(s) remain scheduled' end;

  if to_regclass('storage.buckets') is not null then
    execute 'select public from storage.buckets where id=''custom-cake-references''' into v_storage_public;
    return query select 'custom_cake_storage',
      case when v_storage_public is false then 'pass' else 'fail' end,
      case when v_storage_public is false then 'custom-cake-references bucket is private'
           when v_storage_public is true then 'custom-cake-references bucket is PUBLIC'
           else 'custom-cake-references bucket is missing' end;
  else
    return query select 'custom_cake_storage','warn','Supabase Storage schema is unavailable in this database session';
  end if;

  return query select 'public_site_settings',
    case when exists(select 1 from public.public_site_settings pss where pss.id=1 and coalesce(trim(pss.business_name),'')<>'')
      then 'pass' else 'fail' end,
    case when exists(select 1 from public.public_site_settings pss where pss.id=1 and coalesce(trim(pss.business_name),'')<>'')
      then 'Public website configuration row exists'
      else 'Public website configuration is missing' end;

  select count(*) into v_count
  from public.validation_runs vr
  where vr.environment='staging'
    and vr.overall_status='pass'
    and vr.completed_at is not null;

  return query select 'staging_validation_evidence',
    case when v_count>=1 then 'pass' else 'warn' end,
    case when v_count>=1 then 'A completed passing staging validation run exists'
         else 'No completed passing staging validation run exists yet' end;

  return query select 'release_state',
    case when exists(select 1 from public.system_release_state srs where srs.id=1) then 'pass' else 'fail' end,
    'Release-state row exists';
end;
$$;

revoke all on function public.launch_readiness_checks() from public,anon;
grant execute on function public.launch_readiness_checks() to authenticated;

update public.system_release_state
set app_version='0.31.0',
    latest_migration=30,
    release_stage='real_workflow_validation',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 031 =====
-- DS Bakery v0.32 / Migration 031
-- Formal staging-validation evidence and dynamic release metadata.

create or replace function public.begin_validation_run(
  p_environment text default 'staging',
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
  v_release public.system_release_state%rowtype;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may start a validation run';
  end if;
  if p_environment not in ('staging','production') then
    raise exception 'Environment must be staging or production';
  end if;

  select * into v_release from public.system_release_state where id=1;
  if not found then raise exception 'System release state is missing'; end if;

  insert into public.validation_runs(
    id,environment,app_version,latest_migration,started_by,notes
  )
  values(
    v_id,p_environment,v_release.app_version,v_release.latest_migration,
    auth.uid(),nullif(trim(p_notes),'')
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'begin_validation_run','validation_run',v_id,
    jsonb_build_object(
      'environment',p_environment,
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration
    )
  );

  return v_id;
end;
$$;

create or replace function public.record_environment_connection_check(
  p_check_type text,
  p_status text,
  p_detail text default null,
  p_metadata jsonb default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record environment connection evidence';
  end if;
  if coalesce(trim(p_check_type),'')='' then raise exception 'Check type is required'; end if;
  if p_status not in ('pass','warn','fail') then raise exception 'Invalid connection-check status'; end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  if v_env.environment_mode='unconfigured' then
    raise exception 'Configure the environment before recording connection evidence';
  end if;

  insert into public.environment_connection_checks(
    id,environment_mode,check_type,status,detail,metadata,
    app_version,latest_migration,recorded_by
  )
  values(
    v_id,v_env.environment_mode,trim(p_check_type),p_status,
    nullif(trim(p_detail),''),p_metadata,
    v_release.app_version,v_release.latest_migration,auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_environment_connection_check','environment_connection_check',v_id,
    jsonb_build_object(
      'environment_mode',v_env.environment_mode,
      'check_type',p_check_type,
      'status',p_status,
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration
    )
  );

  return v_id;
end;
$$;

create or replace function public.environment_connection_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_latest jsonb;
  v_pass_count bigint;
  v_fail_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select coalesce(jsonb_agg(to_jsonb(x) order by x.recorded_at desc),'[]'::jsonb)
  into v_latest
  from (
    select distinct on (ecc.check_type)
      ecc.id,ecc.environment_mode,ecc.check_type,ecc.status,ecc.detail,
      ecc.metadata,ecc.app_version,ecc.latest_migration,ecc.recorded_at
    from public.environment_connection_checks ecc
    where ecc.environment_mode=v_env.environment_mode
    order by ecc.check_type,ecc.recorded_at desc
  ) x;

  select
    count(*) filter(where ecc.status='pass'),
    count(*) filter(where ecc.status='fail')
  into v_pass_count,v_fail_count
  from public.environment_connection_checks ecc
  where ecc.environment_mode=v_env.environment_mode
    and ecc.app_version=v_release.app_version
    and ecc.latest_migration=v_release.latest_migration;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'allow_staging_test_accounts',v_env.allow_staging_test_accounts,
    'production_lock',v_env.production_lock,
    'release',jsonb_build_object(
      'app_version',v_release.app_version,
      'latest_migration',v_release.latest_migration,
      'release_stage',v_release.release_stage
    ),
    'latest_checks',v_latest,
    'pass_count',v_pass_count,
    'fail_count',v_fail_count,
    'checked_at',now()
  );
end;
$$;

create or replace function public.go_live_setup_readiness()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_state public.go_live_setup_state%rowtype;
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_owner_count bigint;
  v_product_count bigint;
  v_material_count bigint;
  v_recipe_gap bigint;
  v_supplier_count bigint;
  v_staff_count bigint;
  v_negative_stock bigint;
  v_public_ok boolean;
  v_validation_pass boolean;
  v_auto_pass boolean;
  v_manual_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_state from public.go_live_setup_state where id=1;
  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;

  select count(*) into v_owner_count from public.profiles where active=true and disabled_at is null and role='owner';
  select count(*) into v_staff_count from public.profiles where active=true and disabled_at is null;
  select count(*) into v_product_count from public.products where status='active' and selling_price>0;
  select count(*) into v_material_count from public.raw_materials where status='active';
  select count(*) into v_supplier_count from public.suppliers where active=true;
  select count(*) into v_negative_stock from public.raw_materials where current_stock_qty<0;

  select count(*) into v_recipe_gap
  from public.products p
  where p.status='active'
    and p.track_recipe=true
    and not exists(select 1 from public.recipes r where r.product_id=p.id and r.active=true);

  select exists(
    select 1 from public.public_site_settings
    where id=1
      and coalesce(trim(business_name),'')<>''
      and coalesce(trim(phone),'')<>''
      and coalesce(trim(whatsapp_phone),'')<>''
      and coalesce(trim(address_text),'')<>''
  ) into v_public_ok;

  select exists(
    select 1
    from public.validation_runs vr
    where vr.environment='staging'
      and vr.overall_status='pass'
      and vr.completed_at is not null
      and vr.app_version=v_release.app_version
      and vr.latest_migration=v_release.latest_migration
  ) into v_validation_pass;

  v_auto_pass :=
    v_owner_count>=1
    and v_staff_count>=1
    and v_product_count>=1
    and v_material_count>=1
    and v_supplier_count>=1
    and v_negative_stock=0
    and v_recipe_gap=0
    and v_public_ok
    and v_env.environment_mode<>'unconfigured';

  v_manual_pass :=
    v_state.catalog_verified
    and v_state.opening_stock_verified
    and v_state.payment_methods_verified
    and v_state.public_site_verified
    and v_state.staff_accounts_verified
    and v_state.backup_plan_verified;

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'automatic',jsonb_build_object(
      'active_owner',v_owner_count>=1,
      'active_staff_count',v_staff_count,
      'active_products',v_product_count,
      'active_raw_materials',v_material_count,
      'active_suppliers',v_supplier_count,
      'negative_stock_count',v_negative_stock,
      'recipe_gap_count',v_recipe_gap,
      'public_site_contact_ready',v_public_ok,
      'passing_staging_validation',v_validation_pass
    ),
    'manual',jsonb_build_object(
      'catalog_verified',v_state.catalog_verified,
      'opening_stock_verified',v_state.opening_stock_verified,
      'payment_methods_verified',v_state.payment_methods_verified,
      'public_site_verified',v_state.public_site_verified,
      'staff_accounts_verified',v_state.staff_accounts_verified,
      'backup_plan_verified',v_state.backup_plan_verified
    ),
    'automatic_gate',case when v_auto_pass then 'pass' else 'fail' end,
    'manual_gate',case when v_manual_pass then 'pass' else 'fail' end,
    'staging_validation_gate',case when v_validation_pass then 'pass' else 'warn' end,
    'setup_completed',v_state.completed_at is not null,
    'completed_at',v_state.completed_at,
    'notes',v_state.notes
  );
end;
$$;

update public.system_release_state
set app_version='0.32.0',
    latest_migration=31,
    release_stage='formal_staging_validation',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 032 =====
-- DS Bakery v0.33 / Migration 032
-- Staging placeholder guard and payment-method validation.

create or replace function public.staging_placeholder_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_products bigint;
  v_materials bigint;
  v_suppliers bigint;
  v_customers bigint;
  v_staff bigint;
  v_total bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select count(*) into v_products
  from public.products
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_materials
  from public.raw_materials
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_suppliers
  from public.suppliers
  where upper(name) like 'STAGING TEST%';

  select count(*) into v_customers
  from public.customers
  where upper(full_name) like 'STAGING TEST%';

  select count(*) into v_staff
  from public.profiles
  where full_name in (
    'DS Bakery Owner',
    'DS Bakery Manager',
    'DS Bakery Cashier',
    'DS Bakery Baker',
    'DS Bakery Storekeeper'
  );

  v_total:=v_products+v_materials+v_suppliers+v_customers+v_staff;

  return jsonb_build_object(
    'total_placeholder_records',v_total,
    'products',v_products,
    'raw_materials',v_materials,
    'suppliers',v_suppliers,
    'customers',v_customers,
    'generic_staging_staff',v_staff,
    'clear_for_production',v_total=0
  );
end;
$$;

create or replace function public.payment_method_validation_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_cash bigint;
  v_mtn bigint;
  v_airtel bigint;
  v_conflicts bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select count(*) into v_cash
  from public.payments
  where status='completed' and method='cash';

  select count(*) into v_mtn
  from public.payments
  where status='completed' and method='mtn_momo';

  select count(*) into v_airtel
  from public.payments
  where status='completed' and method='airtel_money';

  select count(*) into v_conflicts
  from public.mobile_money_reference_conflicts;

  return jsonb_build_object(
    'cash_tested',v_cash>0,
    'mtn_momo_tested',v_mtn>0,
    'airtel_money_tested',v_airtel>0,
    'mobile_money_reference_conflicts',v_conflicts,
    'all_methods_verified',v_cash>0 and v_mtn>0 and v_airtel>0 and v_conflicts=0
  );
end;
$$;

create or replace function public.production_cutover_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_placeholders jsonb;
  v_placeholder_count bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_cut from public.production_cutover_state where id=1;
  select * into v_setup from public.go_live_setup_state where id=1;

  v_placeholders:=public.staging_placeholder_summary();
  v_placeholder_count:=coalesce((v_placeholders->>'total_placeholder_records')::bigint,0);

  return jsonb_build_object(
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'go_live_setup_completed',v_setup.completed_at is not null,
    'go_live_setup_completed_at',v_setup.completed_at,
    'operations_enabled',v_cut.operations_enabled,
    'authorized_at',v_cut.authorized_at,
    'suspended_at',v_cut.suspended_at,
    'suspension_reason',v_cut.suspension_reason,
    'placeholder_count',v_placeholder_count,
    'placeholders',v_placeholders,
    'ready_to_authorize',
      v_env.environment_mode='production'
      and v_env.production_lock
      and v_setup.completed_at is not null
      and v_placeholder_count=0
  );
end;
$$;

create or replace function public.authorize_production_operations(p_confirmation text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_env public.system_environment_config%rowtype;
  v_setup public.go_live_setup_state%rowtype;
  v_cut public.production_cutover_state%rowtype;
  v_placeholder_count bigint;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may authorize production operations';
  end if;

  if p_confirmation<>'AUTHORIZE LIVE OPERATIONS' then
    raise exception 'Type AUTHORIZE LIVE OPERATIONS exactly';
  end if;

  select * into v_env
  from public.system_environment_config
  where id=1
  for update;

  select * into v_setup
  from public.go_live_setup_state
  where id=1
  for update;

  select * into v_cut
  from public.production_cutover_state
  where id=1
  for update;

  v_placeholder_count:=coalesce(
    (public.staging_placeholder_summary()->>'total_placeholder_records')::bigint,
    0
  );

  if v_env.environment_mode<>'production' then
    raise exception 'Environment must be Production';
  end if;

  if not v_env.production_lock then
    raise exception 'Production Lock must be enabled before live operations';
  end if;

  if v_setup.completed_at is null then
    raise exception 'Go-Live Setup must be completed first';
  end if;

  if v_placeholder_count>0 then
    raise exception 'Replace or remove all staging placeholder records before live operations';
  end if;

  update public.production_cutover_state
  set
    operations_enabled=true,
    authorized_by=auth.uid(),
    authorized_at=now(),
    suspended_by=null,
    suspended_at=null,
    suspension_reason=null,
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(
    auth.uid(),'authorize_production_operations','production_cutover_state',null,
    to_jsonb(v_cut),
    (select to_jsonb(c) from public.production_cutover_state c where c.id=1)
  );
end;
$$;

create or replace function public.launch_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_checks jsonb;
  v_fail integer;
  v_warn integer;
  v_env public.system_environment_config%rowtype;
  v_release public.system_release_state%rowtype;
  v_setup jsonb;
  v_setup_status text;
  v_cut public.production_cutover_state%rowtype;
  v_cut_status text;
  v_lock_status text;
  v_connection_status text;
  v_placeholders jsonb;
  v_placeholder_count bigint;
  v_placeholder_status text;
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may run launch-readiness summary';
  end if;

  select * into v_env from public.system_environment_config where id=1;
  select * into v_release from public.system_release_state where id=1;
  select * into v_cut from public.production_cutover_state where id=1;

  v_setup:=public.go_live_setup_readiness();
  v_placeholders:=public.staging_placeholder_summary();
  v_placeholder_count:=coalesce((v_placeholders->>'total_placeholder_records')::bigint,0);

  v_setup_status:=case
    when coalesce((v_setup->>'setup_completed')::boolean,false) then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_lock_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_env.production_lock then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_cut_status:=case
    when v_env.environment_mode='staging' then 'pass'
    when v_env.environment_mode='production' and v_cut.operations_enabled then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  v_connection_status:=case
    when v_env.environment_mode='production' then 'pass'
    when exists(
      select 1
      from public.environment_connection_checks ecc
      where ecc.environment_mode='staging'
        and ecc.check_type='supabase_connectivity'
        and ecc.status='pass'
        and ecc.app_version=v_release.app_version
        and ecc.latest_migration=v_release.latest_migration
    ) then 'pass'
    else 'warn'
  end;

  v_placeholder_status:=case
    when v_placeholder_count=0 then 'pass'
    when v_env.environment_mode='production' then 'fail'
    else 'warn'
  end;

  select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb),
         count(*) filter(where x.status='fail'),
         count(*) filter(where x.status='warn')
  into v_checks,v_fail,v_warn
  from (
    select * from public.launch_readiness_checks()
    union all
    select 'environment_mode'::text,
      case when v_env.environment_mode='unconfigured' then 'fail' else 'pass' end,
      case when v_env.environment_mode='unconfigured' then 'Environment mode has not been configured'
           else 'Environment mode: '||v_env.environment_mode end
    union all
    select 'staging_connection_evidence'::text,
      v_connection_status,
      case
        when v_env.environment_mode='production' then 'Staging connection evidence was a pre-production gate'
        when v_connection_status='pass' then 'Passing Supabase staging connectivity evidence exists'
        else 'Run the real Supabase staging connectivity check'
      end
    union all
    select 'staging_placeholder_data'::text,
      v_placeholder_status,
      case
        when v_placeholder_count=0 then 'No staging placeholder records remain'
        when v_env.environment_mode='production' then v_placeholder_count::text||' staging placeholder record(s) must be replaced before production'
        else v_placeholder_count::text||' staging placeholder record(s) remain; acceptable in staging but must be replaced before production'
      end
    union all
    select 'go_live_setup'::text,
      v_setup_status,
      case
        when v_setup_status='pass' then 'Go-live setup has been completed'
        when v_setup_status='fail' then 'Production mode requires completed go-live setup'
        else 'Go-live setup is not completed yet'
      end
    union all
    select 'production_lock'::text,
      v_lock_status,
      case
        when v_env.environment_mode='staging' then 'Production Lock is not required in staging'
        when v_env.production_lock then 'Production Lock is enabled'
        else 'Production Lock is required before live operations'
      end
    union all
    select 'production_operations'::text,
      v_cut_status,
      case
        when v_env.environment_mode='staging' then 'Transactional writes are allowed for staging tests'
        when v_cut.operations_enabled then 'Live business operations are authorized'
        else 'Live business operations are not authorized'
      end
  ) x;

  return jsonb_build_object(
    'app_version',v_release.app_version,
    'latest_migration',v_release.latest_migration,
    'environment_mode',v_env.environment_mode,
    'production_lock',v_env.production_lock,
    'operations_enabled',v_cut.operations_enabled,
    'placeholders',v_placeholders,
    'go_live_setup',v_setup,
    'database_checks',v_checks,
    'fail_count',v_fail,
    'warn_count',v_warn,
    'database_gate',case when v_fail=0 then 'pass' else 'fail' end,
    'checked_at',now()
  );
end;
$$;

revoke all on function public.staging_placeholder_summary() from public,anon;
revoke all on function public.payment_method_validation_summary() from public,anon;
grant execute on function public.staging_placeholder_summary() to authenticated;
grant execute on function public.payment_method_validation_summary() to authenticated;

update public.system_release_state
set app_version='0.33.0',
    latest_migration=32,
    release_stage='placeholder_guard_payment_validation',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 033 =====
-- DS Bakery v0.34 / Migration 033
-- Backup and recovery readiness.

create table if not exists public.backup_recovery_events(
  id uuid primary key default gen_random_uuid(),
  event_type text not null check(event_type in ('plan_prepared','backup_created','backup_verified','restore_drill')),
  status text not null check(status in ('pass','warn','fail')),
  backup_label text null,
  checksum text null,
  notes text null,
  recorded_by uuid null references public.profiles(id),
  recorded_at timestamptz not null default now()
);

alter table public.backup_recovery_events enable row level security;

drop policy if exists "owner manager read backup recovery events" on public.backup_recovery_events;
create policy "owner manager read backup recovery events"
on public.backup_recovery_events for select
to authenticated
using (public.current_staff_role() in ('owner','manager'));

create or replace function public.record_backup_recovery_event(
  p_event_type text,
  p_status text,
  p_backup_label text default null,
  p_checksum text default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid:=gen_random_uuid();
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may record backup/recovery evidence';
  end if;

  if p_event_type not in ('plan_prepared','backup_created','backup_verified','restore_drill') then
    raise exception 'Invalid backup/recovery event type';
  end if;
  if p_status not in ('pass','warn','fail') then
    raise exception 'Invalid backup/recovery event status';
  end if;

  insert into public.backup_recovery_events(
    id,event_type,status,backup_label,checksum,notes,recorded_by
  )
  values(
    v_id,p_event_type,p_status,
    nullif(trim(p_backup_label),''),
    nullif(trim(p_checksum),''),
    nullif(trim(p_notes),''),
    auth.uid()
  );

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'record_backup_recovery_event','backup_recovery_event',v_id,
    jsonb_build_object(
      'event_type',p_event_type,
      'status',p_status,
      'backup_label',p_backup_label,
      'checksum',p_checksum
    )
  );

  return v_id;
end;
$$;

create or replace function public.recovery_verification_manifest()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_release public.system_release_state%rowtype;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v_release from public.system_release_state where id=1;

  return jsonb_build_object(
    'generated_at',now(),
    'app_version',v_release.app_version,
    'latest_migration',v_release.latest_migration,
    'release_stage',v_release.release_stage,
    'critical_counts',jsonb_build_object(
      'profiles',(select count(*) from public.profiles),
      'products',(select count(*) from public.products),
      'raw_materials',(select count(*) from public.raw_materials),
      'suppliers',(select count(*) from public.suppliers),
      'recipes',(select count(*) from public.recipes),
      'purchases',(select count(*) from public.purchases),
      'inventory_transactions',(select count(*) from public.inventory_transactions),
      'production_runs',(select count(*) from public.production_runs),
      'waste_events',(select count(*) from public.waste_events),
      'customers',(select count(*) from public.customers),
      'customer_orders',(select count(*) from public.customer_orders),
      'sales',(select count(*) from public.sales),
      'payments',(select count(*) from public.payments),
      'expenses',(select count(*) from public.expenses),
      'audit_logs',(select count(*) from public.audit_logs)
    ),
    'integrity',jsonb_build_object(
      'negative_stock_count',(select count(*) from public.raw_materials where current_stock_qty<0),
      'active_owner_count',(select count(*) from public.profiles where active=true and disabled_at is null and role='owner'),
      'open_cashier_shift_count',(select count(*) from public.cashier_shifts where status='open'),
      'mobile_money_conflict_count',(select count(*) from public.mobile_money_reference_conflicts),
      'validation_pass_count',(select count(*) from public.validation_runs where overall_status='pass' and completed_at is not null)
    ),
    'financial_totals',jsonb_build_object(
      'completed_sales_total',(select coalesce(sum(total),0) from public.sales where status='completed'),
      'completed_payments_total',(select coalesce(sum(amount),0) from public.payments where status='completed'),
      'customer_order_payments_total',(select coalesce(sum(amount),0) from public.customer_order_payments where payment_status='completed'),
      'expenses_total',(select coalesce(sum(amount),0) from public.expenses)
    )
  );
end;
$$;

create or replace function public.backup_recovery_status()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_latest_backup jsonb;
  v_latest_verify jsonb;
  v_latest_restore jsonb;
  v_restore_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select to_jsonb(x) into v_latest_backup
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='backup_created'
    order by recorded_at desc limit 1
  ) x;

  select to_jsonb(x) into v_latest_verify
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='backup_verified'
    order by recorded_at desc limit 1
  ) x;

  select to_jsonb(x) into v_latest_restore
  from (
    select id,status,backup_label,checksum,notes,recorded_at
    from public.backup_recovery_events
    where event_type='restore_drill'
    order by recorded_at desc limit 1
  ) x;

  v_restore_pass:=exists(
    select 1 from public.backup_recovery_events
    where event_type='restore_drill' and status='pass'
  );

  return jsonb_build_object(
    'strategy','supabase_cli_logical_backup_plus_provider_backup',
    'latest_backup',v_latest_backup,
    'latest_backup_verification',v_latest_verify,
    'latest_restore_drill',v_latest_restore,
    'restore_drill_passed',v_restore_pass,
    'go_live_backup_gate',case when v_restore_pass then 'pass' else 'pending' end
  );
end;
$$;

revoke all on function public.record_backup_recovery_event(text,text,text,text,text) from public,anon;
revoke all on function public.recovery_verification_manifest() from public,anon;
revoke all on function public.backup_recovery_status() from public,anon;
grant execute on function public.record_backup_recovery_event(text,text,text,text,text) to authenticated;
grant execute on function public.recovery_verification_manifest() to authenticated;
grant execute on function public.backup_recovery_status() to authenticated;

update public.system_release_state
set app_version='0.34.0',
    latest_migration=33,
    release_stage='backup_recovery_readiness',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 034 =====
-- DS Bakery v0.35 / Migration 034
-- Deployment preparation and staging-host readiness tracking.

create table if not exists public.deployment_readiness_state(
  id smallint primary key default 1 check(id=1),
  target_host text null,
  target_environment text not null default 'staging' check(target_environment in ('staging','production')),
  staging_url text null,
  source_prepared boolean not null default false,
  runtime_env_prepared boolean not null default false,
  healthcheck_prepared boolean not null default false,
  build_verified boolean not null default false,
  healthcheck_verified boolean not null default false,
  public_site_verified boolean not null default false,
  auth_login_verified boolean not null default false,
  notes text null,
  updated_by uuid null references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.deployment_readiness_state(id,target_host,target_environment,notes)
values(1,'Railway','staging','Production deployment preparation started. Existing Railway production service has not been modified.')
on conflict(id) do nothing;

alter table public.deployment_readiness_state enable row level security;

drop policy if exists "owner manager read deployment readiness" on public.deployment_readiness_state;
create policy "owner manager read deployment readiness"
on public.deployment_readiness_state for select
to authenticated
using (public.current_staff_role() in ('owner','manager'));

create or replace function public.update_deployment_readiness(
  p_target_host text,
  p_target_environment text,
  p_staging_url text,
  p_source_prepared boolean,
  p_runtime_env_prepared boolean,
  p_healthcheck_prepared boolean,
  p_build_verified boolean,
  p_healthcheck_verified boolean,
  p_public_site_verified boolean,
  p_auth_login_verified boolean,
  p_notes text default null
)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if public.current_staff_role()<>'owner' then
    raise exception 'Only owner may update deployment readiness';
  end if;
  if p_target_environment not in ('staging','production') then
    raise exception 'Target environment must be staging or production';
  end if;

  update public.deployment_readiness_state
  set
    target_host=nullif(trim(p_target_host),''),
    target_environment=p_target_environment,
    staging_url=nullif(trim(p_staging_url),''),
    source_prepared=coalesce(p_source_prepared,false),
    runtime_env_prepared=coalesce(p_runtime_env_prepared,false),
    healthcheck_prepared=coalesce(p_healthcheck_prepared,false),
    build_verified=coalesce(p_build_verified,false),
    healthcheck_verified=coalesce(p_healthcheck_verified,false),
    public_site_verified=coalesce(p_public_site_verified,false),
    auth_login_verified=coalesce(p_auth_login_verified,false),
    notes=nullif(trim(p_notes),''),
    updated_by=auth.uid(),
    updated_at=now()
  where id=1;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(
    auth.uid(),'update_deployment_readiness','deployment_readiness_state',null,
    (select to_jsonb(d) from public.deployment_readiness_state d where d.id=1)
  );
end;
$$;

create or replace function public.deployment_readiness_summary()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.deployment_readiness_state%rowtype;
  v_required_pass boolean;
begin
  if public.current_staff_role() not in ('owner','manager') then
    raise exception 'Owner or manager access required';
  end if;

  select * into v from public.deployment_readiness_state where id=1;

  v_required_pass :=
    v.source_prepared
    and v.runtime_env_prepared
    and v.healthcheck_prepared
    and v.build_verified
    and v.healthcheck_verified
    and v.public_site_verified
    and v.auth_login_verified;

  return jsonb_build_object(
    'target_host',v.target_host,
    'target_environment',v.target_environment,
    'staging_url',v.staging_url,
    'source_prepared',v.source_prepared,
    'runtime_env_prepared',v.runtime_env_prepared,
    'healthcheck_prepared',v.healthcheck_prepared,
    'build_verified',v.build_verified,
    'healthcheck_verified',v.healthcheck_verified,
    'public_site_verified',v.public_site_verified,
    'auth_login_verified',v.auth_login_verified,
    'deployment_gate',case when v_required_pass then 'pass' else 'pending' end,
    'notes',v.notes,
    'updated_at',v.updated_at
  );
end;
$$;

revoke all on function public.update_deployment_readiness(text,text,text,boolean,boolean,boolean,boolean,boolean,boolean,boolean,text) from public,anon;
revoke all on function public.deployment_readiness_summary() from public,anon;
grant execute on function public.update_deployment_readiness(text,text,text,boolean,boolean,boolean,boolean,boolean,boolean,boolean,text) to authenticated;
grant execute on function public.deployment_readiness_summary() to authenticated;

update public.system_release_state
set app_version='0.35.0',
    latest_migration=34,
    release_stage='deployment_preparation',
    updated_at=now()
where id=1;


-- ===== INTEGRATION STAGE / MIGRATION 035 =====
-- DS Bakery v0.36 / Migration 035
-- Staging hardening consolidation: dashboard permissions, RLS performance/policy cleanup,
-- duplicate-index removal, and restricted execution of internal helper RPCs.

-- Dashboard/security permission keys required by the practical Owner dashboard and access checks.
insert into public.app_permissions(permission_key,description,critical)
values
  ('dashboard:view','View the management dashboard',false),
  ('security:manage','Manage security controls and security settings',true)
on conflict (permission_key) do update
set description=excluded.description,
    critical=excluded.critical;

insert into public.role_permission_defaults(role,permission_key,allowed)
values
  ('owner','dashboard:view',true),
  ('manager','dashboard:view',true),
  ('cashier','dashboard:view',false),
  ('baker','dashboard:view',false),
  ('storekeeper','dashboard:view',false),
  ('owner','security:manage',true),
  ('manager','security:manage',false),
  ('cashier','security:manage',false),
  ('baker','security:manage',false),
  ('storekeeper','security:manage',false)
on conflict (role,permission_key) do update set allowed=excluded.allowed;

-- Confirmed duplicate index.
drop index if exists public.communication_logs_customer_created_idx;

-- RLS: use a single read policy plus command-specific write policies where possible.
drop policy if exists "owner manages profiles" on public.profiles;
drop policy if exists "owner insert profiles" on public.profiles;
drop policy if exists "owner update profiles" on public.profiles;
drop policy if exists "owner delete profiles" on public.profiles;
drop policy if exists "staff can read own profile" on public.profiles;
create policy "staff can read own profile" on public.profiles for select to authenticated
using (id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "owner insert profiles" on public.profiles for insert to authenticated
with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update profiles" on public.profiles for update to authenticated
using (public.current_staff_role()='owner'::public.staff_role)
with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete profiles" on public.profiles for delete to authenticated
using (public.current_staff_role()='owner'::public.staff_role);

-- Auth init-plan optimization on hot read paths.
drop policy if exists "staff read permitted cash movements" on public.cash_movements;
create policy "staff read permitted cash movements" on public.cash_movements for select
using (created_by=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

drop policy if exists "production staff read plan items" on public.production_plan_items;
create policy "production staff read plan items" on public.production_plan_items for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or (public.current_staff_role()='baker'::public.staff_role and assigned_baker_id=(select auth.uid())));

drop policy if exists "production staff read runs" on public.production_runs;
create policy "production staff read runs" on public.production_runs for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or confirmed_by=(select auth.uid()));

drop policy if exists "staff read relevant waste" on public.waste_events;
create policy "staff read relevant waste" on public.waste_events for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or recorded_by=(select auth.uid()) or (public.current_staff_role()='storekeeper'::public.staff_role and waste_type='raw_material'::public.waste_type));

drop policy if exists "staff read own or management attendance" on public.attendance_records;
create policy "staff read own or management attendance" on public.attendance_records for select
using (staff_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

drop policy if exists "staff read relevant baker tasks" on public.baker_tasks;
create policy "staff read relevant baker tasks" on public.baker_tasks for select
using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]) or assigned_baker_id=(select auth.uid()));

drop policy if exists "production staff read consumption" on public.production_consumptions;
create policy "production staff read consumption" on public.production_consumptions for select
using (
  public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role,'storekeeper'::public.staff_role])
  or (
    public.current_staff_role()='baker'::public.staff_role
    and exists (
      select 1
      from public.production_runs pr
      join public.production_plan_items ppi on ppi.id=pr.plan_item_id
      where pr.id=production_consumptions.production_run_id
        and (pr.confirmed_by=(select auth.uid()) or ppi.assigned_baker_id=(select auth.uid()))
    )
  )
);

-- Attendance settings.
drop policy if exists "owner manage attendance settings" on public.attendance_settings;
drop policy if exists "owner insert attendance settings" on public.attendance_settings;
drop policy if exists "owner update attendance settings" on public.attendance_settings;
drop policy if exists "owner delete attendance settings" on public.attendance_settings;
alter policy "staff read attendance settings" on public.attendance_settings to authenticated;
create policy "owner insert attendance settings" on public.attendance_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update attendance settings" on public.attendance_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete attendance settings" on public.attendance_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Business settings.
drop policy if exists "owner manage business settings" on public.business_settings;
drop policy if exists "owner insert business settings" on public.business_settings;
drop policy if exists "owner update business settings" on public.business_settings;
drop policy if exists "owner delete business settings" on public.business_settings;
alter policy "management read business settings" on public.business_settings to authenticated;
create policy "owner insert business settings" on public.business_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update business settings" on public.business_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete business settings" on public.business_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Cashier shifts.
drop policy if exists "manager owner manage shifts" on public.cashier_shifts;
drop policy if exists "management insert cashier shifts" on public.cashier_shifts;
drop policy if exists "management update cashier shifts" on public.cashier_shifts;
drop policy if exists "management delete cashier shifts" on public.cashier_shifts;
drop policy if exists "sales staff read own shifts" on public.cashier_shifts;
create policy "sales staff read own shifts" on public.cashier_shifts for select to authenticated
using (cashier_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management insert cashier shifts" on public.cashier_shifts for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update cashier shifts" on public.cashier_shifts for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete cashier shifts" on public.cashier_shifts for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Daily closings.
drop policy if exists "owner manager manage closings" on public.daily_closings;
drop policy if exists "management insert daily closings" on public.daily_closings;
drop policy if exists "management update daily closings" on public.daily_closings;
drop policy if exists "management delete daily closings" on public.daily_closings;
alter policy "owner manager read closings" on public.daily_closings to authenticated;
create policy "management insert daily closings" on public.daily_closings for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update daily closings" on public.daily_closings for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete daily closings" on public.daily_closings for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Product categories.
drop policy if exists "owner manager manage categories" on public.product_categories;
drop policy if exists "management insert product categories" on public.product_categories;
drop policy if exists "management update product categories" on public.product_categories;
drop policy if exists "management delete product categories" on public.product_categories;
alter policy "staff read categories" on public.product_categories to authenticated;
create policy "management insert product categories" on public.product_categories for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update product categories" on public.product_categories for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete product categories" on public.product_categories for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Staff work shifts.
drop policy if exists "management schedules" on public.staff_work_shifts;
drop policy if exists "management insert work shifts" on public.staff_work_shifts;
drop policy if exists "management update work shifts" on public.staff_work_shifts;
drop policy if exists "management delete work shifts" on public.staff_work_shifts;
drop policy if exists "staff read own or management schedules" on public.staff_work_shifts;
create policy "staff read own or management schedules" on public.staff_work_shifts for select to authenticated
using (staff_id=(select auth.uid()) or public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management insert work shifts" on public.staff_work_shifts for insert to authenticated with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management update work shifts" on public.staff_work_shifts for update to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role])) with check (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));
create policy "management delete work shifts" on public.staff_work_shifts for delete to authenticated using (public.current_staff_role()=any(array['owner'::public.staff_role,'manager'::public.staff_role]));

-- Waste settings.
drop policy if exists "owner manage waste settings" on public.waste_settings;
drop policy if exists "owner insert waste settings" on public.waste_settings;
drop policy if exists "owner update waste settings" on public.waste_settings;
drop policy if exists "owner delete waste settings" on public.waste_settings;
alter policy "relevant staff read waste settings" on public.waste_settings to authenticated;
create policy "owner insert waste settings" on public.waste_settings for insert to authenticated with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner update waste settings" on public.waste_settings for update to authenticated using (public.current_staff_role()='owner'::public.staff_role) with check (public.current_staff_role()='owner'::public.staff_role);
create policy "owner delete waste settings" on public.waste_settings for delete to authenticated using (public.current_staff_role()='owner'::public.staff_role);

-- Internal helpers are callable only through audited parent RPCs or server-side service role paths.
revoke execute on function public.apply_approved_raw_waste(uuid) from authenticated;
revoke execute on function public.calculate_daily_closing(date) from authenticated;
revoke execute on function public.complete_sale(jsonb,numeric,jsonb,text,boolean,uuid) from authenticated;
revoke execute on function public.current_product_unit_cost(uuid) from authenticated;
revoke execute on function public.launch_readiness_checks() from authenticated;
revoke execute on function public.production_run_unit_cost(uuid) from authenticated;
revoke execute on function public.refresh_customer_order_total(uuid) from authenticated;
revoke execute on function public.refresh_purchase_totals(uuid) from authenticated;
revoke execute on function public.staging_placeholder_summary() from authenticated;
revoke execute on function public.sync_order_loyalty_points(uuid) from authenticated;
revoke execute on function public.sync_sale_loyalty_points(uuid) from authenticated;
revoke execute on function public.verify_approver_pin(text) from authenticated;

update public.system_release_state
set app_version='0.36.0',
    latest_migration=35,
    release_stage='staging_hardening_consolidation',
    updated_at=now()
where id=1;
