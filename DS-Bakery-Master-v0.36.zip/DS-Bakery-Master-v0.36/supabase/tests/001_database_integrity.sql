-- Run as an administrative SQL session after migrations 002–021.
-- PASS rows should return zero issue_count unless noted as WARN.

select 'negative_inventory' check_key,count(*) issue_count
from public.raw_materials where current_stock_qty<0

union all
select 'multiple_active_recipes',count(*)
from (
  select product_id from public.recipes where active=true
  group by product_id having count(*)>1
) x

union all
select 'invalid_customer_order_net_paid',count(*)
from public.customer_orders co
where public.customer_order_net_paid(co.id)<-0.01
   or public.customer_order_net_paid(co.id)>co.total_amount+0.01

union all
select 'excess_finished_waste',count(*)
from public.production_runs pr
where coalesce((
  select sum(we.quantity) from public.waste_events we
  where we.production_run_id=pr.id
    and we.waste_type='finished_product'
    and we.approval_status<>'rejected'
),0)>pr.quantity_produced

union all
select 'historical_mobile_money_conflicts',count(*)
from public.mobile_money_reference_conflicts;
