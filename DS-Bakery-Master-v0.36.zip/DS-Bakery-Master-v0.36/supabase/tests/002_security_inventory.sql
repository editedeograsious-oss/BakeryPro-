-- Administrative security inventory.
-- Review every result before production.

-- Tables in public schema with RLS disabled.
select n.nspname schema_name,c.relname table_name,c.relrowsecurity rls_enabled
from pg_class c
join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public'
  and c.relkind='r'
  and c.relrowsecurity=false
order by c.relname;

-- SECURITY DEFINER functions and configured search path.
select
  n.nspname schema_name,
  p.proname function_name,
  pg_get_function_identity_arguments(p.oid) arguments,
  p.prosecdef security_definer,
  p.proconfig configuration
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and p.prosecdef=true
order by p.proname;

-- Functions executable by PUBLIC.
select
  n.nspname schema_name,
  p.proname function_name,
  pg_get_function_identity_arguments(p.oid) arguments
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and has_function_privilege('public',p.oid,'EXECUTE')
order by p.proname;
