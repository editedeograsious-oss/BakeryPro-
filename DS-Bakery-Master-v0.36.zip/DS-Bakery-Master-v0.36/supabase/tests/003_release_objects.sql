-- Required v0.25 release objects.
select 'system_release_state' object_name,to_regclass('public.system_release_state') is not null as object_exists
union all select 'customer_order_refunds',to_regclass('public.customer_order_refunds') is not null
union all select 'inventory_movement_summary',to_regclass('public.inventory_movement_summary') is not null
union all select 'launch_readiness_checks',to_regprocedure('public.launch_readiness_checks()') is not null
union all select 'launch_readiness_summary',to_regprocedure('public.launch_readiness_summary()') is not null
union all select 'save_supplier',to_regprocedure('public.save_supplier(uuid,text,text,text,text,boolean,uuid)') is not null
union all select 'public_site_settings',to_regclass('public.public_site_settings') is not null
union all select 'public_site_info',to_regprocedure('public.public_site_info()') is not null
union all select 'public_product_catalog',to_regprocedure('public.public_product_catalog()') is not null
union all select 'update_public_site_settings',to_regprocedure('public.update_public_site_settings(text,text,text,text,text,text,text,text,text,text,boolean,boolean)') is not null
union all select 'validation_runs',to_regclass('public.validation_runs') is not null
union all select 'validation_check_results',to_regclass('public.validation_check_results') is not null
union all select 'validation_run_summary',to_regclass('public.validation_run_summary') is not null
union all select 'begin_validation_run',to_regprocedure('public.begin_validation_run(text,text)') is not null
union all select 'record_validation_check',to_regprocedure('public.record_validation_check(uuid,text,text,text,text,text)') is not null
union all select 'complete_validation_run',to_regprocedure('public.complete_validation_run(uuid,text)') is not null
union all select 'system_environment_config',to_regclass('public.system_environment_config') is not null
union all select 'configure_system_environment',to_regprocedure('public.configure_system_environment(text,boolean,text,text)') is not null
union all select 'enable_production_lock',to_regprocedure('public.enable_production_lock(text)') is not null
union all select 'environment_state',to_regprocedure('public.environment_state()') is not null
union all select 'go_live_setup_state',to_regclass('public.go_live_setup_state') is not null
union all select 'go_live_setup_readiness',to_regprocedure('public.go_live_setup_readiness()') is not null
union all select 'update_go_live_setup_checklist',to_regprocedure('public.update_go_live_setup_checklist(boolean,boolean,boolean,boolean,boolean,boolean,text)') is not null
union all select 'complete_go_live_setup',to_regprocedure('public.complete_go_live_setup(text)') is not null
union all select 'production_cutover_state',to_regclass('public.production_cutover_state') is not null
union all select 'production_cutover_status',to_regprocedure('public.production_cutover_status()') is not null
union all select 'authorize_production_operations',to_regprocedure('public.authorize_production_operations(text)') is not null
union all select 'suspend_production_operations',to_regprocedure('public.suspend_production_operations(text)') is not null
union all select 'assert_business_operation_allowed',to_regprocedure('public.assert_business_operation_allowed()') is not null
union all select 'environment_connection_checks',to_regclass('public.environment_connection_checks') is not null
union all select 'record_environment_connection_check',to_regprocedure('public.record_environment_connection_check(text,text,text,jsonb)') is not null
union all select 'environment_connection_summary',to_regprocedure('public.environment_connection_summary()') is not null;

-- Required public-contact columns.
select
  count(*) filter(where column_name='secondary_phone')=1 as secondary_phone_exists,
  count(*) filter(where column_name='tiktok_handle')=1 as tiktok_handle_exists
from information_schema.columns
where table_schema='public'
  and table_name='public_site_settings'
  and column_name in ('secondary_phone','tiktok_handle');
