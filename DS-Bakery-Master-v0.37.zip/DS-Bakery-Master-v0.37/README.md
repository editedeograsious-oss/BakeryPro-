# DS Bakery Master v0.37 — Usability, Data Management & Core Business Completion

- App version: **0.37.0**
- Database migration target: **036**
- Environment: **staging until explicit production cutover**

DS Bakery Master is one integrated bakery-management system and public online shop. v0.37 adds the practical controls identified during real staging review: logout/account recovery, edit controls, safe deletion with Recycle Bin, Customer Credit Book, staff salaries/payroll, finished-goods batches with actual batch costing, and a real public cart/checkout that creates Customer Orders.

## Core business areas
Sales/POS, Cash/MTN/Airtel payments, Customer Credit, expenses, cashier shifts, daily closing, products, recipes/costing, raw-material inventory, purchasing/receiving, production, finished-goods batches, waste, customers/orders/custom cakes, delivery, loyalty, WhatsApp click-to-chat, attendance/schedules, staff/security, payroll, management reports, public website and online ordering.

## Data protection principle
Normal users may see a Delete action for eligible records, but DS Bakery does not silently erase accounting or stock history. Master/setup records can be soft-deleted and restored. Financial/stock records use cancellation, void, refund or reversal controls. Audit logs are never deletable.

## Batch profit principle
Raw-material weighted-average cost is captured at production consumption. Each confirmed production run creates a finished-goods batch with actual batch/unit cost. Sales and completed customer orders allocate quantity from finished batches so COGS and realized gross profit are based on the real batch cost.

## Still intentionally pending before production
- Replace staging placeholder data with the bakery's real catalog, opening stock and final staff details.
- Complete and document a real backup/restore drill.
- Complete final public-site browser/visual verification.
- Complete controlled production cutover.
- Automatic MTN/Airtel payment API integration and automated customer notifications are later-phase enhancements.

See `docs/V037_USABILITY_DATA_MANAGEMENT_CORE_BUSINESS.md` for the v0.37 feature summary.
