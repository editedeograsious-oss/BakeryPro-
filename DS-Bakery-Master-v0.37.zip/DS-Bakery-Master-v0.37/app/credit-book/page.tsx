import Sidebar from "@/components/Sidebar";
import CreditBookManager from "@/components/finance/CreditBookManager";
import { requirePermission } from "@/lib/access";
import { getCreditBookData } from "@/lib/repositories/business37";

export const dynamic="force-dynamic";
export default async function CreditBook(){
  const staff=await requirePermission("credit:read",["owner","manager","cashier"]);
  const data=await getCreditBookData();
  return <div className="shell"><Sidebar/><main className="main"><CreditBookManager accounts={data.accounts} ledger={data.ledger} live={!data.demo} canSetTerms={["owner","manager"].includes(staff.profile.role)}/></main></div>;
}
