import Sidebar from "@/components/Sidebar";
import FinishedGoodsManager from "@/components/operations/FinishedGoodsManager";
import { requirePermission } from "@/lib/access";
import { getFinishedGoodsData } from "@/lib/repositories/business37";

export const dynamic="force-dynamic";
export default async function FinishedGoodsPage(){
  await requirePermission("finished_goods:read",["owner","manager","baker","storekeeper"]);
  const data=await getFinishedGoodsData();
  return <div className="shell"><Sidebar/><main className="main"><FinishedGoodsManager batches={data.batches}/></main></div>;
}
