import Sidebar from "@/components/Sidebar";
import InventoryManager from "@/components/core/InventoryManager";
import { requireStaff } from "@/lib/auth";
import { getInventoryPageData } from "@/lib/repositories/coreLive";

export const dynamic="force-dynamic";

export default async function Inventory(){
  const staff=await requireStaff(["owner","manager","storekeeper","baker"]);
  const data=await getInventoryPageData();
  const canAdjust=["owner","manager","storekeeper"].includes(staff.profile.role);

  return <div className="shell"><Sidebar/><main className="main">
    <InventoryManager materials={data.materials} suppliers={data.suppliers} live={!data.demo} canAdjust={canAdjust}/>
  </main></div>;
}
