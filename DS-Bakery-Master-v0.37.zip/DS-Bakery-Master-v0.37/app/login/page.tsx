'use client';

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function Login(){
  const router=useRouter();
  const params=useSearchParams();
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [role,setRole]=useState("owner");
  const [message,setMessage]=useState("");
  const [loading,setLoading]=useState(false);
  const [resetBusy,setResetBusy]=useState(false);

  const liveMode=useMemo(()=>Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),[]);

  async function submit(e:React.FormEvent){
    e.preventDefault();setMessage("");
    if(!liveMode){localStorage.setItem("dsb-demo-role",role);router.push("/dashboard");return;}
    setLoading(true);
    const supabase=createClient();
    const {error}=await supabase.auth.signInWithPassword({email,password});
    setLoading(false);
    if(error){setMessage("Login failed. Check your email and password.");return;}
    const requested=params.get("next");
    const safeNext=requested&&requested.startsWith("/")&&!requested.startsWith("//")?requested:"/dashboard";
    router.replace(safeNext);router.refresh();
  }

  async function forgotPassword(){
    if(!liveMode){setMessage("Password reset is available when connected to Supabase Auth.");return;}
    if(!email.trim()){setMessage("Enter your staff email first, then select Forgot password.");return;}
    setResetBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const redirectTo=`${window.location.origin}/auth/callback?next=/reset-password`;
      const {error}=await supabase.auth.resetPasswordForEmail(email.trim(),{redirectTo});
      if(error)throw error;
      setMessage("Password reset email sent. Open the newest email from DS Bakery and follow the reset link.");
    }catch(e){setMessage(e instanceof Error?e.message:"Could not send password reset email.");}
    finally{setResetBusy(false);}
  }

  return <div className="auth-wrap">
    <form className="auth-card" onSubmit={submit}>
      <div className="brand" style={{marginBottom:22}}><img src="/ds-bakery-logo.svg" alt="DS Bakery"/><div><strong>DS Bakery</strong><small>Secure Staff Login</small></div></div>
      <div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username"/></div>
      <div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></div>
      {!liveMode&&<div className="field"><label>Preview role</label><select value={role} onChange={e=>setRole(e.target.value)}><option value="owner">CEO / Owner</option><option value="manager">General Manager</option><option value="cashier">Sales Team</option><option value="baker">Head Baker</option><option value="storekeeper">Stock Manager</option></select></div>}
      {message&&<p style={{color:"var(--brown)",fontSize:12,lineHeight:1.5}}>{message}</p>}
      <button disabled={loading} className="btn primary" style={{width:"100%"}}>{loading?"Signing in…":liveMode?"Sign In":"Enter Demo System"}</button>
      {liveMode&&<button type="button" className="btn secondary" disabled={resetBusy} style={{width:"100%",marginTop:8}} onClick={forgotPassword}>{resetBusy?"Sending reset email…":"Forgot Password"}</button>}
      <p style={{fontSize:12,color:"var(--muted)",lineHeight:1.5}}>{liveMode?"Authentication is handled by Supabase Auth. Disabled staff profiles are rejected by application and database controls.":"Cloud credentials are not configured, so this is running in demo-login mode."}</p>
    </form>
  </div>;
}
