import Sidebar from "@/components/Sidebar";
import MyAccountManager from "@/components/account/MyAccountManager";
import { requireStaff } from "@/lib/auth";
import { isDemoMode } from "@/lib/runtime";

export const dynamic="force-dynamic";

export default async function MyAccount(){
  const staff=await requireStaff();
  return <div className="shell"><Sidebar/><main className="main">
    <MyAccountManager profile={staff.profile} email={staff.user?.email??"demo@dsbakery.local"} live={!isDemoMode()}/>
  </main></div>;
}
