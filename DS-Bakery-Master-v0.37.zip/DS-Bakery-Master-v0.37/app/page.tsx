import Link from "next/link";
import { getPublicSiteData } from "@/lib/repositories/publicSiteLive";
import { buildPublicWhatsAppUrl, buildTikTokUrl } from "@/lib/publicSite";
import PublicShop from "@/components/public/PublicShop";

export const dynamic="force-dynamic";

export default async function Home(){
  const {info,catalog,demo}=await getPublicSiteData();
  const menuCatalog:any[]=Array.isArray(catalog)?catalog:[];
  const categories:string[]=Array.from(new Set<string>(menuCatalog.map((p:any)=>String(p.category_name||"Bakery Menu"))));

  const generalWhatsApp=buildPublicWhatsAppUrl(
    info.whatsapp_phone,
    `Hello ${info.business_name}, I would like to make an order.`
  );
  const cakeWhatsApp=buildPublicWhatsAppUrl(
    info.whatsapp_phone,
    `Hello ${info.business_name}, I would like to ask about a custom cake.`
  );
  const tiktokUrl=buildTikTokUrl(info.tiktok_handle);

  return <main style={{minHeight:"100vh",background:"linear-gradient(180deg,#fffaf0 0%,#f8f2e8 55%,#fff 100%)"}}>
    <header style={{maxWidth:1180,margin:"0 auto",padding:"18px 22px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}>
      <Link href="/" style={{display:"flex",alignItems:"center",gap:10,textDecoration:"none"}}>
        <img src="/ds-bakery-logo.svg" alt={info.business_name} style={{width:54,height:54,borderRadius:"50%",background:"#111"}}/>
        <div><b style={{display:"block",fontFamily:"Georgia,serif",fontSize:22,color:"var(--brown)"}}>{info.business_name}</b><small style={{color:"var(--muted)"}}>{info.tagline}</small></div>
      </Link>
      <nav style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>
        <a className="btn secondary" href="#menu">Menu</a>
        {info.custom_cake_enabled&&<a className="btn secondary" href="#custom-cakes">Custom Cakes</a>}
        <a className="btn secondary" href="#contact">Contact</a>
        <Link className="btn primary" href="/login">Staff Login</Link>
      </nav>
    </header>

    <section style={{maxWidth:1180,margin:"0 auto",padding:"52px 22px 38px",display:"grid",gridTemplateColumns:"minmax(0,1.1fr) minmax(280px,.9fr)",gap:28,alignItems:"center"}}>
      <div>
        {demo&&<span className="badge gold">Preview Data</span>}
        <h1 style={{fontFamily:"Georgia,serif",fontSize:"clamp(42px,7vw,76px)",lineHeight:1.02,color:"var(--brown)",margin:"14px 0 16px"}}>{info.business_name}</h1>
        <p style={{fontSize:20,lineHeight:1.65,color:"var(--muted)",maxWidth:720}}>{info.hero_message||info.tagline}</p>
        <div style={{display:"flex",gap:10,flexWrap:"wrap",marginTop:24}}>
          <a className="btn primary" href="#menu">View Bakery Menu</a>
          {generalWhatsApp&&<a className="btn secondary" href={generalWhatsApp} target="_blank" rel="noreferrer">Order on WhatsApp</a>}
        </div>
        <div style={{display:"flex",gap:18,flexWrap:"wrap",marginTop:24,color:"var(--muted)",fontSize:13}}>
          {info.delivery_enabled&&<span><b style={{color:"var(--brown)"}}>Delivery:</b> Available</span>}
          {info.opening_hours&&<span><b style={{color:"var(--brown)"}}>Hours:</b> {info.opening_hours}</span>}
        </div>
      </div>

      <div className="card" style={{padding:28,background:"linear-gradient(145deg,#fff,#fff3d9)",borderRadius:28}}>
        <img src="/ds-bakery-logo.svg" alt="" aria-hidden="true" style={{width:170,height:170,borderRadius:"50%",display:"block",margin:"0 auto 18px",background:"#111"}}/>
        <h2 style={{fontFamily:"Georgia,serif",textAlign:"center",color:"var(--brown)",margin:"0 0 8px"}}>Fresh from DS Bakery</h2>
        <p style={{textAlign:"center",color:"var(--muted)",lineHeight:1.6,margin:0}}>Browse the live bakery menu below. Prices shown are the current selling prices from the same DS Bakery system used by staff.</p>
      </div>
    </section>

    <section id="menu" style={{maxWidth:1180,margin:"0 auto",padding:"34px 22px 60px"}}>
      <div style={{maxWidth:760}}>
        <span className="badge green">Live Menu</span>
        <h2 style={{fontFamily:"Georgia,serif",fontSize:38,color:"var(--brown)",margin:"12px 0 8px"}}>Bakery Menu</h2>
        <p style={{color:"var(--muted)",lineHeight:1.6}}>Only active customer-facing products are shown. Stock quantities, recipes, ingredient costs and profit information remain private.</p>
      </div>

      <PublicShop catalog={menuCatalog} categories={categories} businessName={info.business_name} whatsappPhone={info.whatsapp_phone} deliveryEnabled={Boolean(info.delivery_enabled)}/>
    </section>

    {info.custom_cake_enabled&&<section id="custom-cakes" style={{background:"#3b2015",color:"#fff"}}>
      <div style={{maxWidth:1180,margin:"0 auto",padding:"56px 22px",display:"grid",gridTemplateColumns:"minmax(0,1fr) minmax(280px,.75fr)",gap:24,alignItems:"center"}}>
        <div>
          <span className="badge gold">Celebrations</span>
          <h2 style={{fontFamily:"Georgia,serif",fontSize:40,margin:"12px 0"}}>Custom Cakes</h2>
          <p style={{lineHeight:1.7,color:"#eadfce",fontSize:17}}>Tell us the size, flavour, theme, colours, inscription and event date you have in mind. Staff can then create the detailed custom-cake order inside the DS Bakery system, record the quote and manage the deposit and production approval.</p>
          {cakeWhatsApp&&<a className="btn primary" style={{marginTop:10}} href={cakeWhatsApp} target="_blank" rel="noreferrer">Ask About a Custom Cake</a>}
        </div>
        <div style={{background:"#fff7e8",color:"#3b2015",borderRadius:22,padding:24}}>
          <h3 style={{fontFamily:"Georgia,serif",marginTop:0}}>Useful details to send</h3>
          <p>Event date and preferred collection/delivery time</p>
          <p>Approximate size or number of servings</p>
          <p>Flavour, filling and frosting preference</p>
          <p>Theme, colours and inscription</p>
          <p>A reference image, if you have one</p>
        </div>
      </div>
    </section>}

    <section id="contact" style={{maxWidth:1180,margin:"0 auto",padding:"58px 22px"}}>
      <h2 style={{fontFamily:"Georgia,serif",fontSize:38,color:"var(--brown)",margin:"0 0 8px"}}>Contact {info.business_name}</h2>
      <p style={{color:"var(--muted)",margin:"0 0 22px"}}>Located at <b style={{color:"var(--brown)"}}>{info.address_text||"Kiwafu Lugonjo"}</b>.</p>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14}}>
        <a className="card" href={info.phone?`tel:${info.phone}`:"#"} style={{textDecoration:"none",color:"inherit"}}>
          <div className="label">Telephone 1</div>
          <div style={{fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8}}>{info.phone||"0708743663"}</div>
        </a>

        <a className="card" href={info.secondary_phone?`tel:${info.secondary_phone}`:"#"} style={{textDecoration:"none",color:"inherit"}}>
          <div className="label">Telephone 2</div>
          <div style={{fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8}}>{info.secondary_phone||"0760547003"}</div>
        </a>

        <a className="card" href={generalWhatsApp??"#"} target={generalWhatsApp?"_blank":undefined} rel={generalWhatsApp?"noreferrer":undefined} style={{textDecoration:"none",color:"inherit"}}>
          <div className="label">WhatsApp</div>
          <div style={{fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8}}>◉ {info.whatsapp_phone||"0760547003"}</div>
        </a>

        <a className="card" href={info.email?`mailto:${info.email}`:"#"} style={{textDecoration:"none",color:"inherit"}}>
          <div className="label">Email</div>
          <div style={{fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8,wordBreak:"break-word"}}>{info.email||"dscakes3@gmail.com"}</div>
        </a>

        <a className="card" href={tiktokUrl??"#"} target={tiktokUrl?"_blank":undefined} rel={tiktokUrl?"noreferrer":undefined} style={{textDecoration:"none",color:"inherit"}}>
          <div className="label">TikTok</div>
          <div style={{display:"flex",alignItems:"center",gap:9,fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8}}>
            <svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M15.4 3c.5 2.5 1.9 4 4.6 4.2v3.1c-1.7 0-3.2-.5-4.6-1.5v6.1c0 3.8-2.6 6.1-5.8 6.1-3 0-5.6-2.2-5.6-5.5 0-3.5 2.8-5.7 6.4-5.5v3.2c-1.8-.2-3.2.7-3.2 2.3 0 1.4 1.1 2.4 2.4 2.4 1.5 0 2.6-1.1 2.6-3V3h3.2z"/>
            </svg>
            {info.tiktok_handle||"Ds bakery"}
          </div>
        </a>

        <div className="card">
          <div className="label">Location</div>
          <div style={{fontSize:18,fontWeight:800,color:"var(--brown)",marginTop:8}}>{info.address_text||"Kiwafu Lugonjo"}</div>
        </div>
      </div>
    </section>

    <footer style={{borderTop:"1px solid #eadfce",background:"#fff",padding:"24px 22px"}}>
      <div style={{maxWidth:1180,margin:"0 auto",display:"flex",justifyContent:"space-between",gap:16,flexWrap:"wrap",color:"var(--muted)",fontSize:13}}>
        <span>© {new Date().getFullYear()} {info.business_name}</span>
        <span>Menu prices come from the DS Bakery Master System.</span>
      </div>
    </footer>
  </main>;
}
