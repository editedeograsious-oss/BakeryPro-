import Sidebar from "@/components/Sidebar";
import PayrollManager from "@/components/finance/PayrollManager";
import { requirePermission } from "@/lib/access";
import { getPayrollData } from "@/lib/repositories/business37";

export const dynamic="force-dynamic";
export default async function PayrollPage(){
  await requirePermission("payroll:read",["owner","manager"]);
  const data=await getPayrollData();
  return <div className="shell"><Sidebar/><main className="main"><PayrollManager staff={data.staff} compensation={data.compensation} runs={data.runs} items={data.items} advances={data.advances} live={!data.demo}/></main></div>;
}
