import Sidebar from "@/components/Sidebar";
import RecycleBinManager from "@/components/admin/RecycleBinManager";
import { requirePermission } from "@/lib/access";
import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

export const dynamic="force-dynamic";

export default async function RecycleBin(){
  const staff=await requirePermission("recycle:manage",["owner","manager"]);
  let rows:any[]=[];
  if(!isDemoMode()){
    const supabase=await createClient();
    const {data,error}=await supabase.from("recycle_bin_summary").select("*").order("deleted_at",{ascending:false}).limit(500);
    if(error)throw error;rows=data??[];
  }
  return <div className="shell"><Sidebar/><main className="main"><RecycleBinManager rows={rows} live={!isDemoMode()} isOwner={staff.profile.role==="owner"}/></main></div>;
}
