"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function ResetPassword(){
  const router=useRouter();
  const [password,setPassword]=useState("");
  const [confirm,setConfirm]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function submit(e:React.FormEvent){
    e.preventDefault();
    if(password.length<8){setMessage("Use a password with at least 8 characters.");return;}
    if(password!==confirm){setMessage("Passwords do not match.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.auth.updateUser({password});
      if(error)throw error;
      setMessage("Password updated. You can now sign in.");
      await supabase.auth.signOut();
      setTimeout(()=>router.replace("/login"),700);
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update the password. Open the newest reset link and try again.");}
    finally{setBusy(false);}
  }

  return <div className="auth-wrap"><form className="auth-card" onSubmit={submit}>
    <div className="brand"><img src="/ds-bakery-logo.svg" alt="DS Bakery"/><div><strong>DS Bakery</strong><small>Reset Password</small></div></div>
    <div className="field"><label>New password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="new-password"/></div>
    <div className="field"><label>Confirm password</label><input type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} autoComplete="new-password"/></div>
    {message&&<p style={{fontSize:12,color:"var(--brown)"}}>{message}</p>}
    <button className="btn primary" disabled={busy} style={{width:"100%"}}>{busy?"Updating…":"Set New Password"}</button>
  </form></div>;
}
