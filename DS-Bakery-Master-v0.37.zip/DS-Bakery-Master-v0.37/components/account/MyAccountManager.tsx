"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { StaffRole } from "@/lib/permissions";

const roleLabels:Record<StaffRole,string>={owner:"CEO / Owner",manager:"General Manager",cashier:"Sales Team",baker:"Head Baker",storekeeper:"Stock Manager"};

export default function MyAccountManager({profile,email,live}:{profile:any;email:string;live:boolean}){
  const router=useRouter();
  const [fullName,setFullName]=useState(profile.full_name??"");
  const [newPassword,setNewPassword]=useState("");
  const [confirmPassword,setConfirmPassword]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function saveProfile(){
    if(!fullName.trim()){setMessage("Enter your display name.");return;}
    if(!live){setMessage("Demo mode: profile changes are not saved to the cloud database.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("update_my_profile",{p_full_name:fullName.trim()});
      if(error)throw error;
      setMessage("Account name updated.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update your account.");}
    finally{setBusy(false);}
  }

  async function changePassword(){
    if(newPassword.length<8){setMessage("Use a password with at least 8 characters.");return;}
    if(newPassword!==confirmPassword){setMessage("The new passwords do not match.");return;}
    if(!live){setMessage("Demo mode: password changes are disabled.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.auth.updateUser({password:newPassword});
      if(error)throw error;
      setNewPassword("");setConfirmPassword("");
      setMessage("Password changed successfully.");
    }catch(e){setMessage(e instanceof Error?e.message:"Could not change password.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>My Account</h1><p>Manage your own DS Bakery staff profile and password.</p></div></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="grid2">
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Account Details</h3>
        <div className="field"><label>Email</label><input value={email} disabled/></div>
        <div className="field"><label>Business role</label><input value={roleLabels[profile.role as StaffRole]??profile.role} disabled/></div>
        <div className="field"><label>Display name</label><input value={fullName} onChange={e=>setFullName(e.target.value)}/></div>
        <button className="btn primary" disabled={busy} onClick={saveProfile}>Save My Details</button>
      </div>
      <div className="card">
        <h3 style={{color:"var(--brown)",marginTop:0}}>Change Password</h3>
        <div className="field"><label>New password</label><input type="password" autoComplete="new-password" value={newPassword} onChange={e=>setNewPassword(e.target.value)}/></div>
        <div className="field"><label>Confirm new password</label><input type="password" autoComplete="new-password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)}/></div>
        <button className="btn primary" disabled={busy} onClick={changePassword}>Change Password</button>
        <p style={{fontSize:12,color:"var(--muted)",lineHeight:1.5}}>Use a unique password. DS Bakery never displays or stores your password in the staff interface.</p>
      </div>
    </div>
  </>;
}
