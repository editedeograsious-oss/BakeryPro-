'use client';

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

import { businessRoleLabel } from "@/lib/roleLabels";
export default function AttendanceManager({rows,settings,self,live,canManage}:{rows:any[];settings:any;self:any;live:boolean;canManage:boolean}){
  const router=useRouter();
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const [grace,setGrace]=useState(Number(settings?.late_grace_minutes??5));

  const present=useMemo(()=>rows.filter(r=>r.clock_in_at).length,[rows]);
  const late=useMemo(()=>rows.filter(r=>Number(r.late_minutes||0)>0).length,[rows]);
  const absent=useMemo(()=>rows.filter(r=>r.display_status==="absent").length,[rows]);

  async function clock(action:"in"|"out"){
    if(!live){setMessage(`Demo mode: clock-${action} simulated.`);return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc(action==="in"?"clock_in_staff":"clock_out_staff");
      if(error)throw error;
      setMessage(action==="in"?"Clock-in recorded.":"Clock-out recorded.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Attendance action failed.");}
    finally{setBusy(false);}
  }

  async function saveGrace(){
    if(!canManage)return;
    if(grace<0||grace>120){setMessage("Grace period must be between 0 and 120 minutes.");return;}
    if(!live){setMessage("Demo mode: grace period update simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("update_attendance_settings",{p_late_grace_minutes:grace});
      if(error)throw error;
      setMessage("Attendance grace period updated.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update settings.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead">
      <div><h1>Attendance</h1><p>Live clock-in/out and lateness against the staff work schedule.</p></div>
      <div style={{display:"flex",gap:8}}><button className="btn primary" disabled={busy||self?.clock_in_at} onClick={()=>clock("in")}>Clock In</button><button className="btn secondary" disabled={busy||!self?.clock_in_at||self?.clock_out_at} onClick={()=>clock("out")}>Clock Out</button></div>
    </div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Scheduled Today</div><div className="value">{rows.length}</div></div>
      <div className="card stat"><div className="label">Present</div><div className="value">{present}</div></div>
      <div className="card stat"><div className="label">Late</div><div className="value">{late}</div></div>
      <div className="card stat"><div className="label">Absent / Missed</div><div className="value">{absent}</div></div>
    </div>

    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Staff</th><th>Role</th><th>Scheduled</th><th>Station</th><th>Clock In</th><th>Clock Out</th><th>Late</th><th>Status</th></tr></thead>
      <tbody>{rows.length===0?<tr><td colSpan={8}>No staff work shifts scheduled today.</td></tr>:rows.map(r=><tr key={r.shift_id}><td><b>{r.full_name}</b></td><td>{businessRoleLabel(r.role)}</td><td>{r.scheduled_start} – {r.scheduled_end}</td><td>{r.work_station??"—"}</td><td>{r.clock_in_at?new Date(r.clock_in_at).toLocaleTimeString():"—"}</td><td>{r.clock_out_at?new Date(r.clock_out_at).toLocaleTimeString():"—"}</td><td>{Number(r.late_minutes||0)?`${r.late_minutes} min`:"—"}</td><td><span className={r.display_status==="late"||r.display_status==="absent"?"badge red":r.display_status==="completed"||r.display_status==="on_time"?"badge green":"badge gold"}>{r.display_status}</span></td></tr>)}</tbody>
    </table></div>

    <div className="grid2" style={{marginTop:16}}>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Attendance Rule</h3><p>Current grace period: <b>{grace} minutes</b></p>{canManage&&<><div className="field"><label>Grace period</label><input type="number" min="0" max="120" value={grace} onChange={e=>setGrace(Number(e.target.value))}/></div><button className="btn secondary" disabled={busy} onClick={saveGrace}>Save Rule</button></>}</div>
      <div className="card"><h3 style={{color:"var(--brown)",marginTop:0}}>Separate from Cashier Till Shift</h3><p style={{color:"var(--muted)",lineHeight:1.6}}>Clocking in records staff attendance only. Opening or closing a cashier till remains a separate financial control.</p></div>
    </div>
  </>;
}
