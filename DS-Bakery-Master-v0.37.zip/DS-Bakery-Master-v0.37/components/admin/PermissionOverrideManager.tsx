'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

import { businessRoleLabel } from "@/lib/roleLabels";
export default function PermissionOverrideManager({staff,permissions,selectedId,live}:{staff:any[];permissions:any[];selectedId:string;live:boolean}){
  const router=useRouter();
  const [staffId,setStaffId]=useState(selectedId);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  function selectStaff(id:string){
    setStaffId(id);
    router.push(`/permission-overrides?staff=${encodeURIComponent(id)}`);
  }

  async function setOverride(key:string,value:"default"|"allow"|"deny"){
    const reason=value==="default"?null:window.prompt("Reason for this permission override")?.trim();
    if(value!=="default"&&!reason){setMessage("A reason is required for an individual override.");return;}
    if(!live){setMessage(`Demo mode: ${key} set to ${value}.`);return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const result=value==="default"
        ? await supabase.rpc("clear_staff_permission_override",{p_staff_id:staffId,p_permission_key:key})
        : await supabase.rpc("set_staff_permission_override",{p_staff_id:staffId,p_permission_key:key,p_allowed:value==="allow",p_reason:reason});
      if(result.error)throw result.error;
      setMessage("Permission setting updated.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update permission.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Individual Staff Permissions</h1><p>Owner-only deny/allow exceptions on top of role defaults.</p></div><span className="badge red">Owner Only</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="hero"><h2>Role default first, individual exception second</h2><p>A Deny can remove access from a role. An Allow affects application permission checks, but sensitive database RPCs still keep their hard role rules.</p></div>
    <div className="field" style={{maxWidth:360}}><label>Staff member</label><select value={staffId} onChange={e=>selectStaff(e.target.value)}>{staff.map(s=><option key={s.id} value={s.id}>{s.full_name} • {businessRoleLabel(s.role)}</option>)}</select></div>
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Permission</th><th>Key</th><th>Critical</th><th>Role Default</th><th>Override</th><th>Effective</th></tr></thead>
      <tbody>{permissions.map(p=><tr key={p.permission_key}><td><b>{p.description}</b></td><td><code>{p.permission_key}</code></td><td>{p.critical?<span className="badge red">Critical</span>:"—"}</td><td><span className={p.role_default?"badge green":"badge red"}>{p.role_default?"Allow":"Deny"}</span></td><td><select disabled={busy} value={!p.has_override?"default":p.individual_override?"allow":"deny"} onChange={e=>setOverride(p.permission_key,e.target.value as any)}><option value="default">Role Default</option><option value="allow">Allow</option><option value="deny">Deny</option></select></td><td><span className={p.effective_allowed?"badge green":"badge red"}>{p.effective_allowed?"Allowed":"Denied"}</span></td></tr>)}</tbody>
    </table></div>
  </>;
}
