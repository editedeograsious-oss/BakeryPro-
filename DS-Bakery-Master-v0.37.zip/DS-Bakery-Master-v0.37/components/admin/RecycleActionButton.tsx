"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function RecycleActionButton({entityType,entityId,label,live,onMessage}:{entityType:string;entityId:string;label:string;live:boolean;onMessage?:(m:string)=>void}){
  const router=useRouter();
  const [busy,setBusy]=useState(false);

  async function remove(){
    const reason=window.prompt(`Why are you deleting “${label}”?\n\nThe record will move to the Recycle Bin and may be restored if allowed.`);
    if(reason===null)return;
    if(!reason.trim()){onMessage?.("A deletion reason is required.");return;}
    if(!window.confirm(`Move “${label}” to the Recycle Bin?`))return;
    if(!live){onMessage?.("Demo mode: recycle-bin action simulated.");return;}
    setBusy(true);
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("move_record_to_recycle_bin",{p_entity_type:entityType,p_entity_id:entityId,p_reason:reason.trim()});
      if(error)throw error;
      onMessage?.(`${label} moved to the Recycle Bin.`);
      router.refresh();
    }catch(e){onMessage?.(e instanceof Error?e.message:"Could not move record to Recycle Bin.");}
    finally{setBusy(false);}
  }

  return <button type="button" className="btn danger" disabled={busy} onClick={remove}>{busy?"Deleting…":"Delete"}</button>;
}
