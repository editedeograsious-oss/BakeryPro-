"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function RecycleBinManager({rows,live,isOwner}:{rows:any[];live:boolean;isOwner:boolean}){
  const router=useRouter();
  const [filter,setFilter]=useState("trashed");
  const [message,setMessage]=useState("");
  const [busyId,setBusyId]=useState("");
  const shown=useMemo(()=>rows.filter(r=>filter==="all"||r.status===filter),[rows,filter]);

  async function restore(id:string,label:string){
    if(!window.confirm(`Restore “${label}” from the Recycle Bin?`))return;
    if(!live){setMessage("Demo mode: restore simulated.");return;}
    setBusyId(id);setMessage("");
    try{const supabase=createClient();const {error}=await supabase.rpc("restore_recycled_record",{p_recycle_id:id});if(error)throw error;setMessage(`${label} restored.`);router.refresh();}
    catch(e){setMessage(e instanceof Error?e.message:"Could not restore record.");}finally{setBusyId("");}
  }

  async function purge(id:string,label:string){
    const reason=window.prompt(`Permanent deletion cannot be undone.\nWhy should “${label}” be permanently deleted?`);
    if(reason===null)return;if(!reason.trim()){setMessage("A permanent-delete reason is required.");return;}
    if(!window.confirm(`Permanently delete “${label}”? This is only allowed when no financial, stock or audit dependency requires the original record.`))return;
    if(!live){setMessage("Demo mode: permanent deletion simulated.");return;}
    setBusyId(id);setMessage("");
    try{const supabase=createClient();const {error}=await supabase.rpc("purge_recycled_record",{p_recycle_id:id,p_reason:reason.trim()});if(error)throw error;setMessage(`${label} permanently removed; the recycle audit entry remains.`);router.refresh();}
    catch(e){setMessage(e instanceof Error?e.message:"Permanent deletion was blocked.");}finally{setBusyId("");}
  }

  return <>
    <div className="pagehead"><div><h1>Recycle Bin</h1><p>Restore safely deleted records. Financial, stock and audit history stays protected.</p></div><div className="field" style={{margin:0,minWidth:180}}><label>Show</label><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="trashed">In Recycle Bin</option><option value="restored">Restored</option><option value="purged">Permanently Removed</option><option value="all">All History</option></select></div></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    <div className="hero"><h2>Deletion safety</h2><p>Setup records are soft-deleted. Transactions are cancelled or voided instead of erased. Activity Logs are never deletable.</p></div>
    <div className="tablewrap"><table><thead><tr><th>Record</th><th>Type</th><th>Action</th><th>Deleted By</th><th>Deleted At</th><th>Reason</th><th>Status</th><th>Controls</th></tr></thead><tbody>
      {shown.length===0?<tr><td colSpan={8}>No recycle-bin records in this view.</td></tr>:shown.map(r=><tr key={r.id}><td><b>{r.record_label}</b></td><td>{String(r.entity_type).replaceAll("_"," ")}</td><td>{r.action_kind}</td><td>{r.deleted_by_name??"—"}</td><td>{new Date(r.deleted_at).toLocaleString()}</td><td>{r.delete_reason}</td><td><span className={r.status==="trashed"?"badge gold":r.status==="restored"?"badge green":"badge red"}>{r.status}</span></td><td>{r.status==="trashed"?<div className="action-row"><button className="btn secondary" disabled={busyId===r.id} onClick={()=>restore(r.id,r.record_label)}>Restore</button>{isOwner&&r.purge_candidate&&<button className="btn danger" disabled={busyId===r.id} onClick={()=>purge(r.id,r.record_label)}>Permanent Delete</button>}</div>:"—"}</td></tr>)}
    </tbody></table></div>
  </>;
}
