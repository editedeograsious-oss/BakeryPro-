'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import RecycleActionButton from "@/components/admin/RecycleActionButton";

import { businessRoleLabel } from "@/lib/roleLabels";
export default function ScheduleManager({rows,staff,live,canManage}:{rows:any[];staff:any[];live:boolean;canManage:boolean}){
  const router=useRouter();
  const [staffId,setStaffId]=useState(staff[0]?.id??"");
  const [date,setDate]=useState("");
  const [start,setStart]=useState("07:00");
  const [end,setEnd]=useState("16:00");
  const [station,setStation]=useState("");
  const [notes,setNotes]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  async function createShift(){
    if(!canManage)return;
    if(!staffId||!date||!start||!end){setMessage("Staff, date, start and end are required.");return;}
    if(start>=end){setMessage("Shift end must be later than shift start.");return;}
    if(!live){setMessage("Demo mode: shift creation simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("create_staff_work_shift",{
        p_staff_id:staffId,p_shift_date:date,p_scheduled_start:start,p_scheduled_end:end,
        p_work_station:station.trim()||null,p_notes:notes.trim()||null,p_client_request_id:requestId.current
      });
      if(error)throw error;
      requestId.current=crypto.randomUUID();
      setMessage(`Shift scheduled • ${data}`);setNotes("");router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not create work shift.");}
    finally{setBusy(false);}
  }

  async function cancelShift(id:string){
    const reason=window.prompt("Cancellation reason")?.trim();
    if(!reason){setMessage("Cancellation reason is required.");return;}
    if(!live){setMessage("Demo mode: shift cancellation simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("cancel_staff_work_shift",{p_shift_id:id,p_reason:reason});
      if(error)throw error;
      setMessage("Work shift cancelled.");router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not cancel shift.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Staff Schedule</h1><p>Live staff work shifts feeding attendance calculations.</p></div><span className={canManage?"badge green":"badge gold"}>{canManage?"Manage":"Read Only"}</span></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    {canManage&&<div className="card">
      <h3 style={{color:"var(--brown)",marginTop:0}}>Schedule Work Shift</h3>
      <div className="grid2"><div className="field"><label>Staff</label><select value={staffId} onChange={e=>setStaffId(e.target.value)}>{staff.map(s=><option key={s.id} value={s.id}>{s.full_name} • {businessRoleLabel(s.role)}</option>)}</select></div><div className="field"><label>Date</label><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div></div>
      <div className="grid2"><div className="field"><label>Start</label><input type="time" value={start} onChange={e=>setStart(e.target.value)}/></div><div className="field"><label>End</label><input type="time" value={end} onChange={e=>setEnd(e.target.value)}/></div></div>
      <div className="grid2"><div className="field"><label>Work station</label><input value={station} onChange={e=>setStation(e.target.value)} placeholder="Kitchen / Front POS / Store"/></div><div className="field"><label>Notes</label><input value={notes} onChange={e=>setNotes(e.target.value)}/></div></div>
      <button className="btn primary" disabled={busy} onClick={createShift}>{busy?"Working…":"Schedule Shift"}</button>
    </div>}
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Date</th><th>Staff</th><th>Role</th><th>Time</th><th>Station</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>{rows.length===0?<tr><td colSpan={7}>No upcoming work shifts found.</td></tr>:rows.map(r=><tr key={r.id}><td><b>{r.shift_date}</b></td><td>{r.full_name}</td><td>{businessRoleLabel(r.role)}</td><td>{r.scheduled_start} – {r.scheduled_end}</td><td>{r.work_station??"—"}</td><td><span className={r.status==="scheduled"?"badge gold":r.status==="completed"?"badge green":"badge red"}>{r.status}</span></td><td>{canManage&&r.status==="scheduled"?<div className="action-row"><button className="btn secondary" disabled={busy} onClick={()=>cancelShift(r.id)}>Cancel</button><RecycleActionButton entityType="staff_work_shift" entityId={r.id} label={`${r.full_name} • ${r.shift_date}`} live={live}/></div>:"—"}</td></tr>)}</tbody>
    </table></div>
  </>;
}
