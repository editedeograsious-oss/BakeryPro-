'use client';

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";
import RecycleActionButton from "@/components/admin/RecycleActionButton";

export default function SupplierDirectoryManager({suppliers,live}:{suppliers:any[];live:boolean}){
  const router=useRouter();
  const [selected,setSelected]=useState<any|null>(null);
  const [name,setName]=useState("");
  const [phone,setPhone]=useState("");
  const [email,setEmail]=useState("");
  const [notes,setNotes]=useState("");
  const [active,setActive]=useState(true);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const requestId=useRef(crypto.randomUUID());

  function clear(){
    setSelected(null);setName("");setPhone("");setEmail("");setNotes("");setActive(true);
    requestId.current=crypto.randomUUID();
  }
  function edit(s:any){
    setSelected(s);setName(s.name??"");setPhone(s.phone??"");setEmail(s.email??"");setNotes(s.notes??"");setActive(Boolean(s.active));
  }

  async function save(){
    if(!name.trim()){setMessage("Supplier name is required.");return;}
    if(!live){setMessage("Demo mode: supplier save simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {data,error}=await supabase.rpc("save_supplier",{
        p_supplier_id:selected?.id??null,
        p_name:name.trim(),p_phone:phone.trim()||null,p_email:email.trim()||null,
        p_notes:notes.trim()||null,p_active:active,p_client_request_id:requestId.current
      });
      if(error)throw error;
      setMessage(`Supplier saved • ${data}`);
      clear();router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save supplier.");}
    finally{setBusy(false);}
  }

  const outstanding=suppliers.reduce((s,x)=>s+Number(x.outstanding_balance||0),0);
  const overdue=suppliers.reduce((s,x)=>s+Number(x.overdue_balance||0),0);

  return <>
    <div className="pagehead">
      <div><h1>Suppliers</h1><p>Live supplier directory linked to purchase orders and supplier balances.</p></div>
      <button className="btn primary" onClick={clear}>+ New Supplier</button>
    </div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Active Suppliers</div><div className="value">{suppliers.filter(s=>s.active).length}</div></div>
      <div className="card stat"><div className="label">Outstanding</div><div className="value">{ugx(outstanding)}</div></div>
      <div className="card stat"><div className="label">Overdue</div><div className="value">{ugx(overdue)}</div></div>
      <div className="card stat"><div className="label">Inactive</div><div className="value">{suppliers.filter(s=>!s.active).length}</div></div>
    </div>

    <div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>{selected?"Edit Supplier":"Add Supplier"}</h3>
      <div className="grid2">
        <div className="field"><label>Name</label><input value={name} onChange={e=>setName(e.target.value)}/></div>
        <div className="field"><label>Phone</label><input value={phone} onChange={e=>setPhone(e.target.value)}/></div>
      </div>
      <div className="grid2">
        <div className="field"><label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)}/></div>
        <div className="field"><label>Notes</label><input value={notes} onChange={e=>setNotes(e.target.value)}/></div>
      </div>
      <label style={{display:"flex",gap:8,alignItems:"center",margin:"8px 0 14px"}}><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/> Active supplier</label>
      <button className="btn primary" disabled={busy} onClick={save}>{busy?"Saving…":"Save Supplier"}</button>
    </div>

    <div className="tablewrap" style={{marginTop:16}}>
      <table><thead><tr><th>Supplier</th><th>Phone</th><th>Email</th><th>Outstanding</th><th>Overdue</th><th>Next Due</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>{suppliers.length===0?<tr><td colSpan={8}>No suppliers found.</td></tr>:suppliers.map(s=><tr key={s.id}>
        <td><b>{s.name}</b></td><td>{s.phone??"—"}</td><td>{s.email??"—"}</td><td>{ugx(Number(s.outstanding_balance||0))}</td>
        <td>{Number(s.overdue_balance)>0?<span className="badge red">{ugx(Number(s.overdue_balance))}</span>:<span className="badge green">None</span>}</td>
        <td>{s.next_due_date??"—"}</td><td><span className={s.active?"badge green":"badge gold"}>{s.active?"Active":"Inactive"}</span></td>
        <td><div className="action-row"><button className="btn secondary" onClick={()=>edit(s)}>Edit</button>{s.active&&<RecycleActionButton entityType="supplier" entityId={s.id} label={s.name} live={live} onMessage={setMessage}/>}</div></td>
      </tr>)}</tbody></table>
    </div>
  </>;
}
