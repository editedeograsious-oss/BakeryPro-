'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ugx } from "@/lib/costing";
import RecycleActionButton from "@/components/admin/RecycleActionButton";

export default function ProductManager({products,categories,live}:{products:any[];categories:any[];live:boolean}){
  const router=useRouter();
  const [showForm,setShowForm]=useState(false);
  const [editing,setEditing]=useState<any|null>(null);
  const [name,setName]=useState("");
  const [description,setDescription]=useState("");
  const [price,setPrice]=useState(0);
  const [categoryId,setCategoryId]=useState(categories[0]?.id??"");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  function clear(){setEditing(null);setName("");setDescription("");setPrice(0);setCategoryId(categories[0]?.id??"");setShowForm(false);}
  function newProduct(){clear();setShowForm(true);}
  function editProduct(p:any){setEditing(p);setName(p.name??"");setDescription(p.description??"");setPrice(Number(p.selling_price??0));setCategoryId(p.category_id??"");setShowForm(true);window.scrollTo({top:0,behavior:"smooth"});}

  async function saveProduct(){
    if(!name.trim()||price<0){setMessage("Enter a product name and a valid selling price.");return;}
    if(!live){setMessage("Demo mode: product save simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("save_product",{p_product_id:editing?.id??null,p_name:name.trim(),p_category_id:categoryId||null,p_selling_price:price,p_description:description.trim()||null});
      if(error)throw error;
      setMessage(editing?"Product updated.":"Product added.");clear();router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save product.");}
    finally{setBusy(false);}
  }

  return <>
    <div className="pagehead"><div><h1>Products & Prices</h1><p>Add, edit and safely archive products. Profit now uses production-batch cost when finished goods are sold.</p></div><button className="btn primary" onClick={showForm?clear:newProduct}>{showForm?"Cancel":"+ Add Product"}</button></div>
    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}
    {showForm&&<div className="card" style={{marginBottom:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>{editing?"Edit Product":"New Product"}</h3>
      <div className="grid2"><div className="field"><label>Product name</label><input value={name} onChange={e=>setName(e.target.value)}/></div><div className="field"><label>Category</label><select value={categoryId} onChange={e=>setCategoryId(e.target.value)}><option value="">Uncategorized</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div></div>
      <div className="grid2"><div className="field"><label>Selling price (UGX)</label><input type="number" min="0" value={price} onChange={e=>setPrice(Number(e.target.value))}/></div><div className="field"><label>Description</label><input value={description} onChange={e=>setDescription(e.target.value)} placeholder="Customer-facing description"/></div></div>
      <button className="btn primary" disabled={busy} onClick={saveProduct}>{busy?"Saving…":editing?"Save Changes":"Save Product"}</button>
    </div>}
    <div className="tablewrap"><table><thead><tr><th>Product</th><th>Category</th><th>Selling Price</th><th>Food Cost</th><th>Gross Profit</th><th>Margin</th><th>Status</th><th>Actions</th></tr></thead><tbody>
      {products.length===0?<tr><td colSpan={8}>No products found.</td></tr>:products.map((p:any)=><tr key={p.id}><td><b>{p.name}</b><br/><small>{p.description??""}</small></td><td>{p.category_name??"—"}</td><td>{ugx(Number(p.selling_price))}</td><td>{p.unit_food_cost==null?"No recipe":ugx(Number(p.unit_food_cost))}</td><td><b>{p.gross_profit==null?"—":ugx(Number(p.gross_profit))}</b></td><td>{p.gross_margin_pct==null?"—":`${Number(p.gross_margin_pct).toFixed(1)}%`}</td><td><span className={p.status==="active"?"badge green":"badge gold"}>{p.status}</span></td><td><div className="action-row"><button className="btn secondary" onClick={()=>editProduct(p)}>Edit</button><RecycleActionButton entityType="product" entityId={p.id} label={p.name} live={live} onMessage={setMessage}/></div></td></tr>)}
    </tbody></table></div>
  </>;
}
