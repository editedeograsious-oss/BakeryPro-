'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import RecycleActionButton from "@/components/admin/RecycleActionButton";

export default function BakerTaskPanel({
  tasks,bakers,products,live,canManage
}:{
  tasks:any[];bakers:any[];products:any[];live:boolean;canManage:boolean;
}){
  const router=useRouter();
  const [title,setTitle]=useState("");
  const [bakerId,setBakerId]=useState(bakers[0]?.id??"");
  const [productId,setProductId]=useState(products[0]?.id??"");
  const [dueAt,setDueAt]=useState("");
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);

  async function createTask(){
    if(!canManage){setMessage("Only Owner/Manager can create baker tasks.");return;}
    if(!title.trim()||!bakerId){setMessage("Task title and baker are required.");return;}
    if(!live){setMessage("Demo mode: baker task creation simulated.");return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("create_baker_task",{
        p_title:title.trim(),
        p_assigned_baker_id:bakerId,
        p_product_id:productId||null,
        p_plan_item_id:null,
        p_due_at:dueAt?new Date(dueAt).toISOString():null,
        p_notes:null,
      });
      if(error)throw error;
      setTitle("");setDueAt("");
      setMessage("Baker task created.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not create task.");}
    finally{setBusy(false);}
  }

  async function setStatus(id:string,status:"todo"|"complete"){
    if(!live){setMessage(`Demo mode: task marked ${status}.`);return;}
    setBusy(true);setMessage("");
    try{
      const supabase=createClient();
      const {error}=await supabase.rpc("set_baker_task_status",{p_task_id:id,p_status:status});
      if(error)throw error;
      setMessage(status==="complete"?"Task completed.":"Task reopened.");
      router.refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not update task.");}
    finally{setBusy(false);}
  }

  const completed=tasks.filter(t=>t.status==="complete").length;

  return <>
    <div className="pagehead">
      <div><h1>Baker Tasks</h1><p>Persistent task queue for kitchen staff.</p></div>
      <span className="badge gold">Kitchen View</span>
    </div>

    {message&&<div className="hero" style={{padding:14}}><b>{message}</b></div>}

    <div className="grid4">
      <div className="card stat"><div className="label">Tasks</div><div className="value">{tasks.length}</div></div>
      <div className="card stat"><div className="label">Completed</div><div className="value">{completed}</div></div>
      <div className="card stat"><div className="label">Remaining</div><div className="value">{tasks.length-completed}</div></div>
      <div className="card stat"><div className="label">Storage</div><div className="value" style={{fontSize:20}}>Database</div></div>
    </div>

    {canManage&&<div className="card" style={{marginTop:16}}>
      <h3 style={{color:"var(--brown)",marginTop:0}}>Create Baker Task</h3>
      <div className="field"><label>Task</label><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Prepare / bake / decorate…"/></div>
      <div className="grid2">
        <div className="field"><label>Baker</label><select value={bakerId} onChange={e=>setBakerId(e.target.value)}>{bakers.map(b=><option key={b.id} value={b.id}>{b.full_name}</option>)}</select></div>
        <div className="field"><label>Product</label><select value={productId} onChange={e=>setProductId(e.target.value)}><option value="">General task</option>{products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
      </div>
      <div className="field"><label>Due date/time</label><input type="datetime-local" value={dueAt} onChange={e=>setDueAt(e.target.value)}/></div>
      <button className="btn primary" disabled={busy} onClick={createTask}>{busy?"Working…":"Create Task"}</button>
    </div>}

    <div className="card" style={{marginTop:16}}>
      {tasks.length===0?<p style={{color:"var(--muted)"}}>No baker tasks available.</p>:tasks.map(t=><div key={t.id} style={{display:"flex",justifyContent:"space-between",gap:14,alignItems:"center",padding:"13px 0",borderBottom:"1px solid #f0e6da"}}>
        <div>
          <b style={{textDecoration:t.status==="complete"?"line-through":"none"}}>{t.title}</b>
          <div style={{color:"var(--muted)",fontSize:12,marginTop:4}}>{t.product_name??"General"} • {t.baker_name??"Unassigned"} {t.due_at?`• Due ${new Date(t.due_at).toLocaleString()}`:""}</div>
        </div>
        <div className="action-row"><button className={t.status==="complete"?"btn secondary":"btn primary"} disabled={busy} onClick={()=>setStatus(t.id,t.status==="complete"?"todo":"complete")}>{t.status==="complete"?"Reopen":"Complete"}</button>{canManage&&t.status!=="complete"&&<RecycleActionButton entityType="baker_task" entityId={t.id} label={t.title} live={live}/>}</div>
      </div>)}
    </div>
  </>;
}
