"use client";

import { useMemo, useState } from "react";
import { ugx } from "@/lib/costing";

export default function FinishedGoodsManager({batches}:{batches:any[]}){
  const [product,setProduct]=useState("all");
  const products=useMemo(()=>Array.from(new Map(batches.map((b:any)=>[b.product_id,b.product_name])).entries()),[batches]);
  const shown=product==="all"?batches:batches.filter((b:any)=>b.product_id===product);
  const availableQty=shown.reduce((s:number,b:any)=>s+Number(b.quantity_available||0),0);
  const stockValue=shown.reduce((s:number,b:any)=>s+Number(b.quantity_available||0)*Number(b.unit_cost||0),0);
  const realizedProfit=shown.reduce((s:number,b:any)=>s+Number(b.realized_gross_profit||0),0);
  const wasteCost=shown.reduce((s:number,b:any)=>s+Number(b.waste_cost||0),0);

  return <>
    <div className="pagehead"><div><h1>Finished Goods & Production Batches</h1><p>Actual production batches, remaining finished stock, batch unit cost, sales allocation, waste and realized gross profit.</p></div></div>
    <div className="hero"><h2>Batch-based costing</h2><p>Sales consume the oldest available finished-goods batches. Profit is therefore based on the actual production batch cost rather than today&apos;s ingredient purchase price.</p></div>
    <div className="grid4">
      <div className="card stat"><div className="label">Available Units</div><div className="value">{availableQty.toLocaleString()}</div></div>
      <div className="card stat"><div className="label">Finished Stock Value</div><div className="value">{ugx(stockValue)}</div></div>
      <div className="card stat"><div className="label">Realized Gross Profit</div><div className="value">{ugx(realizedProfit)}</div></div>
      <div className="card stat"><div className="label">Waste Cost</div><div className="value">{ugx(wasteCost)}</div></div>
    </div>
    <div className="card" style={{marginTop:16}}><div className="field" style={{maxWidth:360,margin:0}}><label>Filter product</label><select value={product} onChange={e=>setProduct(e.target.value)}><option value="all">All products</option>{products.map(([id,name])=><option key={String(id)} value={String(id)}>{String(name)}</option>)}</select></div></div>
    <div className="tablewrap" style={{marginTop:16}}><table><thead><tr><th>Batch</th><th>Product</th><th>Date</th><th>Produced</th><th>Available</th><th>Unit Cost</th><th>Batch Cost</th><th>POS Sold</th><th>Orders</th><th>Waste</th><th>Revenue</th><th>Realized Profit</th></tr></thead><tbody>{shown.length===0?<tr><td colSpan={12}>No production batches yet.</td></tr>:shown.map((b:any)=><tr key={b.id}><td><b>{b.batch_no}</b></td><td>{b.product_name}</td><td>{b.production_date}</td><td>{Number(b.quantity_produced).toLocaleString()}</td><td><b>{Number(b.quantity_available).toLocaleString()}</b></td><td>{ugx(Number(b.unit_cost))}</td><td>{ugx(Number(b.batch_cost))}</td><td>{Number(b.pos_qty_sold||0).toLocaleString()}</td><td>{Number(b.order_qty_sold||0).toLocaleString()}</td><td>{Number(b.waste_qty||0).toLocaleString()}</td><td>{ugx(Number(b.pos_revenue||0)+Number(b.order_revenue||0))}</td><td><b>{ugx(Number(b.realized_gross_profit||0))}</b></td></tr>)}</tbody></table></div>
  </>;
}
