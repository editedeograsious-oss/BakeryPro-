# DS Bakery — Railway Staging Deployment

Target the current Supabase staging project first.

## Required Railway variables

```text
NEXT_PUBLIC_SUPABASE_URL=https://kymadepeuqhcsjwbrgqq.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<Supabase publishable key>
NEXT_PUBLIC_DEMO_MODE=false
NEXT_PUBLIC_DEPLOYMENT_ENV=staging
NODE_ENV=production
```

`SUPABASE_SERVICE_ROLE_KEY` is optional for the initial staging website. If later enabled for the staff invite route, enter it only in Railway's protected Variables UI. Never put it in source code or a `NEXT_PUBLIC_` variable.

Do not point `DATABASE_URL` at the separate Railway Postgres service. DS Bakery Master v0.37 uses the Supabase staging project as its application database.

## Railway service settings

- Builder: Railpack
- Build: `npm run build`
- Start: `npm run start -- -p $PORT`
- Health check: `/api/health`
- Health timeout: 120 seconds
- Restart policy: on failure, 3 retries

## Safe cutover rule

Do not edit or replace the existing successful `Ds-Bakery-Live` service yet.

Create a separate staging service, obtain its own Railway domain, validate it, and only then plan a controlled production replacement.
