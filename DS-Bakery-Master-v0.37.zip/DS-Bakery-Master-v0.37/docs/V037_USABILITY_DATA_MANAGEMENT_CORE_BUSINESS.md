# DS Bakery v0.37 — Usability, Data Management & Core Business Completion

v0.37 closes practical operating gaps identified during staging use. It keeps the existing DS Bakery security model while making the system easier to operate as a real bakery.

## Usability
- Role-aware business sidebar with active-page highlighting and mobile drawer.
- Staff **Log Out**, **My Account**, display-name update and change-password controls.
- Forgot-password/reset-password flow through Supabase Auth.
- Business-facing role labels: CEO / Owner, General Manager, Head Baker, Stock Manager and Sales Team.
- Existing products and raw materials can now be edited.

## Safe deletion and Recycle Bin
- CEO / Owner and General Manager can move eligible operational/master records to the Recycle Bin with a required reason.
- Eligible master records use soft deletion and can be restored.
- Financial, stock and completed operational history is protected: completed sales, payments, inventory transactions and audit logs are never silently hard-deleted.
- Expenses are voided rather than erased; safe pending/draft records can be cancelled and restored.
- Permanent purge is Owner-only and limited to eligible master/setup records, while database foreign keys continue to block unsafe deletion.
- Direct table-level DELETE policies for protected staff/settings/closing/shift records are removed so admins cannot bypass the audited Recycle Bin workflow.

## Finished goods and true batch costing
- Every confirmed production run creates a finished-goods batch with actual ingredient consumption cost.
- Finished batches carry actual unit cost and available quantity.
- POS sales and completed customer orders allocate finished goods FIFO from real batches.
- Waste consumes finished batch inventory and records actual batch waste cost.
- Batch reports expose produced quantity, available quantity, revenue, COGS, waste and realized gross profit.

## Customer Credit Book
- Per-customer credit enable/disable, limit and terms.
- POS customer-credit sale option with credit-limit enforcement.
- Credit ledger, due dates, repayments, running balance and overdue visibility.
- Repayments allocate FIFO against individual credit charges so partial payments produce accurate overdue balances.
- CEO / Owner and General Manager can create an audited adjustment for the still-unpaid portion of a credit sale; paid money is never silently erased.
- Cash/MTN/Airtel credit repayments feed daily cash controls.

## Staff salaries and payroll
- Staff compensation profile with monthly/daily/hourly basis, basic salary/rate, allowances and deductions.
- Salary advances.
- Monthly payroll generation and payroll adjustments.
- Salary payment records create Payroll expenses so operating-profit reports include payroll cost.

## Public online shop
- Public menu now has Add to Cart and real online checkout.
- Customer chooses pickup/delivery and required date/time.
- Order is priced using authoritative database prices and enters Customer Orders as a pending web order.
- No automatic payment collection is enabled yet. Payment integrations and automatic customer notifications remain later-phase work as requested.

## Migration
Migration `036_usability_data_management_core_business.sql` contains the database changes for v0.37. Production cutover remains blocked until staging validation, real business data, backup/restore proof and public-site verification are complete.
