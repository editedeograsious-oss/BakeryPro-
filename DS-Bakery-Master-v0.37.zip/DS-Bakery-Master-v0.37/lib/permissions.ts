export type StaffRole =
  | "owner"
  | "manager"
  | "cashier"
  | "baker"
  | "storekeeper";

export type Permission =
  | "dashboard:view"
  | "pos:use"
  | "products:read"
  | "products:write"
  | "recipes:read"
  | "recipes:write"
  | "inventory:read"
  | "inventory:write"
  | "purchases:read"
  | "purchases:write"
  | "expenses:read"
  | "expenses:write"
  | "closing:prepare"
  | "closing:close"
  | "reports:view"
  | "activity:view"
  | "staff:manage"
  | "security:manage"
  | "waste:read"
  | "waste:record"
  | "waste:approve"
  | "delivery:read"
  | "delivery:manage"
  | "loyalty:read"
  | "loyalty:manage"
  | "communication:read"
  | "communication:send"
  | "communication:manage"
  | "attendance:self"
  | "attendance:view"
  | "attendance:manage"
  | "schedule:view"
  | "schedule:manage"
  | "permissions:manage"
  | "recycle:manage"
  | "recycle:purge"
  | "payroll:read"
  | "payroll:manage"
  | "credit:read"
  | "credit:manage"
  | "finished_goods:read";

export const MATRIX: Record<StaffRole, Permission[]> = {
  owner: [
    "dashboard:view","pos:use","products:read","products:write","recipes:read","recipes:write",
    "inventory:read","inventory:write","purchases:read","purchases:write",
    "expenses:read","expenses:write","closing:prepare","closing:close",
    "reports:view","activity:view","staff:manage","security:manage",
    "waste:read","waste:record","waste:approve","delivery:read","delivery:manage",
    "loyalty:read","loyalty:manage","communication:read","communication:send","communication:manage",
    "attendance:self","attendance:view","attendance:manage","schedule:view","schedule:manage","permissions:manage",
    "recycle:manage","recycle:purge","payroll:read","payroll:manage","credit:read","credit:manage","finished_goods:read"
  ],
  manager: [
    "dashboard:view","pos:use","products:read","products:write","recipes:read","recipes:write",
    "inventory:read","inventory:write","purchases:read","purchases:write",
    "expenses:read","expenses:write","closing:prepare","closing:close",
    "reports:view","activity:view","waste:read","waste:record","waste:approve",
    "delivery:read","delivery:manage","loyalty:read","loyalty:manage",
    "communication:read","communication:send","communication:manage",
    "attendance:self","attendance:view","attendance:manage","schedule:view","schedule:manage",
    "recycle:manage","payroll:read","payroll:manage","credit:read","credit:manage","finished_goods:read"
  ],
  cashier: [
    "pos:use","products:read","delivery:read","delivery:manage",
    "loyalty:read","loyalty:manage","communication:read","communication:send",
    "attendance:self","schedule:view","credit:read","credit:manage"
  ],
  baker: [
    "recipes:read","inventory:read","products:read","waste:read","waste:record",
    "attendance:self","schedule:view","finished_goods:read"
  ],
  storekeeper: [
    "inventory:read","inventory:write","purchases:read","purchases:write","products:read",
    "waste:read","waste:record","attendance:self","schedule:view","finished_goods:read"
  ],
};

export function can(role: StaffRole, permission: Permission) {
  return MATRIX[role].includes(permission);
}

export function permissionsFor(role: StaffRole) {
  return MATRIX[role];
}
