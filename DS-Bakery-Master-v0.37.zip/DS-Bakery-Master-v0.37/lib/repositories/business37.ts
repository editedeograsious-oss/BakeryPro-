import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";

export async function getCreditBookData(){
  if(isDemoMode()) return {accounts:[],ledger:[],demo:true};
  const supabase=await createClient();
  const [{data:accounts,error:aErr},{data:ledger,error:lErr}]=await Promise.all([
    supabase.from("customer_credit_summary").select("*").order("balance_due",{ascending:false}).order("full_name"),
    supabase.from("customer_credit_ledger_detail").select("*").order("created_at",{ascending:false}).limit(500),
  ]);
  if(aErr)throw aErr;if(lErr)throw lErr;
  return {accounts:accounts??[],ledger:ledger??[],demo:false};
}

export async function getPayrollData(){
  if(isDemoMode()) return {staff:[],compensation:[],runs:[],items:[],advances:[],demo:true};
  const supabase=await createClient();
  const [
    {data:staff,error:sErr},{data:compensation,error:cErr},{data:runs,error:rErr},
    {data:items,error:iErr},{data:advances,error:aErr},
  ]=await Promise.all([
    supabase.from("profiles").select("id,full_name,role,active,disabled_at").order("full_name"),
    supabase.from("staff_compensation_profiles").select("*").order("updated_at",{ascending:false}),
    supabase.from("payroll_runs").select("*").order("payroll_month",{ascending:false}).limit(24),
    supabase.from("payroll_item_summary").select("*").order("payroll_month",{ascending:false}).order("full_name"),
    supabase.from("salary_advances").select("*").order("granted_at",{ascending:false}).limit(200),
  ]);
  if(sErr)throw sErr;if(cErr)throw cErr;if(rErr)throw rErr;if(iErr)throw iErr;if(aErr)throw aErr;
  return {staff:staff??[],compensation:compensation??[],runs:runs??[],items:items??[],advances:advances??[],demo:false};
}

export async function getFinishedGoodsData(){
  if(isDemoMode()) return {batches:[],demo:true};
  const supabase=await createClient();
  const {data,error}=await supabase.from("finished_goods_batch_summary").select("*").order("production_date",{ascending:false}).order("batch_no",{ascending:false});
  if(error)throw error;
  return {batches:data??[],demo:false};
}
