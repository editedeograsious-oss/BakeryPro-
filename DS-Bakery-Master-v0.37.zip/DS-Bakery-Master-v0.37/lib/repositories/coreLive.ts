import { createClient } from "@/lib/supabase/server";
import { isDemoMode } from "@/lib/runtime";
import {
  demoCategories,
  demoClosing,
  demoMaterials,
  demoPosProducts,
  demoProducts,
  demoRecipes,
  demoShifts,
} from "@/lib/demo/core";

export async function getProductPageData() {
  if (isDemoMode()) {
    return { products: demoProducts, categories: demoCategories, demo: true };
  }

  const supabase = await createClient();
  const [
    { data: costRows, error: costError },
    { data: productRows, error: productError },
    { data: categories, error: categoryError },
  ] = await Promise.all([
    supabase.from("product_cost_summary").select("*").neq("status","archived").order("name"),
    supabase.from("products").select("id,category_id,name,sku,description,selling_price,status,image_url,notes").neq("status","archived").order("name"),
    supabase.from("product_categories").select("id,name").eq("status","active").order("display_order").order("name"),
  ]);
  if (costError) throw costError;
  if (productError) throw productError;
  if (categoryError) throw categoryError;
  const costs=new Map((costRows??[]).map((r:any)=>[r.id,r]));
  return {
    products:(productRows??[]).map((p:any)=>({...p,...(costs.get(p.id)??{}),category_id:p.category_id,description:p.description})),
    categories:categories??[],demo:false
  };
}

export async function getInventoryPageData() {
  if (isDemoMode()) {
    return { materials: demoMaterials, recentMovements: [], suppliers: [], demo: true };
  }

  const supabase = await createClient();
  const [
    {data:summary,error:summaryError},
    {data:raw,error:rawError},
    {data:suppliers,error:supplierError},
    {data:movements,error:movementError},
  ]=await Promise.all([
    supabase.from("inventory_live_summary").select("*").order("name"),
    supabase.from("raw_materials").select("id,supplier_id,name,sku,base_unit,purchase_pack_label,purchase_pack_base_qty,current_purchase_cost,current_stock_qty,low_stock_threshold,status").neq("status","archived").order("name"),
    supabase.from("suppliers").select("id,name").eq("active",true).order("name"),
    supabase.from("inventory_transactions").select("id,tx_type,quantity_delta,unit_cost,notes,created_at,raw_material_id").order("created_at",{ascending:false}).limit(15),
  ]);
  if(summaryError)throw summaryError;if(rawError)throw rawError;if(supplierError)throw supplierError;if(movementError)throw movementError;
  const summaryMap=new Map((summary??[]).map((m:any)=>[m.id,m]));
  const supplierMap=new Map((suppliers??[]).map((s:any)=>[s.id,s.name]));
  return {
    materials:(raw??[]).map((m:any)=>({...m,...(summaryMap.get(m.id)??{}),supplier_id:m.supplier_id,supplier_name:m.supplier_id?supplierMap.get(m.supplier_id)??null:null,purchase_pack_label:m.purchase_pack_label,purchase_pack_base_qty:Number(m.purchase_pack_base_qty)})),
    suppliers:suppliers??[],recentMovements:movements??[],demo:false,
  };
}

export async function getRecipePageData() {
  if (isDemoMode()) {
    return {
      recipes: demoRecipes,
      products: demoProducts.map((p) => ({ id: p.id, name: p.name, selling_price: p.selling_price })),
      materials: demoMaterials,
      demo: true,
    };
  }

  const supabase = await createClient();

  const [
    { data: recipeRows, error: recipeError },
    { data: products, error: productError },
    { data: materials, error: materialError },
  ] = await Promise.all([
    supabase
      .from("recipe_cost_detail")
      .select("*")
      .order("product_name")
      .order("ingredient_name"),
    supabase
      .from("products")
      .select("id,name,selling_price")
      .eq("status", "active")
      .order("name"),
    supabase
      .from("raw_materials")
      .select("id,name,base_unit,current_purchase_cost,purchase_pack_base_qty")
      .eq("status", "active")
      .order("name"),
  ]);

  if (recipeError) throw recipeError;
  if (productError) throw productError;
  if (materialError) throw materialError;

  const grouped = new Map<string, any>();
  for (const row of recipeRows ?? []) {
    if (!grouped.has(row.recipe_id)) {
      grouped.set(row.recipe_id, {
        id: row.recipe_id,
        product_id: row.product_id,
        product_name: row.product_name,
        name: row.recipe_name,
        yield_qty: Number(row.yield_qty),
        selling_price: Number(row.selling_price),
        batch_cost: Number(row.batch_cost),
        unit_food_cost: Number(row.unit_food_cost),
        gross_profit: Number(row.gross_profit),
        margin_pct: Number(row.margin_pct),
        ingredients: [],
      });
    }
    grouped.get(row.recipe_id).ingredients.push({
      raw_material_id: row.raw_material_id,
      name: row.ingredient_name,
      base_unit: row.base_unit,
      quantity_base_unit: Number(row.quantity_base_unit),
      unit_cost: Number(row.unit_cost),
      line_cost: Number(row.line_cost),
    });
  }

  return {
    recipes: Array.from(grouped.values()),
    products: products ?? [],
    materials: (materials ?? []).map((m: any) => ({
      ...m,
      unit_cost:
        Number(m.purchase_pack_base_qty) > 0
          ? Number(m.current_purchase_cost) / Number(m.purchase_pack_base_qty)
          : 0,
    })),
    demo: false,
  };
}

export async function getPosPageData() {
  if (isDemoMode()) {
    const { demoCustomers } = await import("@/lib/demo/service");
    return { products: demoPosProducts, openShift: demoShifts[0], customers: demoCustomers, demo: true };
  }

  const supabase = await createClient();

  const [
    { data: products, error: productError },
    { data: customers, error: customerError },
    { data: { user }, error: userError },
  ] = await Promise.all([
    supabase
      .from("products")
      .select("id,name,selling_price,product_categories(name)")
      .eq("status", "active")
      .order("name"),
    supabase.from("customer_credit_summary").select("customer_id,full_name,phone,active,credit_enabled,credit_limit,balance_due,available_credit,terms_days").eq("active",true).order("full_name"),
    supabase.auth.getUser(),
  ]);

  if (productError) throw productError;
  if (customerError) throw customerError;
  if (userError) throw userError;

  let openShift = null;
  if (user) {
    const { data, error } = await supabase
      .from("cashier_shift_summary")
      .select("*")
      .eq("cashier_id", user.id)
      .eq("status", "open")
      .order("opened_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    openShift = data;
  }

  return {
    products: (products ?? []).map((p: any) => ({
      id: p.id,
      name: p.name,
      selling_price: Number(p.selling_price),
      category_name: p.product_categories?.name ?? "Uncategorized",
    })),
    openShift,
    customers: customers ?? [],
    demo: false,
  };
}

export async function getCashierShiftPageData() {
  if (isDemoMode()) return { shifts: demoShifts, demo: true };

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("cashier_shift_summary")
    .select("*")
    .order("opened_at", { ascending: false })
    .limit(30);

  if (error) throw error;
  return { shifts: data ?? [], demo: false };
}

export async function getDailyClosingPageData() {
  if (isDemoMode()) return { snapshot: demoClosing, demo: true };

  const supabase = await createClient();

  const { data: dateData, error: dateError } = await supabase.rpc("business_current_date");
  if (dateError) throw dateError;

  const businessDate = dateData as string;

  const { data: snapshot, error: snapshotError } = await supabase.rpc(
    "daily_closing_snapshot",
    { p_business_date: businessDate }
  );
  if (snapshotError) throw snapshotError;

  const { data: existing, error: existingError } = await supabase
    .from("daily_closings")
    .select("*")
    .eq("business_date", businessDate)
    .maybeSingle();

  if (existingError) throw existingError;

  return {
    snapshot: { ...(snapshot as any), status: existing?.status ?? "draft", counted_cash: existing?.counted_cash ?? null, cash_variance: existing?.cash_variance ?? null },
    demo: false,
  };
}
