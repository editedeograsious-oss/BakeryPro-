import type { StaffRole } from "@/lib/permissions";

export const BUSINESS_ROLE_LABELS:Record<StaffRole,string>={
  owner:"CEO / Owner",
  manager:"General Manager",
  baker:"Head Baker",
  storekeeper:"Stock Manager",
  cashier:"Sales Team",
};

export function businessRoleLabel(role:string|null|undefined){
  return role && role in BUSINESS_ROLE_LABELS ? BUSINESS_ROLE_LABELS[role as StaffRole] : (role || "Staff");
}
