-- DS Bakery Master v0.37 / Migration 036
-- Usability, recycle bin, payroll, customer credit, true batch costing,
-- finished-goods inventory, and public online ordering.

-- =====================================================================
-- PERMISSIONS / BUSINESS ROLE CAPABILITIES
-- =====================================================================
insert into public.app_permissions(permission_key,description,critical)
values
  ('recycle:manage','Move allowed records to recycle bin and restore them',true),
  ('recycle:purge','Permanently purge eligible recycled records',true),
  ('payroll:read','View staff salary and payroll records',true),
  ('payroll:manage','Manage compensation, payroll and salary payments',true),
  ('credit:read','View customer credit accounts and balances',false),
  ('credit:manage','Manage customer credit terms, sales and repayments',true),
  ('finished_goods:read','View finished-goods batches and batch profitability',false)
on conflict(permission_key) do update
set description=excluded.description,critical=excluded.critical;

insert into public.role_permission_defaults(role,permission_key,allowed)
values
  ('owner','recycle:manage',true),('manager','recycle:manage',true),('cashier','recycle:manage',false),('baker','recycle:manage',false),('storekeeper','recycle:manage',false),
  ('owner','recycle:purge',true),('manager','recycle:purge',false),('cashier','recycle:purge',false),('baker','recycle:purge',false),('storekeeper','recycle:purge',false),
  ('owner','payroll:read',true),('manager','payroll:read',true),('cashier','payroll:read',false),('baker','payroll:read',false),('storekeeper','payroll:read',false),
  ('owner','payroll:manage',true),('manager','payroll:manage',true),('cashier','payroll:manage',false),('baker','payroll:manage',false),('storekeeper','payroll:manage',false),
  ('owner','credit:read',true),('manager','credit:read',true),('cashier','credit:read',true),('baker','credit:read',false),('storekeeper','credit:read',false),
  ('owner','credit:manage',true),('manager','credit:manage',true),('cashier','credit:manage',true),('baker','credit:manage',false),('storekeeper','credit:manage',false),
  ('owner','finished_goods:read',true),('manager','finished_goods:read',true),('cashier','finished_goods:read',false),('baker','finished_goods:read',true),('storekeeper','finished_goods:read',true)
on conflict(role,permission_key) do update set allowed=excluded.allowed;

-- =====================================================================
-- MY ACCOUNT
-- =====================================================================
create or replace function public.update_my_profile(p_full_name text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_before jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if coalesce(trim(p_full_name),'')='' then raise exception 'Display name is required'; end if;

  select to_jsonb(p) into v_before from public.profiles p where p.id=auth.uid();
  if v_before is null then raise exception 'Staff profile not found'; end if;

  update public.profiles set full_name=trim(p_full_name),updated_at=now() where id=auth.uid();
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'update_my_profile','profile',auth.uid(),v_before,(select to_jsonb(p) from public.profiles p where p.id=auth.uid()));
end;
$$;
revoke all on function public.update_my_profile(text) from public,anon;
grant execute on function public.update_my_profile(text) to authenticated;

-- =====================================================================
-- RECYCLE BIN / SOFT DELETE
-- =====================================================================
-- All destructive table-level DELETE policies are removed in v0.37.
-- Staff must use audited recycle/void/cancel RPCs; eligible permanent purge
-- is Owner-only through purge_recycled_record(). This prevents bypassing
-- the Recycle Bin and protects financial, stock and staff history.
drop policy if exists "owner delete attendance settings" on public.attendance_settings;
drop policy if exists "owner delete business settings" on public.business_settings;
drop policy if exists "management delete cashier shifts" on public.cashier_shifts;
drop policy if exists "management delete daily closings" on public.daily_closings;
drop policy if exists "management delete product categories" on public.product_categories;
drop policy if exists "owner delete profiles" on public.profiles;
drop policy if exists "management delete work shifts" on public.staff_work_shifts;
drop policy if exists "owner delete waste settings" on public.waste_settings;

alter table public.expenses
  add column if not exists voided_at timestamptz,
  add column if not exists voided_by uuid references public.profiles(id),
  add column if not exists void_reason text;

create table if not exists public.recycle_bin (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  entity_id uuid not null,
  record_label text not null,
  action_kind text not null default 'soft_delete' check(action_kind in ('soft_delete','cancel','void')),
  snapshot jsonb not null,
  delete_reason text not null,
  deleted_by uuid not null references public.profiles(id),
  deleted_at timestamptz not null default now(),
  restored_by uuid references public.profiles(id),
  restored_at timestamptz,
  purged_by uuid references public.profiles(id),
  purged_at timestamptz,
  purge_reason text,
  status text not null default 'trashed' check(status in ('trashed','restored','purged'))
);
create unique index if not exists recycle_bin_active_entity_unique
  on public.recycle_bin(entity_type,entity_id) where status='trashed';
create index if not exists recycle_bin_deleted_at_idx on public.recycle_bin(deleted_at desc);

alter table public.recycle_bin enable row level security;
drop policy if exists "management read recycle bin" on public.recycle_bin;
create policy "management read recycle bin" on public.recycle_bin for select to authenticated
using (public.staff_has_permission('recycle:manage'));

create or replace view public.recycle_bin_summary
with (security_invoker=true)
as
select rb.id,rb.entity_type,rb.entity_id,rb.record_label,rb.action_kind,rb.delete_reason,
       rb.deleted_at,rb.deleted_by,p.full_name deleted_by_name,rb.status,
       rb.restored_at,rb.restored_by,rb.purged_at,rb.purged_by,
       case when rb.entity_type in ('product','raw_material','supplier','customer','delivery_rider','product_category','recipe') then true else false end as purge_candidate
from public.recycle_bin rb
left join public.profiles p on p.id=rb.deleted_by;

create or replace function public.move_record_to_recycle_bin(p_entity_type text,p_entity_id uuid,p_reason text)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_snapshot jsonb;
  v_label text;
  v_action text:='soft_delete';
  v_recycle_id uuid:=gen_random_uuid();
  v_paid numeric;
  v_received numeric;
begin
  if not public.staff_has_permission('recycle:manage') then raise exception 'Recycle-bin permission required'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Deletion reason is required'; end if;
  if exists(select 1 from public.recycle_bin where entity_type=p_entity_type and entity_id=p_entity_id and status='trashed') then
    raise exception 'Record is already in the recycle bin';
  end if;

  case p_entity_type
    when 'product' then
      select to_jsonb(x),x.name into v_snapshot,v_label from public.products x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Product not found'; end if;
      update public.products set status='archived',updated_at=now() where id=p_entity_id;
    when 'raw_material' then
      select to_jsonb(x),x.name into v_snapshot,v_label from public.raw_materials x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Raw material not found'; end if;
      update public.raw_materials set status='archived',updated_at=now() where id=p_entity_id;
    when 'supplier' then
      select to_jsonb(x),x.name into v_snapshot,v_label from public.suppliers x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Supplier not found'; end if;
      update public.suppliers set active=false,updated_at=now() where id=p_entity_id;
    when 'customer' then
      select to_jsonb(x),x.full_name into v_snapshot,v_label from public.customers x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Customer not found'; end if;
      update public.customers set active=false,updated_at=now() where id=p_entity_id;
    when 'delivery_rider' then
      select to_jsonb(x),x.full_name into v_snapshot,v_label from public.delivery_riders x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Delivery rider not found'; end if;
      update public.delivery_riders set active=false,updated_at=now() where id=p_entity_id;
    when 'product_category' then
      select to_jsonb(x),x.name into v_snapshot,v_label from public.product_categories x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Product category not found'; end if;
      update public.product_categories set status='archived',updated_at=now() where id=p_entity_id;
    when 'recipe' then
      select to_jsonb(x),x.name into v_snapshot,v_label from public.recipes x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Recipe not found'; end if;
      update public.recipes set active=false,updated_at=now() where id=p_entity_id;
    when 'expense' then
      select to_jsonb(x),x.description into v_snapshot,v_label from public.expenses x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Expense not found'; end if;
      if (v_snapshot->>'voided_at') is not null then raise exception 'Expense is already voided'; end if;
      v_action:='void';
      update public.expenses set voided_at=now(),voided_by=auth.uid(),void_reason=trim(p_reason) where id=p_entity_id;
    when 'customer_order' then
      select to_jsonb(x),x.order_no into v_snapshot,v_label from public.customer_orders x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Customer order not found'; end if;
      if (v_snapshot->>'status') not in ('pending','confirmed') then raise exception 'Only pending or confirmed orders can be moved to recycle bin'; end if;
      select public.customer_order_net_paid(p_entity_id) into v_paid;
      if coalesce(v_paid,0)<>0 then raise exception 'Orders with payments must be cancelled/refunded through the order workflow'; end if;
      v_action:='cancel';
      update public.customer_orders set status='cancelled',cancelled_at=now(),cancellation_reason=trim(p_reason),updated_at=now() where id=p_entity_id;
    when 'purchase' then
      select to_jsonb(x),x.purchase_no into v_snapshot,v_label from public.purchases x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Purchase not found'; end if;
      if (v_snapshot->>'status') not in ('draft','ordered') then raise exception 'Only unreceived draft/ordered purchases can be recycled'; end if;
      select coalesce(sum(received_qty_base),0) into v_received from public.purchase_items where purchase_id=p_entity_id;
      if coalesce(v_received,0)>0 or coalesce((v_snapshot->>'amount_paid')::numeric,0)>0 then raise exception 'Received or paid purchases must use the supplier adjustment workflow'; end if;
      v_action:='cancel';
      update public.purchases set status='cancelled',updated_at=now() where id=p_entity_id;
    when 'staff_work_shift' then
      select to_jsonb(x),coalesce(x.work_station,'Staff shift') into v_snapshot,v_label from public.staff_work_shifts x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Staff shift not found'; end if;
      if (v_snapshot->>'status')='completed' then raise exception 'Completed staff shifts cannot be deleted'; end if;
      v_action:='cancel';
      update public.staff_work_shifts set status='cancelled',updated_at=now() where id=p_entity_id;
    when 'baker_task' then
      select to_jsonb(x),x.title into v_snapshot,v_label from public.baker_tasks x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Baker task not found'; end if;
      if (v_snapshot->>'status')='complete' then raise exception 'Completed baker tasks cannot be deleted'; end if;
      v_action:='cancel';
      update public.baker_tasks set status='cancelled',updated_at=now() where id=p_entity_id;
    when 'production_plan_item' then
      select to_jsonb(x),'Production plan '||x.id::text into v_snapshot,v_label from public.production_plan_items x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Production plan item not found'; end if;
      if coalesce((v_snapshot->>'produced_qty')::numeric,0)>0 then raise exception 'Production plans with confirmed output cannot be deleted'; end if;
      v_action:='cancel';
      update public.production_plan_items set status='cancelled',updated_at=now() where id=p_entity_id;
    when 'sale' then
      select to_jsonb(x),x.sale_no into v_snapshot,v_label from public.sales x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Sale not found'; end if;
      if (v_snapshot->>'status')<>'held' then raise exception 'Paid/completed sales cannot be deleted. Use refund/void controls so the audit trail remains intact'; end if;
      v_action:='cancel';
      update public.sales set status='cancelled',held=false,voided_at=now(),voided_by=auth.uid(),void_reason=trim(p_reason) where id=p_entity_id;
    when 'waste_event' then
      select to_jsonb(x),x.reason into v_snapshot,v_label from public.waste_events x where x.id=p_entity_id for update;
      if v_snapshot is null then raise exception 'Waste record not found'; end if;
      if (v_snapshot->>'approval_status')<>'pending' then raise exception 'Only pending waste records can be deleted'; end if;
      v_action:='cancel';
      update public.waste_events set approval_status='rejected',approved_by=auth.uid(),approved_at=now(),decision_note='Moved to recycle bin: '||trim(p_reason) where id=p_entity_id;
    else
      raise exception 'Unsupported recycle-bin record type: %',p_entity_type;
  end case;

  insert into public.recycle_bin(id,entity_type,entity_id,record_label,action_kind,snapshot,delete_reason,deleted_by)
  values(v_recycle_id,p_entity_type,p_entity_id,coalesce(v_label,p_entity_type),v_action,v_snapshot,trim(p_reason),auth.uid());

  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'move_to_recycle_bin',p_entity_type,p_entity_id,v_snapshot,jsonb_build_object('recycle_id',v_recycle_id,'reason',trim(p_reason)));
  return v_recycle_id;
end;
$$;

create or replace function public.restore_recycled_record(p_recycle_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v public.recycle_bin%rowtype; v_status text;
begin
  if not public.staff_has_permission('recycle:manage') then raise exception 'Recycle-bin permission required'; end if;
  select * into v from public.recycle_bin where id=p_recycle_id for update;
  if not found or v.status<>'trashed' then raise exception 'Active recycle-bin record not found'; end if;

  case v.entity_type
    when 'product' then update public.products set status=coalesce((v.snapshot->>'status')::public.record_status,'active'::public.record_status),updated_at=now() where id=v.entity_id;
    when 'raw_material' then update public.raw_materials set status=coalesce((v.snapshot->>'status')::public.record_status,'active'::public.record_status),updated_at=now() where id=v.entity_id;
    when 'supplier' then update public.suppliers set active=coalesce((v.snapshot->>'active')::boolean,true),updated_at=now() where id=v.entity_id;
    when 'customer' then update public.customers set active=coalesce((v.snapshot->>'active')::boolean,true),updated_at=now() where id=v.entity_id;
    when 'delivery_rider' then update public.delivery_riders set active=coalesce((v.snapshot->>'active')::boolean,true),updated_at=now() where id=v.entity_id;
    when 'product_category' then update public.product_categories set status=coalesce((v.snapshot->>'status')::public.record_status,'active'::public.record_status),updated_at=now() where id=v.entity_id;
    when 'recipe' then
      if coalesce((v.snapshot->>'active')::boolean,false) and exists(select 1 from public.recipes where product_id=(v.snapshot->>'product_id')::uuid and active=true and id<>v.entity_id) then
        raise exception 'Another active recipe already exists for this product';
      end if;
      update public.recipes set active=coalesce((v.snapshot->>'active')::boolean,false),updated_at=now() where id=v.entity_id;
    when 'expense' then update public.expenses set voided_at=null,voided_by=null,void_reason=null where id=v.entity_id;
    when 'customer_order' then
      if public.customer_order_net_paid(v.entity_id)<>0 then raise exception 'Order has payment activity and cannot be restored from recycle bin'; end if;
      v_status:=coalesce(v.snapshot->>'status','pending');
      update public.customer_orders set status=v_status::public.customer_order_status,cancelled_at=(v.snapshot->>'cancelled_at')::timestamptz,cancellation_reason=v.snapshot->>'cancellation_reason',updated_at=now() where id=v.entity_id;
    when 'purchase' then
      if exists(select 1 from public.purchase_items where purchase_id=v.entity_id and received_qty_base>0) then raise exception 'Purchase now has receipt activity and cannot be restored'; end if;
      update public.purchases set status=coalesce(v.snapshot->>'status','draft')::public.purchase_status,updated_at=now() where id=v.entity_id;
    when 'staff_work_shift' then update public.staff_work_shifts set status=coalesce(v.snapshot->>'status','scheduled')::public.staff_shift_status,updated_at=now() where id=v.entity_id;
    when 'baker_task' then update public.baker_tasks set status=coalesce(v.snapshot->>'status','todo')::public.baker_task_status,updated_at=now() where id=v.entity_id;
    when 'production_plan_item' then update public.production_plan_items set status=coalesce(v.snapshot->>'status','planned')::public.production_status,updated_at=now() where id=v.entity_id and produced_qty=0;
    when 'sale' then update public.sales set status='held',held=true,voided_at=null,voided_by=null,void_reason=null where id=v.entity_id and status='cancelled';
    when 'waste_event' then update public.waste_events set approval_status='pending',approved_by=null,approved_at=null,decision_note=v.snapshot->>'decision_note' where id=v.entity_id and inventory_transaction_id is null;
    else raise exception 'This record type cannot be restored automatically';
  end case;

  update public.recycle_bin set status='restored',restored_by=auth.uid(),restored_at=now() where id=p_recycle_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'restore_from_recycle_bin',v.entity_type,v.entity_id,jsonb_build_object('recycle_id',p_recycle_id));
end;
$$;

create or replace function public.purge_recycled_record(p_recycle_id uuid,p_reason text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v public.recycle_bin%rowtype;
begin
  if not public.staff_has_permission('recycle:purge') then raise exception 'Only the CEO / Owner can permanently purge records'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Permanent-delete reason is required'; end if;
  select * into v from public.recycle_bin where id=p_recycle_id for update;
  if not found or v.status<>'trashed' then raise exception 'Active recycle-bin record not found'; end if;

  case v.entity_type
    when 'product' then delete from public.products where id=v.entity_id;
    when 'raw_material' then delete from public.raw_materials where id=v.entity_id;
    when 'supplier' then delete from public.suppliers where id=v.entity_id;
    when 'customer' then delete from public.customers where id=v.entity_id;
    when 'delivery_rider' then delete from public.delivery_riders where id=v.entity_id;
    when 'product_category' then delete from public.product_categories where id=v.entity_id;
    when 'recipe' then delete from public.recipes where id=v.entity_id;
    else raise exception 'Financial, stock, production and audit records cannot be permanently erased';
  end case;

  update public.recycle_bin set status='purged',purged_by=auth.uid(),purged_at=now(),purge_reason=trim(p_reason) where id=p_recycle_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'purge_recycled_record',v.entity_type,v.entity_id,v.snapshot,jsonb_build_object('recycle_id',p_recycle_id,'reason',trim(p_reason)));
end;
$$;

revoke all on function public.move_record_to_recycle_bin(text,uuid,text) from public,anon;
revoke all on function public.restore_recycled_record(uuid) from public,anon;
revoke all on function public.purge_recycled_record(uuid,text) from public,anon;
grant execute on function public.move_record_to_recycle_bin(text,uuid,text) to authenticated;
grant execute on function public.restore_recycled_record(uuid) to authenticated;
grant execute on function public.purge_recycled_record(uuid,text) to authenticated;

-- =====================================================================
-- FINISHED GOODS / TRUE PRODUCTION-BATCH COSTING
-- =====================================================================
create table if not exists public.finished_goods_batches (
  id uuid primary key default gen_random_uuid(),
  batch_no text not null unique,
  production_run_id uuid not null unique references public.production_runs(id) on delete restrict,
  product_id uuid not null references public.products(id),
  production_date date not null,
  quantity_produced numeric(14,3) not null check(quantity_produced>0),
  quantity_available numeric(14,3) not null check(quantity_available>=0),
  batch_cost numeric(14,2) not null default 0 check(batch_cost>=0),
  unit_cost numeric(14,6) not null default 0 check(unit_cost>=0),
  created_at timestamptz not null default now()
);
create index if not exists finished_goods_batches_fifo_idx on public.finished_goods_batches(product_id,production_date,created_at) where quantity_available>0;

create table if not exists public.sale_batch_allocations (
  id uuid primary key default gen_random_uuid(),
  sale_item_id uuid not null references public.sale_items(id) on delete restrict,
  batch_id uuid not null references public.finished_goods_batches(id) on delete restrict,
  quantity numeric(14,3) not null check(quantity>0),
  unit_cost numeric(14,6) not null check(unit_cost>=0),
  cogs_amount numeric(14,2) not null check(cogs_amount>=0),
  created_at timestamptz not null default now(),
  unique(sale_item_id,batch_id)
);

create table if not exists public.customer_order_batch_allocations (
  id uuid primary key default gen_random_uuid(),
  order_item_id uuid not null references public.customer_order_items(id) on delete restrict,
  batch_id uuid not null references public.finished_goods_batches(id) on delete restrict,
  quantity numeric(14,3) not null check(quantity>0),
  unit_cost numeric(14,6) not null check(unit_cost>=0),
  cogs_amount numeric(14,2) not null check(cogs_amount>=0),
  created_at timestamptz not null default now(),
  unique(order_item_id,batch_id)
);

create table if not exists public.finished_goods_waste_allocations (
  id uuid primary key default gen_random_uuid(),
  waste_event_id uuid not null references public.waste_events(id) on delete restrict,
  batch_id uuid not null references public.finished_goods_batches(id) on delete restrict,
  quantity numeric(14,3) not null check(quantity>0),
  unit_cost numeric(14,6) not null check(unit_cost>=0),
  cost_amount numeric(14,2) not null check(cost_amount>=0),
  created_at timestamptz not null default now(),
  unique(waste_event_id,batch_id)
);

alter table public.finished_goods_batches enable row level security;
alter table public.sale_batch_allocations enable row level security;
alter table public.customer_order_batch_allocations enable row level security;
alter table public.finished_goods_waste_allocations enable row level security;

create policy "relevant staff read finished batches" on public.finished_goods_batches for select to authenticated
using (public.staff_has_permission('finished_goods:read') or public.staff_has_permission('reports:view'));
create policy "management read sale batch allocations" on public.sale_batch_allocations for select to authenticated
using (public.staff_has_permission('reports:view'));
create policy "management read order batch allocations" on public.customer_order_batch_allocations for select to authenticated
using (public.staff_has_permission('reports:view'));
create policy "production staff read waste batch allocations" on public.finished_goods_waste_allocations for select to authenticated
using (public.staff_has_permission('finished_goods:read') or public.staff_has_permission('reports:view'));

create or replace function public.next_batch_no()
returns text language sql volatile set search_path=public as $$
  select 'BAT-'||to_char(public.business_current_date(),'YYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6))
$$;

create or replace function public.create_finished_goods_batch(p_run_id uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_run public.production_runs%rowtype;
  v_product uuid;
  v_batch_cost numeric(14,2);
  v_id uuid;
begin
  select * into v_run from public.production_runs where id=p_run_id;
  if not found then raise exception 'Production run not found'; end if;
  select product_id into v_product from public.production_plan_items where id=v_run.plan_item_id;
  select coalesce(sum(quantity_used_base*unit_cost_snapshot),0)::numeric(14,2) into v_batch_cost from public.production_consumptions where production_run_id=p_run_id;

  insert into public.finished_goods_batches(batch_no,production_run_id,product_id,production_date,quantity_produced,quantity_available,batch_cost,unit_cost)
  values(public.next_batch_no(),p_run_id,v_product,public.business_date(v_run.confirmed_at),v_run.quantity_produced,v_run.quantity_produced,v_batch_cost,
    case when v_run.quantity_produced>0 then v_batch_cost/v_run.quantity_produced else 0 end)
  on conflict(production_run_id) do update set
    batch_cost=excluded.batch_cost,
    unit_cost=excluded.unit_cost
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.allocate_sale_item_to_batches(p_sale_item_id uuid,p_require_full boolean default true)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.sale_items%rowtype;
  v_sale_status text;
  v_remaining numeric(14,3);
  v_take numeric(14,3);
  v_total_cost numeric(14,2):=0;
  v_batch record;
  v_allocated numeric(14,3):=0;
begin
  select si.* into v_item
  from public.sale_items si
  where si.id=p_sale_item_id for update;
  if not found then raise exception 'Sale item not found'; end if;
  select s.status into v_sale_status from public.sales s where s.id=v_item.sale_id;
  if v_sale_status not in ('completed','partially_refunded','refunded') then return 0; end if;
  if exists(select 1 from public.sale_batch_allocations where sale_item_id=p_sale_item_id) then
    select coalesce(sum(cogs_amount),0) into v_total_cost from public.sale_batch_allocations where sale_item_id=p_sale_item_id;
    return v_total_cost;
  end if;

  v_remaining:=v_item.quantity;
  for v_batch in
    select * from public.finished_goods_batches
    where product_id=v_item.product_id and quantity_available>0
    order by production_date,created_at,id
    for update
  loop
    exit when v_remaining<=0;
    v_take:=least(v_remaining,v_batch.quantity_available);
    insert into public.sale_batch_allocations(sale_item_id,batch_id,quantity,unit_cost,cogs_amount)
    values(p_sale_item_id,v_batch.id,v_take,v_batch.unit_cost,round(v_take*v_batch.unit_cost,2));
    update public.finished_goods_batches set quantity_available=quantity_available-v_take where id=v_batch.id;
    v_total_cost:=v_total_cost+round(v_take*v_batch.unit_cost,2);
    v_allocated:=v_allocated+v_take;
    v_remaining:=v_remaining-v_take;
  end loop;

  if p_require_full and v_remaining>0 then raise exception 'Insufficient finished-goods stock for product % (short by %)',v_item.product_id,v_remaining; end if;
  if v_allocated>0 then
    update public.sale_items set
      unit_cost_snapshot=round(v_total_cost/v_item.quantity,6),
      gross_profit_snapshot=round(v_item.line_total-v_total_cost,2)
    where id=p_sale_item_id;
  end if;
  return v_total_cost;
end;
$$;

create or replace function public.allocate_customer_order_item_to_batches(p_order_item_id uuid,p_require_full boolean default true)
returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item public.customer_order_items%rowtype;
  v_remaining numeric(14,3);v_take numeric(14,3);v_total numeric(14,2):=0;v_batch record;
begin
  select * into v_item from public.customer_order_items where id=p_order_item_id for update;
  if not found or v_item.product_id is null then return 0; end if;
  if exists(select 1 from public.customer_order_batch_allocations where order_item_id=p_order_item_id) then
    select coalesce(sum(cogs_amount),0) into v_total from public.customer_order_batch_allocations where order_item_id=p_order_item_id;
    return v_total;
  end if;
  v_remaining:=v_item.quantity;
  for v_batch in select * from public.finished_goods_batches where product_id=v_item.product_id and quantity_available>0 order by production_date,created_at,id for update
  loop
    exit when v_remaining<=0;
    v_take:=least(v_remaining,v_batch.quantity_available);
    insert into public.customer_order_batch_allocations(order_item_id,batch_id,quantity,unit_cost,cogs_amount)
    values(p_order_item_id,v_batch.id,v_take,v_batch.unit_cost,round(v_take*v_batch.unit_cost,2));
    update public.finished_goods_batches set quantity_available=quantity_available-v_take where id=v_batch.id;
    v_total:=v_total+round(v_take*v_batch.unit_cost,2);v_remaining:=v_remaining-v_take;
  end loop;
  if p_require_full and v_remaining>0 then raise exception 'Insufficient finished-goods stock for customer order item'; end if;
  return v_total;
end;
$$;

create or replace function public.apply_finished_goods_waste(p_waste_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_waste public.waste_events%rowtype;v_remaining numeric(14,3);v_take numeric(14,3);v_batch record;v_total numeric(14,2):=0;
begin
  select * into v_waste from public.waste_events where id=p_waste_id for update;
  if not found or v_waste.waste_type<>'finished_product' or v_waste.approval_status<>'approved' then return; end if;
  if exists(select 1 from public.finished_goods_waste_allocations where waste_event_id=p_waste_id) then return; end if;
  v_remaining:=v_waste.quantity;
  for v_batch in
    select * from public.finished_goods_batches
    where product_id=v_waste.product_id and quantity_available>0
      and (v_waste.production_run_id is null or production_run_id=v_waste.production_run_id)
    order by production_date,created_at,id for update
  loop
    exit when v_remaining<=0;
    v_take:=least(v_remaining,v_batch.quantity_available);
    insert into public.finished_goods_waste_allocations(waste_event_id,batch_id,quantity,unit_cost,cost_amount)
    values(p_waste_id,v_batch.id,v_take,v_batch.unit_cost,round(v_take*v_batch.unit_cost,2));
    update public.finished_goods_batches set quantity_available=quantity_available-v_take where id=v_batch.id;
    v_total:=v_total+round(v_take*v_batch.unit_cost,2);v_remaining:=v_remaining-v_take;
  end loop;
  if v_remaining>0 then raise exception 'Finished-goods waste exceeds available batch stock'; end if;
  update public.waste_events set unit_cost_snapshot=case when quantity>0 then v_total/quantity else unit_cost_snapshot end,total_cost=v_total where id=p_waste_id;
end;
$$;

create or replace function public.trg_allocate_sale_batch()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_status text;
begin
  select status into v_status from public.sales where id=new.sale_id;
  if v_status in ('completed','partially_refunded','refunded') then perform public.allocate_sale_item_to_batches(new.id,true); end if;
  return new;
end;$$;
drop trigger if exists trg_allocate_sale_batch on public.sale_items;
create trigger trg_allocate_sale_batch after insert on public.sale_items for each row execute function public.trg_allocate_sale_batch();

-- Production confirmation now creates an auditable finished-goods batch after all ingredient snapshots are posted.
create or replace function public.confirm_production_run(
  p_plan_item_id uuid,p_quantity_produced numeric,p_client_request_id uuid default null
)
returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_role public.staff_role;v_plan public.production_plan_items%rowtype;v_recipe public.recipes%rowtype;
  v_remaining numeric(14,3);v_run_id uuid:=gen_random_uuid();v_existing uuid;v_item record;
  v_required numeric(18,6);v_unit_cost numeric(14,6);v_tx_id uuid;v_batch_id uuid;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','baker') then raise exception 'Not authorized to confirm production'; end if;
  if p_client_request_id is not null then select id into v_existing from public.production_runs where client_request_id=p_client_request_id; if v_existing is not null then return v_existing; end if; end if;
  if p_quantity_produced<=0 then raise exception 'Quantity produced must be greater than zero'; end if;
  select * into v_plan from public.production_plan_items where id=p_plan_item_id for update;
  if not found then raise exception 'Production plan item not found'; end if;
  if v_plan.status in ('complete','cancelled') then raise exception 'Production plan item is not open'; end if;
  if v_role='baker' and v_plan.assigned_baker_id is distinct from auth.uid() then raise exception 'Baker may confirm only assigned production items'; end if;
  v_remaining:=v_plan.planned_qty-v_plan.produced_qty;
  if p_quantity_produced>v_remaining then raise exception 'Cannot confirm more than remaining planned quantity'; end if;
  select * into v_recipe from public.recipes where product_id=v_plan.product_id and active=true;
  if not found then raise exception 'Product has no active recipe'; end if;
  for v_item in
    select ri.raw_material_id,ri.quantity_base_unit,rm.current_stock_qty,
      case when rm.purchase_pack_base_qty>0 then rm.current_purchase_cost/rm.purchase_pack_base_qty else 0 end current_unit_cost
    from public.recipe_items ri join public.raw_materials rm on rm.id=ri.raw_material_id where ri.recipe_id=v_recipe.id for update of rm
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;
    if v_item.current_stock_qty<v_required then raise exception 'Insufficient stock for raw material %',v_item.raw_material_id; end if;
  end loop;
  insert into public.production_runs(id,plan_item_id,recipe_id,quantity_produced,confirmed_by,client_request_id)
  values(v_run_id,p_plan_item_id,v_recipe.id,p_quantity_produced,auth.uid(),p_client_request_id);
  for v_item in
    select ri.raw_material_id,ri.quantity_base_unit,
      case when rm.purchase_pack_base_qty>0 then rm.current_purchase_cost/rm.purchase_pack_base_qty else 0 end current_unit_cost
    from public.recipe_items ri join public.raw_materials rm on rm.id=ri.raw_material_id where ri.recipe_id=v_recipe.id
  loop
    v_required:=(v_item.quantity_base_unit/v_recipe.yield_qty)*p_quantity_produced;v_unit_cost:=v_item.current_unit_cost;
    insert into public.inventory_transactions(raw_material_id,tx_type,quantity_delta,unit_cost,reference_type,reference_id,created_by,notes)
    values(v_item.raw_material_id,'usage',-v_required,v_unit_cost,'production_run',v_run_id,auth.uid(),'Recipe consumption for confirmed production') returning id into v_tx_id;
    insert into public.production_consumptions(production_run_id,raw_material_id,quantity_used_base,unit_cost_snapshot,inventory_transaction_id)
    values(v_run_id,v_item.raw_material_id,v_required,v_unit_cost,v_tx_id);
  end loop;
  v_batch_id:=public.create_finished_goods_batch(v_run_id);
  update public.production_plan_items set produced_qty=produced_qty+p_quantity_produced,
    status=case when produced_qty+p_quantity_produced>=planned_qty then 'complete'::public.production_status else 'in_progress'::public.production_status end,
    updated_at=now() where id=p_plan_item_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'confirm_production','production_run',v_run_id,jsonb_build_object('plan_item_id',p_plan_item_id,'recipe_id',v_recipe.id,'quantity_produced',p_quantity_produced,'product_id',v_plan.product_id,'batch_id',v_batch_id,'client_request_id',p_client_request_id));
  return v_run_id;
end;$$;

-- Finished-product waste now consumes actual batch stock and cost.
create or replace function public.decide_waste_event(p_waste_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_before public.waste_events%rowtype;v_new public.waste_approval_status;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager may approve/reject waste'; end if;
  if p_decision='approve' then v_new:='approved'; elsif p_decision='reject' then v_new:='rejected'; else raise exception 'Decision must be approve or reject'; end if;
  select * into v_before from public.waste_events where id=p_waste_id for update;
  if not found then raise exception 'Waste event not found'; end if;
  if v_before.approval_status<>'pending' then raise exception 'Only pending waste can be decided'; end if;
  update public.waste_events set approval_status=v_new,approved_by=auth.uid(),approved_at=now(),decision_note=p_note where id=p_waste_id;
  if v_new='approved' and v_before.waste_type='raw_material' then perform public.apply_approved_raw_waste(p_waste_id); end if;
  if v_new='approved' and v_before.waste_type='finished_product' then perform public.apply_finished_goods_waste(p_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),case when v_new='approved' then 'approve_waste' else 'reject_waste' end,'waste_event',p_waste_id,jsonb_build_object('approval_status',v_before.approval_status),jsonb_build_object('approval_status',v_new,'decision_note',p_note));
end;$$;

-- Wrap the existing waste recorder so automatically approved finished-product waste also consumes batch stock.
-- The function body is replaced below with the v0.19 validation plus batch application.
create or replace function public.record_waste_event(
  p_waste_type public.waste_type,p_quantity numeric,p_reason text,p_product_id uuid default null,
  p_raw_material_id uuid default null,p_production_run_id uuid default null,p_notes text default null,p_client_request_id uuid default null
)
returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_role public.staff_role;v_unit_cost numeric(14,6);v_total numeric(14,2);v_threshold numeric(14,2);
  v_status public.waste_approval_status;v_waste_id uuid:=gen_random_uuid();v_run_product uuid;v_run_qty numeric;
  v_existing_waste numeric;v_existing uuid;
begin
  v_role:=public.current_staff_role();
  if p_client_request_id is not null then select id into v_existing from public.waste_events where client_request_id=p_client_request_id; if v_existing is not null then return v_existing; end if; end if;
  if v_role not in ('owner','manager','baker','storekeeper') then raise exception 'Not authorized to record waste'; end if;
  if p_quantity<=0 then raise exception 'Waste quantity must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Waste reason is required'; end if;
  if p_waste_type='finished_product' then
    if v_role='storekeeper' then raise exception 'Storekeeper cannot record finished-product waste'; end if;
    if p_product_id is null or p_raw_material_id is not null then raise exception 'Finished-product waste requires product only'; end if;
    if p_production_run_id is not null then
      select ppi.product_id,pr.quantity_produced into v_run_product,v_run_qty from public.production_runs pr join public.production_plan_items ppi on ppi.id=pr.plan_item_id where pr.id=p_production_run_id;
      if v_run_product is null or v_run_product<>p_product_id then raise exception 'Production run does not match product'; end if;
      select coalesce(sum(quantity),0) into v_existing_waste from public.waste_events where production_run_id=p_production_run_id and waste_type='finished_product' and approval_status<>'rejected';
      if v_existing_waste+p_quantity>v_run_qty then raise exception 'Waste quantity exceeds remaining output of linked production run'; end if;
      select unit_cost into v_unit_cost from public.finished_goods_batches where production_run_id=p_production_run_id;
      if v_unit_cost is null then v_unit_cost:=public.production_run_unit_cost(p_production_run_id); end if;
    else
      select coalesce(sum(quantity_available*unit_cost)/nullif(sum(quantity_available),0),public.current_product_unit_cost(p_product_id)) into v_unit_cost from public.finished_goods_batches where product_id=p_product_id and quantity_available>0;
    end if;
  else
    if v_role='baker' then raise exception 'Baker cannot record raw-material waste'; end if;
    if p_raw_material_id is null or p_product_id is not null then raise exception 'Raw-material waste requires raw material only'; end if;
    select case when purchase_pack_base_qty>0 then current_purchase_cost/purchase_pack_base_qty else 0 end into v_unit_cost from public.raw_materials where id=p_raw_material_id;
    if v_unit_cost is null then raise exception 'Raw material not found'; end if;
  end if;
  v_total:=round((p_quantity*v_unit_cost)::numeric,2);
  select approval_threshold into v_threshold from public.waste_settings where id=1;
  if v_role in ('owner','manager') or v_total<=coalesce(v_threshold,0) then v_status:='approved'; else v_status:='pending'; end if;
  insert into public.waste_events(id,waste_type,product_id,raw_material_id,production_run_id,quantity,reason,notes,unit_cost_snapshot,total_cost,approval_status,recorded_by,approved_by,approved_at,client_request_id)
  values(v_waste_id,p_waste_type,p_product_id,p_raw_material_id,p_production_run_id,p_quantity,trim(p_reason),p_notes,v_unit_cost,v_total,v_status,auth.uid(),case when v_status='approved' then auth.uid() end,case when v_status='approved' then now() end,p_client_request_id);
  if v_status='approved' and p_waste_type='raw_material' then perform public.apply_approved_raw_waste(v_waste_id); end if;
  if v_status='approved' and p_waste_type='finished_product' then perform public.apply_finished_goods_waste(v_waste_id); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'record_waste','waste_event',v_waste_id,jsonb_build_object('waste_type',p_waste_type,'quantity',p_quantity,'reason',p_reason,'total_cost',v_total,'approval_status',v_status,'production_run_id',p_production_run_id,'client_request_id',p_client_request_id));
  return v_waste_id;
end;$$;

create or replace view public.finished_goods_batch_summary
with (security_invoker=true)
as
select b.id,b.batch_no,b.production_run_id,b.product_id,p.name product_name,b.production_date,
       b.quantity_produced,b.quantity_available,(b.quantity_produced-b.quantity_available) quantity_issued,
       b.batch_cost,b.unit_cost,
       coalesce((select sum(a.quantity) from public.sale_batch_allocations a where a.batch_id=b.id),0) pos_qty_sold,
       coalesce((select sum(a.cogs_amount) from public.sale_batch_allocations a where a.batch_id=b.id),0) pos_cogs,
       coalesce((select sum(a.quantity*si.unit_price) from public.sale_batch_allocations a join public.sale_items si on si.id=a.sale_item_id where a.batch_id=b.id),0) pos_revenue,
       coalesce((select sum(a.quantity) from public.customer_order_batch_allocations a where a.batch_id=b.id),0) order_qty_sold,
       coalesce((select sum(a.cogs_amount) from public.customer_order_batch_allocations a where a.batch_id=b.id),0) order_cogs,
       coalesce((select sum(a.quantity*oi.unit_price) from public.customer_order_batch_allocations a join public.customer_order_items oi on oi.id=a.order_item_id where a.batch_id=b.id),0) order_revenue,
       coalesce((select sum(a.quantity) from public.finished_goods_waste_allocations a where a.batch_id=b.id),0) waste_qty,
       coalesce((select sum(a.cost_amount) from public.finished_goods_waste_allocations a where a.batch_id=b.id),0) waste_cost,
       (
         coalesce((select sum(a.quantity*si.unit_price-a.cogs_amount) from public.sale_batch_allocations a join public.sale_items si on si.id=a.sale_item_id where a.batch_id=b.id),0)
         +coalesce((select sum(a.quantity*oi.unit_price-a.cogs_amount) from public.customer_order_batch_allocations a join public.customer_order_items oi on oi.id=a.order_item_id where a.batch_id=b.id),0)
       )::numeric(14,2) realized_gross_profit
from public.finished_goods_batches b join public.products p on p.id=b.product_id;

-- =====================================================================
-- CUSTOMER CREDIT BOOK
-- =====================================================================
create table if not exists public.customer_credit_settings (
  customer_id uuid primary key references public.customers(id) on delete restrict,
  credit_enabled boolean not null default false,
  credit_limit numeric(14,2) not null default 0 check(credit_limit>=0),
  terms_days integer not null default 7 check(terms_days between 0 and 365),
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.customer_credit_ledger (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  sale_id uuid references public.sales(id) on delete restrict,
  entry_type text not null check(entry_type in ('charge','payment','adjustment')),
  amount_delta numeric(14,2) not null check(amount_delta<>0),
  payment_method public.payment_method,
  reference text,
  due_date date,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  client_request_id uuid
);
create unique index if not exists credit_ledger_sale_charge_unique on public.customer_credit_ledger(sale_id) where sale_id is not null and entry_type='charge';
create unique index if not exists credit_ledger_request_unique on public.customer_credit_ledger(client_request_id) where client_request_id is not null;
create index if not exists credit_ledger_customer_date_idx on public.customer_credit_ledger(customer_id,created_at desc);

-- Every payment/negative adjustment is allocated FIFO against individual
-- credit charges. This makes overdue balances accurate even after partial
-- repayments instead of treating an old paid invoice as overdue forever.
create table if not exists public.customer_credit_allocations (
  id uuid primary key default gen_random_uuid(),
  charge_ledger_id uuid not null references public.customer_credit_ledger(id) on delete restrict,
  credit_ledger_id uuid not null references public.customer_credit_ledger(id) on delete restrict,
  amount numeric(14,2) not null check(amount>0),
  created_at timestamptz not null default now(),
  unique(charge_ledger_id,credit_ledger_id)
);
create index if not exists credit_allocations_charge_idx on public.customer_credit_allocations(charge_ledger_id);
create index if not exists credit_allocations_credit_idx on public.customer_credit_allocations(credit_ledger_id);

alter table public.customer_credit_settings enable row level security;
alter table public.customer_credit_ledger enable row level security;
alter table public.customer_credit_allocations enable row level security;
drop policy if exists "credit staff read settings" on public.customer_credit_settings;
drop policy if exists "credit staff read ledger" on public.customer_credit_ledger;
drop policy if exists "credit staff read allocations" on public.customer_credit_allocations;
create policy "credit staff read settings" on public.customer_credit_settings for select to authenticated using(public.staff_has_permission('credit:read'));
create policy "credit staff read ledger" on public.customer_credit_ledger for select to authenticated using(public.staff_has_permission('credit:read'));
create policy "credit staff read allocations" on public.customer_credit_allocations for select to authenticated using(public.staff_has_permission('credit:read'));

create or replace view public.customer_credit_charge_outstanding
with (security_invoker=true)
as
select l.id charge_ledger_id,l.customer_id,l.sale_id,l.amount_delta charge_amount,l.due_date,l.created_at,
       coalesce(sum(a.amount),0)::numeric(14,2) allocated_amount,
       greatest(l.amount_delta-coalesce(sum(a.amount),0),0)::numeric(14,2) outstanding_amount
from public.customer_credit_ledger l
left join public.customer_credit_allocations a on a.charge_ledger_id=l.id
where l.entry_type='charge'
group by l.id,l.customer_id,l.sale_id,l.amount_delta,l.due_date,l.created_at;

create or replace view public.customer_credit_summary
with (security_invoker=true)
as
select c.id customer_id,c.full_name,c.phone,c.active,
       coalesce(s.credit_enabled,false) credit_enabled,coalesce(s.credit_limit,0) credit_limit,coalesce(s.terms_days,7) terms_days,s.notes,
       coalesce(sum(o.outstanding_amount),0)::numeric(14,2) balance_due,
       greatest(coalesce(s.credit_limit,0)-coalesce(sum(o.outstanding_amount),0),0)::numeric(14,2) available_credit,
       min(o.due_date) filter(where o.outstanding_amount>0 and o.due_date<public.business_current_date()) oldest_overdue_date,
       coalesce(sum(o.outstanding_amount) filter(where o.outstanding_amount>0 and o.due_date<public.business_current_date()),0)::numeric(14,2) overdue_net
from public.customers c
left join public.customer_credit_settings s on s.customer_id=c.id
left join public.customer_credit_charge_outstanding o on o.customer_id=c.id
group by c.id,c.full_name,c.phone,c.active,s.credit_enabled,s.credit_limit,s.terms_days,s.notes;

create or replace view public.customer_credit_ledger_detail
with (security_invoker=true)
as
select l.*,c.full_name customer_name,c.phone,s.sale_no,
       case when l.entry_type='charge' then coalesce(o.outstanding_amount,0) else null end charge_outstanding,
       sum(l.amount_delta) over(partition by l.customer_id order by l.created_at,l.id rows unbounded preceding)::numeric(14,2) running_balance
from public.customer_credit_ledger l
join public.customers c on c.id=l.customer_id
left join public.sales s on s.id=l.sale_id
left join public.customer_credit_charge_outstanding o on o.charge_ledger_id=l.id;

create or replace function public.save_customer_credit_terms(p_customer_id uuid,p_enabled boolean,p_credit_limit numeric,p_terms_days integer,p_notes text default null)
returns void language plpgsql security definer set search_path=public as $$
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only CEO / Owner or General Manager can change credit limits'; end if;
  if p_credit_limit<0 then raise exception 'Credit limit cannot be negative'; end if;
  if p_terms_days<0 or p_terms_days>365 then raise exception 'Credit terms must be between 0 and 365 days'; end if;
  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then raise exception 'Active customer not found'; end if;
  insert into public.customer_credit_settings(customer_id,credit_enabled,credit_limit,terms_days,notes,updated_by)
  values(p_customer_id,p_enabled,p_credit_limit,p_terms_days,p_notes,auth.uid())
  on conflict(customer_id) do update set credit_enabled=excluded.credit_enabled,credit_limit=excluded.credit_limit,terms_days=excluded.terms_days,notes=excluded.notes,updated_by=auth.uid(),updated_at=now();
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'save_customer_credit_terms','customer',p_customer_id,jsonb_build_object('credit_enabled',p_enabled,'credit_limit',p_credit_limit,'terms_days',p_terms_days));
end;$$;

create or replace function public.complete_credit_sale(
  p_items jsonb,p_discount numeric,p_notes text,p_client_request_id uuid,p_customer_id uuid
)
returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_sale_id uuid;v_settings public.customer_credit_settings%rowtype;v_balance numeric;v_total numeric;v_item record;
begin
  if not public.staff_has_permission('credit:manage') then raise exception 'Credit-book permission required'; end if;
  if p_customer_id is null then raise exception 'A registered customer is required for a credit sale'; end if;
  if not exists(select 1 from public.customers where id=p_customer_id and active=true) then raise exception 'Active customer not found'; end if;
  select * into v_settings from public.customer_credit_settings where customer_id=p_customer_id for update;
  if not found or not v_settings.credit_enabled then raise exception 'Customer credit is not enabled'; end if;
  select coalesce(sum(outstanding_amount),0) into v_balance from public.customer_credit_charge_outstanding where customer_id=p_customer_id;

  -- Reuse authoritative product pricing and open-shift validation by creating a held sale first.
  -- Any later exception rolls the entire transaction back.
  v_sale_id:=public.complete_sale(p_items,p_discount,'[]'::jsonb,p_notes,true,p_client_request_id);
  select total into v_total from public.sales where id=v_sale_id for update;
  if v_total<=0 then raise exception 'Credit sale total must be positive'; end if;
  if v_settings.credit_limit<=0 or greatest(v_balance,0)+v_total>v_settings.credit_limit then raise exception 'Customer credit limit would be exceeded'; end if;

  update public.sales set status='completed',held=false,customer_id=p_customer_id where id=v_sale_id;
  for v_item in select id from public.sale_items where sale_id=v_sale_id loop
    perform public.allocate_sale_item_to_batches(v_item.id,true);
  end loop;

  insert into public.customer_credit_ledger(customer_id,sale_id,entry_type,amount_delta,due_date,notes,created_by,client_request_id)
  values(p_customer_id,v_sale_id,'charge',v_total,public.business_current_date()+v_settings.terms_days,coalesce(p_notes,'Credit sale'),auth.uid(),p_client_request_id);
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'complete_credit_sale','sale',v_sale_id,jsonb_build_object('customer_id',p_customer_id,'amount',v_total,'due_date',public.business_current_date()+v_settings.terms_days));
  return v_sale_id;
end;$$;

create or replace function public.record_credit_payment(
  p_customer_id uuid,p_amount numeric,p_method public.payment_method,p_reference text default null,p_notes text default null,p_client_request_id uuid default null
)
returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_id uuid:=gen_random_uuid();v_balance numeric;v_existing uuid;v_remaining numeric;v_take numeric;v_charge record;v_settings public.customer_credit_settings%rowtype;
begin
  if not public.staff_has_permission('credit:manage') then raise exception 'Credit-book permission required'; end if;
  if p_amount<=0 then raise exception 'Payment must be greater than zero'; end if;
  if p_method in ('mtn_momo','airtel_money') and coalesce(trim(p_reference),'')='' then raise exception 'Mobile Money reference is required'; end if;
  if p_client_request_id is not null then
    select id into v_existing from public.customer_credit_ledger where client_request_id=p_client_request_id;
    if v_existing is not null then return v_existing; end if;
  end if;
  if not exists(select 1 from public.customers where id=p_customer_id) then raise exception 'Customer not found'; end if;
  select * into v_settings from public.customer_credit_settings where customer_id=p_customer_id for update;
  select coalesce(sum(outstanding_amount),0) into v_balance from public.customer_credit_charge_outstanding where customer_id=p_customer_id;
  if v_balance<=0 then raise exception 'Customer has no outstanding credit balance'; end if;
  if p_amount>v_balance then raise exception 'Payment exceeds outstanding credit balance'; end if;

  insert into public.customer_credit_ledger(id,customer_id,entry_type,amount_delta,payment_method,reference,notes,created_by,client_request_id)
  values(v_id,p_customer_id,'payment',-p_amount,p_method,nullif(trim(p_reference),''),p_notes,auth.uid(),p_client_request_id);

  v_remaining:=p_amount;
  for v_charge in
    select o.charge_ledger_id,o.outstanding_amount
    from public.customer_credit_charge_outstanding o
    where o.customer_id=p_customer_id and o.outstanding_amount>0
    order by o.due_date nulls last,o.created_at,o.charge_ledger_id
  loop
    exit when v_remaining<=0;
    v_take:=least(v_remaining,v_charge.outstanding_amount);
    insert into public.customer_credit_allocations(charge_ledger_id,credit_ledger_id,amount)
    values(v_charge.charge_ledger_id,v_id,v_take);
    v_remaining:=v_remaining-v_take;
  end loop;
  if v_remaining>0.009 then raise exception 'Unable to allocate the full credit payment'; end if;

  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'record_credit_payment','customer_credit_ledger',v_id,jsonb_build_object('customer_id',p_customer_id,'amount',p_amount,'method',p_method));
  return v_id;
end;$$;

-- Reduces only the still-unpaid portion of a credit sale. Paid amounts require
-- the normal refund process because money has already been received.
create or replace function public.adjust_unpaid_credit_sale(
  p_sale_id uuid,p_amount numeric,p_reason text
)
returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_charge public.customer_credit_ledger%rowtype;v_outstanding numeric;v_adj uuid:=gen_random_uuid();v_new_refund numeric;v_total numeric;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only CEO / Owner or General Manager can reduce an unpaid credit sale'; end if;
  if p_amount<=0 then raise exception 'Adjustment amount must be greater than zero'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Adjustment reason is required'; end if;
  select * into v_charge from public.customer_credit_ledger where sale_id=p_sale_id and entry_type='charge' for update;
  if not found then raise exception 'Credit-sale charge not found'; end if;
  select outstanding_amount into v_outstanding from public.customer_credit_charge_outstanding where charge_ledger_id=v_charge.id;
  if p_amount>coalesce(v_outstanding,0) then raise exception 'Adjustment exceeds the unpaid amount. Paid credit must be refunded separately.'; end if;

  insert into public.customer_credit_ledger(id,customer_id,sale_id,entry_type,amount_delta,notes,created_by)
  values(v_adj,v_charge.customer_id,p_sale_id,'adjustment',-p_amount,'Credit sale adjustment: '||trim(p_reason),auth.uid());
  insert into public.customer_credit_allocations(charge_ledger_id,credit_ledger_id,amount)
  values(v_charge.id,v_adj,p_amount);

  select total,coalesce(refund_total,0)+p_amount into v_total,v_new_refund from public.sales where id=p_sale_id for update;
  update public.sales
  set refund_total=v_new_refund,
      status=case when v_new_refund>=v_total then 'refunded' else 'partially_refunded' end
  where id=p_sale_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(auth.uid(),'adjust_unpaid_credit_sale','sale',p_sale_id,jsonb_build_object('amount',p_amount,'reason',trim(p_reason),'credit_adjustment_id',v_adj));
  return v_adj;
end;$$;

revoke all on function public.save_customer_credit_terms(uuid,boolean,numeric,integer,text) from public,anon;
revoke all on function public.complete_credit_sale(jsonb,numeric,text,uuid,uuid) from public,anon;
revoke all on function public.record_credit_payment(uuid,numeric,public.payment_method,text,text,uuid) from public,anon;
revoke all on function public.adjust_unpaid_credit_sale(uuid,numeric,text) from public,anon;
grant execute on function public.save_customer_credit_terms(uuid,boolean,numeric,integer,text) to authenticated;
grant execute on function public.complete_credit_sale(jsonb,numeric,text,uuid,uuid) to authenticated;
grant execute on function public.record_credit_payment(uuid,numeric,public.payment_method,text,text,uuid) to authenticated;
grant execute on function public.adjust_unpaid_credit_sale(uuid,numeric,text) to authenticated;

-- =====================================================================
-- STAFF COMPENSATION / PAYROLL
-- =====================================================================
create table if not exists public.staff_compensation_profiles (
  staff_id uuid primary key references public.profiles(id) on delete restrict,
  salary_type text not null default 'monthly' check(salary_type in ('monthly','daily','hourly')),
  basic_salary numeric(14,2) not null default 0 check(basic_salary>=0),
  default_allowances numeric(14,2) not null default 0 check(default_allowances>=0),
  default_deductions numeric(14,2) not null default 0 check(default_deductions>=0),
  effective_from date not null default current_date,
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.salary_advances (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.profiles(id) on delete restrict,
  amount numeric(14,2) not null check(amount>0),
  remaining_amount numeric(14,2) not null check(remaining_amount>=0),
  reason text not null,
  status text not null default 'open' check(status in ('open','deducted','cancelled')),
  granted_by uuid not null references public.profiles(id),
  granted_at timestamptz not null default now(),
  deducted_at timestamptz
);

create table if not exists public.payroll_runs (
  id uuid primary key default gen_random_uuid(),
  payroll_month date not null unique,
  status text not null default 'draft' check(status in ('draft','approved','partially_paid','paid','void')),
  prepared_by uuid not null references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payroll_items (
  id uuid primary key default gen_random_uuid(),
  payroll_run_id uuid not null references public.payroll_runs(id) on delete restrict,
  staff_id uuid not null references public.profiles(id) on delete restrict,
  salary_type text not null default 'monthly' check(salary_type in ('monthly','daily','hourly')),
  salary_rate numeric(14,2) not null default 0,
  work_units numeric(12,2) not null default 1,
  basic_salary numeric(14,2) not null default 0,
  allowances numeric(14,2) not null default 0,
  deductions numeric(14,2) not null default 0,
  advance_deduction numeric(14,2) not null default 0,
  gross_pay numeric(14,2) generated always as (basic_salary+allowances) stored,
  net_pay numeric(14,2) generated always as (greatest(basic_salary+allowances-deductions-advance_deduction,0)) stored,
  payment_status text not null default 'unpaid' check(payment_status in ('unpaid','paid','void')),
  payment_method public.payment_method,
  payment_reference text,
  paid_at timestamptz,
  expense_id uuid references public.expenses(id),
  notes text,
  unique(payroll_run_id,staff_id)
);

alter table public.staff_compensation_profiles enable row level security;
alter table public.salary_advances enable row level security;
alter table public.payroll_runs enable row level security;
alter table public.payroll_items enable row level security;
create policy "payroll staff read compensation" on public.staff_compensation_profiles for select to authenticated using(public.staff_has_permission('payroll:read'));
create policy "payroll staff read advances" on public.salary_advances for select to authenticated using(public.staff_has_permission('payroll:read'));
create policy "payroll staff read runs" on public.payroll_runs for select to authenticated using(public.staff_has_permission('payroll:read'));
create policy "payroll staff read items" on public.payroll_items for select to authenticated using(public.staff_has_permission('payroll:read'));

create or replace function public.save_staff_compensation(p_staff_id uuid,p_salary_type text,p_basic_salary numeric,p_allowances numeric,p_deductions numeric,p_effective_from date,p_notes text default null)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.staff_has_permission('payroll:manage') then raise exception 'Payroll permission required'; end if;
  if p_salary_type not in ('monthly','daily','hourly') then raise exception 'Invalid salary type'; end if;
  if least(p_basic_salary,p_allowances,p_deductions)<0 then raise exception 'Salary amounts cannot be negative'; end if;
  if not exists(select 1 from public.profiles where id=p_staff_id) then raise exception 'Staff profile not found'; end if;
  insert into public.staff_compensation_profiles(staff_id,salary_type,basic_salary,default_allowances,default_deductions,effective_from,notes,updated_by)
  values(p_staff_id,p_salary_type,p_basic_salary,p_allowances,p_deductions,coalesce(p_effective_from,public.business_current_date()),p_notes,auth.uid())
  on conflict(staff_id) do update set salary_type=excluded.salary_type,basic_salary=excluded.basic_salary,default_allowances=excluded.default_allowances,default_deductions=excluded.default_deductions,effective_from=excluded.effective_from,notes=excluded.notes,updated_by=auth.uid(),updated_at=now();
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'save_staff_compensation','profile',p_staff_id,jsonb_build_object('salary_type',p_salary_type,'basic_salary',p_basic_salary));
end;$$;

create or replace function public.record_salary_advance(p_staff_id uuid,p_amount numeric,p_reason text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid:=gen_random_uuid();
begin
  if not public.staff_has_permission('payroll:manage') then raise exception 'Payroll permission required'; end if;
  if p_amount<=0 or coalesce(trim(p_reason),'')='' then raise exception 'Positive amount and reason are required'; end if;
  insert into public.salary_advances(id,staff_id,amount,remaining_amount,reason,granted_by) values(v_id,p_staff_id,p_amount,p_amount,trim(p_reason),auth.uid());
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'record_salary_advance','salary_advance',v_id,jsonb_build_object('staff_id',p_staff_id,'amount',p_amount));
  return v_id;
end;$$;

create or replace function public.generate_payroll_run(p_payroll_month date)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_month date:=date_trunc('month',p_payroll_month)::date;v_run uuid;v_existing uuid;
begin
  if not public.staff_has_permission('payroll:manage') then raise exception 'Payroll permission required'; end if;
  select id into v_existing from public.payroll_runs where payroll_month=v_month;
  if v_existing is not null then return v_existing; end if;
  insert into public.payroll_runs(payroll_month,prepared_by) values(v_month,auth.uid()) returning id into v_run;
  insert into public.payroll_items(payroll_run_id,staff_id,salary_type,salary_rate,work_units,basic_salary,allowances,deductions,advance_deduction)
  select v_run,p.id,
         coalesce(c.salary_type,'monthly'),coalesce(c.basic_salary,0),
         case coalesce(c.salary_type,'monthly')
           when 'daily' then coalesce((
             select count(distinct sws.shift_date)::numeric
             from public.staff_work_shifts sws
             join public.attendance_records ar on ar.shift_id=sws.id
             where sws.staff_id=p.id
               and sws.shift_date>=v_month and sws.shift_date<(v_month+interval '1 month')::date
               and ar.clock_in_at is not null and coalesce(ar.status::text,'') not in ('absent','excused')
           ),0)
           when 'hourly' then coalesce((
             select round(sum(extract(epoch from (ar.clock_out_at-ar.clock_in_at))/3600.0)::numeric,2)
             from public.staff_work_shifts sws
             join public.attendance_records ar on ar.shift_id=sws.id
             where sws.staff_id=p.id
               and sws.shift_date>=v_month and sws.shift_date<(v_month+interval '1 month')::date
               and ar.clock_in_at is not null and ar.clock_out_at is not null
           ),0)
           else 1
         end as work_units,
         round(coalesce(c.basic_salary,0) *
           case coalesce(c.salary_type,'monthly')
             when 'daily' then coalesce((select count(distinct sws.shift_date)::numeric from public.staff_work_shifts sws join public.attendance_records ar on ar.shift_id=sws.id where sws.staff_id=p.id and sws.shift_date>=v_month and sws.shift_date<(v_month+interval '1 month')::date and ar.clock_in_at is not null and coalesce(ar.status::text,'') not in ('absent','excused')),0)
             when 'hourly' then coalesce((select round(sum(extract(epoch from (ar.clock_out_at-ar.clock_in_at))/3600.0)::numeric,2) from public.staff_work_shifts sws join public.attendance_records ar on ar.shift_id=sws.id where sws.staff_id=p.id and sws.shift_date>=v_month and sws.shift_date<(v_month+interval '1 month')::date and ar.clock_in_at is not null and ar.clock_out_at is not null),0)
             else 1
           end,2),
         coalesce(c.default_allowances,0),coalesce(c.default_deductions,0),
         coalesce((select sum(a.remaining_amount) from public.salary_advances a where a.staff_id=p.id and a.status='open'),0)
  from public.profiles p left join public.staff_compensation_profiles c on c.staff_id=p.id
  where p.active=true and p.disabled_at is null;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'generate_payroll','payroll_run',v_run,jsonb_build_object('payroll_month',v_month));
  return v_run;
end;$$;

create or replace function public.update_payroll_item(p_item_id uuid,p_allowances numeric,p_deductions numeric,p_advance_deduction numeric,p_notes text default null)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.staff_has_permission('payroll:manage') then raise exception 'Payroll permission required'; end if;
  if least(p_allowances,p_deductions,p_advance_deduction)<0 then raise exception 'Payroll adjustments cannot be negative'; end if;
  if exists(select 1 from public.payroll_items where id=p_item_id and payment_status='paid') then raise exception 'Paid payroll items cannot be edited'; end if;
  update public.payroll_items set allowances=p_allowances,deductions=p_deductions,advance_deduction=p_advance_deduction,notes=p_notes where id=p_item_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'update_payroll_item','payroll_item',p_item_id,jsonb_build_object('allowances',p_allowances,'deductions',p_deductions,'advance_deduction',p_advance_deduction));
end;$$;

create or replace function public.pay_payroll_item(p_item_id uuid,p_method public.payment_method,p_reference text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_item public.payroll_items%rowtype;v_run public.payroll_runs%rowtype;v_name text;v_exp uuid:=gen_random_uuid();v_remaining numeric;v_take numeric;v_adv record;
begin
  if not public.staff_has_permission('payroll:manage') then raise exception 'Payroll permission required'; end if;
  if p_method in ('mtn_momo','airtel_money') and coalesce(trim(p_reference),'')='' then raise exception 'Mobile Money reference is required'; end if;
  select * into v_item from public.payroll_items where id=p_item_id for update;
  if not found then raise exception 'Payroll item not found'; end if;
  if v_item.payment_status='paid' then return v_item.expense_id; end if;
  select * into v_run from public.payroll_runs where id=v_item.payroll_run_id for update;
  select full_name into v_name from public.profiles where id=v_item.staff_id;
  if v_item.net_pay>0 then
    insert into public.expenses(id,category,description,amount,payment_method,reference,created_by,client_request_id)
    values(v_exp,'Payroll','Salary - '||coalesce(v_name,'Staff')||' - '||to_char(v_run.payroll_month,'Mon YYYY'),v_item.net_pay,p_method,nullif(trim(p_reference),''),auth.uid(),gen_random_uuid());
  else
    v_exp:=null;
  end if;
  update public.payroll_items set payment_status='paid',payment_method=p_method,payment_reference=nullif(trim(p_reference),''),paid_at=now(),expense_id=v_exp where id=p_item_id;
  v_remaining:=greatest(v_item.advance_deduction,0);
  if v_remaining>0 then
    for v_adv in select id,remaining_amount from public.salary_advances where staff_id=v_item.staff_id and status='open' and remaining_amount>0 order by granted_at,id for update loop
      exit when v_remaining<=0;
      v_take:=least(v_remaining,v_adv.remaining_amount);
      update public.salary_advances
      set remaining_amount=remaining_amount-v_take,
          status=case when remaining_amount-v_take<=0 then 'deducted' else 'open' end,
          deducted_at=case when remaining_amount-v_take<=0 then now() else null end
      where id=v_adv.id;
      v_remaining:=v_remaining-v_take;
    end loop;
    if v_remaining>0 then raise exception 'Advance deduction exceeds remaining open salary advances'; end if;
  end if;
  update public.payroll_runs r set status=case when not exists(select 1 from public.payroll_items pi where pi.payroll_run_id=r.id and pi.payment_status<>'paid' and pi.id<>p_item_id) then 'paid' else 'partially_paid' end,updated_at=now() where r.id=v_item.payroll_run_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data) values(auth.uid(),'pay_salary','payroll_item',p_item_id,jsonb_build_object('staff_id',v_item.staff_id,'net_pay',v_item.net_pay,'method',p_method,'expense_id',v_exp));
  return v_exp;
end;$$;

create or replace view public.payroll_item_summary
with (security_invoker=true)
as
select pi.id,pi.payroll_run_id,pr.payroll_month,pr.status run_status,pi.staff_id,p.full_name,p.role,
       pi.salary_type,pi.salary_rate,pi.work_units,pi.basic_salary,pi.allowances,pi.deductions,pi.advance_deduction,pi.gross_pay,pi.net_pay,
       pi.payment_status,pi.payment_method,pi.payment_reference,pi.paid_at,pi.expense_id,pi.notes
from public.payroll_items pi join public.payroll_runs pr on pr.id=pi.payroll_run_id join public.profiles p on p.id=pi.staff_id
left join public.staff_compensation_profiles sc on sc.staff_id=pi.staff_id;

revoke all on function public.save_staff_compensation(uuid,text,numeric,numeric,numeric,date,text) from public,anon;
revoke all on function public.record_salary_advance(uuid,numeric,text) from public,anon;
revoke all on function public.generate_payroll_run(date) from public,anon;
revoke all on function public.update_payroll_item(uuid,numeric,numeric,numeric,text) from public,anon;
revoke all on function public.pay_payroll_item(uuid,public.payment_method,text) from public,anon;
grant execute on function public.save_staff_compensation(uuid,text,numeric,numeric,numeric,date,text) to authenticated;
grant execute on function public.record_salary_advance(uuid,numeric,text) to authenticated;
grant execute on function public.generate_payroll_run(date) to authenticated;
grant execute on function public.update_payroll_item(uuid,numeric,numeric,numeric,text) to authenticated;
grant execute on function public.pay_payroll_item(uuid,public.payment_method,text) to authenticated;

-- =====================================================================
-- PUBLIC ONLINE SHOP / CHECKOUT (NO ONLINE PAYMENT YET)
-- =====================================================================
alter table public.customer_orders
  alter column created_by drop not null,
  add column if not exists order_source text not null default 'staff' check(order_source in ('staff','public_web'));

create or replace function public.submit_public_order(
  p_full_name text,p_phone text,p_email text,p_fulfillment public.fulfillment_type,p_required_at timestamptz,
  p_delivery_address text,p_notes text,p_items jsonb,p_client_request_id uuid default null
)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_customer uuid;v_order uuid:=gen_random_uuid();v_order_no text;v_item jsonb;v_product record;v_qty numeric;v_existing uuid;
begin
  if coalesce(trim(p_full_name),'')='' or coalesce(trim(p_phone),'')='' then raise exception 'Name and phone are required'; end if;
  if p_required_at<=now() then raise exception 'Required date/time must be in the future'; end if;
  if p_fulfillment='delivery' and coalesce(trim(p_delivery_address),'')='' then raise exception 'Delivery address is required'; end if;
  if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 or jsonb_array_length(p_items)>20 then raise exception 'Order must contain 1 to 20 products'; end if;
  if p_client_request_id is not null then select id into v_existing from public.customer_orders where client_request_id=p_client_request_id; if v_existing is not null then return jsonb_build_object('order_id',v_existing,'order_no',(select order_no from public.customer_orders where id=v_existing),'duplicate',true); end if; end if;

  select id into v_customer from public.customers where phone=trim(p_phone) limit 1;
  if v_customer is null then
    insert into public.customers(full_name,phone,email,address,active,created_by)
    values(trim(p_full_name),trim(p_phone),nullif(trim(p_email),''),case when p_fulfillment='delivery' then nullif(trim(p_delivery_address),'') end,true,null)
    returning id into v_customer;
  else
    update public.customers set full_name=coalesce(nullif(trim(p_full_name),''),full_name),email=coalesce(nullif(trim(p_email),''),email),updated_at=now() where id=v_customer;
  end if;

  v_order_no:=public.next_customer_order_no();
  insert into public.customer_orders(id,order_no,customer_id,status,fulfillment,required_at,delivery_address,notes,created_by,client_request_id,order_source)
  values(v_order,v_order_no,v_customer,'pending',p_fulfillment,p_required_at,case when p_fulfillment='delivery' then nullif(trim(p_delivery_address),'') end,nullif(trim(p_notes),''),null,p_client_request_id,'public_web');

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty:=coalesce((v_item->>'quantity')::numeric,0);
    if v_qty<=0 or v_qty>100 then raise exception 'Invalid order quantity'; end if;
    select id,name,selling_price into v_product from public.products where id=(v_item->>'product_id')::uuid and status='active';
    if v_product.id is null then raise exception 'One of the selected products is unavailable'; end if;
    insert into public.customer_order_items(order_id,product_id,description,quantity,unit_price,line_total)
    values(v_order,v_product.id,v_product.name,v_qty,v_product.selling_price,round(v_qty*v_product.selling_price,2));
  end loop;
  perform public.refresh_customer_order_total(v_order);
  insert into public.audit_logs(actor_id,action,entity,entity_id,after_data)
  values(null,'public_online_order','customer_order',v_order,jsonb_build_object('order_no',v_order_no,'customer_id',v_customer,'source','public_web'));
  return jsonb_build_object('order_id',v_order,'order_no',v_order_no,'total',(select total_amount from public.customer_orders where id=v_order),'duplicate',false);
end;$$;
revoke all on function public.submit_public_order(text,text,text,public.fulfillment_type,timestamptz,text,text,jsonb,uuid) from public;
grant execute on function public.submit_public_order(text,text,text,public.fulfillment_type,timestamptz,text,text,jsonb,uuid) to anon,authenticated;

-- When a customer order is completed, finished-goods batches are consumed once.
create or replace function public.update_customer_order_status(p_order_id uuid,p_status public.customer_order_status)
returns void language plpgsql security definer set search_path=public as $$
declare v_before public.customer_orders%rowtype;v_role public.staff_role;v_item record;
begin
  v_role:=public.current_staff_role();
  if v_role not in ('owner','manager','cashier','baker') then raise exception 'Not authorized'; end if;
  select * into v_before from public.customer_orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_role='cashier' and p_status='in_production' then raise exception 'Sales Team cannot move order into production'; end if;
  if v_role='baker' and p_status not in ('in_production','ready') then raise exception 'Head Baker may only update production/ready status'; end if;
  if p_status='completed' and v_before.status<>'completed' then
    for v_item in select id from public.customer_order_items where order_id=p_order_id and product_id is not null loop perform public.allocate_customer_order_item_to_batches(v_item.id,true); end loop;
  end if;
  update public.customer_orders set status=p_status,completed_at=case when p_status='completed' then coalesce(completed_at,now()) else completed_at end,cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,updated_at=now() where id=p_order_id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,before_data,after_data)
  values(auth.uid(),'update_customer_order_status','customer_order',p_order_id,jsonb_build_object('status',v_before.status),jsonb_build_object('status',p_status));
end;$$;

-- =====================================================================
-- REPORT / CLOSING CORRECTIONS FOR VOIDED EXPENSES + CREDIT RECEIPTS
-- =====================================================================
alter table public.daily_closings
  add column if not exists cash_credit_receipts numeric(14,2) not null default 0,
  add column if not exists mtn_credit_receipts numeric(14,2) not null default 0,
  add column if not exists airtel_credit_receipts numeric(14,2) not null default 0;

create or replace view public.expense_live_summary
with (security_invoker=true)
as
select e.id,public.business_date(e.created_at) business_date,e.category,e.description,e.amount,e.payment_method,e.reference,e.shift_id,
       p.full_name recorded_by_name,e.created_by,e.created_at,e.voided_at,e.voided_by,e.void_reason
from public.expenses e left join public.profiles p on p.id=e.created_by;

create or replace function public.owner_dashboard_summary(p_period text default 'day')
returns table(period_start timestamptz,sales numeric,cash_sales numeric,mtn_momo_sales numeric,airtel_money_sales numeric,gross_profit numeric,expenses numeric,estimated_operating_profit numeric,transaction_count bigint,average_sale numeric)
language plpgsql security definer set search_path=public as $$
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Not authorized'; end if;
  return query with bounds as (select public.period_start(p_period) start_at),
  sales_summary as (select coalesce(sum(s.total-coalesce(s.refund_total,0)),0)::numeric(14,2) sales,count(*)::bigint transaction_count from public.sales s,bounds b where s.created_at>=b.start_at and s.status in ('completed','partially_refunded','refunded')),
  payment_summary as (
    select (coalesce(sum(case when p.method='cash' then p.amount else 0 end),0)-coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='cash' and sr.refunded_at>=b.start_at),0))::numeric(14,2) cash_sales,
           (coalesce(sum(case when p.method='mtn_momo' then p.amount else 0 end),0)-coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='mtn_momo' and sr.refunded_at>=b.start_at),0))::numeric(14,2) mtn_momo_sales,
           (coalesce(sum(case when p.method='airtel_money' then p.amount else 0 end),0)-coalesce((select sum(sr.amount) from public.sale_refunds sr,bounds b where sr.method='airtel_money' and sr.refunded_at>=b.start_at),0))::numeric(14,2) airtel_money_sales
    from public.payments p,bounds b where p.created_at>=b.start_at and p.status='completed'),
  profit_summary as (select coalesce(sum(gross_profit_amount),0)::numeric(14,2) gross_profit from public.sale_profit_lines spl,bounds b where spl.created_at>=b.start_at),
  expense_summary as (select coalesce(sum(amount),0)::numeric(14,2) expenses from public.expenses e,bounds b where e.created_at>=b.start_at and e.voided_at is null)
  select b.start_at,ss.sales,ps.cash_sales,ps.mtn_momo_sales,ps.airtel_money_sales,prs.gross_profit,es.expenses,(prs.gross_profit-es.expenses)::numeric(14,2),ss.transaction_count,
         case when ss.transaction_count>0 then round(ss.sales/ss.transaction_count,2) else 0 end::numeric(14,2)
  from bounds b cross join sales_summary ss cross join payment_summary ps cross join profit_summary prs cross join expense_summary es;
end;$$;

create or replace function public.management_report_v2(p_period text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_start timestamptz;v_end timestamptz:=now();v_days integer;v_summary jsonb;v_products jsonb;v_payments jsonb;v_expenses jsonb;
begin
  if not public.staff_has_permission('reports:view') then raise exception 'Reports permission required'; end if;
  if p_period='week' then v_days:=7; elsif p_period='month' then v_days:=30; else raise exception 'Period must be week or month'; end if;
  v_start:=now()-(v_days||' days')::interval;
  select jsonb_build_object(
    'sales',coalesce(sum(s.total-coalesce(s.refund_total,0)),0),
    'cogs',coalesce((select sum(cogs_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'gross_profit',coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0),
    'expenses',coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end and e.voided_at is null),0),
    'operating_profit',coalesce((select sum(gross_profit_amount) from public.sale_profit_lines spl where spl.created_at>=v_start and spl.created_at<v_end),0)-coalesce((select sum(amount) from public.expenses e where e.created_at>=v_start and e.created_at<v_end and e.voided_at is null),0),
    'purchases',coalesce((select sum(total_amount) from public.purchases p where p.created_at>=v_start and p.created_at<v_end and p.status<>'cancelled'),0),
    'waste_cost',coalesce((select sum(total_cost) from public.waste_events w where w.recorded_at>=v_start and w.recorded_at<v_end and w.approval_status='approved'),0),
    'transactions',count(*) filter(where s.status in ('completed','partially_refunded','refunded')),
    'customer_order_value',coalesce((select sum(total_amount) from public.customer_orders co where co.created_at>=v_start and co.created_at<v_end and co.status<>'cancelled'),0),
    'customer_order_outstanding',coalesce((select sum(balance_due) from public.customer_order_summary where status<>'cancelled'),0),
    'customer_credit_outstanding',coalesce((select sum(greatest(balance_due,0)) from public.customer_credit_summary),0),
    'supplier_outstanding',coalesce((select sum(outstanding_balance) from public.supplier_account_summary),0),
    'supplier_overdue',coalesce((select sum(overdue_balance) from public.supplier_account_summary),0),
    'production_planned',coalesce((select sum(planned_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0),
    'production_produced',coalesce((select sum(produced_qty) from public.production_plan_items ppi where ppi.business_date>=public.business_current_date()-v_days and ppi.status<>'cancelled'),0)
  ) into v_summary from public.sales s where s.created_at>=v_start and s.created_at<v_end;
  select coalesce(jsonb_agg(x order by x.sales_amount desc),'[]'::jsonb) into v_products from (select product_id,product_name,sum(quantity) units,sum(sales_amount) sales_amount,sum(gross_profit_amount) gross_profit from public.sale_profit_lines where created_at>=v_start and created_at<v_end group by product_id,product_name order by sales_amount desc limit 10)x;
  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb) into v_payments from (select method::text method,sum(amount) amount from public.payments where created_at>=v_start and created_at<v_end and status='completed' group by method)x;
  select coalesce(jsonb_agg(x order by x.amount desc),'[]'::jsonb) into v_expenses from (select category,sum(amount) amount from public.expenses where created_at>=v_start and created_at<v_end and voided_at is null group by category)x;
  return jsonb_build_object('summary',v_summary,'products',v_products,'payments',v_payments,'expenses',v_expenses);
end;$$;

create or replace function public.management_report(p_start_date date,p_end_date date)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_sales numeric(14,2);v_cogs numeric(14,2);v_gross numeric(14,2);v_expenses numeric(14,2);v_purchases numeric(14,2);v_transactions bigint;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Not authorized'; end if;
  if p_end_date<p_start_date then raise exception 'Invalid date range'; end if;
  select coalesce(sum(sales_amount),0),coalesce(sum(cogs_amount),0),coalesce(sum(gross_profit_amount),0) into v_sales,v_cogs,v_gross from public.sale_profit_lines where created_at>=p_start_date and created_at<(p_end_date+1);
  select coalesce(sum(amount),0) into v_expenses from public.expenses where created_at>=p_start_date and created_at<(p_end_date+1) and voided_at is null;
  select coalesce(sum(total_amount),0) into v_purchases from public.purchases where purchase_date between p_start_date and p_end_date and status<>'cancelled';
  select count(*) into v_transactions from public.sales where created_at>=p_start_date and created_at<(p_end_date+1) and status in ('completed','partially_refunded');
  return jsonb_build_object('start_date',p_start_date,'end_date',p_end_date,'sales',v_sales,'cogs',v_cogs,'gross_profit',v_gross,'expenses',v_expenses,'estimated_operating_profit',v_gross-v_expenses,'purchases',v_purchases,'transactions',v_transactions);
end;$$;

create or replace function public.daily_closing_snapshot(p_business_date date)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_opening numeric(14,2);v_pos_cash numeric(14,2);v_pos_mtn numeric(14,2);v_pos_airtel numeric(14,2);
  v_cash_refunds numeric(14,2);v_mtn_refunds numeric(14,2);v_airtel_refunds numeric(14,2);
  v_order_cash numeric(14,2);v_order_mtn numeric(14,2);v_order_airtel numeric(14,2);
  v_order_refund_cash numeric(14,2);v_order_refund_mtn numeric(14,2);v_order_refund_airtel numeric(14,2);
  v_credit_cash numeric(14,2);v_credit_mtn numeric(14,2);v_credit_airtel numeric(14,2);
  v_supplier_cash numeric(14,2);v_supplier_mtn numeric(14,2);v_supplier_airtel numeric(14,2);
  v_cash_in numeric(14,2);v_cash_out numeric(14,2);v_cash_exp numeric(14,2);v_momo_exp numeric(14,2);v_tx_count integer;v_pos_sales numeric(14,2);
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager can prepare daily closing'; end if;
  select coalesce(sum(opening_float),0) into v_opening from public.cashier_shifts where public.business_date(opened_at)=p_business_date;
  select coalesce(sum(case when method='cash' then amount else 0 end),0),coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),coalesce(sum(case when method='airtel_money' then amount else 0 end),0) into v_pos_cash,v_pos_mtn,v_pos_airtel from public.payments where status='completed' and public.business_date(created_at)=p_business_date;
  select coalesce(sum(case when method='cash' then amount else 0 end),0),coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),coalesce(sum(case when method='airtel_money' then amount else 0 end),0) into v_cash_refunds,v_mtn_refunds,v_airtel_refunds from public.sale_refunds where public.business_date(refunded_at)=p_business_date;
  select coalesce(sum(case when method='cash' then amount else 0 end),0),coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),coalesce(sum(case when method='airtel_money' then amount else 0 end),0) into v_order_cash,v_order_mtn,v_order_airtel from public.customer_order_payments where payment_status='completed' and public.business_date(paid_at)=p_business_date;
  select coalesce(sum(case when method='cash' then amount else 0 end),0),coalesce(sum(case when method='mtn_momo' then amount else 0 end),0),coalesce(sum(case when method='airtel_money' then amount else 0 end),0) into v_order_refund_cash,v_order_refund_mtn,v_order_refund_airtel from public.customer_order_refunds where public.business_date(refunded_at)=p_business_date;
  select coalesce(sum(case when payment_method='cash' then -amount_delta else 0 end),0),coalesce(sum(case when payment_method='mtn_momo' then -amount_delta else 0 end),0),coalesce(sum(case when payment_method='airtel_money' then -amount_delta else 0 end),0) into v_credit_cash,v_credit_mtn,v_credit_airtel from public.customer_credit_ledger where entry_type='payment' and public.business_date(created_at)=p_business_date;
  select coalesce(sum(case when lower(method)='cash' then amount else 0 end),0),coalesce(sum(case when lower(method)='mtn_momo' then amount else 0 end),0),coalesce(sum(case when lower(method)='airtel_money' then amount else 0 end),0) into v_supplier_cash,v_supplier_mtn,v_supplier_airtel from public.purchase_payments where public.business_date(paid_at)=p_business_date;
  select coalesce(sum(case when movement_type='cash_in' then amount else 0 end),0),coalesce(sum(case when movement_type='cash_out' then amount else 0 end),0) into v_cash_in,v_cash_out from public.cash_movements where public.business_date(created_at)=p_business_date;
  select coalesce(sum(case when payment_method='cash' then amount else 0 end),0),coalesce(sum(case when payment_method in ('mtn_momo','airtel_money') then amount else 0 end),0) into v_cash_exp,v_momo_exp from public.expenses where public.business_date(created_at)=p_business_date and voided_at is null;
  select count(*) filter(where status in ('completed','partially_refunded','refunded')),coalesce(sum(case when status in ('completed','partially_refunded','refunded') then total-coalesce(refund_total,0) else 0 end),0) into v_tx_count,v_pos_sales from public.sales where public.business_date(created_at)=p_business_date;
  return jsonb_build_object('business_date',p_business_date,'opening_float',v_opening,'cash_sales',v_pos_cash-v_cash_refunds,'mtn_momo_sales',v_pos_mtn-v_mtn_refunds,'airtel_money_sales',v_pos_airtel-v_airtel_refunds,
    'cash_order_receipts',v_order_cash-v_order_refund_cash,'mtn_order_receipts',v_order_mtn-v_order_refund_mtn,'airtel_order_receipts',v_order_airtel-v_order_refund_airtel,
    'cash_credit_receipts',v_credit_cash,'mtn_credit_receipts',v_credit_mtn,'airtel_credit_receipts',v_credit_airtel,
    'cash_supplier_payments',v_supplier_cash,'mtn_supplier_payments',v_supplier_mtn,'airtel_supplier_payments',v_supplier_airtel,'cash_in',v_cash_in,'cash_out',v_cash_out,'cash_expenses',v_cash_exp,'momo_expenses',v_momo_exp,
    'expected_cash',v_opening+(v_pos_cash-v_cash_refunds)+(v_order_cash-v_order_refund_cash)+v_credit_cash+v_cash_in-v_cash_out-v_cash_exp-v_supplier_cash,
    'transaction_count',v_tx_count,'total_sales',v_pos_sales,'customer_order_receipts',(v_order_cash+v_order_mtn+v_order_airtel)-(v_order_refund_cash+v_order_refund_mtn+v_order_refund_airtel),'credit_receipts',v_credit_cash+v_credit_mtn+v_credit_airtel);
end;$$;

create or replace function public.calculate_daily_closing(p_business_date date)
returns public.daily_closings language plpgsql security definer set search_path=public as $$
declare v_s jsonb;v_result public.daily_closings;
begin
  if public.current_staff_role() not in ('owner','manager') then raise exception 'Only owner or manager can prepare daily closing'; end if;
  v_s:=public.daily_closing_snapshot(p_business_date);
  insert into public.daily_closings(business_date,opening_float,cash_sales,mtn_momo_sales,airtel_money_sales,cash_order_receipts,mtn_order_receipts,airtel_order_receipts,cash_credit_receipts,mtn_credit_receipts,airtel_credit_receipts,cash_supplier_payments,mtn_supplier_payments,airtel_supplier_payments,cash_in,cash_out,cash_expenses,momo_expenses,expected_cash,transaction_count,prepared_by)
  values(p_business_date,(v_s->>'opening_float')::numeric,(v_s->>'cash_sales')::numeric,(v_s->>'mtn_momo_sales')::numeric,(v_s->>'airtel_money_sales')::numeric,(v_s->>'cash_order_receipts')::numeric,(v_s->>'mtn_order_receipts')::numeric,(v_s->>'airtel_order_receipts')::numeric,(v_s->>'cash_credit_receipts')::numeric,(v_s->>'mtn_credit_receipts')::numeric,(v_s->>'airtel_credit_receipts')::numeric,(v_s->>'cash_supplier_payments')::numeric,(v_s->>'mtn_supplier_payments')::numeric,(v_s->>'airtel_supplier_payments')::numeric,(v_s->>'cash_in')::numeric,(v_s->>'cash_out')::numeric,(v_s->>'cash_expenses')::numeric,(v_s->>'momo_expenses')::numeric,(v_s->>'expected_cash')::numeric,(v_s->>'transaction_count')::integer,auth.uid())
  on conflict(business_date) do update set opening_float=excluded.opening_float,cash_sales=excluded.cash_sales,mtn_momo_sales=excluded.mtn_momo_sales,airtel_money_sales=excluded.airtel_money_sales,cash_order_receipts=excluded.cash_order_receipts,mtn_order_receipts=excluded.mtn_order_receipts,airtel_order_receipts=excluded.airtel_order_receipts,cash_credit_receipts=excluded.cash_credit_receipts,mtn_credit_receipts=excluded.mtn_credit_receipts,airtel_credit_receipts=excluded.airtel_credit_receipts,cash_supplier_payments=excluded.cash_supplier_payments,mtn_supplier_payments=excluded.mtn_supplier_payments,airtel_supplier_payments=excluded.airtel_supplier_payments,cash_in=excluded.cash_in,cash_out=excluded.cash_out,cash_expenses=excluded.cash_expenses,momo_expenses=excluded.momo_expenses,expected_cash=excluded.expected_cash,transaction_count=excluded.transaction_count,prepared_by=excluded.prepared_by,updated_at=now()
  returning * into v_result;
  return v_result;
end;$$;

-- =====================================================================
-- BACKFILL EXISTING PRODUCTION INTO BATCHES, THEN HISTORICAL ALLOCATIONS
-- =====================================================================
do $$
declare r record;
begin
  for r in select id from public.production_runs order by confirmed_at loop
    begin perform public.create_finished_goods_batch(r.id); exception when others then null; end;
  end loop;
  for r in select id from public.waste_events where waste_type='finished_product' and approval_status='approved' order by recorded_at loop
    begin perform public.apply_finished_goods_waste(r.id); exception when others then null; end;
  end loop;
  for r in select si.id from public.sale_items si join public.sales s on s.id=si.sale_id where s.status in ('completed','partially_refunded','refunded') order by s.created_at,si.id loop
    begin perform public.allocate_sale_item_to_batches(r.id,false); exception when others then null; end;
  end loop;
  for r in select oi.id from public.customer_order_items oi join public.customer_orders co on co.id=oi.order_id where co.status='completed' and oi.product_id is not null order by co.completed_at,oi.id loop
    begin perform public.allocate_customer_order_item_to_batches(r.id,false); exception when others then null; end;
  end loop;
end;$$;

-- Internal helpers should not be direct authenticated endpoints.
revoke execute on function public.create_finished_goods_batch(uuid) from authenticated;
revoke execute on function public.allocate_sale_item_to_batches(uuid,boolean) from authenticated;
revoke execute on function public.allocate_customer_order_item_to_batches(uuid,boolean) from authenticated;
revoke execute on function public.apply_finished_goods_waste(uuid) from authenticated;
revoke execute on function public.trg_allocate_sale_batch() from authenticated;

update public.system_release_state
set app_version='0.37.0',latest_migration=36,release_stage='usability_data_management_core_business',updated_at=now()
where id=1;
